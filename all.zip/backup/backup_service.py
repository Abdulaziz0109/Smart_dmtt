"""
SmartDMTT — Avtomatik DB backup tizimi
Har kuni soat 02:00 da ishga tushadi
"""
import os
import shutil
import asyncio
import logging
from datetime import datetime, timedelta
from pathlib import Path

logger = logging.getLogger(__name__)

# ─── SOZLAMALAR ──────────────────────────────────────────────
DB_PATH = "data/database.sqlite"
BACKUP_DIR = "data/backups"
MAX_BACKUPS = 30        # 30 kunlik backup saqlanadi
MAX_BACKUPS_WEEKLY = 12 # 12 haftalik saqlanadi

# ─── BACKUP YARATISH ─────────────────────────────────────────
async def create_backup():
    """Kunlik backup yaratish"""
    try:
        backup_dir = Path(BACKUP_DIR)
        backup_dir.mkdir(parents=True, exist_ok=True)

        now = datetime.now()
        filename = f"smartdmtt_{now.strftime('%Y%m%d_%H%M%S')}.sqlite"
        backup_path = backup_dir / filename

        # DB faylni nusxa olish
        shutil.copy2(DB_PATH, backup_path)
        size_mb = backup_path.stat().st_size / 1024 / 1024

        logger.info(
            f"✅ Backup yaratildi: {filename} "
            f"({size_mb:.2f} MB)"
        )

        # Eski backuplarni tozalash
        await cleanup_old_backups()

        return str(backup_path)

    except Exception as e:
        logger.error(f"❌ Backup xatosi: {e}")
        return None


async def cleanup_old_backups():
    """Eski backuplarni o'chirish"""
    backup_dir = Path(BACKUP_DIR)
    if not backup_dir.exists():
        return

    # Barcha backuplarni sanaga qarab tartiblash
    backups = sorted(
        backup_dir.glob("smartdmtt_*.sqlite"),
        key=lambda f: f.stat().st_mtime,
        reverse=True
    )

    # Kunlik: eng oxirgi 30 tani saqlash
    daily = [b for b in backups if "weekly" not in b.name]
    for old in daily[MAX_BACKUPS:]:
        old.unlink()
        logger.info(f"🗑 Eski backup o'chirildi: {old.name}")

    # Haftalik: dushanba kunlari yaratilgan backup
    weekly = [b for b in backups if "weekly" in b.name]
    for old in weekly[MAX_BACKUPS_WEEKLY:]:
        old.unlink()
        logger.info(f"🗑 Eski haftalik backup o'chirildi: {old.name}")


async def create_weekly_backup():
    """Haftalik backup (dushanba)"""
    try:
        backup_dir = Path(BACKUP_DIR)
        backup_dir.mkdir(parents=True, exist_ok=True)

        now = datetime.now()
        filename = f"smartdmtt_weekly_{now.strftime('%Y_W%W')}.sqlite"
        backup_path = backup_dir / filename

        shutil.copy2(DB_PATH, backup_path)
        size_mb = backup_path.stat().st_size / 1024 / 1024

        logger.info(
            f"✅ Haftalik backup: {filename} "
            f"({size_mb:.2f} MB)"
        )
        return str(backup_path)

    except Exception as e:
        logger.error(f"❌ Haftalik backup xatosi: {e}")
        return None


def get_backup_stats():
    """Backup holati statistikasi"""
    backup_dir = Path(BACKUP_DIR)
    if not backup_dir.exists():
        return {"count": 0, "total_mb": 0, "latest": None}

    backups = sorted(
        backup_dir.glob("smartdmtt_*.sqlite"),
        key=lambda f: f.stat().st_mtime,
        reverse=True
    )

    total_size = sum(b.stat().st_size for b in backups)
    latest = backups[0].name if backups else None

    return {
        "count": len(backups),
        "total_mb": round(total_size / 1024 / 1024, 2),
        "latest": latest,
        "oldest": backups[-1].name if backups else None,
    }
