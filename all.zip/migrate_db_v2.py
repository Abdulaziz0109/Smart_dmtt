import sqlite3
import os

db_path = r'C:\Users\User\Documents\all\data\database.sqlite'

if not os.path.exists(db_path):
    print(f"Database not found at {db_path}")
    exit(1)

try:
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    # Check if column exists
    cursor.execute("PRAGMA table_info(users)")
    columns = [row[1] for row in cursor.fetchall()]
    
    if "kindergarten_id" not in columns:
        cursor.execute("ALTER TABLE users ADD COLUMN kindergarten_id INTEGER;")
        conn.commit()
        print("Migration successful: Added kindergarten_id to users table.")
    else:
        print("Column kindergarten_id already exists.")
        
except sqlite3.OperationalError as e:
    print(f"SQLite Error: {e}")
except Exception as e:
    print(f"Error: {e}")
finally:
    if 'conn' in locals():
        conn.close()
