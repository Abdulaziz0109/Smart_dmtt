#!/bin/bash
# ═══════════════════════════════════════════
# SmartDMTT — Boshqaruv skripti
# Ishlatish:
#   ./run.sh start    — Ishga tushirish
#   ./run.sh stop     — To'xtatish
#   ./run.sh restart  — Qayta ishga tushirish
#   ./run.sh status   — Holat ko'rish
#   ./run.sh logs     — Loglarni ko'rish
# ═══════════════════════════════════════════

# ─── RANGLAR ────────────────────────────────
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
BOLD='\033[1m'
NC='\033[0m' # No Color

# ─── SOZLAMALAR ─────────────────────────────
PROJECT_DIR="$(cd "$(dirname "$0")" && pwd)"
BACKEND_DIR="$PROJECT_DIR/backend"
FRONTEND_DIR="$PROJECT_DIR/frontend"
LOG_DIR="$PROJECT_DIR/logs"
PID_DIR="$PROJECT_DIR/.pids"

BACKEND_PORT=8000
FRONTEND_PORT=5173

# PID fayllar
BOT_PID="$PID_DIR/bot.pid"
BACKEND_PID="$PID_DIR/backend.pid"
FRONTEND_PID="$PID_DIR/frontend.pid"
NGROK_PID="$PID_DIR/ngrok.pid"

# ─── YORDAMCHI FUNKSIYALAR ──────────────────
print_header() {
    echo ""
    echo -e "${CYAN}${BOLD}╔═══════════════════════════════════╗${NC}"
    echo -e "${CYAN}${BOLD}║        SmartDMTT Manager          ║${NC}"
    echo -e "${CYAN}${BOLD}╚═══════════════════════════════════╝${NC}"
    echo ""
}

print_ok()   { echo -e "  ${GREEN}✅ $1${NC}"; }
print_err()  { echo -e "  ${RED}❌ $1${NC}"; }
print_warn() { echo -e "  ${YELLOW}⚠️  $1${NC}"; }
print_info() { echo -e "  ${BLUE}ℹ️  $1${NC}"; }

mkdir -p "$LOG_DIR" "$PID_DIR"

# ─── ISHGA TUSHIRISH ────────────────────────
start_backend() {
    print_info "Backend ishga tushmoqda..."

    if [ -f "$BACKEND_PID" ] && kill -0 $(cat "$BACKEND_PID") 2>/dev/null; then
        print_warn "Backend allaqachon ishlaydi (PID: $(cat $BACKEND_PID))"
        return
    fi

    cd "$BACKEND_DIR"

    # Virtual environment
    if [ -d "venv" ]; then
        source venv/bin/activate
    fi

    nohup uvicorn app.api.main:app \
        --host 0.0.0.0 \
        --port $BACKEND_PORT \
        --reload \
        > "$LOG_DIR/backend.log" 2>&1 &

    echo $! > "$BACKEND_PID"
    sleep 2

    if kill -0 $(cat "$BACKEND_PID") 2>/dev/null; then
        print_ok "Backend ishga tushdi — http://localhost:$BACKEND_PORT"
    else
        print_err "Backend ishga tushmadi! Log: logs/backend.log"
    fi
}

start_bot() {
    print_info "Bot ishga tushmoqda..."

    if [ -f "$BOT_PID" ] && kill -0 $(cat "$BOT_PID") 2>/dev/null; then
        print_warn "Bot allaqachon ishlaydi (PID: $(cat $BOT_PID))"
        return
    fi

    cd "$BACKEND_DIR"

    if [ -d "venv" ]; then
        source venv/bin/activate
    fi

    nohup python -m app.bot.main \
        > "$LOG_DIR/bot.log" 2>&1 &

    echo $! > "$BOT_PID"
    sleep 2

    if kill -0 $(cat "$BOT_PID") 2>/dev/null; then
        print_ok "Bot ishga tushdi"
    else
        print_err "Bot ishga tushmadi! Log: logs/bot.log"
    fi
}

start_frontend() {
    print_info "Frontend ishga tushmoqda..."

    if [ -f "$FRONTEND_PID" ] && kill -0 $(cat "$FRONTEND_PID") 2>/dev/null; then
        print_warn "Frontend allaqachon ishlaydi"
        return
    fi

    cd "$FRONTEND_DIR"

    nohup npm run dev \
        > "$LOG_DIR/frontend.log" 2>&1 &

    echo $! > "$FRONTEND_PID"
    sleep 3

    if kill -0 $(cat "$FRONTEND_PID") 2>/dev/null; then
        print_ok "Frontend ishga tushdi — http://localhost:$FRONTEND_PORT"
    else
        print_err "Frontend ishga tushmadi! Log: logs/frontend.log"
    fi
}

start_ngrok() {
    if ! command -v ngrok &> /dev/null; then
        print_warn "ngrok o'rnatilmagan, o'tkazib yuborildi"
        return
    fi

    print_info "ngrok ishga tushmoqda..."

    if [ -f "$NGROK_PID" ] && kill -0 $(cat "$NGROK_PID") 2>/dev/null; then
        print_warn "ngrok allaqachon ishlaydi"
        return
    fi

    nohup ngrok http $BACKEND_PORT \
        > "$LOG_DIR/ngrok.log" 2>&1 &

    echo $! > "$NGROK_PID"
    sleep 3

    # ngrok URL ni olish
    NGROK_URL=$(curl -s http://localhost:4040/api/tunnels 2>/dev/null | \
        python3 -c "import sys,json; d=json.load(sys.stdin); print(d['tunnels'][0]['public_url'])" 2>/dev/null)

    if [ -n "$NGROK_URL" ]; then
        print_ok "ngrok: $NGROK_URL"
        # .env ga yozish
        if [ -f "$BACKEND_DIR/.env" ]; then
            sed -i "s|WEBHOOK_URL=.*|WEBHOOK_URL=$NGROK_URL|g" "$BACKEND_DIR/.env" 2>/dev/null
            print_info ".env yangilandi"
        fi
    else
        print_warn "ngrok URL aniqlanmadi — http://localhost:4040 da tekshiring"
    fi
}

# ─── TO'XTATISH ─────────────────────────────
stop_service() {
    local name=$1
    local pid_file=$2

    if [ -f "$pid_file" ]; then
        local pid=$(cat "$pid_file")
        if kill -0 "$pid" 2>/dev/null; then
            kill "$pid" 2>/dev/null
            sleep 1
            # Hali ishlaса — majburiy to'xtatish
            kill -9 "$pid" 2>/dev/null
            print_ok "$name to'xtatildi"
        else
            print_warn "$name allaqachon to'xtagan"
        fi
        rm -f "$pid_file"
    else
        print_warn "$name ishlamayapti"
    fi
}

# ─── HOLAT ──────────────────────────────────
check_status() {
    echo -e "\n${BOLD}  Servislar holati:${NC}\n"

    check_service() {
        local name=$1
        local pid_file=$2
        local url=$3

        if [ -f "$pid_file" ] && kill -0 $(cat "$pid_file") 2>/dev/null; then
            echo -e "  ${GREEN}●${NC} ${BOLD}$name${NC} — ishlaydi (PID: $(cat $pid_file)) $url"
        else
            echo -e "  ${RED}●${NC} ${BOLD}$name${NC} — to'xtagan"
        fi
    }

    check_service "Backend   " "$BACKEND_PID"  "→ http://localhost:$BACKEND_PORT"
    check_service "Bot       " "$BOT_PID"       ""
    check_service "Frontend  " "$FRONTEND_PID" "→ http://localhost:$FRONTEND_PORT"
    check_service "ngrok     " "$NGROK_PID"    "→ http://localhost:4040"

    echo ""
}

# ─── LOGLAR ─────────────────────────────────
show_logs() {
    echo ""
    echo -e "${BOLD}  Qaysi log?${NC}"
    echo "  1) Backend"
    echo "  2) Bot"
    echo "  3) Frontend"
    echo "  4) ngrok"
    echo "  5) Hammasi"
    echo ""
    read -p "  Tanlang (1-5): " choice

    case $choice in
        1) tail -f "$LOG_DIR/backend.log" ;;
        2) tail -f "$LOG_DIR/bot.log" ;;
        3) tail -f "$LOG_DIR/frontend.log" ;;
        4) tail -f "$LOG_DIR/ngrok.log" ;;
        5) tail -f "$LOG_DIR"/*.log ;;
        *) print_err "Noto'g'ri tanlov" ;;
    esac
}

# ─── ASOSIY ─────────────────────────────────
print_header

case "${1:-start}" in
    start)
        echo -e "${BOLD}  Ishga tushirish...${NC}\n"
        start_backend
        start_bot
        start_frontend
        start_ngrok
        echo ""
        check_status
        echo -e "  ${CYAN}Loglar: ./run.sh logs${NC}"
        echo -e "  ${CYAN}To'xtatish: ./run.sh stop${NC}\n"
        ;;

    stop)
        echo -e "${BOLD}  To'xtatish...${NC}\n"
        stop_service "Backend"  "$BACKEND_PID"
        stop_service "Bot"      "$BOT_PID"
        stop_service "Frontend" "$FRONTEND_PID"
        stop_service "ngrok"    "$NGROK_PID"
        echo ""
        ;;

    restart)
        echo -e "${BOLD}  Qayta ishga tushirish...${NC}\n"
        stop_service "Backend"  "$BACKEND_PID"
        stop_service "Bot"      "$BOT_PID"
        stop_service "Frontend" "$FRONTEND_PID"
        stop_service "ngrok"    "$NGROK_PID"
        sleep 2
        start_backend
        start_bot
        start_frontend
        start_ngrok
        echo ""
        check_status
        ;;

    status)
        check_status
        ;;

    logs)
        show_logs
        ;;

    backend)
        stop_service "Backend" "$BACKEND_PID"
        sleep 1
        start_backend
        ;;

    bot)
        stop_service "Bot" "$BOT_PID"
        sleep 1
        start_bot
        ;;

    *)
        echo "  Ishlatish:"
        echo "    ./run.sh start    — Hammasi ishga tushadi"
        echo "    ./run.sh stop     — Hammasi to'xtaydi"
        echo "    ./run.sh restart  — Qayta ishga tushadi"
        echo "    ./run.sh status   — Holat"
        echo "    ./run.sh logs     — Loglar"
        echo "    ./run.sh backend  — Faqat backendni restart"
        echo "    ./run.sh bot      — Faqat botni restart"
        echo ""
        ;;
esac
