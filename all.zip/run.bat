@echo off
chcp 65001 >nul
echo SmartDMTT v4.0 ishga tushmoqda...
cd /d "%~dp0"
if exist venv\Scripts\activate.bat (
    call venv\Scripts\activate.bat
) else (
    echo venv topilmadi! pip install -r requirements.txt
    pause & exit
)
cd backend
start "SmartDMTT Backend" cmd /k "uvicorn app.api.main:app --host 0.0.0.0 --port 8000 --reload"
timeout /t 3 >nul
start "SmartDMTT Bot" cmd /k "python -m app.bot.main"
cd ..\frontend
start "SmartDMTT Frontend" cmd /k "npm run dev"
echo.
echo Barchasi ishga tushdi!
echo   Backend: http://localhost:8000
echo   Frontend: http://localhost:5173
echo   API docs: http://localhost:8000/docs
pause
