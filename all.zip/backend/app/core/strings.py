"""
SmartDMTT v4 — Bot xabarlari (5 tilda)
Barcha bot xabarlari shu yerdan olinadi.
get_string(lang, key, **kwargs) — asosiy funksiya
"""

STRINGS = {
    # ─── O'zbek (lotin) ──────────────────────────────────────────────────────
    "uz_latin": {
        # Umumiy
        "welcome":              "Assalomu alaykum, {name}! SmartDMTT botiga xush kelibsiz 👋",
        "choose_role":          "Rolingizni tanlang:",
        "role_changed":         "Rolingiz '{role}' ga o'zgartirildi.",
        "main_menu":            "Asosiy menyu. Kerakli bo'limni tanlang:",
        "feature_soon":         "Bu bo'lim tez orada ishga tushadi. Sabr qiling 🙏",
        "error_occurred":       "Xatolik yuz berdi. Iltimos, qaytadan urinib ko'ring.",
        "cancelled":            "Amal bekor qilindi.",
        "back":                 "Orqaga",
        "confirm":              "Tasdiqlash",
        "cancel":               "Bekor qilish",
        "yes":                  "Ha",
        "no":                   "Yo'q",
        "saved":                "Saqlandi ✅",
        "not_found":            "Topilmadi.",
        "access_denied":        "Sizda bu amalni bajarish huquqi yo'q.",

        # Til tanlash
        "choose_language":      "Tilni tanlang:",
        "language_saved":       "Til saqlandi: O'zbek (lotin) 🇺🇿",

        # To'lov
        "payment_success":      "To'lov qabul qilindi! ✅\nMiqdor: {amount} so'm\nTo'garak: {club}",
        "payment_reminder":     "📢 To'lov eslatmasi\n{child} uchun {club} to'garagi to'lovi — {amount} so'm.\nMuddati: oy oxirigacha.",
        "payment_blocked":      "⛔ Hisob bloklandi. To'lov amalga oshirilmadi.\nIltimos, {amount} so'm to'lang.",
        "payment_removed":      "❌ To'lovni kechiktirganingiz uchun to'garakdan chiqarildingiz.",
        "payment_unblocked":    "✅ To'lov qabul qilindi. Hisobingiz faollashtirildi!",
        "payment_link":         "To'lov havolasi:",
        "payment_choose":       "To'lov tizimini tanlang:",

        # Davomat
        "attendance_present":   "✅ {child} bugun {club} to'garagida qatnashmoqda.",
        "attendance_absent":    "❗ {child} bugun {club} to'garagiga kelmadi.",
        "attendance_confirm":   "Farzandingiz {child} {date} kuni qatnashdi. To'g'rimi?",
        "attendance_excused":   "Sababli qoldirildi. Tushundik 👍",
        "attendance_marked":    "Davomat belgilandi ✅",

        # To'garak
        "club_enrolled":        "🎉 {child} '{club}' to'garagiga yozildi!\nDars jadvali: {schedule}",
        "club_left":            "{child} '{club}' to'garagidan chiqarildi.",
        "club_full":            "'{club}' to'garagi to'lgan. Kutish ro'yxatiga qo'shildingiz.",
        "club_list":            "Mavjud to'garaklar:",
        "club_not_found":       "To'garak topilmadi.",
        "club_members":         "A'zolar soni: {count}/{max}",

        # Qo'shimcha xizmatlar
        "late_pickup_confirm":  "Kechroq olish xizmati: +{amount} so'm qo'shiladi. Rozimisiz?",
        "late_pickup_done":     "Kechroq olish tasdiqlandi. Narx hisobga qo'shildi.",
        "extra_service_saved":  "Qo'shimcha xizmat ro'yxatga olindi ✅",

        # Kuzatuv (muallim)
        "observation_prompt":   "'{club}' darsini tugatdingiz. Bolalar haqida qisqa fikr bildiring:",
        "observation_saved":    "Kuzatuv saqlandi. Rahmat! 🙏",

        # Shikoyat / taklif
        "complaint_type":       "Nima yubormoqchisiz?",
        "complaint_target":     "Kimga tegishli?",
        "complaint_text":       "Matnni yozing:",
        "complaint_anonymous":  "Anonim yuborilsinmi?",
        "complaint_sent":       "Yuborildi ✅ Ko'rib chiqiladi.",
        "complaint_response":   "Shikoyatingizga javob:\n{response}",

        # Muallim
        "teacher_payment_info": "📊 {month} oylik hisob:\nAsosiy: {base} so'm\nBonus: {bonus} so'm\nJami: {total} so'm",
        "lesson_started":       "Dars boshlandi. Davomat olishni unutmang!",
        "lesson_ended":         "Dars tugadi. Yaxshi ish! 👏",

        # Bola profili
        "child_profile_q":      "Shanba savoli 🌟\n{child} bu hafta uyda nima qildi?",
        "child_profile_saved":  "Javob saqlandi. Rahmat!",

        # Admin
        "admin_only":           "Bu buyruq faqat adminlar uchun.",
        "stats_title":          "📊 Tizim statistikasi:",
        "user_blocked_msg":     "Hisobingiz bloklandi. Administrator bilan bog'laning.",

        # Tugmalar
        "btn_webapp":           "📱 Web portal",
        "btn_assistant":        "🤖 Yordamchi",
        "btn_payments":         "💳 To'lovlar",
        "btn_attendance":       "✅ Davomat",
        "btn_children":         "👨‍👩‍👧 Farzandlarim",
        "btn_clubs":            "📚 To'garaklar",
        "btn_reports":          "📈 Hisobotlar",
        "btn_settings":         "⚙️ Sozlamalar",
        "btn_complaint":        "✍️ Shikoyat / Taklif",
        "btn_back":             "⬅️ Orqaga",
        "btn_enroll":           "✨ Yozilish",
        "btn_pay":              "💸 To'lash",
        "btn_rate":             "⭐ Baho berish",
    },

    # ─── O'zbek (kiril) ──────────────────────────────────────────────────────
    "uz_cyrillic": {
        # Umumiy
        "welcome":              "Ассалому алайкум, {name}! SmartDMTT ботига хуш келибсиз 👋",
        "choose_role":          "Ролингизни танланг:",
        "role_changed":         "Ролингиз '{role}' га ўзгартирилди.",
        "main_menu":            "Асосий меню. Керакли бўлимни танланг:",
        "feature_soon":         "Бу бўлим тез орада ишга тушади. Сабр қилинг 🙏",
        "error_occurred":       "Хатолик юз берди. Илтимос, қайтадан уриниб кўринг.",
        "cancelled":            "Амал бекор қилинди.",
        "back":                 "Орқага",
        "confirm":              "Тасдиқлаш",
        "cancel":               "Бекор қилиш",
        "yes":                  "Ҳа",
        "no":                   "Йўқ",
        "saved":                "Сақланди ✅",
        "not_found":            "Топилмади.",
        "access_denied":        "Сизда бу амални бажариш ҳуқуқи йўқ.",

        "choose_language":      "Тилни танланг:",
        "language_saved":       "Тил сақланди: Ўзбек (кирил) 🇺🇿",

        "payment_success":      "Тўлов қабул қилинди! ✅\nМиқдор: {amount} сўм\nТўгарак: {club}",
        "payment_reminder":     "📢 Тўлов эслатмаси\n{child} учун {club} тўгараги тўлови — {amount} сўм.\nМуддати: ой охиригача.",
        "payment_blocked":      "⛔ Ҳисоб блокланди.\nИлтимос, {amount} сўм тўланг.",
        "payment_removed":      "❌ Тўловни кечиктирганингиз учун тўгаракдан чиқарилдингиз.",
        "payment_unblocked":    "✅ Тўлов қабул қилинди. Ҳисобингиз фаоллаштирилди!",
        "payment_link":         "Тўлов ҳаволаси:",
        "payment_choose":       "Тўлов тизимини танланг:",

        "attendance_present":   "✅ {child} бугун {club} тўгарагида қатнашмоқда.",
        "attendance_absent":    "❗ {child} бугун {club} тўгарагига келмади.",
        "attendance_confirm":   "Фарзандингиз {child} {date} куни қатнашди. Тўғрими?",
        "attendance_excused":   "Сабабли қолдирилди. Тушундик 👍",
        "attendance_marked":    "Давомат белгиланди ✅",

        "club_enrolled":        "🎉 {child} '{club}' тўгарагига ёзилди!\nДарс жадвали: {schedule}",
        "club_left":            "{child} '{club}' тўгарагидан чиқарилди.",
        "club_full":            "'{club}' тўгараги тўлган. Кутиш рўйхатига қўшилдингиз.",
        "club_list":            "Мавжуд тўгараклар:",
        "club_not_found":       "Тўгарак топилмади.",
        "club_members":         "Аъзолар сони: {count}/{max}",

        "late_pickup_confirm":  "Кечроқ олиш хизмати: +{amount} сўм қўшилади. Розимисиз?",
        "late_pickup_done":     "Кечроқ олиш тасдиқланди. Нарх ҳисобга қўшилди.",
        "extra_service_saved":  "Қўшимча хизмат рўйхатга олинди ✅",

        "observation_prompt":   "'{club}' дарсини тугатдингиз. Болалар ҳақида қисқа фикр билдиринг:",
        "observation_saved":    "Кузатув сақланди. Раҳмат! 🙏",

        "complaint_type":       "Нима юбормоқчисиз?",
        "complaint_target":     "Кимга тегишли?",
        "complaint_text":       "Матнни ёзинг:",
        "complaint_anonymous":  "Аноним юборилсинми?",
        "complaint_sent":       "Юборилди ✅ Кўриб чиқилади.",
        "complaint_response":   "Шикоятингизга жавоб:\n{response}",

        "teacher_payment_info": "📊 {month} ойлик ҳисоб:\nАсосий: {base} сўм\nБонус: {bonus} сўм\nЖами: {total} сўм",
        "lesson_started":       "Дарс бошланди. Давомат олишни унутманг!",
        "lesson_ended":         "Дарс тугади. Яхши иш! 👏",

        "child_profile_q":      "Шанба саволи 🌟\n{child} бу ҳафта уйда нима қилди?",
        "child_profile_saved":  "Жавоб сақланди. Раҳмат!",

        "admin_only":           "Бу буйруқ фақат админлар учун.",
        "stats_title":          "📊 Тизим статистикаси:",
        "user_blocked_msg":     "Ҳисобингиз блокланди. Администратор билан боғланинг.",

        "btn_webapp":           "📱 Веб портал",
        "btn_assistant":        "🤖 Ёрдамчи",
        "btn_payments":         "💳 Тўловлар",
        "btn_attendance":       "✅ Давомат",
        "btn_children":         "👨‍👩‍👧 Фарзандларим",
        "btn_clubs":            "📚 Тўгараклар",
        "btn_reports":          "📈 Ҳисоботлар",
        "btn_settings":         "⚙️ Созламалар",
        "btn_complaint":        "✍️ Шикоят / Таклиф",
        "btn_back":             "⬅️ Орқага",
        "btn_enroll":           "✨ Ёзилиш",
        "btn_pay":              "💸 Тўлаш",
        "btn_rate":             "⭐ Баҳо бериш",
    },

    # ─── Русский ─────────────────────────────────────────────────────────────
    "ru": {
        # Общее
        "welcome":              "Добро пожаловать, {name}! Рады видеть вас в SmartDMTT 👋",
        "choose_role":          "Выберите роль:",
        "role_changed":         "Ваша роль изменена на '{role}'.",
        "main_menu":            "Главное меню. Выберите нужный раздел:",
        "feature_soon":         "Этот раздел скоро заработает. Спасибо за терпение 🙏",
        "error_occurred":       "Произошла ошибка. Пожалуйста, попробуйте снова.",
        "cancelled":            "Действие отменено.",
        "back":                 "Назад",
        "confirm":              "Подтвердить",
        "cancel":               "Отмена",
        "yes":                  "Да",
        "no":                   "Нет",
        "saved":                "Сохранено ✅",
        "not_found":            "Не найдено.",
        "access_denied":        "У вас нет прав для этого действия.",

        "choose_language":      "Выберите язык:",
        "language_saved":       "Язык сохранён: Русский 🇷🇺",

        "payment_success":      "Оплата принята! ✅\nСумма: {amount} сум\nКружок: {club}",
        "payment_reminder":     "📢 Напоминание об оплате\nОплата за кружок {club} для {child} — {amount} сум.\nСрок: до конца месяца.",
        "payment_blocked":      "⛔ Аккаунт заблокирован.\nПожалуйста, оплатите {amount} сум.",
        "payment_removed":      "❌ Из-за просрочки оплаты вы отчислены из кружка.",
        "payment_unblocked":    "✅ Оплата принята. Ваш аккаунт активирован!",
        "payment_link":         "Ссылка для оплаты:",
        "payment_choose":       "Выберите платёжную систему:",

        "attendance_present":   "✅ {child} сегодня посещает кружок {club}.",
        "attendance_absent":    "❗ {child} сегодня не пришёл в кружок {club}.",
        "attendance_confirm":   "Ваш ребёнок {child} был {date}? Подтвердите.",
        "attendance_excused":   "Отсутствие отмечено как уважительное. Спасибо 👍",
        "attendance_marked":    "Посещаемость отмечена ✅",

        "club_enrolled":        "🎉 {child} записан в кружок '{club}'!\nРасписание: {schedule}",
        "club_left":            "{child} отчислен из кружка '{club}'.",
        "club_full":            "Кружок '{club}' заполнен. Вы добавлены в список ожидания.",
        "club_list":            "Доступные кружки:",
        "club_not_found":       "Кружок не найден.",
        "club_members":         "Участников: {count}/{max}",

        "late_pickup_confirm":  "Услуга позднего забора: +{amount} сум. Подтверждаете?",
        "late_pickup_done":     "Поздний забор подтверждён. Сумма добавлена.",
        "extra_service_saved":  "Дополнительная услуга оформлена ✅",

        "observation_prompt":   "Занятие '{club}' завершено. Оставьте краткие заметки о детях:",
        "observation_saved":    "Наблюдение сохранено. Спасибо! 🙏",

        "complaint_type":       "Что хотите отправить?",
        "complaint_target":     "Кому адресовано?",
        "complaint_text":       "Напишите текст:",
        "complaint_anonymous":  "Отправить анонимно?",
        "complaint_sent":       "Отправлено ✅ Будет рассмотрено.",
        "complaint_response":   "Ответ на вашу жалобу:\n{response}",

        "teacher_payment_info": "📊 Расчёт за {month}:\nБаза: {base} сум\nБонус: {bonus} сум\nИтого: {total} сум",
        "lesson_started":       "Занятие начато. Не забудьте отметить посещаемость!",
        "lesson_ended":         "Занятие завершено. Отличная работа! 👏",

        "child_profile_q":      "Вопрос недели 🌟\nЧем занимался {child} дома на этой неделе?",
        "child_profile_saved":  "Ответ сохранён. Спасибо!",

        "admin_only":           "Эта команда только для администраторов.",
        "stats_title":          "📊 Статистика системы:",
        "user_blocked_msg":     "Ваш аккаунт заблокирован. Обратитесь к администратору.",

        "btn_webapp":           "📱 Веб-портал",
        "btn_assistant":        "🤖 Помощник",
        "btn_payments":         "💳 Платежи",
        "btn_attendance":       "✅ Посещаемость",
        "btn_children":         "👨‍👩‍👧 Мои дети",
        "btn_clubs":            "📚 Кружки",
        "btn_reports":          "📈 Отчёты",
        "btn_settings":         "⚙️ Настройки",
        "btn_complaint":        "✍️ Жалоба / Предложение",
        "btn_back":             "⬅️ Назад",
        "btn_enroll":           "✨ Записаться",
        "btn_pay":              "💸 Оплатить",
        "btn_rate":             "⭐ Оценить",
    },

    # ─── English ─────────────────────────────────────────────────────────────
    "en": {
        "welcome":              "Welcome, {name}! Glad to have you in SmartDMTT 👋",
        "choose_role":          "Choose your role:",
        "role_changed":         "Your role has been changed to '{role}'.",
        "main_menu":            "Main menu. Choose a section:",
        "feature_soon":         "This section is coming soon. Thank you for your patience 🙏",
        "error_occurred":       "An error occurred. Please try again.",
        "cancelled":            "Action cancelled.",
        "back":                 "Back",
        "confirm":              "Confirm",
        "cancel":               "Cancel",
        "yes":                  "Yes",
        "no":                   "No",
        "saved":                "Saved ✅",
        "not_found":            "Not found.",
        "access_denied":        "You don't have permission for this action.",

        "choose_language":      "Choose language:",
        "language_saved":       "Language saved: English 🇬🇧",

        "payment_success":      "Payment received! ✅\nAmount: {amount} UZS\nClub: {club}",
        "payment_reminder":     "📢 Payment reminder\n{club} fee for {child} — {amount} UZS.\nDue: end of month.",
        "payment_blocked":      "⛔ Account blocked.\nPlease pay {amount} UZS.",
        "payment_removed":      "❌ You have been removed from the club due to overdue payment.",
        "payment_unblocked":    "✅ Payment received. Your account is now active!",
        "payment_link":         "Payment link:",
        "payment_choose":       "Choose a payment method:",

        "attendance_present":   "✅ {child} is attending {club} today.",
        "attendance_absent":    "❗ {child} did not show up for {club} today.",
        "attendance_confirm":   "Did {child} attend on {date}? Please confirm.",
        "attendance_excused":   "Absence recorded as excused. Thank you 👍",
        "attendance_marked":    "Attendance marked ✅",

        "club_enrolled":        "🎉 {child} enrolled in '{club}'!\nSchedule: {schedule}",
        "club_left":            "{child} has been removed from '{club}'.",
        "club_full":            "'{club}' is full. You've been added to the waiting list.",
        "club_list":            "Available clubs:",
        "club_not_found":       "Club not found.",
        "club_members":         "Members: {count}/{max}",

        "late_pickup_confirm":  "Late pickup service: +{amount} UZS will be added. Confirm?",
        "late_pickup_done":     "Late pickup confirmed. Amount has been added.",
        "extra_service_saved":  "Extra service registered ✅",

        "observation_prompt":   "'{club}' session ended. Please leave brief notes on the children:",
        "observation_saved":    "Observation saved. Thank you! 🙏",

        "complaint_type":       "What would you like to send?",
        "complaint_target":     "Who is it addressed to?",
        "complaint_text":       "Write your message:",
        "complaint_anonymous":  "Send anonymously?",
        "complaint_sent":       "Sent ✅ It will be reviewed.",
        "complaint_response":   "Response to your complaint:\n{response}",

        "teacher_payment_info": "📊 Payroll for {month}:\nBase: {base} UZS\nBonus: {bonus} UZS\nTotal: {total} UZS",
        "lesson_started":       "Lesson started. Don't forget to mark attendance!",
        "lesson_ended":         "Lesson finished. Great work! 👏",

        "child_profile_q":      "Weekly question 🌟\nWhat did {child} do at home this week?",
        "child_profile_saved":  "Answer saved. Thank you!",

        "admin_only":           "This command is for admins only.",
        "stats_title":          "📊 System statistics:",
        "user_blocked_msg":     "Your account has been blocked. Please contact the administrator.",

        "btn_webapp":           "📱 Web portal",
        "btn_assistant":        "🤖 Assistant",
        "btn_payments":         "💳 Payments",
        "btn_attendance":       "✅ Attendance",
        "btn_children":         "👨‍👩‍👧 My children",
        "btn_clubs":            "📚 Clubs",
        "btn_reports":          "📈 Reports",
        "btn_settings":         "⚙️ Settings",
        "btn_complaint":        "✍️ Complaint / Suggestion",
        "btn_back":             "⬅️ Back",
        "btn_enroll":           "✨ Enroll",
        "btn_pay":              "💸 Pay",
        "btn_rate":             "⭐ Rate",
    },

    # ─── Türkçe ──────────────────────────────────────────────────────────────
    "tr": {
        "welcome":              "Hoş geldiniz, {name}! SmartDMTT botuna hoş geldiniz 👋",
        "choose_role":          "Rolünüzü seçin:",
        "role_changed":         "Rolünüz '{role}' olarak değiştirildi.",
        "main_menu":            "Ana menü. Lütfen bir bölüm seçin:",
        "feature_soon":         "Bu bölüm yakında açılacak. Anlayışınız için teşekkürler 🙏",
        "error_occurred":       "Bir hata oluştu. Lütfen tekrar deneyin.",
        "cancelled":            "İşlem iptal edildi.",
        "back":                 "Geri",
        "confirm":              "Onayla",
        "cancel":               "İptal",
        "yes":                  "Evet",
        "no":                   "Hayır",
        "saved":                "Kaydedildi ✅",
        "not_found":            "Bulunamadı.",
        "access_denied":        "Bu işlem için yetkiniz yok.",

        "choose_language":      "Dil seçin:",
        "language_saved":       "Dil kaydedildi: Türkçe 🇹🇷",

        "payment_success":      "Ödeme alındı! ✅\nTutar: {amount} UZS\nKulüp: {club}",
        "payment_reminder":     "📢 Ödeme hatırlatması\n{child} için {club} ücreti — {amount} UZS.\nSon tarih: ay sonu.",
        "payment_blocked":      "⛔ Hesap bloke edildi.\nLütfen {amount} UZS ödeyin.",
        "payment_removed":      "❌ Ödeme gecikmesi nedeniyle kulüpten çıkarıldınız.",
        "payment_unblocked":    "✅ Ödeme alındı. Hesabınız aktif hale getirildi!",
        "payment_link":         "Ödeme bağlantısı:",
        "payment_choose":       "Ödeme yöntemini seçin:",

        "attendance_present":   "✅ {child} bugün {club} kulübüne katılıyor.",
        "attendance_absent":    "❗ {child} bugün {club} kulübüne gelmedi.",
        "attendance_confirm":   "{child}, {date} tarihinde katıldı mı? Lütfen onaylayın.",
        "attendance_excused":   "Devamsızlık mazeretli olarak işaretlendi. Teşekkürler 👍",
        "attendance_marked":    "Devam durumu işaretlendi ✅",

        "club_enrolled":        "🎉 {child}, '{club}' kulübüne kaydedildi!\nProgram: {schedule}",
        "club_left":            "{child}, '{club}' kulübünden çıkarıldı.",
        "club_full":            "'{club}' kulübü dolu. Bekleme listesine eklendiniz.",
        "club_list":            "Mevcut kulüpler:",
        "club_not_found":       "Kulüp bulunamadı.",
        "club_members":         "Üye sayısı: {count}/{max}",

        "late_pickup_confirm":  "Geç alım hizmeti: +{amount} UZS eklenecek. Onaylıyor musunuz?",
        "late_pickup_done":     "Geç alım onaylandı. Tutar hesaba eklendi.",
        "extra_service_saved":  "Ek hizmet kaydedildi ✅",

        "observation_prompt":   "'{club}' dersi sona erdi. Çocuklar hakkında kısa notlar bırakın:",
        "observation_saved":    "Gözlem kaydedildi. Teşekkürler! 🙏",

        "complaint_type":       "Ne göndermek istiyorsunuz?",
        "complaint_target":     "Kime yönelik?",
        "complaint_text":       "Mesajınızı yazın:",
        "complaint_anonymous":  "Anonim olarak gönderilsin mi?",
        "complaint_sent":       "Gönderildi ✅ İncelenecek.",
        "complaint_response":   "Şikayetinize yanıt:\n{response}",

        "teacher_payment_info": "📊 {month} maaş hesabı:\nTemel: {base} UZS\nPrim: {bonus} UZS\nToplam: {total} UZS",
        "lesson_started":       "Ders başladı. Devam yoklamasını yapmayı unutmayın!",
        "lesson_ended":         "Ders bitti. Harika iş! 👏",

        "child_profile_q":      "Haftalık soru 🌟\n{child} bu hafta evde ne yaptı?",
        "child_profile_saved":  "Cevap kaydedildi. Teşekkürler!",

        "admin_only":           "Bu komut yalnızca yöneticiler içindir.",
        "stats_title":          "📊 Sistem istatistikleri:",
        "user_blocked_msg":     "Hesabınız bloke edildi. Yönetici ile iletişime geçin.",

        "btn_webapp":           "📱 Web portalı",
        "btn_assistant":        "🤖 Asistan",
        "btn_payments":         "💳 Ödemeler",
        "btn_attendance":       "✅ Devam durumu",
        "btn_children":         "👨‍👩‍👧 Çocuklarım",
        "btn_clubs":            "📚 Kulüpler",
        "btn_reports":          "📈 Raporlar",
        "btn_settings":         "⚙️ Ayarlar",
        "btn_complaint":        "✍️ Şikayet / Öneri",
        "btn_back":             "⬅️ Geri",
        "btn_enroll":           "✨ Kayıt ol",
        "btn_pay":              "💸 Öde",
        "btn_rate":             "⭐ Değerlendir",
    },
}

# uz_latin — standart fallback
STRINGS["uz"] = STRINGS["uz_latin"]


def get_string(lang: str, key: str, **kwargs) -> str:
    """Bot xabari qaytaradi. lang topilmasa uz_latin ishlatiladi."""
    lang_dict = STRINGS.get(lang, STRINGS["uz_latin"])
    text = lang_dict.get(key, STRINGS["uz_latin"].get(key, key))
    return text.format(**kwargs) if kwargs else text


# Eski kod bilan moslik uchun alias
def get_text(lang: str, key: str, **kwargs) -> str:
    return get_string(lang, key, **kwargs)


def get_languages() -> list:
    return ["uz_latin", "uz_cyrillic", "ru", "en", "tr"]
