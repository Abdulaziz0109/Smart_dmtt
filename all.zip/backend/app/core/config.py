"""
SmartDMTT v4.0 — Konfiguratsiya fayli
Barcha maxfiy kalitlar .env fayldan o'qiladi
"""
import os
from pathlib import Path
from dotenv import load_dotenv

# .env faylni yuklash (project root dan)
env_path = Path(__file__).parent.parent.parent.parent / ".env"
load_dotenv(dotenv_path=env_path)

def _require(key: str, fallback: str = "") -> str:
    val = os.getenv(key, fallback).strip()
    if not val:
        print(f"⚠️  OGOHLANTIRISH: '{key}' .env faylida topilmadi!", flush=True)
    return val

# ─── BOT ──────────────────────────────────────────────────────
TOKEN: str = _require("BOT_TOKEN")
ADMIN_IDS: list = [int(x.strip()) for x in os.getenv("ADMIN_IDS", "").split(",") if x.strip().isdigit()]
WEBAPP_URL: str = os.getenv("WEBAPP_URL", "https://unsensuous-unvillainous-jeannette.ngrok-free.dev")

# ─── AI / Anthropic Claude ─────────────────────────────────────
ANTHROPIC_API_KEY: str = os.getenv("ANTHROPIC_API_KEY", "").strip()
AI_HELPER_MODEL: str = os.getenv("AI_HELPER_MODEL", "claude-haiku-4-5-20251001")
AI_ANALYSIS_MODEL: str = os.getenv("AI_ANALYSIS_MODEL", "claude-sonnet-4-6")
AI_FREE_LIMIT: int = int(os.getenv("AI_FREE_LIMIT", "3"))

# ─── GitHub Models ─────────────────────────────────────────────
GITHUB_TOKEN: str = os.getenv("GITHUB_TOKEN", "").strip()
GITHUB_AI_MODEL: str = os.getenv("GITHUB_AI_MODEL", "meta-llama/Llama-4-Scout-17B-16E-Instruct")
GITHUB_AI_ANALYSIS_MODEL: str = os.getenv("GITHUB_AI_ANALYSIS_MODEL", "DeepSeek-V3-0324")

# ─── Groq / Gemini ─────────────────────────────────────────────
GROQ_API_KEY: str = os.getenv("GROQ_API_KEY", "").strip()
GROQ_MODEL: str = os.getenv("GROQ_MODEL", "llama-3.1-8b-instant")
GEMINI_API_KEY: str = os.getenv("GEMINI_API_KEY", os.getenv("GOOGLE_API_KEY", "")).strip()
GEMINI_MODEL: str = os.getenv("GEMINI_MODEL", "gemini-2.0-flash")
OPENAI_API_KEY: str = os.getenv("OPENAI_API_KEY", "").strip()
GOOGLE_API_KEY: str = os.getenv("GOOGLE_API_KEY", "").strip()
AI_MAX_RETRIES: int = int(os.getenv("AI_MAX_RETRIES", "3"))
AI_TIMEOUT: int = int(os.getenv("AI_TIMEOUT", "30"))
AI_MAX_HISTORY: int = int(os.getenv("AI_MAX_HISTORY", "10"))
AI_MAX_TOKENS: int = int(os.getenv("AI_MAX_TOKENS", "1024"))
AI_PRIMARY: str = os.getenv("AI_PRIMARY", "github")
AI_FALLBACK: str = os.getenv("AI_FALLBACK", "groq")

# ─── DATABASE ─────────────────────────────────────────────────
DATABASE_URL: str = os.getenv("DATABASE_URL", "sqlite://data/database.sqlite")

# ─── REDIS ────────────────────────────────────────────────────
REDIS_URL: str = os.getenv("REDIS_URL", "redis://localhost:6379/0")
REDIS_PASSWORD: str = os.getenv("REDIS_PASSWORD", "")

# ─── AUTH ─────────────────────────────────────────────────────
SECRET_KEY: str = os.getenv("SECRET_KEY", "your-secret-key-for-jwt-min-32-chars!!")
ALGORITHM: str = "HS256"
SESSION_EXPIRE_HOURS: int = int(os.getenv("SESSION_EXPIRE_HOURS", "720"))  # 30 kun
DEVICE_TRUST_DAYS: int = int(os.getenv("DEVICE_TRUST_DAYS", "30"))
MIN_PASSWORD_LENGTH: int = int(os.getenv("MIN_PASSWORD_LENGTH", "6"))

# ─── TO'LOV TIZIMLARI ─────────────────────────────────────────
CLICK_SERVICE_ID: str = os.getenv("CLICK_SERVICE_ID", "")
CLICK_MERCHANT_ID: str = os.getenv("CLICK_MERCHANT_ID", "")
CLICK_SECRET_KEY: str = os.getenv("CLICK_SECRET_KEY", "")

PAYNET_LOGIN: str = os.getenv("PAYNET_LOGIN", "")
PAYNET_PASSWORD: str = os.getenv("PAYNET_PASSWORD", "")
PAYNET_POINT_ID: str = os.getenv("PAYNET_POINT_ID", "")

PAYME_MERCHANT_ID: str = os.getenv("PAYME_MERCHANT_ID", "")
PAYME_SECRET_KEY: str = os.getenv("PAYME_SECRET_KEY", "")

# ─── TO'LOV QOIDALARI ─────────────────────────────────────────
PAYMENT_DUE_DAY: int = int(os.getenv("PAYMENT_DUE_DAY", "1"))
PAYMENT_REMINDER_DAYS: int = int(os.getenv("PAYMENT_REMINDER_DAYS", "3"))
PAYMENT_BLOCK_DAY: int = int(os.getenv("PAYMENT_BLOCK_DAY", "5"))
PAYMENT_REMOVE_DAY: int = int(os.getenv("PAYMENT_REMOVE_DAY", "15"))
MIN_CLUB_MEMBERS: int = int(os.getenv("MIN_CLUB_MEMBERS", "5"))
LAST_FREE_LESSON: int = int(os.getenv("LAST_FREE_LESSON", "1"))

# ─── DAVOMAT ──────────────────────────────────────────────────
ATTENDANCE_AUTO_CONFIRM_HOURS: int = int(os.getenv("ATTENDANCE_AUTO_CONFIRM_HOURS", "24"))

# ─── SCHEDULER ────────────────────────────────────────────────
WEEKLY_REPORT_DAY: str = os.getenv("WEEKLY_REPORT_DAY", "mon")   # Dushanba
WEEKLY_REPORT_HOUR: int = int(os.getenv("WEEKLY_REPORT_HOUR", "9"))
PARENT_REPORT_DAY: str = os.getenv("PARENT_REPORT_DAY", "fri")   # Juma
PARENT_REPORT_HOUR: int = int(os.getenv("PARENT_REPORT_HOUR", "20"))
AI_ANALYSIS_DAY: str = os.getenv("AI_ANALYSIS_DAY", "sun")       # Yakshanba
AI_ANALYSIS_HOUR: int = int(os.getenv("AI_ANALYSIS_HOUR", "20"))

# ─── WEB API ──────────────────────────────────────────────────
API_HOST: str = os.getenv("API_HOST", "0.0.0.0")
API_PORT: int = int(os.getenv("API_PORT", "8000"))
CORS_ORIGINS: list = os.getenv("CORS_ORIGINS", "*").split(",")
ADMIN_SECRET: str = _require("ADMIN_SECRET", "changeme_admin_secret_2024")

# ─── DEBUG ────────────────────────────────────────────────────
DEBUG: bool = os.getenv("DEBUG", "false").lower() == "true"
LOG_LEVEL: str = os.getenv("LOG_LEVEL", "INFO").upper()
DEFAULT_LANG: str = os.getenv("DEFAULT_LANG", "uz")

# Eski nom bilan moslik (ba'zi fayllar ishlatadi)
ADMIN_CHAT_ID: int = ADMIN_IDS[0] if ADMIN_IDS else 0
OTP_EXPIRE_SECONDS: int = 300
OTP_MAX_ATTEMPTS: int = 3
OTP_EXPIRE_MINUTES: int = 5
MAX_LOGIN_ATTEMPTS: int = 3


def validate():
    errors = []
    if not TOKEN:
        errors.append("BOT_TOKEN — Telegram bot token kerak!")
    if not ADMIN_IDS:
        errors.append("ADMIN_IDS — Admin Telegram ID kerak!")
    if not ANTHROPIC_API_KEY:
        print("⚠️  ANTHROPIC_API_KEY yo'q — AI xizmati ishlamaydi")
    if errors:
        print("\n❌ KONFIGURATSIYA XATOLARI:", flush=True)
        for e in errors:
            print(f"   • {e}", flush=True)
        return False
    return True
