"""
SmartDMTT v4 — Markaziy xabar yuborish tizimi
Barcha bot notification shu orqali o'tadi
"""
import logging
from datetime import date
from aiogram import Bot

from app.models.user import User
from app.models.child import Child
from app.models.club import Club, Enrollment
from app.models.payment import Payment
from app.models.attendance import Attendance
from app.bot.i18n import t

logger = logging.getLogger(__name__)

_bot: Bot | None = None

def set_bot(bot: Bot):
    global _bot
    _bot = bot

async def _send(tg_id: int, text: str, parse_mode: str = "HTML") -> bool:
    """Xabar yuborish — xatolikni yutib, False qaytaradi"""
    if not _bot or not tg_id:
        return False
    try:
        await _bot.send_message(tg_id, text, parse_mode=parse_mode)
        return True
    except Exception as e:
        logger.warning(f"Xabar yuborilmadi (tg_id={tg_id}): {e}")
        return False


# ══════════════════════════════════════════════════════════
#  1. DAVOMAT BELGILANGANDA OTA-ONAGA XABAR
# ══════════════════════════════════════════════════════════
async def notify_attendance(enrollment_id: int, status: str, marked_by: str = ""):
    """
    Muallim davomat belgigach ota-onaga xabar.
    status: present | absent | late | excused
    """
    enr   = await Enrollment.get_or_none(id=enrollment_id)
    if not enr: return

    child = await Child.get_or_none(id=enr.child_id)
    club  = await Club.get_or_none(id=enr.club_id)
    if not child or not club: return

    parent = await User.get_or_none(id=child.parent_id)
    if not parent or not parent.telegram_id: return

    lang  = parent.language or "uz"
    icons = {"present": "✅", "absent": "❌", "late": "⏰", "excused": "📝"}
    icon  = icons.get(status, "📅")

    status_labels = {
        "present": {"uz":"Keldi","kril":"Келди","ru":"Присутствует","en":"Present","turk":"Geldi"},
        "absent":  {"uz":"Kelmadi","kril":"Келмади","ru":"Отсутствует","en":"Absent","turk":"Gelmedi"},
        "late":    {"uz":"Kech keldi","kril":"Кеч келди","ru":"Опоздал","en":"Late","turk":"Geç geldi"},
        "excused": {"uz":"Sababli","kril":"Сабабли","ru":"По уважит.","en":"Excused","turk":"Mazeretli"},
    }
    status_text = status_labels.get(status, {}).get(lang, status)

    today = date.today().strftime("%d.%m.%Y")
    text  = (
        f"📅 <b>Davomat xabari</b>\n"
        f"👶 {child.full_name}\n"
        f"🎯 {club.name}\n"
        f"{icon} {status_text} — {today}"
    )
    if marked_by:
        text += f"\n👨‍🏫 {marked_by}"

    await _send(parent.telegram_id, text)


# ══════════════════════════════════════════════════════════
#  2. TO'LOV ESLATMASI
# ══════════════════════════════════════════════════════════
async def notify_payment_reminder(enrollment_id: int):
    """Ota-onaga oylik to'lov eslatmasi"""
    enr   = await Enrollment.get_or_none(id=enrollment_id)
    if not enr: return

    child = await Child.get_or_none(id=enr.child_id)
    club  = await Club.get_or_none(id=enr.club_id)
    if not child or not club: return

    parent = await User.get_or_none(id=child.parent_id)
    if not parent or not parent.telegram_id: return

    lang = parent.language or "uz"
    month_str = date.today().strftime("%Y-%m")

    already_paid = await Payment.filter(
        enrollment_id=enrollment_id, month=month_str, status="completed"
    ).exists()
    if already_paid: return

    price_f = f"{int(club.price):,}"
    text = (
        f"💳 <b>To'lov eslatmasi</b>\n\n"
        f"👶 {child.full_name}\n"
        f"🎯 {club.name}\n"
        f"💰 {month_str}: {price_f} so'm\n"
        f"🆔 To'lov ID: <code>{enr.payment_id}</code>\n\n"
        f"💡 Click/Payme/Paynet orqali to'lang."
    )
    await _send(parent.telegram_id, text)


# ══════════════════════════════════════════════════════════
#  3. BROADCAST — OMMAVIY XABAR
# ══════════════════════════════════════════════════════════
async def broadcast(
    text: str,
    roles: list[str] | None = None,
    kg_id: int | None = None,
    lang: str | None = None,
) -> dict:
    """
    Ko'pchilikka xabar yuborish.
    roles=None — hammaga. kg_id — faqat shu bog'cha.
    Qaytaradi: {sent, failed, total}
    """
    q = User.filter(is_blocked=False)
    if roles:
        q = q.filter(role__in=roles)
    if kg_id:
        q = q.filter(kindergarten_id=kg_id)
    if lang:
        q = q.filter(language=lang)

    users = await q.all()
    sent = failed = 0
    for u in users:
        if u.telegram_id:
            ok = await _send(u.telegram_id, text)
            if ok: sent += 1
            else:  failed += 1

    logger.info(f"Broadcast: {sent} yuborildi, {failed} xato, jami {len(users)}")
    return {"sent": sent, "failed": failed, "total": len(users)}


# ══════════════════════════════════════════════════════════
#  4. SCHEDULER JOBLAR (bot/main.py dan chaqiriladi)
# ══════════════════════════════════════════════════════════
async def job_daily_payment_reminder():
    """Har kuni soat 10:00 — to'lamagan ota-onalarga eslatma"""
    today     = date.today()
    # Faqat oy boshida (1, 5, 10 kunlari)
    if today.day not in (1, 5, 10, 15, 20, 25):
        return

    month_str = today.strftime("%Y-%m")
    enr_ids   = await Enrollment.filter(status="active").values_list("id", flat=True)
    paid_ids  = set(await Payment.filter(
        enrollment_id__in=list(enr_ids), month=month_str, status="completed"
    ).values_list("enrollment_id", flat=True))

    sent = 0
    for enr_id in enr_ids:
        if enr_id not in paid_ids:
            await notify_payment_reminder(enr_id)
            sent += 1

    logger.info(f"To'lov eslatmasi: {sent} ta yuborildi")


async def job_daily_attendance_summary():
    """Har kuni soat 18:00 — direktorlarga kunlik hisobot"""
    today     = date.today()
    directors = await User.filter(role="director").all()

    for d in directors:
        if not d.telegram_id or not d.kindergarten_id: continue
        kg_id = d.kindergarten_id

        child_ids = await Child.filter(kindergarten_id=kg_id).values_list("id", flat=True)
        enr_ids   = await Enrollment.filter(child_id__in=list(child_ids), status="active").values_list("id", flat=True)

        if not enr_ids: continue

        total   = await Attendance.filter(enrollment_id__in=list(enr_ids), date=today).count()
        present = await Attendance.filter(enrollment_id__in=list(enr_ids), date=today, status="present").count()
        pct     = round(present / total * 100) if total else 0

        month_str = today.strftime("%Y-%m")
        paid_cnt  = await Payment.filter(enrollment_id__in=list(enr_ids), month=month_str, status="completed").count()
        debt_cnt  = len(enr_ids) - paid_cnt

        text = (
            f"📊 <b>Kunlik hisobot — {today.strftime('%d.%m.%Y')}</b>\n\n"
            f"✅ Davomat: {present}/{total} ({pct}%)\n"
            f"💳 To'lagan: {paid_cnt} ta\n"
            f"❌ Qarzdor: {debt_cnt} ta"
        )
        await _send(d.telegram_id, text)
