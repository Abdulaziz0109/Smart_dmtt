from app.services import database as db
import datetime

class UserService:
    @staticmethod
    async def get_user_language(user_id: int) -> str:
        return db.get_user_language(user_id)
            
    @staticmethod
    async def find_user(user_id: int):
        return await db.find_user(user_id)

    @staticmethod
    async def log_analytics(event_type: str, user_id: str, details: str):
        await db.log_analytics(event_type, user_id, details)
