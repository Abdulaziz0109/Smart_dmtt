"""
SmartDMTT v4.0 — AI Yordamchi
Zanjir: Gemini (bepul) → Claude Haiku → OpenAI → Xato xabari
"""
import logging
from datetime import date, datetime, timedelta
from typing import Optional

from app.core import config
from app.models.user import User
from app.models.child import Child
from app.models.club import Enrollment, Club
from app.models.payment import Payment
from app.models.ai_log import AILog, KnowledgeBase
from app.services.redis_service import RedisService

logger = logging.getLogger(__name__)


# ─── Bilimlar bazasi qidirish ─────────────────────────────────────────────────

async def _search_knowledge_base(question: str) -> Optional[str]:
    """Kalit so'z bo'yicha bilimlar bazasidan javob qidirish."""
    q = question.lower()
    try:
        items = await KnowledgeBase.filter(is_active=True).all()
        for item in items:
            if not item.keywords:
                continue
            for keyword in item.keywords.split(","):
                if keyword.strip().lower() in q:
                    return item.answer
    except Exception:
        pass
    return None


# ─── Rolli limitlar ──────────────────────────────────────────────────────────
ROLE_LIMITS = {
    "admin":           200,   # Cheksiz deyarli
    "boshliq":         100,
    "mmtb_boshligi":   100,
    "director":         50,
    "iqtisodchi":       50,
    "teacher":          20,
    "togarak_rahbari":  20,
    "parent":            5,   # To'lagan ota-ona
    "default":           3,   # Qarzdor / mehmon
}

DISCLAIMER = (
    "\n\n⚠️ _AI xato qilishi mumkin. "
    "Muhim qarorlarni rasmiy hisobotlar asosida tekshiring._"
)

# ─── Freemium limit ────────────────────────────────────────────────────────────

async def _check_ai_limit(user: User) -> tuple[bool, int, int]:
    """
    (ruxsat, hozirgi_count, limit) qaytaradi.
    Rol asosida kunlik limit tekshiradi.
    """
    role = user.role or "default"
    limit = ROLE_LIMITS.get(role, ROLE_LIMITS["default"])

    # To'lagan ota-ona → parent limiti oladi (default emas)
    if role == "parent":
        if (datetime.now() - user.created_at).days <= 7:
            return True, 0, limit  # Yangi foydalanuvchi — bepul hafta
        children = await Child.filter(parent_id=user.id).all()
        month_str = date.today().strftime("%Y-%m")
        is_paid = False
        for child in children:
            enrollments = await Enrollment.filter(child_id=child.id, status="active").all()
            for enr in enrollments:
                paid = await Payment.filter(
                    enrollment_id=enr.id, month=month_str, status="completed"
                ).exists()
                if paid:
                    is_paid = True
                    break
        if not is_paid:
            # Qarzdor → default limit
            limit = ROLE_LIMITS["default"]

    today_str = date.today().isoformat()
    key = f"ai_daily:{user.id}:{today_str}"
    try:
        count_str = await RedisService.get(key)
        count = int(count_str) if count_str else 0
        return count < limit, count, limit
    except Exception:
        return True, 0, limit  # Redis yo'q bo'lsa ruxsat ber


async def _increment_ai_count(user_id: int):
    today_str = date.today().isoformat()
    key = f"ai_daily:{user_id}:{today_str}"
    try:
        count_str = await RedisService.get(key)
        count = int(count_str) if count_str else 0
        await RedisService.set(key, str(count + 1), ttl=86400)
    except Exception:
        pass


# ─── Kontekst yaratish ────────────────────────────────────────────────────────

async def _build_context(user: User) -> str:
    role = user.role
    try:
        if role == "parent":
            children = await Child.filter(parent_id=user.id).all()
            if not children:
                return "Farzandlar: hali qo'shilmagan."
            lines = []
            month_str = date.today().strftime("%Y-%m")
            for child in children:
                enrollments = await Enrollment.filter(child_id=child.id, status="active").all()
                for enr in enrollments:
                    club = await Club.get_or_none(id=enr.club_id)
                    paid = await Payment.filter(
                        enrollment_id=enr.id, month=month_str, status="completed"
                    ).exists()
                    pay_status = "To'langan" if paid else "To'lanmagan"
                    lines.append(
                        f"- {child.full_name}: {club.name if club else '?'} | {pay_status}"
                    )
            return "Farzandlar:\n" + "\n".join(lines)

        elif role in ("teacher", "togarak_rahbari"):
            clubs = await Club.filter(teacher_id=user.id, is_active=True).all()
            if not clubs:
                return "To'garaklar: biriktirilmagan."
            lines = []
            for club in clubs:
                count = await Enrollment.filter(club_id=club.id, status="active").count()
                lines.append(f"- {club.name}: {count} o'quvchi")
            return "Sizning to'garaklaringiz:\n" + "\n".join(lines)
    except Exception:
        pass

    return "SmartDMTT — Bulungur tumani maktabgacha ta'lim boshqaruvi tizimi."


# ─── AI Provider funksiyalari ────────────────────────────────────────────────

async def _try_gemini(system: str, question: str, max_tokens: int = 1024) -> Optional[str]:
    """
    Gemini — yangi google.genai yoki eski google.generativeai bilan.
    MUHIM: GEMINI_API_KEY = aistudio.google.com dan olingan kalit.
    GOOGLE_API_KEY = Maps kaliti bo'lib, Gemini uchun ishlamaydi!
    """
    gemini_key = getattr(config, "GEMINI_API_KEY", "") or getattr(config, "GOOGLE_API_KEY", "")
    if not gemini_key:
        logger.warning("GEMINI_API_KEY topilmadi — aistudio.google.com dan oling")
        return None

    model_name = getattr(config, "GEMINI_MODEL", "gemini-2.0-flash")

    # 1. Yangi google.genai paketi bilan urinish
    try:
        from google import genai
        client = genai.Client(api_key=gemini_key)
        response = client.models.generate_content(
            model=model_name,
            contents=f"System: {system}\n\nUser: {question}",
        )
        text = response.text
        if text:
            logger.info(f"✅ Gemini ({model_name}) javob berdi [google.genai]")
            return text
    except ImportError:
        pass
    except Exception as e:
        err = str(e)
        if "429" in err or "quota" in err.lower() or "limit: 0" in err:
            logger.warning(
                "⚠️ Gemini limit:0 — bu kalit Gemini uchun emas! "
                "aistudio.google.com → Get API key → .env: GEMINI_API_KEY=..."
            )
            return None
        elif "not found" in err.lower() or "404" in err:
            logger.warning(f"Gemini model topilmadi: {model_name}")
        else:
            logger.error(f"Gemini xatosi (genai): {e}")

    # 2. Eski google.generativeai paketi bilan urinish
    try:
        import google.generativeai as genai_old
        genai_old.configure(api_key=gemini_key)
        model = genai_old.GenerativeModel(model_name, system_instruction=system)
        response = model.generate_content(question)
        if response.text:
            logger.info(f"✅ Gemini ({model_name}) javob berdi [generativeai]")
            return response.text
    except Exception as e2:
        err2 = str(e2)
        if "429" in err2 or "quota" in err2.lower() or "limit: 0" in err2:
            logger.warning("⚠️ Gemini kvota tugagan yoki kalit noto'g'ri")
        else:
            logger.error(f"Gemini xatosi (generativeai): {e2}")
    return None


async def _try_claude(system: str, question: str, max_tokens: int = 1024) -> Optional[str]:
    """Claude Haiku — kredit bo'lsa ishlaydi."""
    if not config.ANTHROPIC_API_KEY:
        return None
    try:
        import anthropic
        client = anthropic.Anthropic(api_key=config.ANTHROPIC_API_KEY)
        message = client.messages.create(
            model=config.AI_HELPER_MODEL,
            max_tokens=max_tokens,
            system=system,
            messages=[{"role": "user", "content": question}]
        )
        text = message.content[0].text if message.content else None
        if text:
            logger.info("✅ Claude javob berdi")
        return text
    except Exception as e:
        err = str(e)
        if "credit balance" in err.lower() or "400" in err:
            logger.warning("⚠️ Anthropic kredit tugagan")
        else:
            logger.error(f"Claude xatosi: {e}")
    return None


async def _try_openai(system: str, question: str, max_tokens: int = 1024) -> Optional[str]:
    """OpenAI GPT-4o-mini — kvota bo'lsa ishlaydi."""
    openai_key = getattr(config, "OPENAI_API_KEY", "")
    if not openai_key:
        return None
    try:
        import openai
        client = openai.OpenAI(api_key=openai_key)
        resp = client.chat.completions.create(
            model="gpt-4o-mini",
            max_tokens=max_tokens,
            messages=[
                {"role": "system", "content": system},
                {"role": "user", "content": question},
            ]
        )
        text = resp.choices[0].message.content
        if text:
            logger.info("✅ OpenAI javob berdi")
        return text
    except Exception as e:
        err = str(e)
        if "429" in err or "quota" in err.lower() or "insufficient_quota" in err:
            logger.warning("⚠️ OpenAI kvota tugagan")
        else:
            logger.error(f"OpenAI xatosi: {e}")
    return None



async def _try_groq(system: str, question: str, max_tokens: int = 1024) -> Optional[str]:
    """
    Groq (Llama 3) — bepul, tez, hech qanday billing kerak emas.
    Kalit: console.groq.com/keys → bepul ro'yxatdan o'tish
    """
    groq_key = getattr(config, "GROQ_API_KEY", "")
    if not groq_key:
        return None
    try:
        import groq as groq_lib
        client = groq_lib.Groq(api_key=groq_key)
        response = client.chat.completions.create(
            model=getattr(config, "GROQ_MODEL", "llama-3.1-8b-instant"),
            max_tokens=max_tokens,
            temperature=0.7,
            messages=[
                {"role": "system", "content": system},
                {"role": "user", "content": question},
            ]
        )
        text = response.choices[0].message.content
        if text:
            logger.info("✅ Groq (Llama) javob berdi")
        return text
    except Exception as e:
        err = str(e)
        if "429" in err or "rate_limit" in err.lower():
            logger.warning("⚠️ Groq rate limit — biroz kuting")
        else:
            logger.error(f"Groq xatosi: {e}")
    return None


async def _try_github(system: str, question: str, max_tokens: int = 1024) -> Optional[str]:
    """
    GitHub Models — bitta GitHub PAT bilan GPT-5, Llama 4, DeepSeek.
    Kalit: github.com/settings/tokens → "Generate new token (classic)"
    Endpoint: https://models.inference.ai.azure.com
    OpenAI SDK bilan ishlaydi.
    """
    github_token = getattr(config, "GITHUB_TOKEN", "")
    if not github_token:
        return None
    try:
        import openai
        client = openai.OpenAI(
            api_key=github_token,
            base_url="https://models.inference.ai.azure.com",
        )
        model_name = getattr(config, "GITHUB_AI_MODEL", "meta-llama/Llama-4-Scout-17B-16E-Instruct")
        resp = client.chat.completions.create(
            model=model_name,
            max_tokens=max_tokens,
            temperature=0.7,
            messages=[
                {"role": "system", "content": system},
                {"role": "user", "content": question},
            ]
        )
        text = resp.choices[0].message.content
        if text:
            logger.info(f"✅ GitHub Models ({model_name}) javob berdi")
        return text
    except Exception as e:
        err = str(e)
        if "429" in err or "rate" in err.lower():
            logger.warning("⚠️ GitHub Models rate limit")
        elif "401" in err or "403" in err:
            logger.warning("⚠️ GITHUB_TOKEN noto'g'ri yoki muddati tugagan")
        else:
            logger.error(f"GitHub Models xatosi: {e}")
    return None


# ─── ASOSIY FUNKSIYA ──────────────────────────────────────────────────────────

async def get_ai_answer(question: str, user_id: int) -> str:
    """
    AI dan javob olish.
    Zanjir: KnowledgeBase → Gemini → Claude → OpenAI → Xato xabari
    """
    if not question or not question.strip():
        return "Savolingizni yozing."

    user = await User.get_or_none(id=user_id)
    if not user:
        user = await User.get_or_none(telegram_id=user_id)
    if not user:
        return "Foydalanuvchi topilmadi."

    # Rolli limit tekshiruvi
    allowed, cur_count, limit = await _check_ai_limit(user)
    if not allowed:
        role = user.role or "default"
        return (
            f"⚠️ Kunlik limit tugadi ({cur_count}/{limit} ta so'rov).\n"
            f"{'To\'liq foydalanish uchun oylik to\'lovni amalga oshiring.' if role == 'parent' else 'Ertaga qayta urinib ko\'ring.'}"
        )

    # 1. Bilimlar bazasidan qidirish (API sarflamaydi)
    kb_answer = await _search_knowledge_base(question)
    if kb_answer:
        try:
            await AILog.create(
                log_type="helper", user_id=user.id,
                model="knowledge_base", prompt=question,
                response=kb_answer, source="db",
                is_test=getattr(user, "is_test", False)
            )
        except Exception:
            pass
        await _increment_ai_count(user.id)
        return kb_answer

    # Tizim prompt
    context = await _build_context(user)
    system = (
        f"Sen SmartDMTT Bulungur tumani maktabgacha ta'lim boshqaruv tizimining "
        f"aqlli yordamchisissan. "
        f"Foydalanuvchi: {user.full_name or 'Mehmon'}, Rol: {user.role}.\n"
        f"Qisqa va aniq javob ber. O'zbek tilida.\n\n"
        f"Joriy ma'lumotlar:\n{context}"
    )

    # 2. GitHub Models (TEST — faqat shu ishlaydi)
    answer = await _try_github(system, question)

    # 3. Groq/Llama (vaqtincha o'chirilgan)
    # if not answer:
    #     answer = await _try_groq(system, question)

    # 4. Gemini (vaqtincha o'chirilgan)
    # if not answer:
    #     answer = await _try_gemini(system, question)

    # 5. Claude (vaqtincha o'chirilgan)
    # if not answer:
    #     answer = await _try_claude(system, question)

    # 6. OpenAI (vaqtincha o'chirilgan)
    # if not answer:
    #     answer = await _try_openai(system, question)

    # Hamma ishlamadi
    if not answer:
        logger.error("❌ Barcha AI provayderlar javob bermadi")
        return (
            "Uzr, hozirda AI xizmati vaqtincha ishlamayapti. 🙏\n"
            "Savolingizni qayta yuboring yoki administratorga murojaat qiling."
        )

    # Loglash
    try:
        await AILog.create(
            log_type="helper", user_id=user.id,
            model="ai_chain", prompt=question,
            response=answer, source="api",
            is_test=getattr(user, "is_test", False)
        )
    except Exception:
        pass

    await _increment_ai_count(user.id)

    # Disclaimer — admin/boshliq/teacher da qo'shilmaydi (ular professional)
    role = user.role or "default"
    if role in ("parent", "default"):
        answer = answer + DISCLAIMER

    return answer


# ─── Legacy compat ────────────────────────────────────────────────────────────

async def get_llm_answer(question: str, user_id: str, extra_context: str = "") -> str:
    """Eski nom bilan moslik uchun."""
    try:
        uid = int(user_id)
    except (ValueError, TypeError):
        uid = 0
    return await get_ai_answer(question, uid)
