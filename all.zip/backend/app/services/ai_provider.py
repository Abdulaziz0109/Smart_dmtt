"""
SmartDMTT v4 — Multi-model AI Provider
Ichki tahlil: Claude Sonnet
Foydalanuvchi matni: Gemini 2.0 Flash yoki GPT-4o-mini (admin tanlaydi)
"""
import logging
from typing import Optional, Tuple

from app.core import config

logger = logging.getLogger(__name__)

LANG_NAMES = {
    "uz_latin":    "Uzbek Latin script",
    "uz_cyrillic": "Uzbek Cyrillic script (use ONLY Cyrillic characters, never mix with Latin)",
    "ru":          "Russian",
    "en":          "English",
    "tr":          "Turkish",
}


# ─── SystemSettings yordamchi ────────────────────────────────────────────────

async def get_helper_model() -> str:
    try:
        from app.models.system_settings import SystemSettings
        s = await SystemSettings.get_or_none(key="helper_ai_model")
        # gemini-flash ni default qilish — bepul ishlaydi
        return s.value if s else "gemini-flash"
    except Exception:
        return "gemini-flash"


async def get_user_text_model() -> str:
    try:
        from app.models.system_settings import SystemSettings
        s = await SystemSettings.get_or_none(key="user_text_model")
        return s.value if s else "gemini-flash"
    except Exception:
        return "gemini-flash"


# ─── Claude Sonnet (faqat ichki tahlil) ──────────────────────────────────────

async def call_claude_sonnet(
    system_en: str,
    message_en: str,
    max_tokens: int = 2048
) -> str:
    """Faqat ichki tahlil uchun."""
    if not config.ANTHROPIC_API_KEY:
        return ""
    try:
        import anthropic
        client = anthropic.Anthropic(api_key=config.ANTHROPIC_API_KEY)
        resp = client.messages.create(
            model="claude-sonnet-4-6",
            max_tokens=max_tokens,
            system=system_en,
            messages=[{"role": "user", "content": message_en}]
        )
        return resp.content[0].text if resp.content else ""
    except Exception as e:
        logger.error(f"Claude Sonnet xatosi: {e}")
        return ""


# ─── Claude Haiku (fallback) ─────────────────────────────────────────────────

async def call_claude_haiku(
    system_en: str,
    message: str,
    max_tokens: int = 1024
) -> str:
    if not config.ANTHROPIC_API_KEY:
        return ""
    try:
        import anthropic
        client = anthropic.Anthropic(api_key=config.ANTHROPIC_API_KEY)
        resp = client.messages.create(
            model=getattr(config, "AI_HELPER_MODEL", "claude-haiku-4-5-20251001"),
            max_tokens=max_tokens,
            system=system_en,
            messages=[{"role": "user", "content": message}]
        )
        return resp.content[0].text if resp.content else ""
    except Exception as e:
        logger.error(f"Claude Haiku xatosi: {e}")
        return ""


# ─── OpenAI GPT-4o-mini ──────────────────────────────────────────────────────

async def call_openai(
    system_en: str,
    message: str,
    max_tokens: int = 1024
) -> str:
    openai_key = getattr(config, "OPENAI_API_KEY", None)
    if not openai_key:
        raise ValueError("OPENAI_API_KEY topilmadi")
    try:
        import openai
        client = openai.AsyncOpenAI(api_key=openai_key)
        resp = await client.chat.completions.create(
            model="gpt-4o-mini",
            max_tokens=max_tokens,
            messages=[
                {"role": "system", "content": system_en},
                {"role": "user",   "content": message},
            ]
        )
        return resp.choices[0].message.content or ""
    except Exception as e:
        logger.error(f"OpenAI xatosi: {e}")
        raise


# ─── Gemini 2.0 Flash ────────────────────────────────────────────────────────

async def call_gemini(
    system_en: str,
    message: str,
    max_tokens: int = 1024
) -> str:
    """
    Gemini chaqiruvi.
    Model: gemini-2.0-flash (gemini-1.5-flash emas — o'chirilgan!)
    """
    google_key = getattr(config, "GOOGLE_API_KEY", None) or getattr(config, "GEMINI_API_KEY", None)
    if not google_key:
        raise ValueError("GOOGLE_API_KEY topilmadi")
    try:
        import google.generativeai as genai
        genai.configure(api_key=google_key)

        # To'g'ri model nomi (2025+ dan)
        # ❌ gemini-1.5-flash    — bu eski nom, 404 xatosi chiqadi
        # ✅ gemini-2.0-flash    — joriy bepul model
        # ✅ gemini-1.5-flash-latest — eski versiya, hali ishlaydi
        model_name = getattr(config, "GEMINI_MODEL", "gemini-2.0-flash")

        model = genai.GenerativeModel(
            model_name,
            system_instruction=system_en
        )
        resp = model.generate_content(message)
        return resp.text or ""
    except Exception as e:
        err = str(e)
        if "not found" in err.lower() or "404" in err:
            # Avtomatik fallback
            logger.warning(f"Gemini model topilmadi ({model_name}), gemini-1.5-flash-latest sinab ko'rilmoqda")
            try:
                import google.generativeai as genai
                model2 = genai.GenerativeModel("gemini-1.5-flash-latest", system_instruction=system_en)
                resp2 = model2.generate_content(message)
                return resp2.text or ""
            except Exception as e2:
                logger.error(f"Gemini fallback xatosi: {e2}")
                raise e2
        logger.error(f"Gemini xatosi: {e}")
        raise


# ─── Yordamchi AI (Gemini birinchi) ─────────────────────────────────────────

async def call_helper(
    system_en: str,
    message: str,
    lang: str = "uz_latin",
    max_tokens: int = 1024
) -> Tuple[str, str]:
    """
    Yordamchi AI chaqiruvi.
    Qaytaradi: (javob_matni, ishlatilgan_model)
    """
    model_name = await get_helper_model()

    # Gemini birinchi sinash (bepul)
    if model_name in ("gemini-flash", "gemini"):
        try:
            result = await call_gemini(system_en, message, max_tokens)
            if result:
                return result, "gemini-2.0-flash"
        except Exception as e:
            logger.warning(f"Gemini xatosi, keyingi fallback: {e}")

    # Claude Haiku
    if model_name == "claude-haiku" or model_name in ("gemini-flash", "gemini"):
        try:
            result = await call_claude_haiku(system_en, message, max_tokens)
            if result:
                return result, "claude-haiku"
        except Exception as e:
            logger.warning(f"Claude Haiku xatosi, OpenAI sinab ko'rilmoqda: {e}")

    # OpenAI oxirgi urinish
    try:
        result = await call_openai(system_en, message, max_tokens)
        if result:
            return result, "gpt-4o-mini"
    except Exception as e:
        logger.error(f"Barcha AI provayderlar ishlamadi: {e}")

    return (
        "Uzr, AI xizmat hozir vaqtincha ishlamayapti. Keyinroq urinib ko'ring. 🙏",
        "none"
    )


# ─── Foydalanuvchi tiliga aylantirish ────────────────────────────────────────

async def render_for_user(
    content_en: str,
    lang: str,
    context: str = ""
) -> str:
    if not content_en:
        return content_en

    lang_name = LANG_NAMES.get(lang, "Uzbek Latin script")
    system = (
        "You are a localization assistant for SmartDMTT kindergarten management system. "
        f"Render the given content naturally in {lang_name}. "
        "Keep all numbers, names, and percentages exactly as they are. "
        "Do not add or remove any information. "
        "Sound natural and warm, not like a literal translation."
    )
    user_msg = f"Context: {context}\n\nContent to localize:\n{content_en}" if context else content_en

    model_name = await get_user_text_model()
    try:
        if model_name in ("gemini-flash", "gemini"):
            return await call_gemini(system, user_msg, max_tokens=1024)
        else:
            return await call_openai(system, user_msg, max_tokens=1024)
    except Exception:
        try:
            return await call_gemini(system, user_msg, max_tokens=1024)
        except Exception:
            return content_en  # O'girmasdan qaytarish
