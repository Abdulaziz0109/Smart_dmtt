"""
SmartDMTT v4.0 — AI Anomaliya Tahlili (Anthropic Claude Sonnet)
Spec 9.3 bo'yicha: haftalik avtomatik tahlil.
"""
import json
import logging
from datetime import date, timedelta

from app.core import config
from app.models.club import Club
from app.models.child import Enrollment
from app.models.attendance import Attendance
from app.models.payment import Payment
from app.models.rating import Rating
from app.models.ai_log import AILog

logger = logging.getLogger(__name__)


async def _collect_club_stats(club_id: int, weeks: int = 4) -> dict:
    """To'garak statistikasini yig'ish."""
    today = date.today()
    start_date = today - timedelta(weeks=weeks)

    enrollments = await Enrollment.filter(club_id=club_id).all()
    active_count = sum(1 for e in enrollments if e.status == "active")

    attendance_records = await Attendance.filter(
        enrollment_id__in=[e.id for e in enrollments],
    ).filter(date__gte=start_date).all()

    total = len(attendance_records)
    present = sum(1 for a in attendance_records if a.status == "present")
    teacher_confirmed = sum(1 for a in attendance_records if a.teacher_confirmed)
    parent_confirmed = sum(1 for a in attendance_records if a.parent_confirmed is True)

    teacher_rate = (teacher_confirmed / total * 100) if total > 0 else 0
    parent_confirm_rate = (parent_confirmed / teacher_confirmed * 100) if teacher_confirmed > 0 else 0

    # Baholar
    enr_ids = [e.id for e in enrollments]
    ratings = await Rating.filter(
        rated_child_id__in=[e.child_id for e in enrollments],
        week__gte=f"{today.year}-W01"
    ).all()
    avg_rating = sum(r.rating for r in ratings) / len(ratings) if ratings else 0
    all_max = all(r.rating == 5 for r in ratings) if ratings else False

    # To'lov
    month_str = today.strftime("%Y-%m")
    paid_count = 0
    for enr in enrollments:
        if await Payment.filter(enrollment_id=enr.id, month=month_str, status="completed").exists():
            paid_count += 1

    payment_rate = (paid_count / active_count * 100) if active_count > 0 else 0

    return {
        "active_students": active_count,
        "attendance_teacher_pct": round(teacher_rate, 1),
        "attendance_parent_confirm_pct": round(parent_confirm_rate, 1),
        "avg_rating": round(avg_rating, 2),
        "all_max_ratings": all_max,
        "payment_rate_pct": round(payment_rate, 1),
    }


async def run_weekly_analysis(bot=None):
    """
    Haftalik anomaliya tahlili (APScheduler tomonidan chaqiriladi).
    Spec 9.3: har bog'cha, har to'garakdan statistika → Claude Sonnet.
    """
    if not config.ANTHROPIC_API_KEY:
        logger.warning("ANTHROPIC_API_KEY yo'q — AI tahlil o'tkazib yuborildi.")
        return

    clubs = await Club.filter(is_active=True).all()
    if not clubs:
        return

    anomalies_found = []

    for club in clubs:
        stats = await _collect_club_stats(club.id)

        # AI tahlil — GitHub Models → Claude Sonnet → Groq
        try:
            payload = {
                "club_name": club.name,
                "club_id": club.id,
                "stats": stats
            }
            payload_str = json.dumps(payload, ensure_ascii=False)

            SYSTEM_PROMPT = (
                "Sen maktabgacha talim tizimi anomaliya tahlilchisissan. "
                "Berilgan statistikani tahlil qil va FAQAT JSON format qaytarish. "
                "Misol: "
                '{"anomaliya": true, "daraja": "kritik", '
                '"savol_muallim": "...", "savol_otaona": "...", "xulosa": "..."}'
                " Anomaliya: barcha 5/5 baho, 95% davomat ota-ona tasdiqsiz, "
                "3 oy 0 sum, davomat keskin pasayish."
            )

            answer_text = None
            used_model = "none"

            # 1. GitHub Models — gpt-4o (tahlil uchun eng yaxshi, bepul)
            github_token = getattr(config, "GITHUB_TOKEN", "")
            if github_token:
                try:
                    import openai as openai_lib
                    gh_client = openai_lib.OpenAI(
                        api_key=github_token,
                        base_url="https://models.inference.ai.azure.com",
                    )
                    analysis_model = getattr(config, "GITHUB_AI_ANALYSIS_MODEL", "gpt-4o")
                    gh_resp = gh_client.chat.completions.create(
                        model=analysis_model,
                        max_tokens=1024,
                        messages=[
                            {"role": "system", "content": SYSTEM_PROMPT},
                            {"role": "user", "content": payload_str},
                        ]
                    )
                    answer_text = gh_resp.choices[0].message.content
                    used_model = analysis_model
                    logger.info(f"GitHub Models ({analysis_model}) tahlil qildi")
                except Exception as e_gh:
                    logger.warning(f"GitHub Models tahlil xatosi: {e_gh}")

            # 2. Claude Sonnet (vaqtincha o'chirilgan)
            # if not answer_text and config.ANTHROPIC_API_KEY:
            #     ...

            # 3. Groq fallback (vaqtincha o'chirilgan)
            # if not answer_text and groq_key:
            #     ...

            if not answer_text:
                logger.warning(f"Club {club.id} uchun AI javobi yoq")
                continue

            # JSON parse (ba'zan model markdown ```json``` qoshadi)
            try:
                clean = answer_text.strip()
                if "```" in clean:
                    parts = clean.split("```")
                    for part in parts:
                        part = part.strip().lstrip("json").strip()
                        if part.startswith("{"):
                            clean = part
                            break
                result = json.loads(clean)
            except json.JSONDecodeError:
                result = {"anomaliya": False, "daraja": "yoq", "xulosa": answer_text[:200]}

            # AI log saqlash
            await AILog.create(
                log_type="anomaly",
                model=used_model,
                prompt=payload_str,
                response=json.dumps(result, ensure_ascii=False),
                source="api",
                tokens_used=0,
                is_test=False
            )

            if result.get("anomaliya") and bot:
                anomalies_found.append((club, result))

        except Exception as e:
            logger.error(f"Club {club.id} tahlil xatosi: {e}")


    # Anomaliyalarni direktoerlarga yuborish
    if bot and anomalies_found:
        await _notify_directors(bot, anomalies_found)

    logger.info(f"✅ AI tahlil yakunlandi: {len(clubs)} to'garak, {len(anomalies_found)} anomaliya.")


async def _notify_directors(bot, anomalies: list):
    """Anomaliyalarni direktoerlarga xabar qilish."""
    from app.models.user import User
    from app.models.kindergarten import Kindergarten
    from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton

    for club, result in anomalies:
        daraja = result.get("daraja", "ortacha")
        xulosa = result.get("xulosa", "")
        savol_muallim = result.get("savol_muallim", "")

        emoji = "🔴" if daraja == "kritik" else "🟡"

        if club.kindergarten_id:
            kg = await Kindergarten.get_or_none(id=club.kindergarten_id)
            if kg and kg.director_id:
                director = await User.get_or_none(id=kg.director_id)
                if director and director.telegram_id:
                    kb = InlineKeyboardMarkup(inline_keyboard=[[
                        InlineKeyboardButton(text="📨 Muallimga savol", callback_data=f"anom_ask:{club.id}"),
                        InlineKeyboardButton(text="✅ Tekshirildi", callback_data=f"anom_ok:{club.id}"),
                        InlineKeyboardButton(text="🔴 MMTB ga", callback_data=f"anom_mmtb:{club.id}"),
                    ]])
                    await bot.send_message(
                        director.telegram_id,
                        f"{emoji} <b>Anomaliya: {club.name}</b>\n\n"
                        f"📊 {xulosa}\n\n"
                        f"❓ Muallimga savol: {savol_muallim}",
                        parse_mode="HTML",
                        reply_markup=kb
                    )
