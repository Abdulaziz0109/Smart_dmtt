"""
SmartDMTT - AI Servisi
"""
import time
import logging
from typing import List, Dict
import groq
from app.core import config
from app.models.user import User

logger = logging.getLogger(__name__)

class AIService:
    _client = None
    _conversations: dict = {}

    @classmethod
    def get_client(cls) -> groq.Groq:
        if cls._client is None:
            cls._client = groq.Groq(api_key=config.GROQ_API_KEY)
        return cls._client

    @classmethod
    def get_history(cls, user_id: str) -> list:
        uid = str(user_id)
        conv = cls._conversations.get(uid, {})
        history = conv.get("history", [])
        
        last_active = conv.get("last_active", 0)
        if time.time() - last_active > 86400:
            cls._conversations[uid] = {"history": [], "last_active": time.time(), "context": {}}
            return []
        
        return history[-config.AI_MAX_HISTORY:]

    @classmethod
    def add_to_history(cls, user_id: str, role: str, content: str):
        uid = str(user_id)
        if uid not in cls._conversations:
            cls._conversations[uid] = {"history": [], "last_active": time.time(), "context": {}}
        
        cls._conversations[uid]["history"].append({"role": role, "content": content})
        cls._conversations[uid]["last_active"] = time.time()
        
        max_hist = config.AI_MAX_HISTORY * 2
        if len(cls._conversations[uid]["history"]) > max_hist:
            cls._conversations[uid]["history"] = cls._conversations[uid]["history"][-max_hist:]

    @staticmethod
    async def get_llm_answer(prompt: str, user_id: str, history: list = None) -> str:
        client = AIService.get_client()
        messages = [{"role": "system", "content": "You are a helpful assistant."}] # TODO: Build proper system prompt
        if history:
            messages.extend(history)
        messages.append({"role": "user", "content": prompt})
        
        try:
            completion = client.chat.completions.create(
                model=config.GROQ_MODEL,
                messages=messages,
                temperature=0.7,
                max_tokens=config.AI_MAX_TOKENS,
            )
            return completion.choices[0].message.content
        except Exception as e:
            logger.error(f"AI Error: {e}")
            return "Kechirasiz, xatolik yuz berdi."
