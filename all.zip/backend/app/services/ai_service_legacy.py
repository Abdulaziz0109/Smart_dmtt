"""
SmartDMTT - Aqlli AI Yordamchi (Xotirali versiya)
Groq Llama 3.3 modeli bilan ishlaydi
Har bir foydalanuvchi uchun suhbat tarixi saqlanadi
"""
import asyncio
import json
import time
from typing import Optional
from datetime import datetime

import groq
from app.core import config
from app.services.user_service import UserService

# ─── Groq Client ─────────────────────────────────────────────
_client = None

def get_client() -> groq.Groq:
    global _client
    if _client is None:
        _client = groq.Groq(api_key=config.GROQ_API_KEY)
    return _client

# ─── Xotira tizimi ───────────────────────────────────────────
# {user_id: {"history": [...], "last_active": timestamp, "context": {}}}
_conversations: dict = {}

def get_history(user_id: str) -> list:
    """Foydalanuvchining suhbat tarixini olish."""
    uid = str(user_id)
    conv = _conversations.get(uid, {})
    history = conv.get("history", [])
    
    # Eski suhbatni tozalash (24 soatdan keyin)
    last_active = conv.get("last_active", 0)
    if time.time() - last_active > 86400:  # 24 soat
        _conversations[uid] = {"history": [], "last_active": time.time(), "context": {}}
        return []
    
    return history[-config.AI_MAX_HISTORY:]  # Oxirgi N ta xabar

def add_to_history(user_id: str, role: str, content: str):
    """Xotiraga yangi xabar qo'shish."""
    uid = str(user_id)
    if uid not in _conversations:
        _conversations[uid] = {"history": [], "last_active": time.time(), "context": {}}
    
    _conversations[uid]["history"].append({"role": role, "content": content})
    _conversations[uid]["last_active"] = time.time()
    
    # Xotirani cheklash
    max_hist = config.AI_MAX_HISTORY * 2  # user + assistant
    if len(_conversations[uid]["history"]) > max_hist:
        _conversations[uid]["history"] = _conversations[uid]["history"][-max_hist:]

def clear_history(user_id: str):
    """Foydalanuvchi suhbatini tozalash."""
    uid = str(user_id)
    _conversations[uid] = {"history": [], "last_active": time.time(), "context": {}}

def get_active_users() -> int:
    """Faol foydalanuvchilar soni (oxirgi 1 soat)."""
    now = time.time()
    return sum(1 for c in _conversations.values() if now - c.get("last_active", 0) < 3600)

# ─── System Prompt ────────────────────────────────────────────
async def _build_system_prompt(user_id: str) -> str:
    """Rol asosida dinamik system prompt yaratish."""
    uid = str(user_id)
    
    try:
        user, roles = await UserService.find_user(uid)
        role = roles[0] if roles else "Mehmon"
        user_name = user.full_name if user else "Foydalanuvchi"
    except:
        role = "Mehmon"
        user_name = "Foydalanuvchi"
    
    now = datetime.now().strftime("%d.%m.%Y %H:%M")
    
    base = f"""Sen SmartDMTT - bog'cha boshqaruv tizimining aqlli yordamchisisan.
Hozirgi sana va vaqt: {now}
Foydalanuvchi: {user_name} (Rol: {role})

QOIDALAR:
1. Har doim O'zbek tilida javob ber (agar boshqa til so'ralsa, o'sha tilda)
2. Qisqa, aniq va foydali javob ber
3. Agar bilmasang - "Bu haqida ma'lumotim yo'q" de, taxmin qilma
4. Bog'cha, to'garaklar, to'lovlar, davomat haqida yordam ber
5. Maxfiy ma'lumotlarni (token, parol) hech qachon oshkor qilma
6. Xushmuomala va professional bo'l

BOG'CHA HAQIDA UMUMIY MA'LUMOT:
SmartDMTT - zamonaviy bog'cha boshqaruv platformasi:
• To'garaklar: sport, san'at, musiqa, matematika va boshqalar
• Davomat: real vaqtda kuzatish
• To'lovlar: oylik to'lov tizimi
• Ko'p tilli: uz, ru, en, tr
"""
    return base

async def get_llm_answer(question: str, user_id: str) -> str:
    """Foydalanuvchi savoliga LLM orqali javob olish."""
    
    # 1. System Prompt
    system_prompt = await _build_system_prompt(user_id)
    
    # 2. History
    history = get_history(user_id)
    
    # 3. Build messages
    messages = [
        {"role": "system", "content": system_prompt}
    ]
    messages.extend(history)
    messages.append({"role": "user", "content": question})
    
    # 4. Call Groq
    try:
        client = get_client()
        
        # Use asyncio.to_thread for blocking call
        completion = await asyncio.to_thread(
            client.chat.completions.create,
            model=config.GROQ_MODEL,
            messages=messages,
            temperature=0.7,
            max_tokens=config.AI_MAX_TOKENS,
        )
        
        answer = completion.choices[0].message.content
        
        # Update history
        add_to_history(user_id, "user", question)
        add_to_history(user_id, "assistant", answer)
        
        return answer
    except Exception as e:
        print(f"AI Error: {e}")
        return "Kechirasiz, xatolik yuz berdi. Keyinroq urinib ko'ring."
