"""
SmartDMTT v4.0 — DB boshlang'ich ma'lumotlar
Test foydalanuvchilar, namuna bog'chalar va to'garaklar.
"""
import logging
import bcrypt

from app.core import config
from app.models.user import User
from app.models.kindergarten import Kindergarten
from app.models.club import Club

logger = logging.getLogger(__name__)

# ─── Test foydalanuvchilar ────────────────────────────────────────────────────

TEST_USERS = [
    {
        "phone": "+998900000001",
        "full_name": "Admin Test",
        "role": "admin",
        "password": "admin123",
        "is_test": True,
    },
    {
        "phone": "+998900000002",
        "full_name": "Boshliq Test",
        "role": "boshliq",
        "password": "boshliq123",
        "is_test": True,
    },
    {
        "phone": "+998900000003",
        "full_name": "Direktor Test",
        "role": "director",
        "password": "direktor123",
        "is_test": True,
    },
    {
        "phone": "+998900000004",
        "full_name": "Muallim Test",
        "role": "teacher",
        "password": "muallim123",
        "is_test": True,
    },
    {
        "phone": "+998900000005",
        "full_name": "Ota-ona Test",
        "role": "parent",
        "password": "otaona123",
        "is_test": True,
    },
]

# ─── Namuna bog'chalar ────────────────────────────────────────────────────────

SAMPLE_KINDERGARTENS = [
    {"number": 1, "name": "1-son MTM", "address": "Bulungur, Markaziy ko'cha 1"},
    {"number": 2, "name": "2-son MTM", "address": "Bulungur, Bog'iston ko'cha 5"},
    {"number": 3, "name": "3-son MTM", "address": "Bulungur, Navoi ko'cha 12"},
]

# ─── Namuna to'garaklar ───────────────────────────────────────────────────────

SAMPLE_CLUBS = [
    {
        "name": "Ingliz tili",
        "description": "Boshlang'ich ingliz tili kursi",
        "price": 150000,
        "schedule_days": "Mon,Wed,Fri",
        "schedule_time": "09:00",
        "age_min": 4,
        "age_max": 7,
        "max_members": 15,
        "min_members": 5,
        "kindergarten_id": 1,
    },
    {
        "name": "Mental arifmetika",
        "description": "Aqliy arifmetika va mantiqiy fikrlash",
        "price": 180000,
        "schedule_days": "Tue,Thu",
        "schedule_time": "10:00",
        "age_min": 5,
        "age_max": 7,
        "max_members": 12,
        "min_members": 5,
        "kindergarten_id": 1,
    },
    {
        "name": "Shaxmat",
        "description": "Shaxmat asoslari",
        "price": 120000,
        "schedule_days": "Mon,Thu",
        "schedule_time": "14:00",
        "age_min": 5,
        "age_max": 7,
        "max_members": 10,
        "min_members": 5,
        "kindergarten_id": 2,
    },
    {
        "name": "Raqs",
        "description": "Xalq raqslari",
        "price": 100000,
        "schedule_days": "Tue,Fri",
        "schedule_time": "15:00",
        "age_min": 3,
        "age_max": 7,
        "max_members": 20,
        "min_members": 8,
        "kindergarten_id": 2,
    },
    {
        "name": "Robototexnika",
        "description": "Bolalar uchun robototexnika",
        "price": 200000,
        "schedule_days": "Wed,Sat",
        "schedule_time": "11:00",
        "age_min": 5,
        "age_max": 7,
        "max_members": 10,
        "min_members": 5,
        "kindergarten_id": 3,
    },
]


def _hash_password(password: str) -> str:
    return bcrypt.hashpw(password.encode(), bcrypt.gensalt()).decode()


async def init_db():
    """
    Boshlang'ich ma'lumotlarni yaratish.
    Mavjud bo'lsa o'tkazib yuboriladi.
    """
    logger.info("DB init o'tkazib yuborildi — ma'lumotlar bazasi tayyor")


async def run_init():
    """Standalone ishga tushirish uchun."""
    from tortoise import Tortoise
    await Tortoise.init(
        db_url=config.DATABASE_URL,
        modules={"models": ["app.models"]}
    )
    await Tortoise.generate_schemas(safe=True)
    await init_db()
    await Tortoise.close_connections()


if __name__ == "__main__":
    import asyncio
    asyncio.run(run_init())
