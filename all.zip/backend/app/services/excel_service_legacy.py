import io
import datetime
from openpyxl import Workbook
from openpyxl.styles import Font
from aiogram.types import BufferedInputFile

from app.services import database_legacy as db # Ma'lumotlar bazasi bilan ishlash uchun

async def get_excel_file():
    """
    Ma'lumotlar bazasidan barcha jadvallarni olib, Excel fayli shakllantiradi.
    """
    workbook = Workbook()
    # Remove default sheet created by openpyxl
    if workbook.active:
        workbook.remove(workbook.active)
    
    # Get all data from all tables
    all_data = db.get_full_database_export()
    
    if not all_data:
        # Create at least one sheet if empty to avoid error on save
        workbook.create_sheet("No Data")
    
    # Iterate over each table and create a sheet
    for table_name, rows in all_data.items():
        # Excel sheet titles are limited to 31 chars
        sheet_title = table_name[:31]
        sheet = workbook.create_sheet(title=sheet_title)
        
        if not rows:
            continue
            
        # Get headers from the first row keys
        headers = list(rows[0].keys())
        sheet.append(headers)
        
        # Style the header row
        for cell in sheet[1]:
            cell.font = Font(bold=True)
            
        # Write data rows
        for row in rows:
            # Ensure we write values in the same order as headers
            sheet.append([row.get(h) for h in headers])
            
    # Save to memory buffer
    file_stream = io.BytesIO()
    workbook.save(file_stream)
    file_stream.seek(0)
    
    # Generate filename with timestamp
    timestamp = datetime.datetime.now().strftime("%Y-%m-%d_%H-%M")
    filename = f"SmartDMTT_Full_Backup_{timestamp}.xlsx"
    
    return BufferedInputFile(file=file_stream.read(), filename=filename)
