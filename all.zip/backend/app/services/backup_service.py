"""
SmartDMTT v4 — Backup servisi
Kunlik 02:00, haftalik (dushanba) 02:30
"""
import logging
import os
import shutil
from datetime import date, datetime, timedelta
from pathlib import Path

from app.core import config

logger = logging.getLogger(__name__)

# DB yo'li
_DB_PATH = Path(config.DATABASE_URL.replace("sqlite://", "", 1))
if not _DB_PATH.is_absolute():
    _DB_PATH = Path(__file__).resolve().parents[3] / _DB_PATH

_BACKUP_DIR = _DB_PATH.parent / "backups"
_KEEP_DAILY  = int(getattr(config, "BACKUP_KEEP_DAILY", 30))
_KEEP_WEEKLY = int(getattr(config, "BACKUP_KEEP_WEEKLY", 12))


def _ensure_dirs():
    (_BACKUP_DIR / "daily").mkdir(parents=True, exist_ok=True)
    (_BACKUP_DIR / "weekly").mkdir(parents=True, exist_ok=True)


def _cleanup_old(folder: Path, keep: int):
    """Eng eski backup fayllarni o'chiradi, faqat `keep` ta qoldiradi."""
    files = sorted(folder.glob("*.sqlite"), key=lambda f: f.stat().st_mtime)
    for f in files[:-keep] if len(files) > keep else []:
        try:
            f.unlink()
            logger.info(f"Eski backup o'chirildi: {f.name}")
        except Exception as e:
            logger.warning(f"Backup o'chirishda xato: {e}")


async def create_backup() -> str:
    """Kunlik backup yaratish."""
    _ensure_dirs()
    if not _DB_PATH.exists():
        logger.warning(f"DB topilmadi: {_DB_PATH}")
        return ""

    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    dest = _BACKUP_DIR / "daily" / f"database_{timestamp}.sqlite"
    try:
        shutil.copy2(str(_DB_PATH), str(dest))
        _cleanup_old(_BACKUP_DIR / "daily", _KEEP_DAILY)
        logger.info(f"Kunlik backup: {dest.name}")
        return str(dest)
    except Exception as e:
        logger.error(f"Kunlik backup xatosi: {e}")
        return ""


async def create_weekly_backup() -> str:
    """Haftalik backup yaratish."""
    _ensure_dirs()
    if not _DB_PATH.exists():
        logger.warning(f"DB topilmadi: {_DB_PATH}")
        return ""

    week = date.today().strftime("%Y_W%W")
    dest = _BACKUP_DIR / "weekly" / f"database_{week}.sqlite"
    try:
        shutil.copy2(str(_DB_PATH), str(dest))
        _cleanup_old(_BACKUP_DIR / "weekly", _KEEP_WEEKLY)
        logger.info(f"Haftalik backup: {dest.name}")
        return str(dest)
    except Exception as e:
        logger.error(f"Haftalik backup xatosi: {e}")
        return ""
