"""
SmartDMTT - Excel Servisi
"""
import io
import datetime
from openpyxl import Workbook
from openpyxl.styles import Font
from aiogram.types import BufferedInputFile
from app.core import config
from app.models.user import User
# from backend.app.core.database import get_full_database_export # TODO: Implement DAL

class ExcelService:
    @staticmethod
    async def generate_full_report() -> BufferedInputFile:
        workbook = Workbook()
        if workbook.active:
            workbook.remove(workbook.active)
        
        # TODO: Fetch data using Tortoise ORM
        # all_data = await DatabaseService.get_export_data() 
        all_data = {} # Stub
        
        if not all_data:
            workbook.create_sheet("No Data")
        
        file_stream = io.BytesIO()
        workbook.save(file_stream)
        file_stream.seek(0)
        
        timestamp = datetime.datetime.now().strftime("%Y-%m-%d_%H-%M")
        filename = f"SmartDMTT_Full_Backup_{timestamp}.xlsx"
        
        return BufferedInputFile(file=file_stream.read(), filename=filename)
