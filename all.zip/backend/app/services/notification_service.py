from aiogram import Bot
from app.core import config
import asyncio

class NotificationService:
    _bot: Bot = None
    
    @classmethod
    def setup(cls, bot: Bot):
        cls._bot = bot
    
    @classmethod
    async def child_arrived(cls, parent_id: int, child_name: str, time: str):
        """Bola kelganda ota-onaga xabar."""
        if not cls._bot:
            return
        try:
            await cls._bot.send_message(
                parent_id,
                f"✅ {child_name} bog'chaga keldi!\n🕐 Vaqt: {time}"
            )
        except Exception as e:
            print(f"Notification error: {e}")
    
    @classmethod
    async def payment_reminder(cls, parent_id: int, child_name: str, 
                                club_name: str, amount: int, days_left: int):
        """To'lov eslatmasi."""
        if not cls._bot:
            return
        try:
            await cls._bot.send_message(
                parent_id,
                f"💳 To'lov eslatmasi!\n"
                f"👦 Bola: {child_name}\n"
                f"🎯 To'garak: {club_name}\n"
                f"💰 Summa: {amount:,} so'm\n"
                f"📅 {days_left} kun qoldi"
            )
        except Exception as e:
            print(f"Notification error: {e}")
    
    @classmethod
    async def broadcast(cls, user_ids: list, message: str):
        """Ko'plab foydalanuvchilarga xabar."""
        if not cls._bot:
            return
        sent, failed = 0, 0
        for uid in user_ids:
            try:
                await cls._bot.send_message(uid, message)
                sent += 1
                await asyncio.sleep(0.05)  # Rate limit
            except:
                failed += 1
        return {"sent": sent, "failed": failed}
