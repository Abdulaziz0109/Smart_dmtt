"""
SmartDMTT — Redis Service
OTP, session, cache, rate-limit uchun markaziy Redis wrapper.
Redis ishlamasa — xotirada ishlashda davom etadi (fallback).
"""
import json
import time
import logging
import asyncio
from typing import Optional, Any
from app.core import config

logger = logging.getLogger(__name__)

# ─── Xotirada fallback (Redis yo'q bo'lsa) ───────────────────────────────────
_memory_store: dict = {}


class RedisService:
    """
    Redis wrapper. Redis ulanmasa xotirada ishlaydi.
    Production uchun Redis albatta kerak (restart = ma'lumot yo'qoladi).
    """
    _client = None
    _available = False

    @classmethod
    async def connect(cls):
        """Redis ga ulanish. Muvaffaqiyatsiz bo'lsa fallback rejimda ishlaydi."""
        try:
            import redis.asyncio as aioredis
            cls._client = aioredis.from_url(
                config.REDIS_URL,
                password=config.REDIS_PASSWORD or None,
                encoding="utf-8",
                decode_responses=True,
                socket_connect_timeout=3,
                socket_timeout=3,
            )
            await cls._client.ping()
            cls._available = True
            logger.info("✅ Redis ulanish muvaffaqiyatli")
        except Exception as e:
            cls._available = False
            logger.warning(f"⚠️ Redis ulanmadi, xotirada ishlaydi: {e}")

    @classmethod
    async def set(cls, key: str, value: Any, ttl: int = None) -> bool:
        """Qiymat saqlash."""
        data = json.dumps(value, ensure_ascii=False)
        if cls._available and cls._client:
            try:
                if ttl:
                    await cls._client.setex(key, ttl, data)
                else:
                    await cls._client.set(key, data)
                return True
            except Exception as e:
                logger.error(f"Redis set xatosi: {e}")
        # Fallback: xotirada
        _memory_store[key] = {
            "value": data,
            "expires": time.time() + ttl if ttl else None
        }
        return True

    @classmethod
    async def get(cls, key: str) -> Optional[Any]:
        """Qiymat olish."""
        if cls._available and cls._client:
            try:
                raw = await cls._client.get(key)
                return json.loads(raw) if raw else None
            except Exception as e:
                logger.error(f"Redis get xatosi: {e}")
        # Fallback: xotirada
        entry = _memory_store.get(key)
        if not entry:
            return None
        if entry["expires"] and time.time() > entry["expires"]:
            del _memory_store[key]
            return None
        return json.loads(entry["value"])

    @classmethod
    async def delete(cls, key: str) -> bool:
        """Kalit o'chirish."""
        if cls._available and cls._client:
            try:
                await cls._client.delete(key)
                return True
            except Exception as e:
                logger.error(f"Redis delete xatosi: {e}")
        _memory_store.pop(key, None)
        return True

    @classmethod
    async def exists(cls, key: str) -> bool:
        """Kalit mavjudligini tekshirish."""
        if cls._available and cls._client:
            try:
                return bool(await cls._client.exists(key))
            except:
                pass
        entry = _memory_store.get(key)
        if not entry:
            return False
        if entry["expires"] and time.time() > entry["expires"]:
            del _memory_store[key]
            return False
        return True

    @classmethod
    async def incr(cls, key: str, ttl: int = None) -> int:
        """Raqamni 1 ga oshirish (rate limiting uchun)."""
        if cls._available and cls._client:
            try:
                val = await cls._client.incr(key)
                if ttl and val == 1:
                    await cls._client.expire(key, ttl)
                return val
            except Exception as e:
                logger.error(f"Redis incr xatosi: {e}")
        # Fallback
        entry = _memory_store.get(key)
        if not entry or (entry["expires"] and time.time() > entry["expires"]):
            _memory_store[key] = {
                "value": json.dumps(1),
                "expires": time.time() + ttl if ttl else None
            }
            return 1
        current = json.loads(entry["value"])
        new_val = current + 1
        _memory_store[key]["value"] = json.dumps(new_val)
        return new_val

    @classmethod
    def is_available(cls) -> bool:
        return cls._available

    # ─── OTP uchun maxsus metodlar ───────────────────────────────────────────

    @classmethod
    async def save_otp(cls, user_id: str, otp: str) -> None:
        """OTP ni Redis da saqlash (5 daqiqa TTL)."""
        import hashlib
        key = f"otp:{user_id}"
        await cls.set(key, {
            "hash": hashlib.sha256(otp.encode()).hexdigest(),
            "attempts": 0,
            "created_at": time.time()
        }, ttl=config.OTP_EXPIRE_SECONDS)

    @classmethod
    async def verify_otp(cls, user_id: str, otp: str) -> tuple[bool, str]:
        """
        OTP tekshirish.
        Returns: (muvaffaqiyatli, xabar)
        """
        import hashlib
        key = f"otp:{user_id}"
        data = await cls.get(key)

        if not data:
            return False, "OTP muddati tugagan yoki yuborilmagan"

        if data["attempts"] >= config.OTP_MAX_ATTEMPTS:
            await cls.delete(key)
            return False, f"Ko'p urinish. Yangi OTP so'rang"

        otp_hash = hashlib.sha256(otp.encode()).hexdigest()
        if data["hash"] != otp_hash:
            data["attempts"] += 1
            remaining = config.OTP_MAX_ATTEMPTS - data["attempts"]
            await cls.set(key, data, ttl=config.OTP_EXPIRE_SECONDS)
            return False, f"Noto'g'ri kod. {remaining} ta urinish qoldi"

        await cls.delete(key)
        return True, "OK"

    # ─── Qurilma ishonch ─────────────────────────────────────────────────────

    @classmethod
    async def trust_device(cls, user_id: str, device_hash: str) -> None:
        """Qurilmani ishonchli deb belgilash."""
        key = f"trusted_device:{user_id}:{device_hash}"
        await cls.set(key, {"trusted": True, "since": time.time()},
                      ttl=config.DEVICE_TRUST_DAYS * 86400)

    @classmethod
    async def is_device_trusted(cls, user_id: str, device_hash: str) -> bool:
        """Qurilma ishonchli ekanligini tekshirish."""
        key = f"trusted_device:{user_id}:{device_hash}"
        return await cls.exists(key)

    # ─── Rate Limiting ───────────────────────────────────────────────────────

    @classmethod
    async def check_rate_limit(cls, key: str, max_attempts: int,
                               window_seconds: int) -> tuple[bool, int]:
        """
        Rate limit tekshirish.
        Returns: (ruxsat_berildi, qolgan_urinishlar)
        """
        count = await cls.incr(f"rl:{key}", ttl=window_seconds)
        remaining = max(0, max_attempts - count)
        return count <= max_attempts, remaining

    # ─── AI Xotira (persistent) ──────────────────────────────────────────────

    @classmethod
    async def get_ai_history(cls, user_id: str) -> list:
        """AI suhbat tarixini olish."""
        key = f"ai_history:{user_id}"
        data = await cls.get(key)
        return data if isinstance(data, list) else []

    @classmethod
    async def save_ai_history(cls, user_id: str, history: list) -> None:
        """AI suhbat tarixini saqlash (24 soat TTL)."""
        key = f"ai_history:{user_id}"
        # Faqat oxirgi 40 ta xabar
        trimmed = history[-40:] if len(history) > 40 else history
        await cls.set(key, trimmed, ttl=86400)

    @classmethod
    async def clear_ai_history(cls, user_id: str) -> None:
        """AI suhbat tarixini tozalash."""
        await cls.delete(f"ai_history:{user_id}")
