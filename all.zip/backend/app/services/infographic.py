"""
SmartDMTT v4.0 — Infografika Servisi
Pillow bilan haftalik hisobot rasmlari (kengaytirilgan).
"""
import io
import logging
from datetime import date, timedelta

logger = logging.getLogger(__name__)

# ── Brend ranglar ─────────────────────────────────────────────────────────────
C_BG       = (248, 250, 252)   # Fon
C_WHITE    = (255, 255, 255)
C_PRIMARY  = (11,  94,  80)    # #0B5E50
C_PRIMARY2 = (20, 132, 122)    # #14847A
C_SUCCESS  = (5,  150, 105)    # #059669
C_DANGER   = (220, 38,  38)    # #DC2626
C_WARNING  = (217, 119, 6)     # #D97706
C_BLUE     = (37,  99, 235)    # #2563EB
C_GRAY     = (107, 114, 128)   # #6B7280
C_LIGHT    = (229, 234, 233)   # #E5EAE9
C_DARK     = (17,  24,  39)    # #111827
C_CARD     = (255, 255, 255)


def _pil():
    try:
        from PIL import Image, ImageDraw, ImageFont
        return Image, ImageDraw, ImageFont
    except ImportError:
        raise RuntimeError("Pillow o'rnatilmagan: pip install Pillow")


def _font(ImageFont, size: int = 14):
    """Font yuklash — system font topilmasa default."""
    candidates = [
        "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf",
        "/usr/share/fonts/truetype/liberation/LiberationSans-Bold.ttf",
        "C:/Windows/Fonts/arialbd.ttf",
        "C:/Windows/Fonts/calibrib.ttf",
    ]
    for path in candidates:
        try:
            return ImageFont.truetype(path, size)
        except Exception:
            pass
    try:
        return ImageFont.load_default(size=size)
    except Exception:
        return ImageFont.load_default()


def _font_reg(ImageFont, size: int = 14):
    candidates = [
        "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf",
        "/usr/share/fonts/truetype/liberation/LiberationSans-Regular.ttf",
        "C:/Windows/Fonts/arial.ttf",
        "C:/Windows/Fonts/calibri.ttf",
    ]
    for path in candidates:
        try:
            return ImageFont.truetype(path, size)
        except Exception:
            pass
    try:
        return ImageFont.load_default(size=size)
    except Exception:
        return ImageFont.load_default()


def _rect(draw, x, y, w, h, fill, radius=10):
    """Rounded rectangle."""
    try:
        draw.rounded_rectangle([(x, y), (x+w, y+h)], radius=radius, fill=fill)
    except AttributeError:
        draw.rectangle([(x, y), (x+w, y+h)], fill=fill)


def _bar(draw, x, y, w, h, pct, radius=6):
    """Progress bar."""
    color = C_SUCCESS if pct >= 80 else (C_WARNING if pct >= 60 else C_DANGER)
    _rect(draw, x, y, w, h, C_LIGHT, radius)
    fill_w = max(4, int(w * pct / 100))
    _rect(draw, x, y, fill_w, h, color, radius)
    return color


# ── Direktor haftalik ─────────────────────────────────────────────────────────

async def create_director_weekly(kindergarten_id: int) -> bytes:
    """Direktor uchun bog'cha haftalik statistika rasmi."""
    Image, ImageDraw, ImageFont = _pil()

    from app.models.club import Club, Enrollment
    from app.models.child import Attendance
    from app.models.payment import Payment
    from app.models.kindergarten import Kindergarten

    kg = await Kindergarten.get_or_none(id=kindergarten_id)
    kg_name = kg.name if kg else f"Bog'cha #{kindergarten_id}"

    today      = date.today()
    week_start = today - timedelta(days=today.weekday())
    month_str  = today.strftime("%Y-%m")

    clubs = await Club.filter(kindergarten_id=kindergarten_id, is_active=True).all()
    total_enrolled = 0
    total_paid     = 0
    total_att      = 0
    total_present  = 0
    club_stats     = []

    for club in clubs:
        enrollments = await Enrollment.filter(club_id=club.id, status="active").all()
        enr_ids     = [e.id for e in enrollments]

        att_week = await Attendance.filter(enrollment_id__in=enr_ids, date__gte=week_start).all() if enr_ids else []
        att_c    = len(att_week)
        pres_c   = sum(1 for a in att_week if a.status == "present")

        paid_c = await Payment.filter(
            enrollment_id__in=enr_ids, month=month_str, status="completed"
        ).count() if enr_ids else 0

        total_enrolled += len(enrollments)
        total_paid     += paid_c
        total_att      += att_c
        total_present  += pres_c

        att_pct = round(pres_c / att_c * 100) if att_c else 0
        pay_pct = round(paid_c / len(enrollments) * 100) if enrollments else 0
        club_stats.append((club.name, len(enrollments), att_pct, pay_pct))

    att_pct_total = round(total_present / total_att * 100) if total_att else 0
    pay_pct_total = round(total_paid / total_enrolled * 100) if total_enrolled else 0
    debt_count    = total_enrolled - total_paid

    # ── Kanvas ──────────────────────────────────────────────────────────────
    W = 800
    H = 200 + 140 + len(club_stats[:6]) * 56 + 80
    img  = Image.new("RGB", (W, H), C_BG)
    draw = ImageDraw.Draw(img)

    fB18 = _font(ImageFont, 18)
    fB14 = _font(ImageFont, 14)
    fB12 = _font(ImageFont, 12)
    fR12 = _font_reg(ImageFont, 12)
    fR11 = _font_reg(ImageFont, 11)

    # ── Header ──────────────────────────────────────────────────────────────
    try:
        draw.rounded_rectangle([(0, 0), (W, 90)], radius=0, fill=C_PRIMARY)
    except Exception:
        draw.rectangle([(0, 0), (W, 90)], fill=C_PRIMARY)

    draw.text((W//2, 28), "SmartDMTT — Haftalik Hisobot", font=fB18, fill=C_WHITE, anchor="mm")
    draw.text((W//2, 60), f"{kg_name}  |  {week_start.strftime('%d.%m')} – {today.strftime('%d.%m.%Y')}", font=fR12, fill=(200, 230, 225), anchor="mm")

    # ── 4 ta KPI karta ───────────────────────────────────────────────────────
    kpis = [
        ("To'garaklar", len(clubs),         None,           "📚"),
        ("O'quvchilar", total_enrolled,      None,           "👶"),
        ("Davomat",     f"{att_pct_total}%", att_pct_total,  "📅"),
        ("To'lov",      f"{pay_pct_total}%", pay_pct_total,  "💰"),
    ]
    card_w = (W - 60) // 4 - 10
    for i, (label, val, pct, icon) in enumerate(kpis):
        cx = 30 + i * (card_w + 13)
        _rect(draw, cx, 110, card_w, 110, C_CARD, radius=12)
        draw.text((cx + card_w//2, 130), icon, font=fB18, fill=C_PRIMARY, anchor="mm")
        val_color = C_DARK
        if pct is not None:
            val_color = C_SUCCESS if pct >= 80 else (C_WARNING if pct >= 60 else C_DANGER)
        draw.text((cx + card_w//2, 170), str(val), font=fB14, fill=val_color, anchor="mm")
        draw.text((cx + card_w//2, 198), label, font=fR11, fill=C_GRAY, anchor="mm")

    # Qo'shimcha: qarzdorlar
    if debt_count > 0:
        _rect(draw, 30, 232, W-60, 36, (254, 242, 242), radius=8)
        draw.text((W//2, 250), f"⚠️  {debt_count} ta o'quvchi bu oy to'lov qilmagan", font=fR12, fill=C_DANGER, anchor="mm")
    y_cur = 282

    # ── To'garaklar jadvali ──────────────────────────────────────────────────
    _rect(draw, 30, y_cur, W-60, 32, C_PRIMARY, radius=8)
    draw.text((50,  y_cur+16), "To'garak",   font=fB12, fill=C_WHITE, anchor="lm")
    draw.text((530, y_cur+16), "O'quvchi",   font=fB12, fill=C_WHITE, anchor="mm")
    draw.text((620, y_cur+16), "Davomat",    font=fB12, fill=C_WHITE, anchor="mm")
    draw.text((730, y_cur+16), "To'lov",     font=fB12, fill=C_WHITE, anchor="mm")
    y_cur += 40

    for i, (name, cnt, att_p, pay_p) in enumerate(club_stats[:6]):
        row_bg = C_WHITE if i % 2 == 0 else (245, 248, 247)
        _rect(draw, 30, y_cur, W-60, 48, row_bg, radius=6)

        draw.text((50,  y_cur+24), name[:35], font=fR12, fill=C_DARK, anchor="lm")
        draw.text((530, y_cur+24), str(cnt), font=fB12, fill=C_DARK, anchor="mm")

        # Davomat mini bar
        _bar(draw, 570, y_cur+18, 100, 12, att_p, radius=4)
        draw.text((680, y_cur+24), f"{att_p}%", font=fR11, fill=C_GRAY, anchor="lm")

        # To'lov mini bar
        _bar(draw, 570, y_cur+34, 100, 12, pay_p, radius=4)
        draw.text((730, y_cur+24), f"{pay_p}%", font=fR11, fill=C_GRAY, anchor="mm")
        y_cur += 56

    # ── Footer ───────────────────────────────────────────────────────────────
    _rect(draw, 0, H-50, W, 50, C_LIGHT, radius=0)
    draw.text((W//2, H-25), "SmartDMTT v4 — Bulungur tuman MMTB", font=fR11, fill=C_GRAY, anchor="mm")

    buf = io.BytesIO()
    img.save(buf, "PNG", optimize=True)
    buf.seek(0)
    return buf.read()


# ── Ota-ona haftalik ──────────────────────────────────────────────────────────

def create_parent_weekly_report(
    child_name: str,
    club_name: str,
    attendance_pct: int,
    present: int,
    total: int,
    payment_status: str,
) -> bytes:
    """Ota-onaga haftalik farzand hisoboti rasmi."""
    Image, ImageDraw, ImageFont = _pil()

    W, H = 640, 400
    img  = Image.new("RGB", (W, H), C_BG)
    draw = ImageDraw.Draw(img)

    fB16 = _font(ImageFont, 16)
    fB13 = _font(ImageFont, 13)
    fR12 = _font_reg(ImageFont, 12)
    fR11 = _font_reg(ImageFont, 11)

    # Header
    try:
        draw.rounded_rectangle([(0, 0), (W, 80)], radius=0, fill=C_PRIMARY)
    except Exception:
        draw.rectangle([(0, 0), (W, 80)], fill=C_PRIMARY)
    draw.text((W//2, 28), "SmartDMTT — Haftalik Hisobot", font=fB16, fill=C_WHITE, anchor="mm")
    draw.text((W//2, 58), date.today().strftime("%d.%m.%Y"), font=fR12, fill=(200, 230, 225), anchor="mm")

    # Farzand info karta
    _rect(draw, 24, 100, W-48, 76, C_CARD, radius=14)
    draw.text((50, 126), f"👶  {child_name}", font=fB13, fill=C_DARK, anchor="lm")
    draw.text((50, 158), f"📚  {club_name}",  font=fR12, fill=C_GRAY,  anchor="lm")

    # Davomat
    _rect(draw, 24, 192, W-48, 80, C_CARD, radius=14)
    draw.text((50, 208), "Davomat", font=fB13, fill=C_DARK)
    draw.text((W-44, 208), f"{present}/{total} dars ({attendance_pct}%)", font=fR12, fill=C_GRAY, anchor="ra")
    bar_color = _bar(draw, 50, 232, W-100, 20, attendance_pct, radius=6)
    draw.text((50 + (W-100)//2, 242), f"{attendance_pct}%", font=fR11, fill=C_WHITE, anchor="mm")

    # To'lov
    _rect(draw, 24, 288, W-48, 56, C_CARD, radius=14)
    is_paid   = "To'langan" in payment_status or "to'langan" in payment_status
    pay_color = C_SUCCESS if is_paid else C_DANGER
    pay_icon  = "✅" if is_paid else "❌"
    draw.text((50,  316), "To'lov holati:", font=fB13, fill=C_DARK, anchor="lm")
    draw.text((W-44, 316), f"{pay_icon}  {payment_status}", font=fB13, fill=pay_color, anchor="rm")

    # Footer
    _rect(draw, 0, H-46, W, 46, C_LIGHT, radius=0)
    draw.text((W//2, H-23), "SmartDMTT — Maktabgacha ta'lim tizimi", font=fR11, fill=C_GRAY, anchor="mm")

    buf = io.BytesIO()
    img.save(buf, "PNG", optimize=True)
    buf.seek(0)
    return buf.read()


# ── Boshliq umumiy ────────────────────────────────────────────────────────────

async def create_boshliq_summary() -> bytes:
    """Tuman bo'yicha umumiy infografika (boshliq uchun)."""
    Image, ImageDraw, ImageFont = _pil()

    from app.models.kindergarten import Kindergarten
    from app.models.club import Club, Enrollment
    from app.models.child import Attendance
    from app.models.payment import Payment

    today      = date.today()
    week_start = today - timedelta(days=today.weekday())
    month_str  = today.strftime("%Y-%m")

    kgs     = await Kindergarten.filter(is_active=True).all()
    kg_rows = []
    total_enr   = 0
    total_paid  = 0
    total_pres  = 0
    total_att   = 0

    for kg in kgs:
        clubs    = await Club.filter(kindergarten_id=kg.id, is_active=True).all()
        club_ids = [c.id for c in clubs]
        enrs     = await Enrollment.filter(club_id__in=club_ids, status="active").all() if club_ids else []
        enr_ids  = [e.id for e in enrs]

        att_w  = await Attendance.filter(enrollment_id__in=enr_ids, date__gte=week_start).all() if enr_ids else []
        pres_w = sum(1 for a in att_w if a.status == "present")
        paid_m = await Payment.filter(enrollment_id__in=enr_ids, month=month_str, status="completed").count() if enr_ids else 0

        att_p = round(pres_w / len(att_w) * 100) if att_w else 0
        pay_p = round(paid_m / len(enrs) * 100) if enrs else 0

        total_enr  += len(enrs)
        total_paid += paid_m
        total_pres += pres_w
        total_att  += len(att_w)

        kg_rows.append((kg.name[:30], len(clubs), len(enrs), att_p, pay_p))

    att_total_pct = round(total_pres / total_att * 100) if total_att else 0
    pay_total_pct = round(total_paid / total_enr * 100) if total_enr else 0

    W = 860
    H = 160 + 140 + len(kg_rows[:10]) * 52 + 60
    img  = Image.new("RGB", (W, H), C_BG)
    draw = ImageDraw.Draw(img)

    fB18 = _font(ImageFont, 18)
    fB13 = _font(ImageFont, 13)
    fB12 = _font(ImageFont, 12)
    fR12 = _font_reg(ImageFont, 12)
    fR11 = _font_reg(ImageFont, 11)

    # Header
    draw.rectangle([(0, 0), (W, 80)], fill=C_PRIMARY)
    draw.text((W//2, 28), "SmartDMTT — Tuman bo'yicha Hisobot", font=fB18, fill=C_WHITE, anchor="mm")
    draw.text((W//2, 58), f"{today.strftime('%d.%m.%Y')}  |  {len(kgs)} ta bog'cha", font=fR12, fill=(200, 230, 225), anchor="mm")

    # KPI
    kpis = [
        ("Bog'chalar",  len(kgs),             None,            "🏫"),
        ("O'quvchilar", total_enr,             None,            "👶"),
        ("Davomat",     f"{att_total_pct}%",   att_total_pct,   "📅"),
        ("To'lov",      f"{pay_total_pct}%",   pay_total_pct,   "💰"),
    ]
    card_w = (W - 60) // 4 - 10
    for i, (label, val, pct, icon) in enumerate(kpis):
        cx = 30 + i * (card_w + 13)
        _rect(draw, cx, 100, card_w, 110, C_CARD, radius=12)
        draw.text((cx + card_w//2, 120), icon, font=fB18, fill=C_PRIMARY, anchor="mm")
        val_color = C_DARK
        if pct is not None:
            val_color = C_SUCCESS if pct >= 80 else (C_WARNING if pct >= 60 else C_DANGER)
        draw.text((cx + card_w//2, 160), str(val), font=fB13, fill=val_color, anchor="mm")
        draw.text((cx + card_w//2, 186), label, font=fR11, fill=C_GRAY, anchor="mm")

    # Jadval
    y_cur = 228
    _rect(draw, 30, y_cur, W-60, 32, C_PRIMARY, radius=8)
    draw.text((50,  y_cur+16), "Bog'cha",    font=fB12, fill=C_WHITE, anchor="lm")
    draw.text((480, y_cur+16), "To'garaklar",font=fB12, fill=C_WHITE, anchor="mm")
    draw.text((590, y_cur+16), "O'quvchi",   font=fB12, fill=C_WHITE, anchor="mm")
    draw.text((700, y_cur+16), "Davomat",    font=fB12, fill=C_WHITE, anchor="mm")
    draw.text((800, y_cur+16), "To'lov",     font=fB12, fill=C_WHITE, anchor="mm")
    y_cur += 38

    for i, (name, clubs_n, enr_n, att_p, pay_p) in enumerate(kg_rows[:10]):
        row_bg = C_WHITE if i % 2 == 0 else (245, 248, 247)
        _rect(draw, 30, y_cur, W-60, 44, row_bg, radius=6)
        draw.text((50,  y_cur+22), name,       font=fR12, fill=C_DARK, anchor="lm")
        draw.text((480, y_cur+22), str(clubs_n),font=fB12, fill=C_DARK, anchor="mm")
        draw.text((590, y_cur+22), str(enr_n),  font=fB12, fill=C_DARK, anchor="mm")

        att_color = C_SUCCESS if att_p >= 80 else (C_WARNING if att_p >= 60 else C_DANGER)
        pay_color = C_SUCCESS if pay_p >= 80 else (C_WARNING if pay_p >= 60 else C_DANGER)
        draw.text((700, y_cur+22), f"{att_p}%", font=fB12, fill=att_color, anchor="mm")
        draw.text((800, y_cur+22), f"{pay_p}%", font=fB12, fill=pay_color, anchor="mm")
        y_cur += 52

    draw.rectangle([(0, H-44), (W, H)], fill=C_LIGHT)
    draw.text((W//2, H-22), "SmartDMTT v4 — Bulungur tuman MMTB", font=fR11, fill=C_GRAY, anchor="mm")

    buf = io.BytesIO()
    img.save(buf, "PNG", optimize=True)
    buf.seek(0)
    return buf.read()
