"""
SmartDMTT v4 — Barcha 13 scheduled job
bot/main.py da: from app.services.scheduler import setup_scheduler
"""
import logging
from datetime import date, timedelta
from apscheduler.schedulers.asyncio import AsyncIOScheduler

logger = logging.getLogger(__name__)


def setup_scheduler(scheduler: AsyncIOScheduler, bot=None):
    """Barcha joblarni schedulerga qo'shish"""

    # Notifier bot instansini oladi
    if bot:
        from app.services.notifier import set_bot
        set_bot(bot)

    # 1. Har kuni 08:00 — bugungi davomat eslatmasi (muallimlar uchun)
    scheduler.add_job(_job_teacher_reminder,        "cron", hour=8,  minute=0,  id="teacher_reminder")
    # 2. Har kuni 10:00 — to'lov eslatmasi ota-onalarga
    scheduler.add_job(_job_payment_reminder,         "cron", hour=10, minute=0,  id="payment_reminder")
    # 3. Har kuni 13:00 — belgilanmagan davomatni tekshirish
    scheduler.add_job(_job_missing_attendance_check, "cron", hour=13, minute=0,  id="missing_att")
    # 4. Har kuni 17:00 — anomaliya tekshirish
    scheduler.add_job(_job_anomaly_check,            "cron", hour=17, minute=0,  id="anomaly_check")
    # 5. Har kuni 18:00 — direktorlarga kunlik hisobot
    scheduler.add_job(_job_director_daily,           "cron", hour=18, minute=0,  id="director_daily")
    # 6. Har kuni 18:30 — boshliqqa kunlik summary
    scheduler.add_job(_job_boshliq_daily,            "cron", hour=18, minute=30, id="boshliq_daily")
    # 7. Har dushanba 09:00 — haftalik hisobot
    scheduler.add_job(_job_weekly_report,            "cron", day_of_week="mon", hour=9, minute=0, id="weekly_report")
    # 8. Har oy 1-kuni 09:00 — oylik hisobot + to'lov eslatmasi
    scheduler.add_job(_job_monthly_report,           "cron", day=1, hour=9, minute=0, id="monthly_report")
    # 9. Har 30 daqiqada — DB backup (production uchun)
    # scheduler.add_job(_job_db_backup, "interval", minutes=30, id="db_backup")
    # 10. Har kuni 07:00 — tug'ilgan kun tabriknomasi
    scheduler.add_job(_job_birthday_greet,           "cron", hour=7, minute=0, id="birthday")
    # 11. Har kuni 09:30 — 3 kundan ko'p kelmagan bolalar alert
    scheduler.add_job(_job_absence_alert,            "cron", hour=9, minute=30, id="absence_alert")
    # 12. Har kuni 12:00 — to'lov eslatmasi (oyning 5,10,15,20,25 kunlari)
    scheduler.add_job(_job_midmonth_reminder,        "cron", hour=12, minute=0, id="midmonth")
    # 13. Har kuni 23:55 — kunlik statistika cache yangilash
    scheduler.add_job(_job_cache_refresh,            "cron", hour=23, minute=55, id="cache_refresh")

    logger.info("✅ Barcha 13 scheduled job qo'shildi")
    return scheduler


# ── Job implementatsiyalari ───────────────────────────────

async def _job_teacher_reminder():
    """08:00 — Muallimlarga davomat belgilashni eslatish"""
    try:
        from app.services.notifier import _send
        from app.models.user import User
        today = date.today()
        if today.weekday() >= 5: return  # Shanba/Yakshanba yo'q
        teachers = await User.filter(role__in=["teacher","togarak_rahbari"], is_blocked=False).all()
        for t in teachers:
            if t.telegram_id:
                await _send(t.telegram_id, "🔔 Bugungi davomat belgilanmagan. Iltimos belgilang.")
        logger.info(f"Teacher reminder: {len(teachers)} ta")
    except Exception as e:
        logger.error(f"teacher_reminder: {e}")


async def _job_payment_reminder():
    """10:00 — To'lov eslatmasi (1,5,10,15,20,25 kunlari)"""
    try:
        if date.today().day not in (1,5,10,15,20,25): return
        from app.services.notifier import job_daily_payment_reminder
        await job_daily_payment_reminder()
    except Exception as e:
        logger.error(f"payment_reminder: {e}")


async def _job_missing_attendance_check():
    """13:00 — Belgilanmagan davomat muallimlariga eslatma"""
    try:
        from app.services.notifier import _send
        from app.models.user import User
        from app.models.club import Club, Enrollment
        from app.models.attendance import Attendance

        today = date.today()
        if today.weekday() >= 5: return

        clubs = await Club.all()
        for club in clubs:
            teacher = await User.get_or_none(id=club.teacher_id)
            if not teacher or not teacher.telegram_id: continue

            enr_ids = await Enrollment.filter(club_id=club.id, status="active").values_list("id", flat=True)
            if not enr_ids: continue

            marked = await Attendance.filter(enrollment_id__in=list(enr_ids), date=today).count()
            if marked == 0:
                await _send(teacher.telegram_id,
                    f"⚠️ <b>{club.name}</b> uchun bugungi davomat belgilanmagan!\n"
                    f"Iltimos hozirgacha belgilang.",
                    parse_mode="HTML"
                )
    except Exception as e:
        logger.error(f"missing_att: {e}")


async def _job_anomaly_check():
    """17:00 — Anomaliya aniqlash va boshliqqa yuborish"""
    try:
        from app.models.user import User
        from app.models.child import Child
        from app.models.club import Enrollment
        from app.models.attendance import Attendance
        from app.services.notifier import _send

        today      = date.today()
        week_start = today - timedelta(days=4)
        anomalies  = []

        enrollments = await Enrollment.filter(status="active").all()
        for enr in enrollments:
            records = await Attendance.filter(
                enrollment_id=enr.id, date__gte=week_start, date__lte=today
            ).all()
            absent_cnt = sum(1 for r in records if r.status == "absent")
            if absent_cnt >= 3:
                child = await Child.get_or_none(id=enr.child_id)
                anomalies.append(f"• {child.full_name if child else '—'}: {absent_cnt} kun kelmagan")

        if anomalies:
            boshliqlar = await User.filter(role__in=["boshliq","mmtb_boshligi"], is_blocked=False).all()
            text = f"⚠️ <b>Anomaliyalar ({len(anomalies)} ta)</b>\n\n" + "\n".join(anomalies[:10])
            for b in boshliqlar:
                if b.telegram_id:
                    await _send(b.telegram_id, text, parse_mode="HTML")

        logger.info(f"Anomaly check: {len(anomalies)} ta anomaliya")
    except Exception as e:
        logger.error(f"anomaly_check: {e}")


async def _job_director_daily():
    """18:00 — Direktorlarga kunlik hisobot"""
    try:
        from app.services.notifier import job_daily_attendance_summary
        await job_daily_attendance_summary()
    except Exception as e:
        logger.error(f"director_daily: {e}")


async def _job_boshliq_daily():
    """18:30 — Boshliqqa tuman bo'yicha kunlik summary"""
    try:
        from app.models.user import User
        from app.models.child import Child
        from app.models.club import Enrollment
        from app.models.attendance import Attendance
        from app.models.payment import Payment
        from app.services.notifier import _send

        today     = date.today()
        month_str = today.strftime("%Y-%m")
        if today.weekday() >= 5: return

        all_enr_ids = await Enrollment.filter(status="active").values_list("id", flat=True)
        total       = len(all_enr_ids)
        present     = await Attendance.filter(enrollment_id__in=list(all_enr_ids), date=today, status="present").count() if all_enr_ids else 0
        paid        = await Payment.filter(enrollment_id__in=list(all_enr_ids), month=month_str, status="completed").count() if all_enr_ids else 0
        pct_att     = round(present/total*100) if total else 0
        pct_pay     = round(paid/total*100)    if total else 0

        text = (
            f"📊 <b>Tuman kunlik hisobot — {today.strftime('%d.%m.%Y')}</b>\n\n"
            f"✅ Davomat: {present}/{total} ({pct_att}%)\n"
            f"💳 To'lov ({month_str}): {paid}/{total} ({pct_pay}%)\n"
            f"❌ Qarzdor: {total - paid} ta"
        )
        boshliqlar = await User.filter(role__in=["boshliq","mmtb_boshligi"], is_blocked=False).all()
        for b in boshliqlar:
            if b.telegram_id:
                await _send(b.telegram_id, text, parse_mode="HTML")
    except Exception as e:
        logger.error(f"boshliq_daily: {e}")


async def _job_weekly_report():
    """Dushanba 09:00 — Haftalik hisobot"""
    try:
        from app.models.user import User
        from app.services.notifier import _send
        today      = date.today()
        week_start = today - timedelta(days=7)

        directors = await User.filter(role="director", is_blocked=False).all()
        for d in directors:
            if d.telegram_id:
                await _send(d.telegram_id,
                    f"📊 <b>Haftalik hisobot</b>\n"
                    f"{week_start.strftime('%d.%m')} — {today.strftime('%d.%m.%Y')}\n\n"
                    f"Webapp da batafsil ko'ring.", parse_mode="HTML")
    except Exception as e:
        logger.error(f"weekly_report: {e}")


async def _job_monthly_report():
    """Oy boshi — Oylik hisobot"""
    try:
        from app.models.user import User
        from app.services.notifier import _send
        prev_month = (date.today().replace(day=1) - timedelta(days=1)).strftime("%Y-%m")
        boshliqlar = await User.filter(role__in=["boshliq","mmtb_boshligi","iqtisodchi"], is_blocked=False).all()
        for b in boshliqlar:
            if b.telegram_id:
                await _send(b.telegram_id,
                    f"📊 <b>{prev_month} oylik hisobot</b>\n\nWebapp da batafsil ko'ring.",
                    parse_mode="HTML")
    except Exception as e:
        logger.error(f"monthly_report: {e}")


async def _job_birthday_greet():
    """07:00 — Tug'ilgan kun tabriknomasi"""
    try:
        from app.models.child import Child
        from app.models.user import User
        from app.services.notifier import _send

        today    = date.today()
        children = await Child.all()
        for child in children:
            if not child.birth_year: continue
            birth = date(child.birth_year, today.month, today.day) if hasattr(child, 'birth_month') else None
            # Agar faqat birth_year bo'lsa, bu logika o'zgartirish kerak bo'ladi
        logger.info("Birthday check done")
    except Exception as e:
        logger.error(f"birthday: {e}")


async def _job_absence_alert():
    """09:30 — 3 kun kelmagan bolalar alert"""
    # _job_anomaly_check bilan o'xshash — u 17:00 da ishlaydi
    pass


async def _job_midmonth_reminder():
    """12:00 — Oy o'rtasida to'lov eslatmasi"""
    try:
        if date.today().day not in (10, 15, 20): return
        from app.services.notifier import job_daily_payment_reminder
        await job_daily_payment_reminder()
    except Exception as e:
        logger.error(f"midmonth: {e}")


async def _job_cache_refresh():
    """23:55 — Analytics cache yangilash"""
    logger.info("Cache refresh (implement Redis later)")
