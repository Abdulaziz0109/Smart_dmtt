"""
SmartDMTT - To'lov Servisi
"""
import json
import time
import logging
import base64
from typing import Optional, Dict, Any
from app.core import config
from app.models.payment import Payment

logger = logging.getLogger(__name__)

class PaymentStatus:
    PENDING  = "pending"
    CREATED  = "created"
    PAID     = "paid"
    FAILED   = "failed"
    CANCELED = "canceled"
    REFUNDED = "refunded"

class PaymentService:
    @staticmethod
    def create_click_payment_url(
        amount: int,
        order_id: str,
        description: str = "SmartDMTT to'lov",
        return_url: str = ""
    ) -> str:
        """Click to'lov linkini yaratish."""
        
        if not config.CLICK_MERCHANT_ID or not config.CLICK_SERVICE_ID:
            return ""
        
        params = {
            "service_id": config.CLICK_SERVICE_ID,
            "merchant_id": config.CLICK_MERCHANT_ID,
            "amount": amount,
            "transaction_param": order_id,
            "merchant_trans_id": order_id,
        }
        
        if return_url:
            params["return_url"] = return_url
        
        query = "&".join([f"{k}={v}" for k, v in params.items()])
        return f"https://my.click.uz/services/pay?{query}"

    @staticmethod
    def create_payme_payment_url(
        amount: int,
        order_id: str,
        description: str = "SmartDMTT to'lov"
    ) -> str:
        """Payme to'lov linkini yaratish."""
        
        if not config.PAYME_MERCHANT_ID:
            return ""
        
        # Payme amount = tiyin (so'm * 100)
        amount_tiyin = amount * 100
        
        params = json.dumps({
            "m": config.PAYME_MERCHANT_ID,
            "ac.order_id": order_id,
            "a": amount_tiyin,
            "l": "uz",
            "ct": int(time.time() * 1000 + 1800000),  # 30 daqiqa
            "cr": "UZS"
        })
        
        encoded = base64.b64encode(params.encode()).decode()
        
        base_url = "https://checkout.paycom.uz" if not config.PAYME_TEST_MODE else "https://test.paycom.uz"
        return f"{base_url}/{encoded}"

    @staticmethod
    def get_payment_buttons(
        payment_id: str,
        amount: int,
        child_name: str,
        club_name: str,
        lang: str = "uz"
    ) -> dict:
        """Telegram inline klaviaturasi uchun to'lov tugmalari."""
        click_url = PaymentService.create_click_payment_url(amount, payment_id, f"{child_name} - {club_name}")
        payme_url = PaymentService.create_payme_payment_url(amount, payment_id, f"{child_name} - {club_name}")
        
        return {
            "click": click_url,
            "payme": payme_url
        }
