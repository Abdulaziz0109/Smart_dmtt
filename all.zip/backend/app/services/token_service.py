"""
SmartDMTT — JWT Token Service
Xavfsiz foydalanuvchi tokenlarini yaratish va tekshirish.
"""
import jwt
import time
import hashlib
from datetime import datetime, timedelta
from typing import Optional, Dict
from app.core import config


class TokenService:

    @staticmethod
    def create_access_token(user_id: int, roles: list,
                             extra: dict = None) -> str:
        """JWT access token yaratish."""
        payload = {
            "sub": str(user_id),
            "roles": roles,
            "iat": datetime.utcnow(),
            "exp": datetime.utcnow() + timedelta(hours=config.SESSION_EXPIRE_HOURS),
            "type": "access",
        }
        if extra:
            payload.update(extra)
        return jwt.encode(payload, config.SECRET_KEY, algorithm=config.ALGORITHM)

    @staticmethod
    def decode_token(token: str) -> Dict:
        """
        JWT tokenni tekshirish va payload qaytarish.
        Raises: ValueError agar token yaroqsiz bo'lsa.
        """
        try:
            return jwt.decode(token, config.SECRET_KEY,
                              algorithms=[config.ALGORITHM])
        except jwt.ExpiredSignatureError:
            raise ValueError("Token muddati tugagan. Qayta kiring.")
        except jwt.InvalidTokenError as e:
            raise ValueError(f"Token yaroqsiz: {e}")

    @staticmethod
    def get_device_hash(request_headers: dict, user_agent: str = "") -> str:
        """
        Qurilma barmoq izi yaratish.
        IP + User-Agent asosida qurilmani identifikatsiya qiladi.
        """
        ip = (request_headers.get("x-forwarded-for", "")
              or request_headers.get("x-real-ip", "")
              or "unknown")
        raw = f"{ip}:{user_agent}"
        return hashlib.sha256(raw.encode()).hexdigest()[:16]
