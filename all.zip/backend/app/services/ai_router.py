"""
SmartDMTT — Multi-AI Router
Groq → Gemini fallback zanjiri.
Bitta API ishlamasa avtomatik keyingisiga o'tadi.
"""
import asyncio
import logging
import time
from typing import Optional, List, Dict
from app.core import config
from app.services.redis_service import RedisService

logger = logging.getLogger(__name__)

# ─── Provider holati (qaysi API ishlayapti/ishlamayapti) ─────────────────────
_provider_status: Dict[str, Dict] = {
    "groq": {"available": True, "last_error": 0, "error_count": 0},
    "gemini": {"available": True, "last_error": 0, "error_count": 0},
}
_COOLDOWN = 60  # 1 daqiqa - xato bo'lsa shu vaqt o'tgach qayta sinab ko'radi


def _is_provider_available(name: str) -> bool:
    """Provider hozir ishlatish mumkinligini tekshirish."""
    s = _provider_status.get(name, {})
    if not s.get("available", True):
        # Cooldown o'tganmi?
        if time.time() - s.get("last_error", 0) > _COOLDOWN:
            s["available"] = True
            s["error_count"] = 0
    return s.get("available", True)


def _mark_provider_error(name: str) -> None:
    """Provider xatosini qayd etish."""
    s = _provider_status.setdefault(name, {})
    s["error_count"] = s.get("error_count", 0) + 1
    s["last_error"] = time.time()
    if s["error_count"] >= config.AI_MAX_RETRIES:
        s["available"] = False
        logger.warning(f"⚠️ {name} vaqtincha o'chirildi ({_COOLDOWN}s)")


def _mark_provider_success(name: str) -> None:
    """Provider muvaffaqiyatli ishladi."""
    s = _provider_status.setdefault(name, {})
    s["available"] = True
    s["error_count"] = 0


# ─── Groq ─────────────────────────────────────────────────────────────────────

async def _call_groq(messages: List[Dict], system: str,
                     max_tokens: int) -> Optional[str]:
    """Groq API ga so'rov yuborish."""
    if not config.GROQ_API_KEY:
        return None
    try:
        import groq
        client = groq.Groq(api_key=config.GROQ_API_KEY)

        full_messages = [{"role": "system", "content": system}] + messages

        # Asyncio timeout bilan
        loop = asyncio.get_event_loop()
        response = await asyncio.wait_for(
            loop.run_in_executor(
                None,
                lambda: client.chat.completions.create(
                    model=config.GROQ_MODEL,
                    messages=full_messages,
                    max_tokens=max_tokens,
                    temperature=0.7,
                )
            ),
            timeout=config.AI_TIMEOUT
        )
        text = response.choices[0].message.content
        _mark_provider_success("groq")
        return text

    except asyncio.TimeoutError:
        logger.warning("⏱️ Groq timeout")
        _mark_provider_error("groq")
        return None
    except Exception as e:
        err_str = str(e).lower()
        if "rate_limit" in err_str or "429" in err_str:
            logger.warning("🔴 Groq rate limit")
            _mark_provider_error("groq")
        elif "quota" in err_str or "insufficient" in err_str:
            logger.warning("🔴 Groq quota tugadi")
            _provider_status["groq"]["available"] = False
        else:
            logger.error(f"Groq xatosi: {e}")
            _mark_provider_error("groq")
        return None


# ─── Gemini ───────────────────────────────────────────────────────────────────

async def _call_gemini(messages: List[Dict], system: str,
                       max_tokens: int) -> Optional[str]:
    """Google Gemini API ga so'rov yuborish."""
    if not config.GEMINI_API_KEY:
        return None
    try:
        import google.generativeai as genai
        genai.configure(api_key=config.GEMINI_API_KEY)

        model = genai.GenerativeModel(
            model_name=config.GEMINI_MODEL,
            system_instruction=system,
            generation_config=genai.GenerationConfig(
                max_output_tokens=max_tokens,
                temperature=0.7,
            )
        )

        # Xabarlarni Gemini formatiga o'tkazish
        gemini_messages = []
        for msg in messages:
            role = "user" if msg["role"] == "user" else "model"
            gemini_messages.append({"role": role, "parts": [msg["content"]]})

        # Oxirgi user xabarini ajratib olish
        if gemini_messages and gemini_messages[-1]["role"] == "user":
            last_user_msg = gemini_messages[-1]["parts"][0]
            history = gemini_messages[:-1]
        else:
            last_user_msg = "Salom"
            history = gemini_messages

        loop = asyncio.get_event_loop()
        response = await asyncio.wait_for(
            loop.run_in_executor(
                None,
                lambda: model.start_chat(history=history).send_message(last_user_msg)
            ),
            timeout=config.AI_TIMEOUT
        )
        text = response.text
        _mark_provider_success("gemini")
        return text

    except asyncio.TimeoutError:
        logger.warning("⏱️ Gemini timeout")
        _mark_provider_error("gemini")
        return None
    except Exception as e:
        err_str = str(e).lower()
        if "quota" in err_str or "429" in err_str or "resource_exhausted" in err_str:
            logger.warning("🔴 Gemini quota/rate limit")
            _mark_provider_error("gemini")
        else:
            logger.error(f"Gemini xatosi: {e}")
            _mark_provider_error("gemini")
        return None


# ─── ASOSIY FUNKSIYA ──────────────────────────────────────────────────────────

# Provider chaqiruv funksiyalari ro'yxati
_PROVIDERS = {
    "groq": _call_groq,
    "gemini": _call_gemini,
}


async def ask_ai(
    messages: List[Dict],
    system: str = "Siz SmartDMTT bog'cha tizimining yordamchisisiz.",
    max_tokens: int = 1024,
    user_id: str = None,
) -> str:
    """
    Multi-AI so'rov. Groq → Gemini tartibida sinab ko'radi.
    Ikkalasi ham ishlamasa umumiy javob qaytaradi.

    Args:
        messages: [{"role": "user/assistant", "content": "..."}]
        system: Tizim ko'rsatmasi
        max_tokens: Maksimal token soni
        user_id: Foydalanuvchi ID (loglash uchun)

    Returns:
        AI javobi (str)
    """
    # Tartib: primary → fallback
    order = [config.AI_PRIMARY, config.AI_FALLBACK]
    # Takrorlanmaslik uchun
    seen = set()
    providers_to_try = []
    for name in order:
        if name in _PROVIDERS and name not in seen:
            providers_to_try.append(name)
            seen.add(name)

    for provider_name in providers_to_try:
        if not _is_provider_available(provider_name):
            logger.info(f"⏭️ {provider_name} hozir mavjud emas, o'tkazib yuborildi")
            continue

        call_fn = _PROVIDERS[provider_name]
        logger.info(f"🤖 AI so'rov: {provider_name} (user={user_id})")

        result = await call_fn(messages, system, max_tokens)
        if result:
            logger.info(f"✅ {provider_name} javob berdi")
            return result

        logger.warning(f"❌ {provider_name} javob bermadi, keyingisiga o'tilmoqda")

    # Ikkalasi ham ishlamadi
    logger.error("❌ Barcha AI providerlar ishlamadi")
    return (
        "Kechirasiz, AI yordamchi hozir vaqtincha ishlamayapti. "
        "Bir ozdan so'ng qayta urinib ko'ring. 🙏"
    )


async def ask_ai_with_history(
    user_id: str,
    new_message: str,
    system: str,
    max_tokens: int = 1024,
) -> str:
    """
    Redis dan tarix olib, AI ga yuboradi, tarixni yangilaydi.
    ai_helper.py dan foydalanish o'rniga shu funksiyani ishlating.
    """
    # Tarixni Redis dan olish
    history = await RedisService.get_ai_history(user_id)

    # Yangi xabarni qo'shish
    history.append({"role": "user", "content": new_message})

    # AI dan javob olish
    response = await ask_ai(history, system=system, max_tokens=max_tokens,
                            user_id=user_id)

    # Javobni tarixga qo'shish
    history.append({"role": "assistant", "content": response})

    # Redis da saqlash
    await RedisService.save_ai_history(user_id, history)

    return response


def get_providers_status() -> Dict:
    """Admin panel uchun AI provider holati."""
    result = {}
    for name, status in _provider_status.items():
        is_available = _is_provider_available(name)
        result[name] = {
            "available": is_available,
            "error_count": status.get("error_count", 0),
            "last_error_ago": int(time.time() - status.get("last_error", 0))
            if status.get("last_error") else None,
            "has_key": bool(
                config.GROQ_API_KEY if name == "groq" else config.GEMINI_API_KEY
            )
        }
    return result
