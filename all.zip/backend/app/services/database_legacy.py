import asyncio
import json
from typing import Any, Dict, List, Optional, Tuple
from pathlib import Path
import re
import unicodedata
import sqlite3
import datetime
import os
from dotenv import load_dotenv

# Load env from root or relative path
load_dotenv()

# Update DB_PATH to be absolute or relative to project root correctly
# Assuming running from root, data/ is in root.
DB_PATH = Path(os.getenv("DB_PATH", "data/database.sqlite"))

def get_db_connection():
    # Ensure directory exists
    if not DB_PATH.parent.exists():
        DB_PATH.parent.mkdir(parents=True, exist_ok=True)
        
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    if not DB_PATH.exists():
        DB_PATH.parent.mkdir(parents=True, exist_ok=True)
        pass

init_db()

TABLES = [
    "users", "children", "clubs", "enrollments",
    "attendance", "payments", "faq", "faq_pending", "camera_attendance", 
    "ratings", "feedback", "analytics", "kindergartens"
]

_cache: Dict[str, List[Dict[str, Any]]] = {k: [] for k in TABLES}
_user_active_roles: Dict[str, str] = {}
_otp_cache: Dict[str, str] = {} 

def save_otp(user_id: str, code: str):
    _otp_cache[str(user_id)] = str(code)

def verify_otp(user_id: str, code: str) -> bool:
    stored = _otp_cache.get(str(user_id))
    if stored and stored == str(code):
        del _otp_cache[str(user_id)]
        return True
    return False

async def refresh_cache() -> None:
    for table in TABLES:
        await _load_table_to_cache(table)
    print("Baza va Bilimlar Bazasi yangilandi!")

async def _load_table_to_cache(table_name: str) -> None:
    conn = get_db_connection()
    cursor = conn.cursor()
    try:
        target_table = table_name
        if table_name == "registrations":
            target_table = "enrollments"
            
        cursor.execute(f"SELECT name FROM sqlite_master WHERE type='table' AND name=?", (target_table,))
        if not cursor.fetchone():
            _cache[table_name] = []
            return

        cursor.execute(f"SELECT * FROM {target_table}")
        rows = cursor.fetchall()
        _cache[table_name] = [dict(row) for row in rows]
    except Exception as e:
        print(f"Error loading {table_name}: {e}")
        _cache[table_name] = []
    finally:
        conn.close()

def find_user(uid: Any) -> Tuple[Optional[Dict[str, Any]], Optional[List[str]]]:
    uid_str = str(uid)
    conn = get_db_connection()
    cursor = conn.cursor()
    try:
        cursor.execute("SELECT * FROM users WHERE id = ?", (uid_str,))
        user = cursor.fetchone()
        if user:
            user_dict = dict(user)
            roles = user_dict.get("role", "").split(",")
            roles = [r.strip() for r in roles if r.strip()]
            return user_dict, roles
        return None, None
    finally:
        conn.close()

def get_user_language(user_id: int) -> str:
    user, _ = find_user(user_id)
    if user:
        return user.get("lang", "uz")
    return "uz"

def get_full_database_export():
    data = {}
    conn = get_db_connection()
    cursor = conn.cursor()
    try:
        cursor.execute("SELECT name FROM sqlite_master WHERE type='table'")
        tables = cursor.fetchall()
        for table in tables:
            t_name = table[0]
            cursor.execute(f"SELECT * FROM {t_name}")
            rows = cursor.fetchall()
            data[t_name] = [dict(row) for row in rows]
    finally:
        conn.close()
    return data

async def log_analytics(event_type: str, user_id: str, details: str):
    conn = get_db_connection()
    try:
        conn.execute(
            "INSERT INTO analytics (event_type, user_id, details, timestamp) VALUES (?, ?, ?, ?)",
            (event_type, user_id, details, datetime.datetime.now().isoformat())
        )
        conn.commit()
    except Exception as e:
        print(f"Analytics Error: {e}")
    finally:
        conn.close()
