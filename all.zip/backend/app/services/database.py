"""
SmartDMTT - Database Service (Tortoise ORM Wrapper)
Unified Database Access Layer
"""
import asyncio
import logging
import json
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple
from datetime import datetime

from app.models.user import User
from app.models.child import Child
from app.models.club import Enrollment
from app.models.attendance import Attendance
from app.models.club import Club
from app.models.payment import Payment
from app.services.redis_service import RedisService

logger = logging.getLogger(__name__)

DATA_DIR = Path("data")

# ─── USERS ───────────────────────────────────────────────────────────────────

async def find_user(uid: Any) -> Tuple[Optional[Dict], Optional[List[str]]]:
    """Foydalanuvchini topish va rollarini qaytarish."""
    try:
        uid_int = int(uid)
        
        # Try finding by ID first
        u = await User.get_or_none(id=uid_int)
        
        # If not found by ID, maybe it's a telegram_id search?
        if not u:
            u = await User.get_or_none(telegram_id=uid_int)
            
        if u:
            roles_str = str(u.role or "guest")
            roles = [r.strip() for r in roles_str.split(",") if r.strip()]
            
            user_dict = {
                "id": str(u.id),
                "user_id": str(u.id),
                "full_name": u.full_name,
                "phone": u.phone,
                "role": u.role,
                "language": u.language,
                "telegram_id": u.telegram_id,
                "kindergarten": u.kindergarten
            }
            return user_dict, roles if roles else ["guest"]
            
    except Exception as e:
        logger.error(f"find_user error: {e}")
        
    return None, None

async def get_user_language(user_id: Any) -> str:
    u, _ = await find_user(user_id)
    return u.get("language", "uz") if u else "uz"

async def set_user_language(user_id: Any, language: str) -> None:
    try:
        uid_int = int(user_id)
        u = await User.get_or_none(id=uid_int)
        if not u:
            u = await User.get_or_none(telegram_id=uid_int)
            
        if u:
            u.language = language
            await u.save()
    except Exception as e:
        logger.error(f"set_user_language error: {e}")

async def add_user_if_not_exists(uid: Any, full_name: str, phone: str,
                                  role: str = "guest", language: str = "uz") -> None:
    try:
        uid_int = int(uid)
        exists = await User.get_or_none(telegram_id=uid_int)
        if not exists:
            exists_pk = await User.get_or_none(id=uid_int)
            if not exists_pk:
                await User.create(
                    id=uid_int,
                    telegram_id=uid_int,
                    full_name=full_name,
                    phone=phone,
                    role=role,
                    language=language
                )
    except Exception as e:
        logger.error(f"add_user_if_not_exists error: {e}")

async def get_all_users() -> List[Dict]:
    users = await User.all()
    return [
        {
            "id": str(u.id),
            "user_id": str(u.id),
            "full_name": u.full_name,
            "phone": u.phone,
            "role": u.role,
            "language": u.language,
            "kindergarten": u.kindergarten
        } for u in users
    ]

# ─── CHILDREN ────────────────────────────────────────────────────────────────

async def get_all_children() -> List[Dict]:
    children = await Child.all()
    return [
        {
            "child_id": str(c.id),
            "full_name": c.full_name,
            "parent_id": str(c.parent_id) if c.parent_id else None,
            "birth_date": str(c.birth_date) if c.birth_date else "",
            "kindergarten": c.kindergarten,
            "guruh": c.group_name
        } for c in children
    ]

async def get_children_by_parent(parent_id: Any) -> List[Dict]:
    try:
        pid = int(parent_id)
        children = await Child.filter(parent_id=pid).all()
        return [
            {
                "child_id": str(c.id),
                "full_name": c.full_name,
                "parent_id": str(c.parent_id),
                "birth_date": str(c.birth_date) if c.birth_date else "",
                "kindergarten": c.kindergarten,
                "guruh": c.group_name,
                "billing_id": c.billing_id
            } for c in children
        ]
    except:
        return []

# ─── CLUBS ───────────────────────────────────────────────────────────────────

async def get_all_clubs() -> List[Dict]:
    clubs = await Club.filter(is_active=True).all()
    return [
        {
            "club_id": str(c.id),
            "name": c.name,
            "description": c.description,
            "teacher_id": str(c.teacher_id) if c.teacher_id else None,
            "price": float(c.price),
            "room": c.room,
            "capacity": c.capacity,
            "kindergarten": c.kindergarten,
            "is_active": c.is_active,
            "day": (c.schedule or {}).get("days", "") if isinstance(c.schedule, dict) else "",
            "time": (c.schedule or {}).get("time", "") if isinstance(c.schedule, dict) else ""
        } for c in clubs
    ]

async def get_clubs_by_teacher(teacher_id: Any) -> List[Dict]:
    try:
        tid = int(teacher_id)
        clubs = await Club.filter(teacher_id=tid, is_active=True).all()
        return [
            {
                "club_id": str(c.id),
                "name": c.name,
                "description": c.description,
                "price": float(c.price),
                "room": c.room,
                "capacity": c.capacity,
                "day": (c.schedule or {}).get("days", "") if isinstance(c.schedule, dict) else "",
                "time": (c.schedule or {}).get("time", "") if isinstance(c.schedule, dict) else ""
            } for c in clubs
        ]
    except:
        return []

# ─── REGISTRATIONS (Enrollments) ─────────────────────────────────────────────

async def get_all_registrations() -> List[Dict]:
    enrollments = await Enrollment.all()
    return [
        {
            "reg_id": str(e.id),
            "child_id": str(e.child_id),
            "club_id": str(e.club_id),
            "status": e.status,
            "enrolled_at": str(e.enrolled_at)
        } for e in enrollments
    ]

# ─── ATTENDANCE ──────────────────────────────────────────────────────────────

async def get_all_attendance() -> List[Dict]:
    attendance = await Attendance.all()
    # Need to join with Enrollment to get child_id/club_id?
    # Attendance linked to Enrollment. Enrollment linked to Child/Club.
    # This is expensive. For now, maybe just return what we have?
    # Or fetch related?
    # Using fetch_related is better.
    return [] # Placeholder to avoid complex join for now in this wrapper

# ─── PAYMENTS ────────────────────────────────────────────────────────────────

async def get_all_payments() -> List[Dict]:
    payments = await Payment.all()
    return [
        {
            "id": str(p.id),
            "child_id": str(p.child_id),
            "club_id": str(p.club_id),
            "amount": float(p.amount),
            "date": str(p.date),
            "status": p.status,
            "method": p.method
        } for p in payments
    ]

# ─── FAQ (JSON fallback) ─────────────────────────────────────────────────────

def get_all_faq() -> List[Dict]:
    p = DATA_DIR / "faq.json"
    if not p.exists():
        return []
    try:
        d = json.loads(p.read_text(encoding="utf-8"))
        return d if isinstance(d, list) else []
    except:
        return []

# ─── OTP (Redis) ─────────────────────────────────────────────────────────────

async def save_otp(user_id: str, code: str) -> None:
    await RedisService.save_otp(str(user_id), code)

async def verify_otp(user_id: str, code: str) -> bool:
    success, _ = await RedisService.verify_otp(str(user_id), code)
    return success

# ─── Helpers ─────────────────────────────────────────────────────────────────

async def get_user_active_role(uid: Any) -> Optional[str]:
    u, roles = await find_user(uid)
    if roles:
        return roles[0]
    return "Mehmon"

# ─── ANALYTICS ───────────────────────────────────────────────────────────────

async def log_analytics(event_type: str, user_id: str, details: str = "") -> None:
    # Basic implementation: log to file or create Analytics model if exists
    # Using simple print/log for now or Redis list?
    # Ideally, save to DB if Analytics model is ready.
    try:
        from app.models.analytics import Analytics
        await Analytics.create(
            event=event_type,
            user_id=str(user_id),
            details=details,
            ts=datetime.now()
        )
    except Exception as e:
        logger.error(f"log_analytics error: {e}")
