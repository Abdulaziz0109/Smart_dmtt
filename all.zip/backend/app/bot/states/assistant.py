from aiogram.fsm.state import StatesGroup, State

class AssistantState(StatesGroup):
    in_conversation = State()  # State when user is talking to the assistant
