"""
SmartDMTT v4.0 — /start ro'yxatdan o'tish FSM holatlari
"""
from aiogram.fsm.state import State, StatesGroup


class RegistrationState(StatesGroup):
    """Yangi ota-ona ro'yxatdan o'tish oqimi."""
    waiting_consent = State()               # Rozilik kutilmoqda
    waiting_phone = State()                 # Telefon ulash kutilmoqda
    choosing_role = State()                 # Ota-ona yoki Mehmon
    choosing_place_type = State()           # Davlat / Xususiy / Boshqa
    entering_kindergarten_number = State()  # Bog'cha raqami
    entering_other_place = State()          # Boshqa muassasa nomi
    entering_child_name = State()           # Farzand ismi familiyasi
    entering_child_birth_year = State()     # Tug'ilgan yili
    choosing_new_password = State()         # Parol almashtirish


class PasswordState(StatesGroup):
    """Parol o'zgartirish."""
    entering_old_password = State()   # Eski parolni tekshirish
    entering_new_password = State()   # Yangi parol kiritish


class AbsenceState(StatesGroup):
    """Kela olmash ogohlantirishi."""
    choosing_date = State()
    choosing_reason = State()


class AssistantState(StatesGroup):
    """AI yordamchi suhbati."""
    in_conversation = State()
