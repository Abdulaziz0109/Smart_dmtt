"""
SmartDMTT v4 — Bot main.py (yakuniy versiya)
Barcha handlerlar + scheduler + notifier
"""
import asyncio, logging
from aiogram import Bot, Dispatcher
from aiogram.fsm.storage.memory import MemoryStorage
from apscheduler.schedulers.asyncio import AsyncIOScheduler

from app.core.config import settings

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s %(levelname)s %(name)s: %(message)s"
)
logger = logging.getLogger(__name__)


async def main():
    from app.bot.handlers.parent          import router as parent_router
    from app.bot.handlers.teacher         import router as teacher_router
    from app.bot.handlers.boshliq         import router as boshliq_router
    from app.bot.handlers.director        import router as director_router
    from app.bot.handlers.iqtisodchi      import router as iqtisodchi_router
    from app.bot.handlers.admin_bot        import router as admin_bot_router
    from app.bot.handlers.role_switch      import router as role_switch_router
    from app.bot.handlers.language_handler import router as lang_router
    from app.services.notifier             import set_bot
    from app.services.scheduler            import setup_scheduler

    bot       = Bot(token=settings.BOT_TOKEN)
    storage   = MemoryStorage()
    dp        = Dispatcher(storage=storage)
    scheduler = AsyncIOScheduler(timezone="Asia/Tashkent")

    # Notifier bot instansi
    set_bot(bot)

    # Routerlar — tartib muhim
    dp.include_router(role_switch_router)   # /rol /setrole /users
    dp.include_router(lang_router)          # /til /language
    dp.include_router(admin_bot_router)     # admin buyruqlari
    dp.include_router(boshliq_router)       # boshliq
    dp.include_router(director_router)      # direktor
    dp.include_router(iqtisodchi_router)    # iqtisodchi
    dp.include_router(teacher_router)       # muallim
    dp.include_router(parent_router)        # ota-ona (eng oxirgi — umumiy handler)

    # 13 ta scheduled job
    setup_scheduler(scheduler, bot)
    scheduler.start()

    logger.info("🚀 SmartDMTT Bot v4 ishga tushdi")
    try:
        await dp.start_polling(bot, allowed_updates=dp.resolve_used_update_types())
    finally:
        scheduler.shutdown()
        await bot.session.close()
        logger.info("Bot to'xtatildi")


if __name__ == "__main__":
    asyncio.run(main())
