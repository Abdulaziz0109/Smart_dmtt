"""
backend/app/bot/i18n/__init__.py
i18n_init.py dan barcha funksiyalarni re-export qiladi
Shunday qilib: from app.bot.i18n import t, get_lang, lang_keyboard
"""
from app.bot.i18n.i18n_init import (
    t,
    get_lang,
    lang_keyboard,
    SUPPORTED_LANGS,
    DEFAULT_LANG,
)

__all__ = ["t", "get_lang", "lang_keyboard", "SUPPORTED_LANGS", "DEFAULT_LANG"]
