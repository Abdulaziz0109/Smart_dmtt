"""
SmartDMTT i18n — Markaziy tarjima moduli
Qo'llab-quvvatlanadigan tillar: uz, kril, ru, en, turk
"""
import json, os, logging
from functools import lru_cache

logger = logging.getLogger(__name__)

SUPPORTED_LANGS = ("uz", "kril", "ru", "en", "turk")
DEFAULT_LANG    = "uz"

_CACHE: dict[str, dict] = {}

def _load(lang: str) -> dict:
    if lang in _CACHE:
        return _CACHE[lang]
    base = os.path.dirname(__file__)
    path = os.path.join(base, f"{lang}.json")
    try:
        with open(path, encoding="utf-8") as f:
            data = json.load(f)
        _CACHE[lang] = data
        return data
    except FileNotFoundError:
        logger.warning(f"i18n: {lang}.json topilmadi, uz ishlatilmoqda")
        return _load(DEFAULT_LANG)
    except Exception as e:
        logger.error(f"i18n yuklanmadi ({lang}): {e}")
        return {}


def t(key: str, lang: str = DEFAULT_LANG, **kwargs) -> str:
    """
    Asosiy tarjima funksiyasi.
    Ishlatish: t("welcome_new", "ru")
    O'zgaruvchilar: t("ai_limit", "uz", used=3, limit=5)
    """
    lang = lang if lang in SUPPORTED_LANGS else DEFAULT_LANG
    data = _load(lang)
    text = data.get(key)

    if text is None:
        # Fallback: uz dan olish
        fallback = _load(DEFAULT_LANG)
        text = fallback.get(key, f"[{key}]")
        if text == f"[{key}]":
            logger.warning(f"i18n: kalit topilmadi: {key}")

    # O'zgaruvchilarni almashtirish
    if kwargs:
        try:
            text = text.format(**kwargs)
        except (KeyError, ValueError) as e:
            logger.warning(f"i18n format xato ({key}): {e}")

    return text


def get_lang(user) -> str:
    """User obyektidan til olish"""
    if not user:
        return DEFAULT_LANG
    lang = getattr(user, "language", DEFAULT_LANG) or DEFAULT_LANG
    return lang if lang in SUPPORTED_LANGS else DEFAULT_LANG


def lang_keyboard() -> list[list[dict]]:
    """Til tanlash inline klaviaturasi"""
    return [[
        {"text": "🇺🇿 O'zbek",   "callback_data": "lang_uz"},
        {"text": "Ўзбек 🇺🇿",    "callback_data": "lang_kril"},
    ], [
        {"text": "🇷🇺 Русский",   "callback_data": "lang_ru"},
        {"text": "🇬🇧 English",   "callback_data": "lang_en"},
    ], [
        {"text": "🇹🇷 Türkçe",    "callback_data": "lang_turk"},
    ]]
