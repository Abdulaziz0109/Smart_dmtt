"""
SmartMMTB — Bot UI & Role Management v3
========================================
Professional, clean, emojilar bilan tushunarli dizayn
"""
from aiogram import Dispatcher, F, types
from aiogram.types import (
    InlineKeyboardButton, InlineKeyboardMarkup,
    ReplyKeyboardMarkup, KeyboardButton, WebAppInfo
)
from app.services import database as db
from app.core import strings
from app.core import config

ROLES = {
    "admin":     "Admin",
    "iqtisodchi":"Iqtisodchi",
    "mmtb":      "MMTB boshligi",
    "direktor":  "Bogcha direktori",
    "oqituvchi": "Oqituvchi",
    "ota_ona":   "Ota_ona",
    "mehmon":    "Mehmon",
}

ROLE_LABEL = {
    "Admin":           "👑 Admin",
    "Iqtisodchi":      "💼 Iqtisodchi",
    "MMTB boshligi":   "🏛 MMTB Boshligi",
    "Bogcha direktori":"🏫 Direktor",
    "Oqituvchi":       "📚 O'qituvchi",
    "Ota_ona":         "👨‍👩‍👧 Ota-ona",
    "Mehmon":          "👤 Mehmon",
}

WEBAPP_URL = config.WEBAPP_URL
if not WEBAPP_URL or not WEBAPP_URL.startswith("https"):
    # Fallback default
    WEBAPP_URL = "https://unsensuous-unvillainous-jeannette.ngrok-free.dev"

# ─── Greeting ─────────────────────────────────────────────────────────────────
def build_greeting(uid, user_name: str, role: str, lang: str, kg: str = "") -> str:
    label = ROLE_LABEL.get(role, f"👤 {role}")
    kg_line = f"\n🏫 <b>{kg}</b>" if kg else ""
    msgs = {
        "uz": (
            f"🌿 Assalomu alaykum, <b>{user_name}</b>!\n"
            f"{label}{kg_line}\n\n"
            f"SmartMMTB — bog'cha boshqaruv tizimiga xush kelibsiz.\n"
            f"Quyidagi tugmalardan foydalaning 👇"
        ),
        "ru": (
            f"🌿 Здравствуйте, <b>{user_name}</b>!\n"
            f"{label}{kg_line}\n\n"
            f"Добро пожаловать в SmartMMTB.\n"
            f"Используйте кнопки ниже 👇"
        ),
        "en": (
            f"🌿 Hello, <b>{user_name}</b>!\n"
            f"{label}{kg_line}\n\n"
            f"Welcome to SmartMMTB.\n"
            f"Use the buttons below 👇"
        ),
        "tr": (
            f"🌿 Merhaba, <b>{user_name}</b>!\n"
            f"{label}{kg_line}\n\n"
            f"SmartMMTB'ye hoş geldiniz.\n"
            f"Aşağıdaki düğmeleri kullanın 👇"
        ),
    }
    return msgs.get(lang, msgs["uz"])

# ─── Menu builder ─────────────────────────────────────────────────────────────
def get_menu(role: str, lang: str = "uz") -> ReplyKeyboardMarkup:
    t = lambda k: strings.get_text(lang, k)
    W = lambda: KeyboardButton(text=t("btn_webapp"), web_app=WebAppInfo(url=WEBAPP_URL))
    B = lambda k: KeyboardButton(text=t(k))

    # ── ADMIN ──────────────────────────────────────────────────────────────
    if role == "Admin":
        return ReplyKeyboardMarkup(keyboard=[
            [W(), B("btn_assistant")],
            [B("btn_hisobotlar"),  B("btn_davomat")],
            [B("btn_tolovlar"),    B("btn_qarzdorlar")],
            [B("btn_oqituvchilar"),B("btn_togaraklar_royxati")],
            [B("btn_togarak_yaratish"), B("btn_sozlamalar")],
        ], resize_keyboard=True, input_field_placeholder="👑 Admin paneli")

    # ── IQTISODCHI ─────────────────────────────────────────────────────────
    if role == "Iqtisodchi":
        return ReplyKeyboardMarkup(keyboard=[
            [W(), B("btn_assistant")],
            [B("btn_tolovlar"),    B("btn_qarzdorlar")],
            [B("btn_hisobotlar"),  B("btn_togaraklar_royxati")],
            [B("btn_sozlamalar")],
        ], resize_keyboard=True, input_field_placeholder="💼 Moliyaviy panel")

    # ── MMTB BOSHLIGI ──────────────────────────────────────────────────────
    if role == "MMTB boshligi":
        return ReplyKeyboardMarkup(keyboard=[
            [W(), B("btn_assistant")],
            [B("btn_hisobotlar"),  B("btn_davomat")],
            [B("btn_togaraklar_royxati"), B("btn_oqituvchilar")],
            [B("btn_sozlamalar")],
        ], resize_keyboard=True, input_field_placeholder="🏛 MMTB paneli")

    # ── DIREKTOR ───────────────────────────────────────────────────────────
    if role == "Bogcha direktori":
        return ReplyKeyboardMarkup(keyboard=[
            [W(), B("btn_assistant")],
            [B("btn_davomat"),     B("btn_oqituvchilar")],
            [B("btn_togaraklar_royxati"), B("btn_togarak_yaratish")],
            [B("btn_sozlamalar")],
        ], resize_keyboard=True, input_field_placeholder="🏫 Direktor paneli")

    # ── O'QITUVCHI ─────────────────────────────────────────────────────────
    if role == "Oqituvchi":
        return ReplyKeyboardMarkup(keyboard=[
            [W(), B("btn_assistant")],
            [B("btn_darsni_boshlash"),  B("btn_davomat_qilish")],
            [B("btn_mening_togaraklarim"), B("btn_baho_berish")],
            [B("btn_taklif_shikoyat"), B("btn_sozlamalar")],
        ], resize_keyboard=True, input_field_placeholder="📚 O'qituvchi paneli")

    # ── OTA-ONA ────────────────────────────────────────────────────────────
    if role == "Ota_ona":
        return ReplyKeyboardMarkup(keyboard=[
            [W(), B("btn_assistant")],
            [B("btn_farzandlarim"),    B("btn_balans")],
            [B("btn_tolov_qilish"),    B("btn_davomat_sababi")],
            [B("btn_togarakka_yozilish"), B("btn_togarak_ozgartirish")],
            [B("btn_baho_berish"),     B("btn_sozlamalar")],
        ], resize_keyboard=True, input_field_placeholder="👨‍👩‍👧 Ota-ona paneli")

    # ── MEHMON ─────────────────────────────────────────────────────────────
    return ReplyKeyboardMarkup(keyboard=[
        [W(), B("btn_assistant")],
        [B("btn_togaraklar_haqida")],
        [B("btn_sozlamalar")],
    ], resize_keyboard=True, input_field_placeholder="👤 SmartMMTB")


# ─── Settings keyboard ─────────────────────────────────────────────────────────
def get_settings_keyboard(lang: str = "uz") -> InlineKeyboardMarkup:
    """Sozlamalar inline keyboard."""
    t = lambda k: strings.get_text(lang, k)
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="🌐 Til o'zgartirish", callback_data="settings:lang")],
        [InlineKeyboardButton(text="👤 Rolni ko'rish",    callback_data="settings:role")],
        [InlineKeyboardButton(text="ℹ️ Tizim haqida",    callback_data="settings:about")],
    ])

def get_language_keyboard() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="🇺🇿 O'zbekcha (lotin)",  callback_data="lang:uz")],
        [InlineKeyboardButton(text="🇺🇿 Ўзбекча (кирилл)", callback_data="lang:kr")],
        [InlineKeyboardButton(text="🇷🇺 Русский",           callback_data="lang:ru")],
        [InlineKeyboardButton(text="🇬🇧 English",           callback_data="lang:en")],
        [InlineKeyboardButton(text="🇹🇷 Türkçe",           callback_data="lang:tr")],
    ])

# ─── Role switcher ─────────────────────────────────────────────────────────────
async def show_role_switcher(message: types.Message, user_lang: str):
    kb = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text=v, callback_data=f"role_switch:{v}")]
        for v in ROLES.values()
    ])
    await message.answer("👤 Rolni tanlang:", reply_markup=kb, parse_mode="HTML")


# ─── Status card ──────────────────────────────────────────────────────────────
async def send_status_card(message: types.Message, uid: int, lang: str):
    """Foydalanuvchi uchun shaxsiy statistika kartochkasi."""
    import datetime
    role = db.get_user_active_role(uid) or "Mehmon"
    user, _ = db.find_user(uid)
    today = datetime.date.today().strftime("%d.%m.%Y")

    if role == "Ota_ona":
        children = db.get_children_by_parent(uid)
        payments = db.get_payment_status_by_parent(uid)
        unpaid = sum(1 for p in payments if not p.get("paid") and str(p.get("status","")) != "completed")
        msg = (
            f"📊 <b>Sizning holatingiz</b> ({today})\n"
            f"━━━━━━━━━━━━━━━\n"
            f"👧 Farzandlar: <b>{len(children)}</b> ta\n"
            f"{'❌' if unpaid else '✅'} To'lanmagan: <b>{unpaid}</b> ta\n"
        )
        await message.answer(msg, parse_mode="HTML")

    elif role in ("Admin", "Iqtisodchi", "MMTB boshligi"):
        # Stats are async in v3 wrapper, but sync in our json db.
        # But wait, our json db doesn't have get_stats. 
        # We need to implement it or wrap it.
        # The json db has specific getters.
        # Let's try to get simple stats.
        users_count = len(db.get_all_users())
        children_count = len(db.get_all_children())
        attendance = db.get_all_attendance()
        present_today = sum(1 for a in attendance if a.get("date") == datetime.date.today().isoformat() and a.get("status") == "present")
        absent_today = sum(1 for a in attendance if a.get("date") == datetime.date.today().isoformat() and a.get("status") == "absent")
        
        msg = (
            f"📊 <b>Tizim holati</b> ({today})\n"
            f"━━━━━━━━━━━━━━━\n"
            f"👤 Foydalanuvchilar: <b>{users_count}</b>\n"
            f"👦 Bolalar: <b>{children_count}</b>\n"
            f"✅ Bugun keldi: <b>{present_today}</b>\n"
            f"❌ Bugun kelmadi: <b>{absent_today}</b>\n"
            # f"💰 Bu oy tushum: <b>{stats['revenue_month']:,.0f}</b> so'm\n"
            # f"⚠️ Qarzdorlar: <b>{stats['debtors']}</b>\n"
        )
        await message.answer(msg, parse_mode="HTML")

    elif role == "Oqituvchi":
        clubs = db.get_clubs_by_teacher(uid)
        msg = (
            f"📊 <b>Sizning to'garaklaringiz</b>\n"
            f"━━━━━━━━━━━━━━━\n"
            f"📚 Jami: <b>{len(clubs)}</b> ta to'garak\n"
        )
        await message.answer(msg, parse_mode="HTML")


# ─── Register role management ─────────────────────────────────────────────────
def register_role_management_commands(dp: Dispatcher, set_user_commands_func, LocalizedCommand):
    """Role switcher va sozlamalar handler'larini ro'yxatdan o'tkazish."""

    @dp.message(LocalizedCommand("cmd_val_switch_role"))
    async def switch_role_cmd(message: types.Message):
        uid = message.from_user.id
        user_data = db.find_user(uid)
        roles = user_data[1] if user_data else []
        
        # Check config for admin ID
        from app.core import config
        if "Admin" not in (roles or []) and str(uid) != str(config.ADMIN_CHAT_ID):
            await message.answer("Bu buyruq faqat adminlar uchun.")
            return
        user_lang = db.get_user_language(uid)
        await show_role_switcher(message, user_lang)

    @dp.callback_query(F.data.startswith("role_switch:"))
    async def role_switch_callback(callback: types.CallbackQuery):
        uid   = callback.from_user.id
        role  = callback.data.split(":", 1)[1]
        user_lang = db.get_user_language(uid)
        db.set_user_active_role(uid, role)
        await callback.answer(f"✅ Rol: {role}", show_alert=False)
        menu = get_menu(role, user_lang)
        label = ROLE_LABEL.get(role, role)
        await callback.message.answer(
            f"{label} — rol tanlandi. Menyu yangilandi.",
            reply_markup=menu, parse_mode="HTML"
        )
        await set_user_commands_func(uid, [role])

    @dp.callback_query(F.data.startswith("settings:"))
    async def settings_callback(callback: types.CallbackQuery):
        uid  = callback.from_user.id
        lang = db.get_user_language(uid)
        action = callback.data.split(":")[1]
        if action == "lang":
            await callback.message.edit_text("🌐 Tilni tanlang:", reply_markup=get_language_keyboard())
        elif action == "role":
            role = db.get_user_active_role(uid) or "Mehmon"
            u, roles = db.find_user(uid)
            roles_str = ", ".join(roles or ["Mehmon"])
            await callback.message.edit_text(
                f"👤 Hozirgi rol: <b>{ROLE_LABEL.get(role, role)}</b>\n"
                f"📋 Barcha rollar: {roles_str}",
                parse_mode="HTML"
            )
        elif action == "about":
            await callback.message.edit_text(
                "ℹ️ <b>SmartMMTB v3</b>\n"
                "━━━━━━━━━━━━━━━\n"
                "Bog'chalar boshqaruv tizimi\n"
                "PostgreSQL • Groq AI • Telegram\n\n"
                "© 2024–2026 SmartMMTB",
                parse_mode="HTML"
            )
        await callback.answer()
