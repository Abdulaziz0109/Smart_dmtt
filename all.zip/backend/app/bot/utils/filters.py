from aiogram import F, types
from aiogram.filters import BaseFilter
from app.core import strings
from app.services.user_service import UserService

def menu_text_filter(key: str) -> F:
    """Creates a filter that matches a menu button text in any available language."""
    valid_texts = [strings.get_text(lang, key) for lang in strings.get_languages()]
    return F.text.in_(valid_texts)

class LocalizedCommand(BaseFilter):
    """A custom filter to match localized commands from strings.py."""
    def __init__(self, command_key: str):
        self.command_key = command_key

    async def __call__(self, message: types.Message) -> bool:
        # Get all possible command values for the key across all languages
        command_values = [strings.get_text(lang, self.command_key) for lang in strings.get_languages()]
        
        # Check if the message text (without the '/') is one of the valid command values
        if message.text and message.text.startswith('/'):
            command_text = message.text[1:].strip().split()[0]
            command_text = command_text.split("@", 1)[0]
            return command_text.lower() in {c.lower() for c in command_values}
        return False
