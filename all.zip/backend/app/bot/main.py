"""
SmartDMTT v4 — backend/app/bot/main.py
Bot + Tortoise ORM init + Scheduler + Polling
"""
import asyncio
import logging
from aiogram import Bot, Dispatcher
from aiogram.fsm.storage.memory import MemoryStorage
from app.core import config

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s %(levelname)s %(name)s: %(message)s"
)
logger = logging.getLogger(__name__)

# run_system.py uchun global export
bot = Bot(token=config.TOKEN)
dp  = Dispatcher(storage=MemoryStorage())


def _register():
    pairs = [
        ("app.bot.handlers.role_switch",      "router"),
        ("app.bot.handlers.language_handler", "router"),
        ("app.bot.handlers.admin_bot",        "router"),
        ("app.bot.handlers.boshliq",          "router"),
        ("app.bot.handlers.director",         "router"),
        ("app.bot.handlers.iqtisodchi",       "router"),
        ("app.bot.handlers.teacher",          "router"),
        ("app.bot.handlers.parent",           "router"),
        ("app.bot.handlers.start",            "router"),
        ("app.bot.handlers.clubs_bot",        "router"),
        ("app.bot.handlers.attendance",       "router"),
        ("app.bot.handlers.complaint",        "router"),
        ("app.bot.handlers.observation",      "router"),
        ("app.bot.handlers.location",         "router"),
    ]
    ok, fail = [], []
    for mod_path, rname in pairs:
        try:
            import importlib
            mod    = importlib.import_module(mod_path)
            router = getattr(mod, rname, None)
            if router:
                dp.include_router(router)
                ok.append(mod_path.split(".")[-1])
        except Exception as e:
            fail.append(f"{mod_path.split('.')[-1]}: {e}")
    if ok:   logger.info(f"✅ Handlerlar: {', '.join(ok)}")
    if fail: logger.warning(f"⚠️  Yuklanmadi: {'; '.join(fail)}")


_register()


async def _init_db():
    """Bot uchun Tortoise ORM ulanishi"""
    try:
        from tortoise import Tortoise
        await Tortoise.init(
            db_url=config.DATABASE_URL,
            modules={"models": ["app.models"]}
        )
        await Tortoise.generate_schemas(safe=True)
        logger.info("✅ Bot DB ulanish tayyor")
    except Exception as e:
        logger.error(f"❌ Bot DB xatosi: {e}")


async def _polling():
    # 1. DB init
    await _init_db()

    # 2. Notifier
    try:
        from app.services.notifier import set_bot
        set_bot(bot)
    except Exception as e:
        logger.warning(f"Notifier: {e}")

    # 3. Scheduler
    try:
        from app.services.scheduler import setup_scheduler
        from apscheduler.schedulers.asyncio import AsyncIOScheduler
        scheduler = AsyncIOScheduler(timezone="Asia/Tashkent")
        setup_scheduler(scheduler, bot)
        scheduler.start()
        logger.info("✅ Scheduler (13 job)")
    except Exception as e:
        logger.warning(f"Scheduler: {e}")

    # 4. Polling
    logger.info("🚀 SmartDMTT Bot polling boshlandi...")
    try:
        await dp.start_polling(bot, allowed_updates=dp.resolve_used_update_types())
    finally:
        from tortoise import Tortoise
        await Tortoise.close_connections()
        await bot.session.close()
        logger.info("Bot to'xtatildi")


if __name__ == "__main__":
    import sys
    if sys.platform == "win32":
        asyncio.set_event_loop_policy(asyncio.WindowsSelectorEventLoopPolicy())
    asyncio.run(_polling())
