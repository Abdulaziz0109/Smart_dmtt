from aiogram import BaseMiddleware
from aiogram.types import TelegramObject, Message, CallbackQuery
from typing import Callable, Any, Awaitable
from app.services.user_service import UserService

class LanguageMiddleware(BaseMiddleware):
    """
    Middleware that automatically detects and stores user's language preference.
    Makes language available in handler context via event.context['user_lang']
    """
    
    async def __call__(
        self,
        handler: Callable[[TelegramObject, dict[str, Any]], Awaitable[Any]],
        event: TelegramObject,
        data: dict[str, Any],
    ) -> Any:
        # Get user ID from different event types
        user_id = None
        if isinstance(event, Message):
            user_id = event.from_user.id
        elif isinstance(event, CallbackQuery):
            user_id = event.from_user.id
        
        # Get user's language from database
        if user_id:
            user_lang = await UserService.get_user_language(user_id)
            data["user_lang"] = user_lang
            data["user_id"] = user_id
        else:
            data["user_lang"] = "uz"  # Default
            data["user_id"] = None
        
        return await handler(event, data)
