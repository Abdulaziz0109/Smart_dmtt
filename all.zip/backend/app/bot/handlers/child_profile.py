"""
SmartDMTT v4 — Bola profili handleri (ota-ona)
Shanba: haftada 1 savol "Uyda nima qildi?"
Scheduler 3 oylik ma'lumot to'plangach AI tavsiya yuboradi.
"""
import logging
from datetime import date, timedelta

from aiogram import Router, F, Bot
from aiogram.types import Message, CallbackQuery, InlineKeyboardMarkup, InlineKeyboardButton
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup

from app.models import User
from app.models.child import Child
from app.models.observation import ChildObservation
from app.models.club import Enrollment
from app.core.strings import get_string

logger = logging.getLogger(__name__)
router = Router()


class ChildProfileFSM(StatesGroup):
    enter_answer = State()


# ─── Scheduler chaqiradi — shanba kuni ───────────────────────────────────────

async def send_weekly_question(bot: Bot):
    """Har shanba barcha ota-onalarga haftalik savol yuboradi."""
    today = date.today()
    # Faqat shanba kuni (weekday=5)
    if today.weekday() != 5:
        return

    parents = await User.filter(role="parent").all()
    for parent in parents:
        if not parent.telegram_id:
            continue
        children = await Child.filter(parent_id=parent.id).all()
        if not children:
            continue
        lang = parent.language or "uz_latin"
        for child in children:
            try:
                text = get_string(lang, "child_profile_q", child=child.full_name)
                kb = InlineKeyboardMarkup(inline_keyboard=[[
                    InlineKeyboardButton(
                        text="✍️ Javob berish",
                        callback_data=f"cp_answer:{child.id}"
                    )
                ]])
                await bot.send_message(parent.telegram_id, text, reply_markup=kb)
            except Exception as e:
                logger.warning(f"Haftalik savol yuborilmadi ({parent.telegram_id}): {e}")


# ─── Callback: "Javob berish" tugmasi ────────────────────────────────────────

@router.callback_query(F.data.startswith("cp_answer:"))
async def start_answer(cb: CallbackQuery, state: FSMContext):
    child_id = int(cb.data.split(":")[1])
    user = await User.get_or_none(telegram_id=cb.from_user.id)
    lang = user.language if user else "uz_latin"

    child = await Child.get_or_none(id=child_id)
    if not child:
        await cb.answer("Bola topilmadi")
        return

    await state.update_data(child_id=child_id, lang=lang)
    await cb.message.edit_text(
        f"<b>{child.full_name}</b> bu hafta uyda nima qildi?\n"
        "Qisqacha yozing (1-3 jumla):",
        parse_mode="HTML"
    )
    await state.set_state(ChildProfileFSM.enter_answer)
    await cb.answer()


@router.message(ChildProfileFSM.enter_answer)
async def save_answer(message: Message, state: FSMContext, bot: Bot):
    data = await state.get_data()
    lang = data.get("lang", "uz_latin")
    child_id = data.get("child_id")
    answer = message.text.strip()

    if len(answer) < 3:
        await message.answer("Iltimos, biroz batafsil yozing:")
        return

    # Javobni ChildObservation sifatida saqlamaymiz —
    # enrollment yo'q bo'lishi mumkin (to'garak tanlashdan oldin).
    # Alohida saqlaymiz: enrollment_id=None bo'lgan yozuv.
    # Hozirda faqat log saqlaymiz, keyinchalik AI tavsiya uchun ishlatiladi.
    child = await Child.get_or_none(id=child_id)

    # Enrollment topib, observation sifatida saqlaymiz
    enrollment = await Enrollment.filter(child_id=child_id, status="active").first()
    if enrollment:
        await ChildObservation.create(
            enrollment=enrollment,
            date=date.today(),
            # Matnli javob — barcha raqamlar None, faqat completed_task=True belgisi
            completed_task=True,
        )
    # TODO: answer matni keyinchalik child_notes jadvalida saqlanadi

    await message.answer(get_string(lang, "child_profile_saved"))
    await state.clear()

    # 3 oylik ma'lumot yig'ilganmi — AI tavsiya tekshiruvi
    await _check_ai_recommendation(bot, child, lang)


async def _check_ai_recommendation(bot: Bot, child: Child, lang: str):
    """3 oy davomida yetarli kuzatuv bo'lsa AI tavsiya yuboradi."""
    try:
        three_months_ago = date.today() - timedelta(days=90)
        enrollments = await Enrollment.filter(child_id=child.id).all()
        enr_ids = [e.id for e in enrollments]
        if not enr_ids:
            return

        obs_count = await ChildObservation.filter(
            enrollment_id__in=enr_ids,
            date__gte=three_months_ago
        ).count()

        if obs_count < 10:
            return

        parent = await User.get_or_none(id=child.parent_id)
        if not parent or not parent.telegram_id:
            return

        # AI tavsiya so'rovi (scheduler orqali to'liq amalga oshiriladi)
        await bot.send_message(
            parent.telegram_id,
            f"📊 <b>{child.full_name}</b> uchun 3 oylik profil tayyorlanmoqda...\n"
            "Tez orada AI tavsiyalar yuboriladi.",
            parse_mode="HTML"
        )
    except Exception as e:
        logger.warning(f"AI tavsiya tekshiruvi xatosi: {e}")
