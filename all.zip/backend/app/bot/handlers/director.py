"""
SmartDMTT v4 — Direktor bot handlerlari
i18n bilan to'liq integratsiya
"""
import logging
from datetime import date, timedelta
from aiogram import Router, F, types
from aiogram.filters import Command
from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton

from app.models.user import User
from app.models.child import Child
from app.models.club import Club, Enrollment
from app.models.payment import Payment
from app.models.attendance import Attendance
from app.models.kindergarten import Kindergarten
from app.bot.i18n import t, get_lang

logger = logging.getLogger(__name__)
router = Router()

# ── Helper ────────────────────────────────────────────────
async def _get_director(tg_id: int) -> User | None:
    return await User.get_or_none(telegram_id=tg_id, role="director")

async def _kg_id(user: User) -> int | None:
    return user.kindergarten_id

def _kb(lang: str, buttons: list[list[tuple]]) -> types.ReplyKeyboardMarkup:
    """ReplyKeyboard yaratish: [[(text, ...)], ...]"""
    return types.ReplyKeyboardMarkup(
        keyboard=[[types.KeyboardButton(text=b[0]) for b in row] for row in buttons],
        resize_keyboard=True,
    )

# ── /start ────────────────────────────────────────────────
@router.message(Command("start"))
async def cmd_start(message: types.Message):
    user = await User.get_or_none(telegram_id=message.from_user.id)
    if not user or user.role != "director":
        await message.answer("Ruxsat yo'q. Iltimos admin bilan bog'laning.")
        return
    lang = get_lang(user)
    name = user.full_name or message.from_user.first_name or "Direktor"
    await message.answer(
        f"👋 Xush kelibsiz, {name}!\n"
        f"SmartDMTT — Bog'cha boshqaruv tizimi.",
        reply_markup=_main_menu(lang)
    )

def _main_menu(lang: str) -> types.ReplyKeyboardMarkup:
    return _kb(lang, [
        [("🏫 Bog'cha holati",), ("📊 Statistika",)],
        [("👨‍🏫 Xodimlar",),    ("👶 Bolalar",)],
        [("💰 Moliya",),         ("📢 E'lon",)],
        [("🤖 AI Tahlil",),      ("👤 Profil",)],
    ])

# ── 🏫 Bog'cha holati ─────────────────────────────────────
@router.message(F.text == "🏫 Bog'cha holati")
async def bog_cha_holati(message: types.Message):
    user = await _get_director(message.from_user.id)
    if not user: return
    lang  = get_lang(user)
    kg_id = await _kg_id(user)
    if not kg_id:
        await message.answer("Bog'cha biriktirilmagan. Admin bilan bog'laning.")
        return

    kg    = await Kindergarten.get_or_none(id=kg_id)
    today = date.today()
    month_str = today.strftime("%Y-%m")

    total_children = await Child.filter(kindergarten_id=kg_id).count()
    total_clubs    = await Club.filter(kindergarten_id=kg_id).count()

    child_ids = await Child.filter(kindergarten_id=kg_id).values_list("id", flat=True)
    enr_ids   = await Enrollment.filter(child_id__in=list(child_ids), status="active").values_list("id", flat=True)

    att_total   = await Attendance.filter(enrollment_id__in=list(enr_ids), date=today).count() if enr_ids else 0
    att_present = await Attendance.filter(enrollment_id__in=list(enr_ids), date=today, status="present").count() if enr_ids else 0
    att_pct     = round(att_present / att_total * 100) if att_total else 0

    paid_ids = await Payment.filter(
        enrollment_id__in=list(enr_ids), month=month_str, status="completed"
    ).values_list("enrollment_id", flat=True) if enr_ids else []
    debtors = len(enr_ids) - len(paid_ids)

    kg_name = kg.name if kg else "Bog'cha"
    lines = [
        f"🏫 <b>{kg_name}</b>",
        f"📅 {today.strftime('%d.%m.%Y')}",
        "",
        f"👶 Bolalar: <b>{total_children}</b>",
        f"🎯 To'garaklar: <b>{total_clubs}</b>",
        f"✅ Bugungi davomat: <b>{att_present}/{att_total} ({att_pct}%)</b>",
        f"💸 Qarzdorlar ({month_str}): <b>{debtors}</b>",
    ]

    bar_filled = round(att_pct / 10)
    bar = "🟩" * bar_filled + "⬜" * (10 - bar_filled)
    lines.append(f"\n{bar} {att_pct}%")

    await message.answer("\n".join(lines), parse_mode="HTML")

# ── 📊 Statistika ─────────────────────────────────────────
@router.message(F.text == "📊 Statistika")
async def statistika(message: types.Message):
    user = await _get_director(message.from_user.id)
    if not user: return
    kg_id = await _kg_id(user)
    if not kg_id:
        await message.answer("Bog'cha biriktirilmagan.")
        return

    today  = date.today()
    week_start = today - timedelta(days=today.weekday())

    child_ids = await Child.filter(kindergarten_id=kg_id).values_list("id", flat=True)
    enr_ids   = await Enrollment.filter(child_id__in=list(child_ids), status="active").values_list("id", flat=True)

    # Haftalik davomat
    lines = ["📊 <b>Haftalik statistika</b>\n"]
    day_names = ["Du", "Se", "Ch", "Pa", "Ju", "Sh", "Ya"]
    for i in range(7):
        d = week_start + timedelta(days=i)
        if d > today:
            break
        total   = await Attendance.filter(enrollment_id__in=list(enr_ids), date=d).count() if enr_ids else 0
        present = await Attendance.filter(enrollment_id__in=list(enr_ids), date=d, status="present").count() if enr_ids else 0
        pct     = round(present / total * 100) if total else 0
        bar     = "🟩" * round(pct/20) + "⬜" * (5 - round(pct/20))
        lines.append(f"{day_names[i]} {d.strftime('%d.%m')}: {bar} {pct}%")

    # To'garaklar reytingi
    clubs = await Club.filter(kindergarten_id=kg_id).all()
    club_stats = []
    for club in clubs:
        count = await Enrollment.filter(club_id=club.id, status="active").count()
        club_stats.append((club.name, count))
    club_stats.sort(key=lambda x: x[1], reverse=True)

    lines.append("\n🏆 <b>To'garaklar (yozilganlar soni):</b>")
    for name, cnt in club_stats[:5]:
        lines.append(f"• {name}: {cnt} ta")

    await message.answer("\n".join(lines), parse_mode="HTML")

# ── 👨‍🏫 Xodimlar ──────────────────────────────────────────
@router.message(F.text == "👨‍🏫 Xodimlar")
async def xodimlar(message: types.Message):
    user = await _get_director(message.from_user.id)
    if not user: return
    kg_id = await _kg_id(user)
    if not kg_id: return

    staff = await User.filter(
        kindergarten_id=kg_id,
        role__in=["teacher", "togarak_rahbari", "iqtisodchi"]
    ).all()

    if not staff:
        await message.answer("Xodimlar ro'yxati bo'sh.")
        return

    lines = ["👨‍🏫 <b>Xodimlar ro'yxati</b>\n"]
    role_icons = {"teacher": "📚", "togarak_rahbari": "🎯", "iqtisodchi": "💰"}
    for s in staff:
        icon = role_icons.get(s.role, "👤")
        lines.append(f"{icon} <b>{s.full_name or '—'}</b> — {s.role}\n   📞 {s.phone or '—'}")

    await message.answer("\n".join(lines), parse_mode="HTML")

# ── 👶 Bolalar ────────────────────────────────────────────
@router.message(F.text == "👶 Bolalar")
async def bolalar(message: types.Message):
    user = await _get_director(message.from_user.id)
    if not user: return
    kg_id = await _kg_id(user)
    if not kg_id: return

    total    = await Child.filter(kindergarten_id=kg_id).count()
    children = await Child.filter(kindergarten_id=kg_id).order_by("full_name").limit(20).all()

    lines = [f"👶 <b>Bolalar ro'yxati</b> (jami: {total})\n"]
    for i, c in enumerate(children, 1):
        lines.append(f"{i}. {c.full_name} ({c.birth_year})")

    if total > 20:
        lines.append(f"\n... va yana {total - 20} ta")

    await message.answer("\n".join(lines), parse_mode="HTML")

# ── 💰 Moliya ─────────────────────────────────────────────
@router.message(F.text == "💰 Moliya")
async def moliya(message: types.Message):
    user = await _get_director(message.from_user.id)
    if not user: return
    kg_id = await _kg_id(user)
    if not kg_id: return

    today     = date.today()
    month_str = today.strftime("%Y-%m")

    child_ids = await Child.filter(kindergarten_id=kg_id).values_list("id", flat=True)
    enr_ids   = await Enrollment.filter(child_id__in=list(child_ids), status="active").values_list("id", flat=True)

    if not enr_ids:
        await message.answer("Ma'lumot yo'q.")
        return

    payments  = await Payment.filter(enrollment_id__in=list(enr_ids), month=month_str, status="completed").all()
    paid_ids  = {p.enrollment_id for p in payments}
    revenue   = sum(p.amount for p in payments if p.amount)
    debtors   = len(enr_ids) - len(paid_ids)
    pay_pct   = round(len(paid_ids) / len(enr_ids) * 100) if enr_ids else 0

    bar = "🟩" * round(pay_pct/20) + "⬜" * (5 - round(pay_pct/20))
    lines = [
        f"💰 <b>Moliyaviy holat — {month_str}</b>",
        "",
        f"💳 To'lagan: <b>{len(paid_ids)}</b> ta ({pay_pct}%)",
        f"❌ Qarzdor: <b>{debtors}</b> ta",
        f"💵 Daromad: <b>{revenue:,} so'm</b>",
        f"\n{bar} {pay_pct}%",
    ]
    await message.answer("\n".join(lines), parse_mode="HTML")

# ── 📢 E'lon ──────────────────────────────────────────────
@router.message(F.text == "📢 E'lon")
async def elon_start(message: types.Message):
    user = await _get_director(message.from_user.id)
    if not user: return

    kb = InlineKeyboardMarkup(inline_keyboard=[[
        InlineKeyboardButton(text="📢 Barcha ota-onalarga", callback_data="broadcast_parents"),
        InlineKeyboardButton(text="👨‍🏫 Xodimlarga",       callback_data="broadcast_staff"),
    ]])
    await message.answer("📢 Kimga e'lon yuborasiz?", reply_markup=kb)

@router.callback_query(F.data.startswith("broadcast_"))
async def broadcast_confirm(callback: types.CallbackQuery):
    target = callback.data.split("_")[1]
    label  = "ota-onalar" if target == "parents" else "xodimlar"
    await callback.answer()

    kb = InlineKeyboardMarkup(inline_keyboard=[[
        InlineKeyboardButton(text="✅ Ha, yuborish", callback_data=f"send_{target}"),
        InlineKeyboardButton(text="❌ Bekor",        callback_data="cancel_broadcast"),
    ]])
    await callback.message.answer(
        f"📢 <b>{label.capitalize()}</b> ga e'lon yuborishingiz uchun xabar matnini yuboring.",
        parse_mode="HTML", reply_markup=kb
    )

@router.callback_query(F.data == "cancel_broadcast")
async def cancel_broadcast(callback: types.CallbackQuery):
    await callback.answer("Bekor qilindi")
    await callback.message.delete()

# ── 🤖 AI Tahlil ──────────────────────────────────────────
@router.message(F.text == "🤖 AI Tahlil")
async def ai_tahlil(message: types.Message):
    user = await _get_director(message.from_user.id)
    if not user: return
    lang = get_lang(user)

    await message.answer(
        "🤖 Savolingizni yozing.\n\n"
        "Masalan:\n"
        "• Bu oyda davomat nima uchun tushdi?\n"
        "• Qaysi to'garak eng ko'p qarzdorga ega?\n"
        "• Xodimlar samaradorligini qanday oshirish mumkin?"
    )

@router.message(F.text == "👤 Profil")
async def profil(message: types.Message):
    user = await _get_director(message.from_user.id)
    if not user: return
    lang  = get_lang(user)
    kg_id = await _kg_id(user)
    kg    = await Kindergarten.get_or_none(id=kg_id) if kg_id else None

    lines = [
        "👤 <b>Profil</b>",
        "",
        f"Ism: {user.full_name or '—'}",
        f"Telefon: {user.phone or '—'}",
        f"Rol: {user.role}",
        f"Bog'cha: {kg.name if kg else '—'}",
        f"Til: {user.language or 'uz'}",
    ]
    await message.answer("\n".join(lines), parse_mode="HTML")
