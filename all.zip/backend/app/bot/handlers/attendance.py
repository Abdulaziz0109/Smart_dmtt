"""
SmartDMTT v4.0 — Davomat handlerlari
Spec 6.1–6.3 bo'yicha: Ikki tomonlama tekshiruv.
"""
import logging
from datetime import date, datetime

from aiogram import Router, F, Bot, types
from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton

from app.models import Child, Club, User, Attendance, AbsenceNotice
from app.models.club import Enrollment
from app.models.rating import Rating

logger = logging.getLogger(__name__)
router = Router()


# ─── Muallimga dars boshlandi xabari ─────────────────────────────────────────

async def notify_teacher_class_start(bot: Bot, club_id: int, today: date):
    """Dars vaqti keldi — muallimga davomat belgilash xabari."""
    club = await Club.get_or_none(id=club_id, is_active=True)
    if not club or not club.teacher_id:
        return

    teacher = await User.get_or_none(id=club.teacher_id)
    if not teacher or not teacher.telegram_id:
        return

    enrollments = await Enrollment.filter(club_id=club_id, status="active").all()
    if not enrollments:
        return

    buttons = []
    for enr in enrollments:
        child = await Child.get_or_none(id=enr.child_id)
        if not child:
            continue

        absence = await AbsenceNotice.filter(
            enrollment_id=enr.id, date=today
        ).first()

        default = "absent" if absence else "present"
        label = f"{'✅' if default == 'present' else '❌'} {child.full_name}"
        buttons.append([InlineKeyboardButton(
            text=label,
            callback_data=f"att_t:{enr.id}:{default}"
        )])

    if not buttons:
        return

    buttons.append([InlineKeyboardButton(
        text="💾 Saqlash",
        callback_data=f"att_save:{club_id}:{today.isoformat()}"
    )])

    kb = InlineKeyboardMarkup(inline_keyboard=buttons)
    await bot.send_message(
        teacher.telegram_id,
        f"📚 <b>{club.name}</b> boshlandi!\n"
        f"Davomatni belgilang ({today.strftime('%d.%m.%Y')}):",
        parse_mode="HTML",
        reply_markup=kb
    )


# ─── Toggle ───────────────────────────────────────────────────────────────────

@router.callback_query(F.data.startswith("att_t:"))
async def toggle_attendance(callback: types.CallbackQuery):
    _, enr_id_str, current = callback.data.split(":")
    enr_id = int(enr_id_str)
    new_status = "absent" if current == "present" else "present"

    enr = await Enrollment.get_or_none(id=enr_id)
    if not enr:
        await callback.answer("Xatolik.")
        return

    child = await Child.get_or_none(id=enr.child_id)
    label = f"{'✅' if new_status == 'present' else '❌'} {child.full_name if child else '?'}"

    kb = callback.message.reply_markup
    if kb:
        new_buttons = []
        for row in kb.inline_keyboard:
            new_row = []
            for btn in row:
                if btn.callback_data == callback.data:
                    new_row.append(InlineKeyboardButton(
                        text=label,
                        callback_data=f"att_t:{enr_id}:{new_status}"
                    ))
                else:
                    new_row.append(btn)
            new_buttons.append(new_row)
        await callback.message.edit_reply_markup(
            reply_markup=InlineKeyboardMarkup(inline_keyboard=new_buttons)
        )
    await callback.answer()


# ─── Saqlash ──────────────────────────────────────────────────────────────────

@router.callback_query(F.data.startswith("att_save:"))
async def save_attendance(callback: types.CallbackQuery):
    parts = callback.data.split(":")
    club_id = int(parts[1])
    today = date.fromisoformat(parts[2])

    kb = callback.message.reply_markup
    saved = []

    if kb:
        for row in kb.inline_keyboard:
            for btn in row:
                if btn.callback_data and btn.callback_data.startswith("att_t:"):
                    _, enr_id_str, status = btn.callback_data.split(":")
                    enr_id = int(enr_id_str)

                    att, created = await Attendance.get_or_create(
                        enrollment_id=enr_id,
                        date=today,
                        defaults={"status": status, "teacher_confirmed": True}
                    )
                    if not created:
                        att.status = status
                        att.teacher_confirmed = True
                        await att.save()

                    saved.append((enr_id, status))

    # Ota-onalarga xabar
    bot = callback.bot
    for enr_id, status in saved:
        enr = await Enrollment.get_or_none(id=enr_id)
        if not enr:
            continue
        child = await Child.get_or_none(id=enr.child_id)
        if not child:
            continue
        parent = await User.get_or_none(id=child.parent_id)
        if not parent or not parent.telegram_id:
            continue

        absence = await AbsenceNotice.filter(enrollment_id=enr_id, date=today).exists()
        if absence:
            continue

        if status == "present":
            kb_parent = InlineKeyboardMarkup(inline_keyboard=[[
                InlineKeyboardButton(text="✅ Ha, o'zim kuzatib qoldim", callback_data=f"att_p_ok:{enr_id}:{today.isoformat()}"),
                InlineKeyboardButton(text="❌ Xato", callback_data=f"att_p_err:{enr_id}:{today.isoformat()}"),
            ]])
            await bot.send_message(
                parent.telegram_id,
                f"✅ <b>{child.full_name}</b> bugun to'garakda qatnashmoqda.",
                parse_mode="HTML",
                reply_markup=kb_parent
            )
        else:
            kb_parent = InlineKeyboardMarkup(inline_keyboard=[[
                InlineKeyboardButton(text="🤒 Kasal", callback_data=f"att_p_sick:{enr_id}:{today.isoformat()}"),
                InlineKeyboardButton(text="🚗 Boshqa", callback_data=f"att_p_other:{enr_id}:{today.isoformat()}"),
                InlineKeyboardButton(text="⏭ O'tkazib", callback_data=f"att_p_skip:{enr_id}:{today.isoformat()}"),
            ]])
            await bot.send_message(
                parent.telegram_id,
                f"❌ <b>{child.full_name}</b> bugun to'garakda qatnashmadi.",
                parse_mode="HTML",
                reply_markup=kb_parent
            )

    await callback.message.edit_reply_markup(reply_markup=None)
    await callback.message.answer(
        f"✅ Davomat saqlandi ({len(saved)} o'quvchi).\n⭐ Baholash:"
    )
    await _start_rating(callback.message, saved)
    await callback.answer()


async def _start_rating(message: types.Message, saved: list):
    """Baholash bosqichi."""
    for enr_id, _ in saved:
        enr = await Enrollment.get_or_none(id=enr_id)
        if not enr:
            continue
        child = await Child.get_or_none(id=enr.child_id)
        if not child:
            continue

        kb = InlineKeyboardMarkup(inline_keyboard=[[
            InlineKeyboardButton(text=str(i), callback_data=f"rate_child:{enr_id}:{i}")
            for i in range(1, 6)
        ], [
            InlineKeyboardButton(text="⏭ O'tkazib yuborish", callback_data=f"rate_skip:{enr_id}")
        ]])
        await message.answer(
            f"⭐ <b>{child.full_name}</b> — baho:",
            parse_mode="HTML",
            reply_markup=kb
        )


# ─── Ota-ona tasdiqlash callbacklari ─────────────────────────────────────────

@router.callback_query(F.data.startswith("att_p_ok:"))
async def parent_ok(callback: types.CallbackQuery):
    parts = callback.data.split(":")
    enr_id, date_str = int(parts[1]), parts[2]
    att = await Attendance.get_or_none(enrollment_id=enr_id, date=date.fromisoformat(date_str))
    if att:
        att.parent_confirmed = True
        att.parent_confirmed_at = datetime.now()
        await att.save()
    await callback.message.edit_reply_markup(reply_markup=None)
    await callback.answer("✅ Tasdiqlandi!")


@router.callback_query(F.data.startswith("att_p_err:"))
async def parent_err(callback: types.CallbackQuery):
    parts = callback.data.split(":")
    enr_id, date_str = int(parts[1]), parts[2]
    att = await Attendance.get_or_none(enrollment_id=enr_id, date=date.fromisoformat(date_str))
    if att:
        att.parent_confirmed = False
        att.parent_confirmed_at = datetime.now()
        await att.save()
        logger.warning(f"Anomaliya flag: ota-ona rad etdi. enrollment_id={enr_id}")
    await callback.message.edit_reply_markup(reply_markup=None)
    await callback.answer("❌ Qayd etildi.")


@router.callback_query(F.data.startswith("att_p_sick:"))
async def parent_sick(callback: types.CallbackQuery):
    parts = callback.data.split(":")
    enr_id, date_str = int(parts[1]), parts[2]
    att = await Attendance.get_or_none(enrollment_id=enr_id, date=date.fromisoformat(date_str))
    if att:
        att.parent_confirmed = True
        att.excuse_reason = "sick"
        att.parent_confirmed_at = datetime.now()
        await att.save()
    await callback.message.edit_reply_markup(reply_markup=None)
    await callback.answer("🤒 Qayd etildi.")


@router.callback_query(F.data.startswith("att_p_other:"))
async def parent_other(callback: types.CallbackQuery):
    parts = callback.data.split(":")
    enr_id, date_str = int(parts[1]), parts[2]
    att = await Attendance.get_or_none(enrollment_id=enr_id, date=date.fromisoformat(date_str))
    if att:
        att.parent_confirmed = True
        att.excuse_reason = "other"
        att.parent_confirmed_at = datetime.now()
        await att.save()
    await callback.message.edit_reply_markup(reply_markup=None)
    await callback.answer("🚗 Qayd etildi.")


@router.callback_query(F.data.startswith("att_p_skip:"))
async def parent_skip(callback: types.CallbackQuery):
    await callback.message.edit_reply_markup(reply_markup=None)
    await callback.answer("⏭")


# ─── Baholash ─────────────────────────────────────────────────────────────────

@router.callback_query(F.data.startswith("rate_child:"))
async def rate_child(callback: types.CallbackQuery):
    parts = callback.data.split(":")
    enr_id, rating_val = int(parts[1]), int(parts[2])
    enr = await Enrollment.get_or_none(id=enr_id)
    if enr:
        week_str = date.today().strftime("%Y-W%V")
        await Rating.get_or_create(
            rater_id=callback.from_user.id,
            rated_child_id=enr.child_id,
            club_id=enr.club_id,
            week=week_str,
            defaults={"rating": rating_val}
        )
    await callback.message.edit_reply_markup(reply_markup=None)
    await callback.answer(f"⭐ {rating_val}")


@router.callback_query(F.data.startswith("rate_skip:"))
async def rate_skip(callback: types.CallbackQuery):
    await callback.message.edit_reply_markup(reply_markup=None)
    await callback.answer("⏭")
