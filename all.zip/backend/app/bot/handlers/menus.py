"""
SmartDMTT v4.0 — Bot menyulari (barcha rollar uchun)
"""
from aiogram.types import ReplyKeyboardMarkup, KeyboardButton, InlineKeyboardMarkup, InlineKeyboardButton
from aiogram.types import WebAppInfo


def get_greeting(name: str) -> str:
    return f"👋 Xush kelibsiz, <b>{name}</b>!"


def _parse_role(role: str) -> str:
    roles = [r.strip().lower() for r in role.split(",")]
    priority = ["admin", "boshliq", "mmtb_boshligi", "iqtisodchi", "director", "teacher", "togarak_rahbari", "oqituvchi", "parent", "guest"]
    for p in priority:
        if p in roles:
            return p
    return roles[0] if roles else "guest"


def get_menu_keyboard(role: str) -> ReplyKeyboardMarkup:
    r = _parse_role(role)

    if r == "guest":
        return ReplyKeyboardMarkup(keyboard=[
            [KeyboardButton(text="🗺 Bog'chalar xaritasi"), KeyboardButton(text="📚 To'garaklar")],
            [KeyboardButton(text="📣 E'lonlar"), KeyboardButton(text="🤖 Yordamchi")],
            [KeyboardButton(text="👨‍👩‍👧 Ota-ona sifatida ro'yxatdan o'tish")],
        ], resize_keyboard=True)

    elif r == "parent":
        return ReplyKeyboardMarkup(keyboard=[
            [KeyboardButton(text="👶 Bolam"), KeyboardButton(text="📚 To'garaklar")],
            [KeyboardButton(text="💰 To'lov"), KeyboardButton(text="📣 E'lonlar")],
            [KeyboardButton(text="🤖 Yordamchi"), KeyboardButton(text="👤 Profil")],
        ], resize_keyboard=True)

    elif r in ("teacher", "togarak_rahbari", "oqituvchi"):
        return ReplyKeyboardMarkup(keyboard=[
            [KeyboardButton(text="📅 Davomat"), KeyboardButton(text="👶 Guruhim")],
            [KeyboardButton(text="📊 Statistika"), KeyboardButton(text="📣 E'lon")],
            [KeyboardButton(text="🤖 Yordamchi"), KeyboardButton(text="👤 Profil")],
        ], resize_keyboard=True)

    elif r == "director":
        return ReplyKeyboardMarkup(keyboard=[
            [KeyboardButton(text="📊 Statistika"), KeyboardButton(text="👩‍🏫 Xodimlar")],
            [KeyboardButton(text="👶 Bolalar"), KeyboardButton(text="📚 To'garaklar")],
            [KeyboardButton(text="💰 Moliya"), KeyboardButton(text="📣 E'lon")],
            [KeyboardButton(text="🤖 Yordamchi"), KeyboardButton(text="👤 Profil")],
        ], resize_keyboard=True)

    elif r in ("boshliq", "mmtb_boshligi"):
        return ReplyKeyboardMarkup(keyboard=[
            [KeyboardButton(text="📊 Statistika"), KeyboardButton(text="🏫 Bog'chalar")],
            [KeyboardButton(text="👩‍🏫 Muallimlar"), KeyboardButton(text="💰 Moliya")],
            [KeyboardButton(text="⚠️ Anomaliyalar"), KeyboardButton(text="📣 E'lon")],
            [KeyboardButton(text="🤖 Yordamchi"), KeyboardButton(text="👤 Profil")],
        ], resize_keyboard=True)

    elif r in ("admin", "iqtisodchi"):
        return ReplyKeyboardMarkup(keyboard=[
            [KeyboardButton(text="👥 Foydalanuvchilar"), KeyboardButton(text="🏫 Bog'chalar")],
            [KeyboardButton(text="📚 To'garaklar"), KeyboardButton(text="💰 Moliya")],
            [KeyboardButton(text="⚠️ Anomaliyalar"), KeyboardButton(text="📊 Statistika")],
            [KeyboardButton(text="🤖 Yordamchi"), KeyboardButton(text="📣 Broadcast")],
            [KeyboardButton(text="🔧 Tizim"), KeyboardButton(text="👤 Profil")],
        ], resize_keyboard=True)

    return ReplyKeyboardMarkup(keyboard=[
        [KeyboardButton(text="🏠 Asosiy")],
    ], resize_keyboard=True)


def get_webapp_button(webapp_url: str) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[[
        InlineKeyboardButton(
            text="📱 WebApp ni ochish",
            web_app=WebAppInfo(url=webapp_url)
        )
    ]])
