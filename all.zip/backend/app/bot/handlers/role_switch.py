"""
SmartDMTT v4 — Admin Rol Almashtirish Bot Handleri
/rol komandasi — faqat admin va boshliq uchun.
Foydalanuvchiga test uchun rol berish yoki o'zgartirish.
"""
import logging
from aiogram import Router, F, types
from aiogram.filters import Command
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton

from app.models.user import User

logger = logging.getLogger(__name__)
router = Router()

ADMIN_IDS_ROLES = ["admin", "boshliq", "mmtb_boshligi"]

ALL_ROLES = [
    ("admin",            "🔑 Admin"),
    ("boshliq",          "🏛 Boshliq"),
    ("mmtb_boshligi",    "🏢 MMTB Boshliq"),
    ("director",         "🏫 Direktor"),
    ("iqtisodchi",       "📊 Iqtisodchi"),
    ("teacher",          "👨‍🏫 Muallim"),
    ("togarak_rahbari",  "🎯 To'garak rahbar"),
    ("parent",           "👨‍👧 Ota-ona"),
    ("guest",            "👤 Mehmon"),
]


class RoleSwitchState(StatesGroup):
    waiting_user_id = State()


async def _is_admin(tg_id: int) -> bool:
    user = await User.get_or_none(telegram_id=tg_id)
    return user is not None and user.role in ADMIN_IDS_ROLES


# ─── /rol komandasi ───────────────────────────────────────────────────────────

@router.message(Command("rol"))
async def cmd_rol(message: types.Message, state: FSMContext):
    """Admin o'zi uchun rol almashtirishi yoki boshqa foydalanuvchiga."""
    if not await _is_admin(message.from_user.id):
        return

    user = await User.get_or_none(telegram_id=message.from_user.id)
    if not user:
        return

    # /rol 998900000002 teacher — to'g'ridan buyruq
    args = message.text.split()[1:] if message.text else []
    if len(args) == 2:
        target_phone_or_id, new_role = args
        target = await User.get_or_none(phone=f"+{target_phone_or_id.lstrip('+')}") or \
                 await User.get_or_none(id=int(target_phone_or_id) if target_phone_or_id.isdigit() else 0)
        if not target:
            await message.answer(f"❌ Foydalanuvchi topilmadi: {target_phone_or_id}")
            return
        valid_roles = [r for r, _ in ALL_ROLES]
        if new_role not in valid_roles:
            await message.answer(f"❌ Noto'g'ri rol. Mavjud: {', '.join(valid_roles)}")
            return
        old_role = target.role
        target.role = new_role
        await target.save()
        await message.answer(
            f"✅ <b>{target.full_name}</b> roli o'zgartirildi:\n"
            f"{old_role} → <b>{new_role}</b>",
            parse_mode="HTML"
        )
        return

    # O'zi uchun rol tanlash
    kb = _build_role_kb(user.id, "self")
    await message.answer(
        f"👤 <b>{user.full_name}</b>\n"
        f"Hozirgi rol: <code>{user.role}</code>\n\n"
        f"Qaysi rolda test qilmoqchisiz?\n"
        f"(Faqat test uchun — haqiqiy huquqlar saqlanadi)",
        parse_mode="HTML",
        reply_markup=kb
    )


def _build_role_kb(user_id, target: str) -> InlineKeyboardMarkup:
    rows = []
    for role, label in ALL_ROLES:
        rows.append([InlineKeyboardButton(
            text=label,
            callback_data=f"setrol:{user_id}:{role}:{target}"
        )])
    rows.append([InlineKeyboardButton(text="❌ Bekor qilish", callback_data="setrol_cancel")])
    return InlineKeyboardMarkup(inline_keyboard=rows)


@router.callback_query(F.data.startswith("setrol:"))
async def cb_setrol(callback: types.CallbackQuery):
    if not await _is_admin(callback.from_user.id):
        await callback.answer("Ruxsat yo'q", show_alert=True)
        return

    parts = callback.data.split(":")
    target_id = int(parts[1])
    new_role   = parts[2]

    target = await User.get_or_none(id=target_id)
    if not target:
        await callback.answer("Foydalanuvchi topilmadi", show_alert=True)
        return

    old_role = target.role
    target.role = new_role
    await target.save()

    await callback.answer(f"✅ Rol: {new_role}", show_alert=False)
    try:
        await callback.message.edit_text(
            f"✅ <b>{target.full_name}</b>\n"
            f"Rol o'zgartirildi: <code>{old_role}</code> → <b>{new_role}</b>\n\n"
            f"🔄 Webapp da qayta kirish kerak (token yangilanadi).",
            parse_mode="HTML"
        )
    except Exception:
        pass


@router.callback_query(F.data == "setrol_cancel")
async def cb_setrol_cancel(callback: types.CallbackQuery):
    await callback.answer()
    try:
        await callback.message.delete()
    except Exception:
        pass


# ─── /users — foydalanuvchilar ro'yxati ──────────────────────────────────────

@router.message(Command("users"))
async def cmd_users(message: types.Message):
    if not await _is_admin(message.from_user.id):
        return

    users = await User.all().order_by("role").limit(30)
    lines = []
    for u in users:
        tg = f"tg:{u.telegram_id}" if u.telegram_id else "—"
        lines.append(f"<code>{u.id}</code> | {u.role:<18} | {u.full_name or '—'} | {tg}")

    await message.answer(
        f"👥 <b>Foydalanuvchilar ({len(users)} ta)</b>\n\n" + "\n".join(lines),
        parse_mode="HTML"
    )


# ─── /setrole telefon@rol — tezkor ───────────────────────────────────────────

@router.message(Command("setrole"))
async def cmd_setrole(message: types.Message):
    """
    /setrole +998900000002 teacher
    Boshqa foydalanuvchiga rol berish.
    """
    if not await _is_admin(message.from_user.id):
        return

    args = message.text.split()[1:]
    if len(args) < 2:
        roles_text = "\n".join(f"  • {r}" for r, _ in ALL_ROLES)
        await message.answer(
            "❌ Noto'g'ri format.\n\n"
            "Ishlatish:\n"
            "<code>/setrole +998900000002 teacher</code>\n\n"
            f"Mavjud rollar:\n{roles_text}",
            parse_mode="HTML"
        )
        return

    phone_or_id = args[0]
    new_role    = args[1]
    valid_roles = [r for r, _ in ALL_ROLES]

    if new_role not in valid_roles:
        await message.answer(f"❌ Noto'g'ri rol: <code>{new_role}</code>", parse_mode="HTML")
        return

    # Qidirish
    target = None
    if phone_or_id.lstrip("+").isdigit() and len(phone_or_id) > 8:
        # Telefon raqam
        normalized = phone_or_id if phone_or_id.startswith("+") else f"+{phone_or_id}"
        target = await User.get_or_none(phone=normalized)
    if not target and phone_or_id.isdigit():
        target = await User.get_or_none(id=int(phone_or_id))
    if not target and phone_or_id.isdigit():
        target = await User.get_or_none(telegram_id=int(phone_or_id))

    if not target:
        await message.answer(f"❌ Foydalanuvchi topilmadi: <code>{phone_or_id}</code>", parse_mode="HTML")
        return

    old_role = target.role
    target.role = new_role
    await target.save()

    role_label = dict(ALL_ROLES).get(new_role, new_role)
    await message.answer(
        f"✅ <b>Rol o'zgartirildi</b>\n\n"
        f"👤 {target.full_name or '—'}\n"
        f"📞 {target.phone or '—'}\n"
        f"⬅️ Eski rol: <code>{old_role}</code>\n"
        f"➡️ Yangi rol: <b>{role_label}</b>\n\n"
        f"🔄 Webapp da qayta kirish kerak.",
        parse_mode="HTML"
    )
