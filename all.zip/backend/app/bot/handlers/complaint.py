"""
SmartDMTT v4 — Shikoyat, taklif, maqtov handleri (barcha rollar)
Javob zanjiri: Direktor 24h -> MMTB boshliq 3 kun -> Admin
"""
import logging
from datetime import datetime

from aiogram import Router, F, Bot
from aiogram.types import (
    Message, CallbackQuery,
    InlineKeyboardMarkup, InlineKeyboardButton
)
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup

from app.models import User
from app.models.complaint import Complaint
from app.core.strings import get_string

logger = logging.getLogger(__name__)
router = Router()


class ComplaintFSM(StatesGroup):
    choose_type     = State()
    choose_target   = State()
    choose_anon     = State()
    enter_text      = State()


def _type_keyboard(lang: str) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="📢 Shikoyat",  callback_data="cmp_type:complaint")],
        [InlineKeyboardButton(text="💡 Taklif",    callback_data="cmp_type:suggestion")],
        [InlineKeyboardButton(text="👏 Maqtov",    callback_data="cmp_type:praise")],
        [InlineKeyboardButton(text=get_string(lang, "cancel"), callback_data="cmp_cancel")],
    ])


def _target_keyboard(lang: str) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="👩‍🏫 Muallim",    callback_data="cmp_tgt:teacher")],
        [InlineKeyboardButton(text="🏫 Bog'cha",     callback_data="cmp_tgt:kindergarten")],
        [InlineKeyboardButton(text="📚 To'garak",    callback_data="cmp_tgt:club")],
        [InlineKeyboardButton(text="⚙️ Tizim",       callback_data="cmp_tgt:system")],
        [InlineKeyboardButton(text=get_string(lang, "back"), callback_data="cmp_back_type")],
    ])


def _anon_keyboard(lang: str) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[
        [
            InlineKeyboardButton(text="🎭 Anonim",   callback_data="cmp_anon:yes"),
            InlineKeyboardButton(text="👤 Ochiq",    callback_data="cmp_anon:no"),
        ],
        [InlineKeyboardButton(text=get_string(lang, "back"), callback_data="cmp_back_tgt")],
    ])


# ─── Entry point ─────────────────────────────────────────────────────────────

async def start_complaint(message: Message, state: FSMContext, user: User):
    """Menyudan chaqiriladi."""
    lang = user.language or "uz_latin"
    await state.update_data(lang=lang, user_id=user.id)
    await message.answer(get_string(lang, "complaint_type"), reply_markup=_type_keyboard(lang))
    await state.set_state(ComplaintFSM.choose_type)


@router.callback_query(F.data.startswith("cmp_type:"), ComplaintFSM.choose_type)
async def choose_type(cb: CallbackQuery, state: FSMContext):
    ctype = cb.data.split(":")[1]
    data = await state.get_data()
    lang = data.get("lang", "uz_latin")
    await state.update_data(complaint_type=ctype)
    await cb.message.edit_text(get_string(lang, "complaint_target"), reply_markup=_target_keyboard(lang))
    await state.set_state(ComplaintFSM.choose_target)
    await cb.answer()


@router.callback_query(F.data.startswith("cmp_tgt:"), ComplaintFSM.choose_target)
async def choose_target(cb: CallbackQuery, state: FSMContext):
    target = cb.data.split(":")[1]
    data = await state.get_data()
    lang = data.get("lang", "uz_latin")
    await state.update_data(target_type=target)
    await cb.message.edit_text(get_string(lang, "complaint_anonymous"), reply_markup=_anon_keyboard(lang))
    await state.set_state(ComplaintFSM.choose_anon)
    await cb.answer()


@router.callback_query(F.data.startswith("cmp_anon:"), ComplaintFSM.choose_anon)
async def choose_anon(cb: CallbackQuery, state: FSMContext):
    is_anon = cb.data.split(":")[1] == "yes"
    data = await state.get_data()
    lang = data.get("lang", "uz_latin")
    await state.update_data(is_anonymous=is_anon)
    await cb.message.edit_text(get_string(lang, "complaint_text"))
    await state.set_state(ComplaintFSM.enter_text)
    await cb.answer()


@router.message(ComplaintFSM.enter_text)
async def enter_text(message: Message, state: FSMContext, bot: Bot):
    data = await state.get_data()
    lang = data.get("lang", "uz_latin")
    text = message.text.strip()

    if len(text) < 5:
        await message.answer("Matn juda qisqa. Batafsil yozing:")
        return

    user = await User.get_or_none(id=data["user_id"])
    complaint = await Complaint.create(
        user=user,
        complaint_type=data.get("complaint_type", "complaint"),
        target_type=data.get("target_type", "system"),
        text=text,
        is_anonymous=data.get("is_anonymous", True),
        status="new",
    )

    await message.answer(get_string(lang, "complaint_sent"))
    await state.clear()

    # Javob zanjiri — direktor + boshliqqa xabar
    await _notify_admins(bot, complaint, user, lang)


async def _notify_admins(bot: Bot, complaint: Complaint, sender: User, lang: str):
    """Direktor va boshliqqa yangi shikoyat haqida xabar."""
    type_map = {"complaint": "Shikoyat", "suggestion": "Taklif", "praise": "Maqtov"}
    target_map = {"teacher": "Muallim", "club": "To'garak", "kindergarten": "Bog'cha", "system": "Tizim"}

    sender_info = "Anonim" if complaint.is_anonymous else (sender.full_name or str(sender.id))
    notification = (
        f"📩 Yangi {type_map.get(complaint.complaint_type, complaint.complaint_type)}\n"
        f"Kimdan: {sender_info}\n"
        f"Kimga: {target_map.get(complaint.target_type, complaint.target_type)}\n"
        f"Matn: {complaint.text[:300]}"
    )

    try:
        recipients = await User.filter(role__in=["admin", "boshliq", "director"]).all()
        for r in recipients:
            if r.telegram_id:
                await bot.send_message(r.telegram_id, notification)
    except Exception as e:
        logger.warning(f"Shikoyat bildirishnomasi xatosi: {e}")


# ─── Orqaga tugmalari ─────────────────────────────────────────────────────────

@router.callback_query(F.data == "cmp_back_type", ComplaintFSM.choose_target)
async def back_to_type(cb: CallbackQuery, state: FSMContext):
    data = await state.get_data()
    lang = data.get("lang", "uz_latin")
    await cb.message.edit_text(get_string(lang, "complaint_type"), reply_markup=_type_keyboard(lang))
    await state.set_state(ComplaintFSM.choose_type)
    await cb.answer()


@router.callback_query(F.data == "cmp_back_tgt", ComplaintFSM.choose_anon)
async def back_to_target(cb: CallbackQuery, state: FSMContext):
    data = await state.get_data()
    lang = data.get("lang", "uz_latin")
    await cb.message.edit_text(get_string(lang, "complaint_target"), reply_markup=_target_keyboard(lang))
    await state.set_state(ComplaintFSM.choose_target)
    await cb.answer()


@router.callback_query(F.data == "cmp_cancel")
async def cancel_complaint(cb: CallbackQuery, state: FSMContext):
    user = await User.get_or_none(telegram_id=cb.from_user.id)
    lang = user.language if user else "uz_latin"
    await cb.message.edit_text(get_string(lang, "cancelled"))
    await state.clear()
    await cb.answer()
