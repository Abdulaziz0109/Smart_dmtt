"""
SmartDMTT v4.0 — Sozlamalar handler
/sozlamalar, /profil, /yordam, /parol_almashtirish
Til almashtirish, profil ko'rish, yordam
"""
import logging
import bcrypt

from aiogram import Router, F, types
from aiogram.filters import Command
from aiogram.fsm.context import FSMContext
from aiogram.types import (
    InlineKeyboardMarkup, InlineKeyboardButton,
    ReplyKeyboardRemove, ReplyKeyboardMarkup, KeyboardButton
)

from app.models.user import User
from app.bot.states.registration import PasswordState
from app.bot.states.assistant import AssistantState

logger = logging.getLogger(__name__)
router = Router()


# ─── Yordamchi ───────────────────────────────────────────────────────────────

def _lang_label(code: str) -> str:
    return {
        "uz_latin":   "O'zbek (lotin) ✅",
        "uz_cyrillic": "Ўзбек (кирил) ✅",
        "ru":          "Русский ✅",
        "en":          "English ✅",
        "tr":          "Türkçe ✅",
    }.get(code, code)


def _settings_keyboard() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="🌐 Til", callback_data="settings_lang"),
         InlineKeyboardButton(text="🔐 Parol", callback_data="settings_parol")],
        [InlineKeyboardButton(text="❌ Yopish", callback_data="settings_close")],
    ])


def _lang_keyboard(current_lang: str) -> InlineKeyboardMarkup:
    langs = [
        ("O'zbek (lotin)",  "uz_latin"),
        ("Ўзбек (кирил)",   "uz_cyrillic"),
        ("Русский",         "ru"),
        ("English",         "en"),
        ("Türkçe",          "tr"),
    ]
    rows = []
    for label, code in langs:
        check = " ✅" if current_lang == code else ""
        rows.append([InlineKeyboardButton(
            text=label + check,
            callback_data=f"set_lang:{code}"
        )])
    rows.append([InlineKeyboardButton(text="⬅️ Orqaga", callback_data="back_to_settings")])
    return InlineKeyboardMarkup(inline_keyboard=rows)


def _role_display(role: str) -> str:
    mapping = {
        "admin":         "🔑 Administrator",
        "boshliq":       "🏛 MMTB Boshliq",
        "mmtb_boshligi": "🏛 MMTB Boshliq",
        "iqtisodchi":    "💼 Iqtisodchi",
        "director":      "🏫 Direktor",
        "teacher":       "👩‍🏫 O'qituvchi",
        "togarak_rahbari":"🎯 To'garak rahbari",
        "oqituvchi":     "👩‍🏫 O'qituvchi",
        "parent":        "👨‍👩‍👧 Ota-ona",
        "guest":         "👤 Mehmon",
    }
    return mapping.get(role.strip().lower(), role)


# ─── /sozlamalar ─────────────────────────────────────────────────────────────

@router.message(Command("sozlamalar"))
@router.message(F.text.in_({"🔧 Tizim", "⚙️ Sozlamalar"}))
async def cmd_sozlamalar(message: types.Message):
    user = await User.get_or_none(telegram_id=message.from_user.id)
    lang = user.language if user else "uz_latin"
    role = user.role if user else "guest"

    await message.answer(
        f"⚙️ <b>Sozlamalar</b>\n\n"
        f"👤 Rol: {_role_display(role)}\n"
        f"🌐 Til: {_lang_label(lang)}\n\n"
        f"Nimani o'zgartirmoqchisiz?",
        parse_mode="HTML",
        reply_markup=_settings_keyboard()
    )


# ─── Til tanlash ─────────────────────────────────────────────────────────────

@router.callback_query(F.data == "settings_lang")
async def settings_lang(callback: types.CallbackQuery):
    user = await User.get_or_none(telegram_id=callback.from_user.id)
    lang = user.language if user else "uz_latin"

    await callback.message.edit_text(
        "🌐 <b>Tilni tanlang:</b>",
        parse_mode="HTML",
        reply_markup=_lang_keyboard(lang)
    )
    await callback.answer()


@router.callback_query(F.data.startswith("set_lang:"))
async def set_language(callback: types.CallbackQuery):
    lang_code = callback.data.split(":")[1]
    valid = {"uz_latin", "uz_cyrillic", "ru", "en", "tr"}
    if lang_code not in valid:
        await callback.answer("Noto'g'ri til.")
        return

    user = await User.get_or_none(telegram_id=callback.from_user.id)
    if user:
        user.language = lang_code
        await user.save()

    await callback.message.edit_text(
        f"✅ Til o'zgartirildi: <b>{_lang_label(lang_code)}</b>",
        parse_mode="HTML",
        reply_markup=InlineKeyboardMarkup(inline_keyboard=[[
            InlineKeyboardButton(text="⬅️ Sozlamalarga qaytish", callback_data="back_to_settings")
        ]])
    )
    await callback.answer("✅ Saqlandi")


@router.callback_query(F.data == "back_to_settings")
async def back_to_settings(callback: types.CallbackQuery):
    user = await User.get_or_none(telegram_id=callback.from_user.id)
    lang = user.language if user else "uz_latin"
    role = user.role if user else "guest"

    await callback.message.edit_text(
        f"⚙️ <b>Sozlamalar</b>\n\n"
        f"👤 Rol: {_role_display(role)}\n"
        f"🌐 Til: {_lang_label(lang)}\n\n"
        f"Nimani o'zgartirmoqchisiz?",
        parse_mode="HTML",
        reply_markup=_settings_keyboard()
    )
    await callback.answer()


@router.callback_query(F.data == "settings_close")
async def settings_close(callback: types.CallbackQuery):
    await callback.message.delete()
    await callback.answer("Yopildi")


# ─── /profil ─────────────────────────────────────────────────────────────────

@router.message(Command("profil"))
@router.message(F.text == "👤 Profil")
async def cmd_profil(message: types.Message):
    user = await User.get_or_none(telegram_id=message.from_user.id)
    if not user:
        await message.answer("❌ Foydalanuvchi topilmadi. /start yuboring.")
        return

    kg_name = ""
    if user.kindergarten_id:
        try:
            from app.models.kindergarten import Kindergarten
            kg = await Kindergarten.get_or_none(id=user.kindergarten_id)
            kg_name = f"\n🏫 Bog'cha: {kg.name}" if kg else ""
        except Exception:
            pass

    tg_link = ""
    if user.username:
        tg_link = f"\n🔗 @{user.username}"

    await message.answer(
        f"👤 <b>Profil</b>\n\n"
        f"📛 Ism: {user.full_name or '—'}\n"
        f"📱 Telefon: {user.phone or '—'}\n"
        f"🎭 Rol: {_role_display(user.role or 'guest')}\n"
        f"🌐 Til: {_lang_label(user.language or 'uz_latin')}"
        f"{kg_name}{tg_link}\n\n"
        f"🔐 Parolni o'zgartirish: /parol_almashtirish",
        parse_mode="HTML"
    )


# ─── /parol_almashtirish ─────────────────────────────────────────────────────

@router.message(Command("parol_almashtirish"))
@router.callback_query(F.data == "settings_parol")
async def cmd_parol_almashtirish(event: types.Message | types.CallbackQuery, state: FSMContext):
    if isinstance(event, types.CallbackQuery):
        await event.answer()
        msg = event.message
    else:
        msg = event

    user = await User.get_or_none(telegram_id=msg.from_user.id if isinstance(event, types.Message) else event.from_user.id)
    if not user:
        await msg.answer("❌ Avval /start yuboring.")
        return

    # Eski parol bormi — tekshirish kerak
    has_password = bool(user.username and user.username.startswith("$2b$"))

    if has_password:
        await msg.answer(
            "🔐 Eski parolingizni kiriting:",
            reply_markup=ReplyKeyboardRemove()
        )
        await state.set_state(PasswordState.entering_old_password)
    else:
        await msg.answer(
            "🔐 Yangi parolni kiriting (kamida 6 belgi):",
            reply_markup=ReplyKeyboardRemove()
        )
        await state.set_state(PasswordState.entering_new_password)


@router.message(PasswordState.entering_old_password)
async def check_old_password(message: types.Message, state: FSMContext):
    user = await User.get_or_none(telegram_id=message.from_user.id)
    if not user:
        await state.clear()
        return

    old_pw = message.text.strip()
    try:
        ok = bcrypt.checkpw(old_pw.encode(), user.username.encode())
    except Exception:
        ok = False

    if not ok:
        await message.answer(
            "❌ Parol noto'g'ri. Qayta kiriting yoki /start yuboring."
        )
        return

    await message.answer("✅ Tasdiqlandi. Yangi parolni kiriting (kamida 6 belgi):")
    await state.set_state(PasswordState.entering_new_password)


@router.message(PasswordState.entering_new_password)
async def save_new_password(message: types.Message, state: FSMContext):
    password = message.text.strip()
    if len(password) < 6:
        await message.answer("⚠️ Parol kamida 6 belgidan iborat bo'lishi kerak.")
        return

    user = await User.get_or_none(telegram_id=message.from_user.id)
    if user:
        user.username = bcrypt.hashpw(password.encode(), bcrypt.gensalt()).decode()
        await user.save()
        await message.answer(
            "✅ <b>Parol muvaffaqiyatli o'zgartirildi!</b>\n\n"
            "WebApp ga kirish uchun yangi parolingizni ishlating.",
            parse_mode="HTML"
        )
    else:
        await message.answer("❌ Xatolik yuz berdi. /start yuboring.")

    await state.clear()


# ─── /yordam ─────────────────────────────────────────────────────────────────

@router.message(Command("yordam"))
@router.message(F.text.in_({"🟢 Yordam"}))
async def cmd_yordam(message: types.Message):
    user = await User.get_or_none(telegram_id=message.from_user.id)
    role = user.role if user else "guest"
    r = role.split(",")[0].strip().lower()

    base = (
        "🤖 <b>SmartDMTT Yordamchi</b>\n\n"
        "<b>Asosiy buyruqlar:</b>\n"
        "/start — Boshlash / qayta kirish\n"
        "/profil — Profilni ko'rish\n"
        "/sozlamalar — Sozlamalar (til, parol)\n"
        "/parol_almashtirish — Parolni o'zgartirish\n"
        "/yordam — Shu sahifa\n\n"
    )

    if r in ("admin", "iqtisodchi"):
        extra = (
            "<b>Admin buyruqlari:</b>\n"
            "👥 Foydalanuvchilar — ro'yxatni ko'rish\n"
            "🏫 Bog'chalar — boshqaruv\n"
            "📊 Statistika — umumiy hisobot\n"
            "📣 Broadcast — hamma ga xabar\n"
        )
    elif r in ("boshliq", "mmtb_boshligi"):
        extra = (
            "<b>Boshliq paneli:</b>\n"
            "📊 Statistika — tuman bo'yicha\n"
            "🏫 Bog'chalar — barcha 30 ta\n"
            "⚠️ Anomaliyalar — muammoli holatlar\n"
        )
    elif r == "director":
        extra = (
            "<b>Direktor paneli:</b>\n"
            "📊 Statistika — bog'cha hisoboti\n"
            "👩‍🏫 Xodimlar — o'qituvchilar\n"
            "👶 Bolalar — ro'yxat\n"
            "💰 Moliya — to'lovlar\n"
        )
    elif r in ("teacher", "togarak_rahbari", "oqituvchi"):
        extra = (
            "<b>O'qituvchi paneli:</b>\n"
            "📅 Davomat — belgilash\n"
            "👶 Guruhim — bolalar ro'yxati\n"
            "📊 Statistika — guruh ko'rsatkichlari\n"
        )
    elif r == "parent":
        extra = (
            "<b>Ota-ona paneli:</b>\n"
            "👶 Bolam — farzand ma'lumotlari\n"
            "💰 To'lov — to'lov holati\n"
            "📣 E'lonlar — bog'cha xabarlari\n"
        )
    else:
        extra = (
            "<b>Mehmon imkoniyatlari:</b>\n"
            "🗺 Bog'chalar xaritasi\n"
            "📚 To'garaklar ro'yxati\n"
        )

    await message.answer(
        base + extra +
        "\n📱 <b>WebApp:</b> Bot menyusidagi «Kabinet» tugmasini bosing.",
        parse_mode="HTML"
    )


@router.message(F.text.in_({"🤖 Yordamchi", "🤖 AI Yordam"}))
async def start_ai_helper(message: types.Message, state: FSMContext):
    user = await User.get_or_none(telegram_id=message.from_user.id)
    if not user:
        await message.answer("Avval /start yuboring.")
        return
    await state.set_state(AssistantState.in_conversation)
    kb = ReplyKeyboardMarkup(
        keyboard=[[KeyboardButton(text="❌ Yakunlash")]],
        resize_keyboard=True
    )
    await message.answer(
        "🤖 Savolingizni yozing.\n"
        "Yakunlash uchun «❌ Yakunlash» ni bosing.",
        reply_markup=kb
    )


@router.message(AssistantState.in_conversation)
async def handle_ai_helper(message: types.Message, state: FSMContext):
    text = (message.text or "").strip()
    if not text:
        await message.answer("Savolingizni yozing.")
        return
    if text == "❌ Yakunlash":
        await state.clear()
        from app.bot.handlers.menus import get_menu_keyboard
        user = await User.get_or_none(telegram_id=message.from_user.id)
        role = user.role if user else "guest"
        await message.answer("Asosiy menyu:", reply_markup=get_menu_keyboard(role))
        return
    if text.startswith("/"):
        await state.clear()
        from app.bot.handlers.menus import get_menu_keyboard
        user = await User.get_or_none(telegram_id=message.from_user.id)
        role = user.role if user else "guest"
        await message.answer("Asosiy menyu:", reply_markup=get_menu_keyboard(role))
        return

    user = await User.get_or_none(telegram_id=message.from_user.id)
    if not user:
        await message.answer("Avval /start yuboring.")
        return

    from app.services.ai_helper import get_ai_answer
    wait = await message.answer("🤔 Javob tayyorlanmoqda...")
    try:
        answer = await get_ai_answer(text, user.id)
        await wait.delete()
        await message.answer(answer)
    except Exception as e:
        await wait.edit_text(f"Xatolik: {e}")
