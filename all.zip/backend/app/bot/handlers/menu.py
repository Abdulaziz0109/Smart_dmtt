import logging
from aiogram import Router, types, F
from aiogram.fsm.context import FSMContext
from app.bot.utils.filters import menu_text_filter, LocalizedCommand
from app.bot.utils import role_management
from app.services import database as db
from app.core import strings
from app.services.user_service import UserService
logger = logging.getLogger(__name__)

# -------------------------------------------------------------------------
# MENU HANDLERS
# -------------------------------------------------------------------------

@router.message(LocalizedCommand("cmd_val_settings"))

@router.message(LocalizedCommand("cmd_val_help"))
@router.message(menu_text_filter("btn_assistant"))
async def help_handler(message: types.Message):
    uid = message.from_user.id
    user_lang = await UserService.get_user_language(uid)
    await message.answer("🤖 Yordamchi — tez orada ishga tushadi.", parse_mode="HTML")

@router.message(menu_text_filter("btn_reports"))
async def reports_handler(message: types.Message):
    uid = message.from_user.id
    users = await db.get_all_users()
    children = await db.get_all_children()
    clubs = await db.get_all_clubs()
    report = (
        f"📈 <b>Hisobotlar</b>\n\n"
        f"👥 Foydalanuvchilar: {len(users)}\n"
        f"👶 Bolalar: {len(children)}\n"
        f"📚 To'garaklar: {len(clubs)}\n"
    )
    await message.answer(report, parse_mode="HTML")

@router.message(menu_text_filter("btn_attendance"))
async def attendance_menu_handler(message: types.Message):
    await message.answer("✅ Davomat bo'limi — tez orada.")

@router.message(menu_text_filter("btn_payments"))
async def payments_handler(message: types.Message):
    await message.answer("💳 To'lovlar — tez orada.")

@router.message(menu_text_filter("btn_children"))
async def teachers_handler(message: types.Message):
    uid = message.from_user.id
    users = await db.get_all_users()
    teachers = [u for u in users if "teacher" in u.get("role", "").lower()]
    if not teachers:
        await message.answer("👩‍🏫 O'qituvchilar topilmadi.")
        return
    text = "👩‍🏫 <b>O'qituvchilar ro'yxati:</b>\n\n"
    for i, t in enumerate(teachers, 1):
        text += f"{i}. {t.get('full_name', 'Ismsiz')} ({t.get('phone', '-')})\n"
    await message.answer(text, parse_mode="HTML")

@router.message(menu_text_filter("btn_clubs"))
async def clubs_list_handler(message: types.Message):
    clubs = await db.get_all_clubs()
    if not clubs:
        await message.answer("📋 To'garaklar topilmadi.")
        return
    text = "📋 <b>To'garaklar ro'yxati:</b>\n\n"
    for i, c in enumerate(clubs, 1):
        text += f"{i}. {c.get('name', 'Nomsiz')} - {c.get('price', 0)} so'm\n"
    await message.answer(text, parse_mode="HTML")

@router.message(F.text == "📱 WebApp")
async def open_webapp_handler(message: types.Message):
    from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton, WebAppInfo
    from app.core import config
    kb = InlineKeyboardMarkup(inline_keyboard=[[
        InlineKeyboardButton(text="🌐 WebApp ochish", web_app=WebAppInfo(url=config.WEBAPP_URL))
    ]])
    await message.answer("📱 WebApp:", reply_markup=kb)

