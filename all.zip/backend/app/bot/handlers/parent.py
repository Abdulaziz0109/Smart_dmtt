"""
SmartDMTT v4 — Ota-ona bot handlerlari
Python 3.11 uchun tuzatilgan (f-string backslash yo'q)
AbsenceState shu faylda aniqlanadi — import muammosi yo'q
"""
import logging
from datetime import date, timedelta

from aiogram import Router, F, types
from aiogram.filters import Command
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import StatesGroup, State
from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton

from app.models.user import User
from app.models.child import Child
from app.models.club import Club, Enrollment
from app.models.payment import Payment
from app.models.attendance import Attendance, AbsenceNotice
from app.bot.i18n import t, get_lang

logger = logging.getLogger(__name__)
router = Router()


# ── FSM holatlari (shu faylda, import muammosi yo'q) ─────
class AbsenceState(StatesGroup):
    choosing_date   = State()
    choosing_reason = State()


# ── Helper ────────────────────────────────────────────────
async def _get_parent(tg_id: int) -> User | None:
    return await User.get_or_none(telegram_id=tg_id)


def _main_menu() -> types.ReplyKeyboardMarkup:
    return types.ReplyKeyboardMarkup(
        keyboard=[
            [types.KeyboardButton(text="👶 Bolam"),   types.KeyboardButton(text="💰 To'lov")],
            [types.KeyboardButton(text="📅 Davomat"), types.KeyboardButton(text="👤 Profil")],
            [types.KeyboardButton(text="🤖 AI Yordam")],
        ],
        resize_keyboard=True,
    )


# ── /start ────────────────────────────────────────────────
@router.message(Command("start"))
async def cmd_start(message: types.Message):
    user = await User.get_or_none(telegram_id=message.from_user.id)
    if not user:
        await message.answer(
            "👋 Xush kelibsiz!\n\nRo'yxatdan o'tish uchun telefon raqamingizni yuboring:",
            reply_markup=types.ReplyKeyboardMarkup(
                keyboard=[[types.KeyboardButton(text="📱 Raqamni yuborish", request_contact=True)]],
                resize_keyboard=True,
            )
        )
        return

    lang = get_lang(user)
    name = user.full_name or message.from_user.first_name or "Foydalanuvchi"
    await message.answer(
        f"👋 {t('welcome', lang)}, {name}!\nSmartDMTT — Bulung'ur tuman MTT tizimi.",
        reply_markup=_main_menu()
    )


# ── 👶 Bolam ─────────────────────────────────────────────
@router.message(F.text == "👶 Bolam")
async def bolam(message: types.Message):
    user = await _get_parent(message.from_user.id)
    if not user:
        return

    children = await Child.filter(parent_id=user.id).all()
    if not children:
        await message.answer("Hali farzand qo'shilmagan.")
        return

    today     = date.today()
    month_str = today.strftime("%Y-%m")
    parts     = []

    for child in children:
        enrollments = await Enrollment.filter(child_id=child.id, status="active").all()
        clubs_lines = []
        total_debt  = 0

        for enr in enrollments:
            club = await Club.get_or_none(id=enr.club_id)
            if not club:
                continue
            paid = await Payment.filter(
                enrollment_id=enr.id, month=month_str, status="completed"
            ).exists()

            icon       = "✅" if paid else "❌"
            price_val  = int(club.price)
            price_info = "" if paid else f" ({price_val:,} so'm)"
            clubs_lines.append(
                f"  {icon} {club.name} — <code>{enr.payment_id}</code>{price_info}"
            )
            if not paid:
                total_debt += price_val

        att_lines = []
        for enr in enrollments:
            att  = await Attendance.filter(enrollment_id=enr.id, date=today).first()
            club = await Club.get_or_none(id=enr.club_id)
            if club and att:
                icons = {"present": "✅", "absent": "❌", "late": "⏰", "excused": "📝"}
                att_lines.append(f"  {icons.get(att.status, '—')} {club.name}")

        clubs_text = "\n".join(clubs_lines) if clubs_lines else "  To'garakka yozilmagan"
        att_text   = "\n".join(att_lines)   if att_lines   else "  Ma'lumot yo'q"
        debt_part  = ""
        if total_debt > 0:
            debt_part = f"\n💸 Qarz: <b>{total_debt:,} so'm</b>"

        parts.append(
            f"👶 <b>{child.full_name}</b> ({child.birth_year}-yil)\n"
            f"📚 To'garaklar:\n{clubs_text}{debt_part}\n"
            f"📅 Bugun:\n{att_text}"
        )

    kb = InlineKeyboardMarkup(inline_keyboard=[[
        InlineKeyboardButton(text="📅 Kela olmayman", callback_data="absence_notice")
    ]])
    await message.answer("\n\n".join(parts), parse_mode="HTML", reply_markup=kb)


# ── 💰 To'lov ─────────────────────────────────────────────
@router.message(F.text == "💰 To'lov")
async def payment_info(message: types.Message):
    user = await _get_parent(message.from_user.id)
    if not user:
        return

    children  = await Child.filter(parent_id=user.id).all()
    today     = date.today()
    month_str = today.strftime("%Y-%m")

    if not children:
        await message.answer("Farzand mavjud emas.")
        return

    parts = []
    for child in children:
        enrollments = await Enrollment.filter(child_id=child.id, status="active").all()
        for enr in enrollments:
            club = await Club.get_or_none(id=enr.club_id)
            if not club:
                continue

            paid = await Payment.filter(
                enrollment_id=enr.id, month=month_str, status="completed"
            ).exists()

            history = await Payment.filter(
                enrollment_id=enr.id, status="completed"
            ).order_by("-paid_at").limit(3).all()

            hist_lines = []
            for p in history:
                d_str  = p.paid_at.strftime("%d.%m.%Y") if p.paid_at else "—"
                amount = f"{p.amount:,}" if p.amount else "—"
                hist_lines.append(f"  ✅ {p.month} — {amount} so'm ({d_str})")

            status_icon = "✅ To'langan" if paid else "❌ To'lanmagan"
            price_f     = f"{int(club.price):,}"
            hist_text   = "\n".join(hist_lines) if hist_lines else "  Tarix yo'q"

            parts.append(
                f"👶 <b>{child.full_name}</b>\n"
                f"📚 {club.name}\n"
                f"💳 ID: <code>{enr.payment_id}</code>\n"
                f"💰 {month_str}: {status_icon}\n"
                f"💵 Narx: {price_f} so'm/oy\n"
                f"📋 Oxirgi to'lovlar:\n{hist_text}"
            )

    if parts:
        footer = (
            "\n\n💡 <b>To'lov usullari:</b>\n"
            "• Click: Xizmatlar → SmartDMTT\n"
            "• Payme: To'lov ID orqali\n"
            "• Paynet: Maktabgacha → SmartDMTT"
        )
        await message.answer("\n\n".join(parts) + footer, parse_mode="HTML")
    else:
        await message.answer("To'garaklarga yozilmagan.")


# ── 📅 Davomat ────────────────────────────────────────────
@router.message(F.text == "📅 Davomat")
async def attendance_info(message: types.Message):
    user = await _get_parent(message.from_user.id)
    if not user:
        return

    children = await Child.filter(parent_id=user.id).all()
    if not children:
        await message.answer("Farzand mavjud emas.")
        return

    today      = date.today()
    week_start = today - timedelta(days=today.weekday())
    day_names  = ["Du", "Se", "Ch", "Pa", "Ju", "Sh", "Ya"]
    icons      = {"present": "✅", "absent": "❌", "late": "⏰", "excused": "📝"}
    parts      = []

    for child in children:
        enrollments = await Enrollment.filter(child_id=child.id, status="active").all()
        for enr in enrollments:
            club = await Club.get_or_none(id=enr.club_id)
            if not club:
                continue

            records = await Attendance.filter(
                enrollment_id=enr.id, date__gte=week_start
            ).order_by("date").all()

            day_parts = []
            for a in records:
                d_idx = a.date.weekday()
                day_parts.append(f"{day_names[d_idx]}:{icons.get(a.status, '?')}")

            days_text = " ".join(day_parts) if day_parts else "Ma'lumot yo'q"
            total   = len(records)
            present = sum(1 for a in records if a.status == "present")
            pct     = round(present / total * 100) if total else 0

            parts.append(
                f"👶 <b>{child.full_name}</b> — {club.name}\n"
                f"📅 Bu hafta: {days_text}\n"
                f"📊 Davomat: {present}/{total} ({pct}%)"
            )

    if parts:
        kb = InlineKeyboardMarkup(inline_keyboard=[[
            InlineKeyboardButton(text="📅 Kela olmayman", callback_data="absence_notice")
        ]])
        await message.answer("\n\n".join(parts), parse_mode="HTML", reply_markup=kb)
    else:
        await message.answer("To'garaklarga yozilmagan.")


# ── Kela olmayman — FSM ────────────────────────────────────
@router.callback_query(F.data == "absence_notice")
async def absence_start(callback: types.CallbackQuery, state: FSMContext):
    await callback.answer()
    tomorrow  = date.today() + timedelta(days=1)
    day_after = date.today() + timedelta(days=2)
    t_str  = tomorrow.strftime("%d.%m")
    da_str = day_after.strftime("%d.%m")

    kb = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text=f"📅 Ertaga ({t_str})",  callback_data=f"abs_date_{tomorrow.isoformat()}")],
        [InlineKeyboardButton(text=f"📅 {da_str}",          callback_data=f"abs_date_{day_after.isoformat()}")],
    ])
    await callback.message.answer("Qaysi kuni kela olmaysiz?", reply_markup=kb)
    await state.set_state(AbsenceState.choosing_date)


@router.callback_query(F.data.startswith("abs_date_"), AbsenceState.choosing_date)
async def absence_date(callback: types.CallbackQuery, state: FSMContext):
    date_str = callback.data.split("_", 2)[2]
    await state.update_data(absence_date=date_str)
    await callback.answer()
    kb = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="🤒 Kasal",       callback_data="abs_reason_sick")],
        [InlineKeyboardButton(text="🚗 Boshqa sabab", callback_data="abs_reason_other")],
    ])
    await callback.message.answer("Sabab?", reply_markup=kb)
    await state.set_state(AbsenceState.choosing_reason)


@router.callback_query(F.data.startswith("abs_reason_"), AbsenceState.choosing_reason)
async def absence_reason(callback: types.CallbackQuery, state: FSMContext):
    reason       = "sick" if callback.data == "abs_reason_sick" else "other"
    data         = await state.get_data()
    abs_date_str = data.get("absence_date", "")
    await callback.answer()

    user = await User.get_or_none(telegram_id=callback.from_user.id)
    if not user:
        return

    saved = 0
    children = await Child.filter(parent_id=user.id).all()
    for child in children:
        enrollments = await Enrollment.filter(child_id=child.id, status="active").all()
        for enr in enrollments:
            existing = await AbsenceNotice.get_or_none(enrollment_id=enr.id, date=abs_date_str)
            if not existing:
                await AbsenceNotice.create(enrollment_id=enr.id, date=abs_date_str, reason=reason)
                saved += 1

    await state.clear()

    abs_d      = date.fromisoformat(abs_date_str)
    date_f     = abs_d.strftime("%d.%m.%Y")
    reason_lbl = "Kasal" if reason == "sick" else "Boshqa sabab"

    result = "✅ <b>Qayd etildi!</b>\n"
    result += f"📅 {date_f} — {reason_lbl}\n"
    result += "Muallim xabardor qilinadi."
    await callback.message.answer(result, parse_mode="HTML")


# ── 👤 Profil ─────────────────────────────────────────────
@router.message(F.text == "👤 Profil")
async def profil(message: types.Message):
    user = await User.get_or_none(telegram_id=message.from_user.id)
    if not user:
        return

    children_count = await Child.filter(parent_id=user.id).count()
    lang_names     = {"uz": "O'zbek (lotin)", "kril": "O'zbek (kril)", "ru": "Русский", "en": "English", "turk": "Türkçe"}
    lang_label     = lang_names.get(user.language or "uz", "O'zbek")

    info = (
        f"👤 <b>Profil</b>\n\n"
        f"Ism: {user.full_name or '—'}\n"
        f"Telefon: {user.phone or '—'}\n"
        f"Farzandlar: {children_count} ta\n"
        f"Til: {lang_label}\n"
        f"Rol: {user.role or 'parent'}"
    )
    await message.answer(info, parse_mode="HTML")


# ── 🤖 AI Yordam ──────────────────────────────────────────
@router.message(F.text == "🤖 AI Yordam")
async def ai_help_prompt(message: types.Message):
    await message.answer(
        "🤖 Savolingizni yozing:\n\n"
        "• To'garakka qanday yozilaman?\n"
        "• To'lov qanday qilinadi?\n"
        "• Davomat qanday belgilanadi?"
    )


@router.message(F.text.func(lambda t: t and len(t) > 10 and not t.startswith("/")))
async def ai_question(message: types.Message):
    user = await User.get_or_none(telegram_id=message.from_user.id)
    if not user or user.role not in ("parent", "guest"):
        return

    from app.services.ai_helper import get_ai_answer
    wait = await message.answer("🤔 Javob tayyorlanmoqda...")
    try:
        answer = await get_ai_answer(message.text, user.id)
        await wait.delete()
        await message.answer(answer, parse_mode="Markdown")
    except Exception as e:
        logger.error(f"AI xato: {e}")
        await wait.edit_text("Xatolik yuz berdi. Qayta urinib ko'ring.")
