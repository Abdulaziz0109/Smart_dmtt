"""
SmartDMTT v4 — Admin bot handlerlari
Spec 5.6 bo'yicha: tizim boshqaruvi, foydalanuvchilar, AI jurnal
"""
import io
import logging
import secrets
import string
import bcrypt
from datetime import datetime
from aiogram import Router, F, types
from aiogram.filters import Command
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.utils.keyboard import InlineKeyboardBuilder, ReplyKeyboardBuilder

from app.models.user import User
from app.models.kindergarten import Kindergarten
from app.models.club import Club, Enrollment
from app.models.child import Child
from app.models.payment import Payment
from app.models.ai_log import AILog
# from app.services.knowledge_base import add_to_base
from app.models.knowledge_base_entry import KnowledgeBaseEntry

logger = logging.getLogger(__name__)
router = Router()


# ─── FSM ─────────────────────────────────────────────────────
class AdminStates(StatesGroup):
    add_user_name = State()
    add_user_phone = State()
    add_user_role = State()
    add_user_kinder = State()
    broadcast_text = State()
    set_password = State()


# ─── FILTR ───────────────────────────────────────────────────
def is_admin(user: User) -> bool:
    return user.role == "admin"


# ─── ASOSIY MENYU ────────────────────────────────────────────
async def admin_menu(message: types.Message):
    kb = ReplyKeyboardBuilder()
    kb.button(text="👥 Foydalanuvchilar")
    kb.button(text="🏫 Bog'chalar")
    kb.button(text="📚 To'garaklar")
    kb.button(text="💰 Moliya")
    kb.button(text="📊 Statistika")
    kb.button(text="🤖 AI Jurnal")
    kb.button(text="📣 Broadcast")
    kb.button(text="🔧 Tizim")
    kb.button(text="📱 WebApp")
    kb.button(text="👤 Profil")
    kb.adjust(2)
    await message.answer(
        "👑 <b>Admin paneli</b>\n\nNimani boshqarmoqchisiz?",
        reply_markup=kb.as_markup(resize_keyboard=True),
        parse_mode="HTML"
    )


# ─── FOYDALANUVCHILAR ────────────────────────────────────────
@router.message(F.text == "👥 Foydalanuvchilar")
async def cmd_users(message: types.Message):
    uid = message.from_user.id
    user = await User.get_or_none(id=uid)
    if not user or not is_admin(user):
        return

    roles = ["admin", "boshliq", "director", "teacher", "parent", "guest"]
    lines = ["👥 <b>Foydalanuvchilar statistikasi</b>\n"]
    total = 0
    for r in roles:
        c = await User.filter(role=r, is_test=False).count()
        total += c
        icons = {"admin": "👑", "boshliq": "🏛", "director": "🏫",
                 "teacher": "👩‍🏫", "parent": "👨‍👩‍👧", "guest": "👤"}
        lines.append(f"{icons.get(r, '•')} {r}: {c}")

    test_count = await User.filter(is_test=True).count()
    lines.append(f"\n🔢 Jami: {total}")
    lines.append(f"🧪 Test: {test_count}")

    kb = InlineKeyboardBuilder()
    kb.button(text="➕ Yangi foydalanuvchi", callback_data="admin_add_user")
    kb.button(text="🔍 Qidirish", callback_data="admin_search_user")
    kb.button(text="📥 Excel eksport", callback_data="admin_export_users")
    kb.adjust(1)

    await message.answer("\n".join(lines), reply_markup=kb.as_markup(), parse_mode="HTML")


@router.callback_query(F.data == "admin_add_user")
async def cb_add_user(callback: types.CallbackQuery, state: FSMContext):
    await state.set_state(AdminStates.add_user_name)
    await callback.message.answer(
        "➕ <b>Yangi foydalanuvchi</b>\n\nIsm familiyasini yozing:"
    )
    await callback.answer()


@router.message(AdminStates.add_user_name)
async def handle_user_name(message: types.Message, state: FSMContext):
    await state.update_data(full_name=message.text.strip())
    await state.set_state(AdminStates.add_user_phone)
    await message.answer("📞 Telefon raqamini yozing (+998...):")


@router.message(AdminStates.add_user_phone)
async def handle_user_phone(message: types.Message, state: FSMContext):
    phone = message.text.strip()
    if not phone.startswith("+"):
        phone = "+" + phone
    if len(phone) < 12:
        await message.answer("❌ Telefon formati noto'g'ri. Qaytadan yozing:")
        return
    if await User.get_or_none(phone=phone):
        await message.answer("❌ Bu telefon allaqachon mavjud. Boshqa raqam:")
        return

    await state.update_data(phone=phone)
    await state.set_state(AdminStates.add_user_role)

    kb = InlineKeyboardBuilder()
    for role in ["boshliq", "director", "teacher", "parent"]:
        kb.button(text=role, callback_data=f"admin_user_role_{role}")
    kb.adjust(2)

    await message.answer("🎭 Rolni tanlang:", reply_markup=kb.as_markup())


@router.callback_query(F.data.startswith("admin_user_role_"))
async def cb_user_role(callback: types.CallbackQuery, state: FSMContext):
    role = callback.data.split("_")[-1]
    await state.update_data(role=role)

    data = await state.get_data()
    full_name = data["full_name"]
    phone = data["phone"]

    # Parol yaratish
    pwd = ''.join(secrets.choice(string.ascii_letters + string.digits) for _ in range(8))
    pwd_hash = bcrypt.hashpw(pwd.encode(), bcrypt.gensalt()).decode()

    user = await User.create(
        full_name=full_name,
        phone=phone,
        role=role,
        username=pwd_hash,
    )

    await state.clear()
    await callback.message.answer(
        f"✅ <b>Foydalanuvchi qo'shildi!</b>\n\n"
        f"👤 {full_name}\n"
        f"📞 {phone}\n"
        f"🎭 {role}\n"
        f"🔑 Parol: <code>{pwd}</code>\n\n"
        f"Bu parolni foydalanuvchiga bering.",
        parse_mode="HTML"
    )
    await callback.answer()


@router.callback_query(F.data == "admin_export_users")
async def cb_export_users(callback: types.CallbackQuery):
    """Foydalanuvchilar Excel eksport"""
    try:
        import openpyxl
        from openpyxl.styles import Font, PatternFill

        users = await User.filter(is_test=False).order_by("role", "full_name").all()
        wb = openpyxl.Workbook()
        ws = wb.active
        ws.title = "Foydalanuvchilar"

        headers = ["ID", "Ism", "Telefon", "Rol", "Bog'cha", "Holat"]
        for col, h in enumerate(headers, 1):
            cell = ws.cell(row=1, column=col, value=h)
            cell.font = Font(bold=True, color="FFFFFF")
            cell.fill = PatternFill("solid", fgColor="0B5E50")

        for row, u in enumerate(users, 2):
            ws.append([
                u.id, u.full_name, u.phone, u.role,
                u.kindergarten_id or "",
                "Bloklangan" if u.is_blocked else "Faol"
            ])

        buf = io.BytesIO()
        wb.save(buf)
        buf.seek(0)

        await callback.message.answer_document(
            types.BufferedInputFile(buf.read(), filename="foydalanuvchilar.xlsx"),
            caption=f"📊 Foydalanuvchilar ro'yxati ({len(users)} ta)"
        )
    except ImportError:
        await callback.message.answer("❌ openpyxl o'rnatilmagan")

    await callback.answer()


# ─── BOG'CHALAR ──────────────────────────────────────────────
@router.message(F.text == "🏫 Bog'chalar")
async def cmd_kinders_admin(message: types.Message):
    uid = message.from_user.id
    user = await User.get_or_none(id=uid)
    if not user or not is_admin(user):
        return

    kinders = await Kindergarten.filter(is_active=True).order_by("number").all()
    lines = [f"🏫 <b>Bog'chalar ({len(kinders)} ta)</b>\n"]
    for k in kinders:
        clubs = await Club.filter(kindergarten_id=k.id, is_active=True).count()
        lines.append(f"• {k.number}-son — {clubs} to'garak")

    kb = InlineKeyboardBuilder()
    kb.button(text="➕ Yangi bog'cha", callback_data="admin_add_kinder")
    kb.adjust(1)

    await message.answer("\n".join(lines), reply_markup=kb.as_markup(), parse_mode="HTML")


# ─── STATISTIKA ──────────────────────────────────────────────
@router.message(F.text == "📊 Statistika")
async def cmd_stat_admin(message: types.Message):
    uid = message.from_user.id
    user = await User.get_or_none(id=uid)
    if not user or not is_admin(user):
        return

    today = datetime.now()
    month_str = today.strftime("%Y-%m")

    total_users = await User.filter(is_test=False).count()
    total_kinders = await Kindergarten.filter(is_active=True).count()
    total_clubs = await Club.filter(is_active=True).count()
    total_children = await Child.all().count()
    total_enrolled = await Enrollment.filter(status="active").count()
    total_payments = await Payment.filter(month=month_str, status="completed").count()
    total_ai_logs = await AILog.filter(is_test=False).count()

    text = (
        f"📊 <b>Tizim Statistikasi</b>\n"
        f"📅 {today.strftime('%d.%m.%Y %H:%M')}\n\n"
        f"👥 Foydalanuvchilar: <b>{total_users}</b>\n"
        f"🏫 Bog'chalar: <b>{total_kinders}</b>\n"
        f"📚 To'garaklar: <b>{total_clubs}</b>\n"
        f"👶 Bolalar: <b>{total_children}</b>\n"
        f"📋 Yozilganlar: <b>{total_enrolled}</b>\n"
        f"💰 Joriy oy to'lovlari: <b>{total_payments}</b>\n"
        f"🤖 AI so'rovlar (jami): <b>{total_ai_logs}</b>"
    )

    await message.answer(text, parse_mode="HTML")


# ─── AI JURNAL ───────────────────────────────────────────────
@router.message(F.text == "🤖 AI Jurnal")
async def cmd_ai_jurnal(message: types.Message):
    uid = message.from_user.id
    user = await User.get_or_none(id=uid)
    if not user or not is_admin(user):
        return

    kb = InlineKeyboardBuilder()
    kb.button(text="📝 Yordamchi (helper)", callback_data="admin_ai_helper")
    kb.button(text="⚠️ Anomaliyalar", callback_data="admin_ai_anomaly")
    kb.button(text="📨 Yuborilgan xabarlar", callback_data="admin_ai_messages")
    kb.adjust(1)

    total = await AILog.filter(is_test=False).count()
    await message.answer(
        f"🤖 <b>AI Jurnal</b>\n\nJami yozuvlar: {total} ta",
        reply_markup=kb.as_markup(),
        parse_mode="HTML"
    )


@router.callback_query(F.data.startswith("admin_ai_"))
async def cb_ai_logs(callback: types.CallbackQuery):
    type_map = {
        "admin_ai_helper": "helper",
        "admin_ai_anomaly": "anomaly",
        "admin_ai_messages": "message",
    }
    log_type = type_map.get(callback.data, "helper")

    logs = await AILog.filter(
        log_type=log_type, is_test=False
    ).order_by("-created_at").limit(10).all()

    if not logs:
        await callback.message.answer("Yozuvlar topilmadi.")
        await callback.answer()
        return

    kb = InlineKeyboardBuilder()
    for log in logs:
        dt = log.created_at.strftime("%d.%m %H:%M") if log.created_at else "?"
        preview = (log.prompt or "")[:40]
        kb.button(
            text=f"🤖 {dt} — {preview}...",
            callback_data=f"admin_log_detail_{log.id}"
        )
    kb.adjust(1)

    await callback.message.answer(
        f"🤖 <b>AI Jurnal — {log_type}</b> ({len(logs)} ta)",
        reply_markup=kb.as_markup(),
        parse_mode="HTML"
    )
    await callback.answer()


@router.callback_query(F.data.startswith("admin_log_detail_"))
async def cb_log_detail(callback: types.CallbackQuery):
    log_id = int(callback.data.split("_")[-1])
    log = await AILog.get_or_none(id=log_id)
    if not log:
        await callback.answer("Topilmadi")
        return

    user = await User.get_or_none(id=log.user_id) if log.user_id else None
    text = (
        f"🤖 <b>AI Log #{log.id}</b>\n\n"
        f"👤 Kim: {user.full_name if user else '?'}\n"
        f"🎯 Tur: {log.log_type}\n"
        f"🔮 Model: {log.model or '?'}\n"
        f"📊 Manba: {log.source or '?'}\n"
        f"🔢 Tokenlar: {log.tokens_used or 0}\n\n"
        f"❓ Savol:\n{(log.prompt or '')[:300]}\n\n"
        f"💬 Javob:\n{(log.response or '')[:400]}"
    )

    kb = InlineKeyboardBuilder()
    if log.log_type == "helper":
        kb.button(
            text="📌 Bilimlar bazasiga qo'shish",
            callback_data=f"admin_log_to_base_{log_id}"
        )
    kb.button(text="⬅️ Orqaga", callback_data=f"admin_ai_{log.log_type}")
    kb.adjust(1)

    await callback.message.edit_text(text, reply_markup=kb.as_markup(), parse_mode="HTML")
    await callback.answer()


@router.callback_query(F.data.startswith("admin_log_to_base_"))
async def cb_log_to_base(callback: types.CallbackQuery):
    log_id = int(callback.data.split("_")[-1])
    log = await AILog.get_or_none(id=log_id)
    if log and log.prompt and log.response:
        # await add_to_base(log.prompt, log.response)
        await callback.message.answer("✅ Bilimlar bazasiga qo'shildi! (Hozircha o'chirilgan)")
    else:
        await callback.message.answer("❌ Xato: savol yoki javob bo'sh")
    await callback.answer()


# ─── BROADCAST ───────────────────────────────────────────────
@router.message(F.text == "📣 Broadcast")
async def cmd_admin_broadcast(message: types.Message, state: FSMContext):
    uid = message.from_user.id
    user = await User.get_or_none(id=uid)
    if not user or not is_admin(user):
        return

    kb = InlineKeyboardBuilder()
    kb.button(text="🌐 Hamma", callback_data="adb_all")
    kb.button(text="👨‍👩‍👧 Ota-onalar", callback_data="adb_parent")
    kb.button(text="👩‍🏫 Muallimlar", callback_data="adb_teacher")
    kb.button(text="🏫 Direktorlar", callback_data="adb_director")
    kb.button(text="🏛 Boshliqlar", callback_data="adb_boshliq")
    kb.adjust(2)

    await message.answer(
        "📣 <b>Admin Broadcast</b>\n\nKimga yubormoqchisiz?",
        reply_markup=kb.as_markup(),
        parse_mode="HTML"
    )


@router.callback_query(F.data.startswith("adb_"))
async def cb_admin_bc_target(callback: types.CallbackQuery, state: FSMContext):
    role = callback.data.replace("adb_", "")
    await state.update_data(bc_role=role)
    await state.set_state(AdminStates.broadcast_text)
    label = "Hamma" if role == "all" else role
    await callback.message.answer(
        f"✏️ <b>{label}</b> ga yuborish uchun xabar yozing:",
        parse_mode="HTML"
    )
    await callback.answer()


@router.message(AdminStates.broadcast_text)
async def handle_admin_broadcast(message: types.Message, state: FSMContext):
    data = await state.get_data()
    role = data.get("bc_role", "all")
    await state.clear()

    query = User.filter(is_test=False, is_blocked=False)
    if role != "all":
        query = query.filter(role=role)
    users = await query.all()

    sent, failed = 0, 0
    for u in users:
        if not u.id:
            continue
        try:
            await message.bot.send_message(
                u.id,
                f"📣 <b>SmartDMTT xabari</b>\n\n{message.text}",
                parse_mode="HTML"
            )
            sent += 1
        except Exception:
            failed += 1

    await message.answer(
        f"✅ Yuborildi: {sent} ta\n❌ Xato: {failed} ta"
    )


# ─── TIZIM ───────────────────────────────────────────────────
@router.message(F.text == "🔧 Tizim")
async def cmd_system(message: types.Message):
    uid = message.from_user.id
    user = await User.get_or_none(id=uid)
    if not user or not is_admin(user):
        return

    from app.core import config
    text = (
        f"🔧 <b>Tizim holati</b>\n\n"
        f"🤖 AI Yordamchi: {config.AI_HELPER_MODEL}\n"
        f"🔮 AI Tahlil: {config.AI_ANALYSIS_MODEL}\n"
        f"💬 Bepul limit: {config.AI_FREE_LIMIT} ta/kun\n\n"
        f"💰 To'lov muddati: oyning {config.PAYMENT_DUE_DAY}-sanasi\n"
        f"⚠️ Eslatma: {config.PAYMENT_REMINDER_DAYS}-kundan\n"
        f"🔒 Blok: {config.PAYMENT_BLOCK_DAY}-kunda\n"
        f"❌ Chiqarish: {config.PAYMENT_REMOVE_DAY}-kunda\n\n"
        f"👶 Min. guruh hajmi: {config.MIN_CLUB_MEMBERS} ta\n"
        f"📅 Davomat tasdiqlash: 24 soat"
    )

    await message.answer(text, parse_mode="HTML")

# ─── AI TAHLIL TEST ───────────────────────────────────────────
@router.message(Command("test_ai"))
@router.message(F.text == "🔬 AI Test")
async def cmd_test_ai(message: types.Message):
    """Admin uchun: GitHub Models ni hoziroq sinash."""
    uid = message.from_user.id
    user = await User.get_or_none(id=uid)
    if not user or not is_admin(user):
        return

    wait = await message.answer("⏳ GitHub Models sinash boshlandi...")

    try:
        from app.core import config
        import openai as openai_lib
        import json

        github_token = getattr(config, "GITHUB_TOKEN", "")
        if not github_token:
            await wait.edit_text("❌ GITHUB_TOKEN .env da topilmadi!")
            return

        # ── 1. Yordamchi (Llama 4) ────────────────────────────
        helper_model = getattr(config, "GITHUB_AI_MODEL", "gpt-4o-mini")
        try:
            gh = openai_lib.OpenAI(
                api_key=github_token,
                base_url="https://models.inference.ai.azure.com",
            )
            r1 = gh.chat.completions.create(
                model=helper_model,
                max_tokens=200,
                messages=[
                    {"role": "system", "content": "Sen SmartDMTT yordamchisissan. Qisqa javob ber."},
                    {"role": "user", "content": "Salom! Sen kimsan va nima qila olasan?"},
                ]
            )
            helper_ans = r1.choices[0].message.content or "Javob yo'q"
            helper_ok = f"✅ {helper_model}"
        except Exception as e:
            helper_ans = str(e)[:200]
            helper_ok = "❌ Xato"

        # ── 2. Tahlil (DeepSeek-V3) ───────────────────────────
        analysis_model = getattr(config, "GITHUB_AI_ANALYSIS_MODEL", "gpt-4o")
        test_payload = json.dumps({
            "club_name": "Test to'garak",
            "club_id": 1,
            "stats": {
                "active_students": 12,
                "attendance_teacher_pct": 95.0,
                "attendance_parent_confirm_pct": 29.0,
                "avg_rating": 5.0,
                "all_max_ratings": True,
                "payment_rate_pct": 40.0
            }
        }, ensure_ascii=False)
        try:
            gh2 = openai_lib.OpenAI(
                api_key=github_token,
                base_url="https://models.inference.ai.azure.com",
            )
            r2 = gh2.chat.completions.create(
                model=analysis_model,
                max_tokens=300,
                messages=[
                    {"role": "system", "content": "JSON format qaytarish: {anomaliya, daraja, xulosa}"},
                    {"role": "user", "content": test_payload},
                ]
            )
            analysis_ans = r2.choices[0].message.content or "Javob yo'q"
            analysis_ok = f"✅ {analysis_model}"
        except Exception as e:
            analysis_ans = str(e)[:200]
            analysis_ok = "❌ Xato"

        await wait.edit_text(
            f"🔬 <b>GitHub Models Test</b>\n\n"
            f"💬 <b>Yordamchi:</b> {helper_ok}\n"
            f"<i>{helper_ans[:200]}</i>\n\n"
            f"🔍 <b>Tahlil:</b> {analysis_ok}\n"
            f"<code>{analysis_ans[:300]}</code>",
            parse_mode="HTML"
        )

    except Exception as e:
        await wait.edit_text(f"❌ Test xatosi: {e}")
