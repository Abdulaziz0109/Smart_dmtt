"""
SmartDMTT v4 — Iqtisodchi bot handlerlari
"""
import logging
from datetime import date
from aiogram import Router, F, types
from aiogram.filters import Command
from app.models.user import User
from app.models.child import Child
from app.models.club import Club, Enrollment
from app.models.payment import Payment
from app.models.kindergarten import Kindergarten
from app.bot.i18n import t, get_lang

logger = logging.getLogger(__name__)
router = Router()

async def _get_user(tg_id):
    return await User.get_or_none(telegram_id=tg_id, role="iqtisodchi")

def _menu():
    return types.ReplyKeyboardMarkup(keyboard=[
        [types.KeyboardButton(text="💰 Oylik hisobot"), types.KeyboardButton(text="❌ Qarzdorlar")],
        [types.KeyboardButton(text="📊 Statistika"),    types.KeyboardButton(text="👤 Profil")],
    ], resize_keyboard=True)

@router.message(Command("start"))
async def start(message: types.Message):
    user = await User.get_or_none(telegram_id=message.from_user.id)
    if not user or user.role != "iqtisodchi":
        await message.answer("Ruxsat yo'q."); return
    await message.answer(f"👋 Xush kelibsiz, {user.full_name}!\n💰 Moliya tizimi.", reply_markup=_menu())

@router.message(F.text == "💰 Oylik hisobot")
async def oylik(message: types.Message):
    user = await _get_user(message.from_user.id)
    if not user: return
    month_str = date.today().strftime("%Y-%m")
    kg_id = user.kindergarten_id

    child_ids = await Child.filter(kindergarten_id=kg_id).values_list("id", flat=True) if kg_id else []
    enr_ids   = await Enrollment.filter(child_id__in=list(child_ids), status="active").values_list("id", flat=True) if child_ids else []

    payments  = await Payment.filter(enrollment_id__in=list(enr_ids), month=month_str, status="completed").all() if enr_ids else []
    revenue   = sum(float(p.amount or 0) for p in payments)
    paid_cnt  = len(payments)
    debt_cnt  = len(enr_ids) - paid_cnt

    lines = [
        f"💰 <b>Oylik hisobot — {month_str}</b>",
        "",
        f"✅ To'lagan: <b>{paid_cnt}</b> ta",
        f"❌ Qarzdor: <b>{debt_cnt}</b> ta",
        f"💵 Jami daromad: <b>{revenue:,.0f} so'm</b>",
    ]
    if enr_ids:
        pct = round(paid_cnt / len(enr_ids) * 100)
        bar = "🟩" * round(pct/20) + "⬜" * (5 - round(pct/20))
        lines.append(f"\n{bar} {pct}%")

    await message.answer("\n".join(lines), parse_mode="HTML")

@router.message(F.text == "❌ Qarzdorlar")
async def qarzdorlar(message: types.Message):
    user = await _get_user(message.from_user.id)
    if not user: return
    month_str = date.today().strftime("%Y-%m")
    kg_id = user.kindergarten_id

    child_ids = await Child.filter(kindergarten_id=kg_id).values_list("id", flat=True) if kg_id else []
    enr_ids   = await Enrollment.filter(child_id__in=list(child_ids), status="active").values_list("id", flat=True) if child_ids else []

    if not enr_ids:
        await message.answer("Ma'lumot yo'q."); return

    paid_ids = set(await Payment.filter(
        enrollment_id__in=list(enr_ids), month=month_str, status="completed"
    ).values_list("enrollment_id", flat=True))

    lines = [f"❌ <b>Qarzdorlar — {month_str}</b>\n"]
    count = 0
    for enr_id in enr_ids:
        if enr_id in paid_ids: continue
        enr   = await Enrollment.get_or_none(id=enr_id)
        child = await Child.get_or_none(id=enr.child_id) if enr else None
        club  = await Club.get_or_none(id=enr.club_id)   if enr else None
        parent= await User.get_or_none(id=child.parent_id) if child else None

        name   = child.full_name  if child  else "—"
        club_n = club.name        if club   else "—"
        price  = float(club.price) if club  else 0
        phone  = parent.phone     if parent else "—"

        lines.append(f"• {name} / {club_n}\n  📞 {phone} — {price:,.0f} so'm")
        count += 1
        if count >= 20: break

    if count == 0:
        await message.answer("Barcha to'lovlar amalga oshirilgan! 🎉"); return

    lines.insert(1, f"Jami: {count} ta\n")
    await message.answer("\n".join(lines), parse_mode="HTML")

@router.message(F.text == "📊 Statistika")
async def statistika(message: types.Message):
    user = await _get_user(message.from_user.id)
    if not user: return
    kg_id = user.kindergarten_id
    today = date.today()

    child_cnt = await Child.filter(kindergarten_id=kg_id).count() if kg_id else 0
    club_cnt  = await Club.filter(kindergarten_id=kg_id).count()  if kg_id else 0

    months_revenue = []
    for i in range(3):
        m = date(today.year, today.month - i if today.month - i > 0 else today.month - i + 12, 1)
        m_str = m.strftime("%Y-%m")
        child_ids = await Child.filter(kindergarten_id=kg_id).values_list("id", flat=True) if kg_id else []
        enr_ids   = await Enrollment.filter(child_id__in=list(child_ids)).values_list("id", flat=True) if child_ids else []
        pays = await Payment.filter(enrollment_id__in=list(enr_ids), month=m_str, status="completed").all() if enr_ids else []
        rev  = sum(float(p.amount or 0) for p in pays)
        months_revenue.append((m_str, rev))

    lines = [
        f"📊 <b>Statistika</b>",
        f"👶 Bolalar: {child_cnt}",
        f"🎯 To'garaklar: {club_cnt}",
        "\n💰 Oylik daromadlar:",
    ]
    for m_str, rev in months_revenue:
        lines.append(f"  {m_str}: {rev:,.0f} so'm")

    await message.answer("\n".join(lines), parse_mode="HTML")

@router.message(F.text == "👤 Profil")
async def profil(message: types.Message):
    user = await _get_user(message.from_user.id)
    if not user: return
    kg = await Kindergarten.get_or_none(id=user.kindergarten_id) if user.kindergarten_id else None
    await message.answer(
        f"👤 <b>Profil</b>\n\nIsm: {user.full_name}\nTelefon: {user.phone}\nBog'cha: {kg.name if kg else '—'}",
        parse_mode="HTML"
    )
