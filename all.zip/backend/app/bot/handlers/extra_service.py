"""
SmartDMTT v4 — Qo'shimcha xizmatlar handleri (ota-ona)
"""
import logging
from datetime import date, datetime

from aiogram import Router, F, Bot
from aiogram.types import Message, CallbackQuery, InlineKeyboardMarkup, InlineKeyboardButton
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup

from app.models import User, Club
from app.models.child import Child
from app.models.extra_service import ExtraService
from app.models.club import Enrollment
from app.core.strings import get_string
from app.core import config

logger = logging.getLogger(__name__)
router = Router()

# So'm/daqiqa narxlar (config yoki default)
LATE_PICKUP_RATE      = getattr(config, "LATE_PICKUP_RATE", 8000)
EARLY_DROPOFF_RATE    = getattr(config, "EARLY_DROPOFF_RATE", 5000)
INDIVIDUAL_RATE       = getattr(config, "INDIVIDUAL_LESSON_RATE", 35000)


class ExtraServiceFSM(StatesGroup):
    choose_child    = State()
    choose_type     = State()
    enter_time      = State()
    confirm         = State()


def _type_keyboard(lang: str) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="🕐 Kechroq olaman", callback_data="es_type:late_pickup")],
        [InlineKeyboardButton(text="🌅 Ertaroq olib ketaman", callback_data="es_type:early_dropoff")],
        [InlineKeyboardButton(text="📚 Individual dars", callback_data="es_type:individual")],
        [InlineKeyboardButton(text="🍱 Tushlik qo'shish", callback_data="es_type:lunch")],
        [InlineKeyboardButton(text=get_string(lang, "cancel"), callback_data="es_cancel")],
    ])


def _confirm_keyboard(lang: str) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[
        [
            InlineKeyboardButton(text=get_string(lang, "yes"), callback_data="es_confirm:yes"),
            InlineKeyboardButton(text=get_string(lang, "no"),  callback_data="es_confirm:no"),
        ]
    ])


TYPE_RATES = {
    "late_pickup":    LATE_PICKUP_RATE,
    "early_dropoff":  EARLY_DROPOFF_RATE,
    "individual":     INDIVIDUAL_RATE,
    "lunch":          15000,
    "transport":      20000,
}

TYPE_NAMES = {
    "late_pickup":   "Kechroq olish",
    "early_dropoff": "Ertaroq olib ketish",
    "individual":    "Individual dars",
    "lunch":         "Tushlik",
    "transport":     "Transport",
}


# ─── Entry point: /extra buyrug'i yoki menyudan ──────────────────────────────

async def start_extra_service(message: Message, state: FSMContext, user: User):
    """Menyudan chaqiriladi."""
    lang = user.language or "uz_latin"
    children = await Child.filter(parent_id=user.id).all()
    if not children:
        await message.answer("Farzandingiz ro'yxatda yo'q.")
        return

    if len(children) == 1:
        await state.update_data(child_id=children[0].id, lang=lang)
        await message.answer(
            f"<b>{children[0].full_name}</b> uchun xizmat tanlang:",
            reply_markup=_type_keyboard(lang),
            parse_mode="HTML"
        )
        await state.set_state(ExtraServiceFSM.choose_type)
    else:
        buttons = [
            [InlineKeyboardButton(text=c.full_name, callback_data=f"es_child:{c.id}")]
            for c in children
        ]
        await message.answer("Farzandni tanlang:", reply_markup=InlineKeyboardMarkup(inline_keyboard=buttons))
        await state.update_data(lang=lang)
        await state.set_state(ExtraServiceFSM.choose_child)


@router.callback_query(F.data.startswith("es_child:"), ExtraServiceFSM.choose_child)
async def choose_child(cb: CallbackQuery, state: FSMContext):
    child_id = int(cb.data.split(":")[1])
    data = await state.get_data()
    lang = data.get("lang", "uz_latin")
    child = await Child.get_or_none(id=child_id)
    await state.update_data(child_id=child_id)
    await cb.message.edit_text(
        f"<b>{child.full_name}</b> uchun xizmat tanlang:",
        reply_markup=_type_keyboard(lang),
        parse_mode="HTML"
    )
    await state.set_state(ExtraServiceFSM.choose_type)
    await cb.answer()


@router.callback_query(F.data.startswith("es_type:"), ExtraServiceFSM.choose_type)
async def choose_type(cb: CallbackQuery, state: FSMContext):
    svc_type = cb.data.split(":")[1]
    data = await state.get_data()
    lang = data.get("lang", "uz_latin")
    await state.update_data(service_type=svc_type)

    if svc_type in ("late_pickup", "early_dropoff"):
        await cb.message.edit_text("Vaqtni kiriting (masalan: 18:30):")
        await state.set_state(ExtraServiceFSM.enter_time)
    else:
        amount = TYPE_RATES.get(svc_type, 0)
        name   = TYPE_NAMES.get(svc_type, svc_type)
        await state.update_data(amount=amount, end_time=None)
        text = get_string(lang, "late_pickup_confirm", amount=f"{amount:,}")
        text = f"{name}: {amount:,} so'm qo'shiladi. Tasdiqlaysizmi?"
        await cb.message.edit_text(text, reply_markup=_confirm_keyboard(lang))
        await state.set_state(ExtraServiceFSM.confirm)
    await cb.answer()


@router.message(ExtraServiceFSM.enter_time)
async def enter_time(message: Message, state: FSMContext):
    data = await state.get_data()
    lang = data.get("lang", "uz_latin")
    time_str = message.text.strip()

    # Oddiy format tekshiruvi
    parts = time_str.split(":")
    if len(parts) != 2 or not all(p.isdigit() for p in parts):
        await message.answer("Format: SS:DD (masalan 18:30)")
        return

    svc_type = data.get("service_type", "late_pickup")
    amount   = TYPE_RATES.get(svc_type, 0)
    name     = TYPE_NAMES.get(svc_type, svc_type)
    await state.update_data(end_time=time_str, amount=amount)

    text = f"{name} — {time_str}\n+{amount:,} so'm qo'shiladi. Tasdiqlaysizmi?"
    await message.answer(text, reply_markup=_confirm_keyboard(lang))
    await state.set_state(ExtraServiceFSM.confirm)


@router.callback_query(F.data.startswith("es_confirm:"), ExtraServiceFSM.confirm)
async def confirm_service(cb: CallbackQuery, state: FSMContext, bot: Bot):
    answer = cb.data.split(":")[1]
    data   = await state.get_data()
    lang   = data.get("lang", "uz_latin")

    if answer == "no":
        await cb.message.edit_text(get_string(lang, "cancelled"))
        await state.clear()
        await cb.answer()
        return

    child = await Child.get_or_none(id=data["child_id"])
    svc = await ExtraService.create(
        child=child,
        service_type=data["service_type"],
        date=date.today(),
        end_time=data.get("end_time"),
        amount=data.get("amount", 0),
        status="pending",
    )

    await cb.message.edit_text(get_string(lang, "extra_service_saved"))
    await state.clear()
    await cb.answer()

    # Bogcha ma'muriga xabar
    try:
        kg_id = child.kindergarten_id
        if kg_id:
            admins = await User.filter(role__in=["admin", "director"], kindergarten_id=kg_id).all()
            svc_name = TYPE_NAMES.get(data["service_type"], data["service_type"])
            text = (
                f"📋 Yangi qo'shimcha xizmat so'rovi\n"
                f"Bola: {child.full_name}\n"
                f"Xizmat: {svc_name}\n"
                f"Narx: {int(data.get('amount', 0)):,} so'm"
            )
            for admin in admins:
                if admin.telegram_id:
                    await bot.send_message(admin.telegram_id, text)
    except Exception as e:
        logger.warning(f"Admin xabari yuborilmadi: {e}")


@router.callback_query(F.data == "es_cancel")
async def cancel_service(cb: CallbackQuery, state: FSMContext):
    user = await User.get_or_none(telegram_id=cb.from_user.id)
    lang = user.language if user else "uz_latin"
    await cb.message.edit_text(get_string(lang, "cancelled"))
    await state.clear()
    await cb.answer()
