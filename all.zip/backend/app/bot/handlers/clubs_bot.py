"""
SmartDMTT v4 — To'garaklar bot handlerlari
Spec 7 bo'yicha: yozilish, chiqish, kutish ro'yxati
"""
import logging
import random
from datetime import datetime
from aiogram import Router, F, types
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.utils.keyboard import InlineKeyboardBuilder, ReplyKeyboardBuilder

from app.models import User, Kindergarten, Club, WaitingList, Child
from app.models.club import Enrollment

logger = logging.getLogger(__name__)
router = Router()


class ClubsStates(StatesGroup):
    exit_reason = State()
    leave_notice_date = State()


# ─── TO'GARAKLAR RO'YXATI ────────────────────────────────────
@router.message(F.text == "📚 To'garaklar")
async def cmd_clubs_list(message: types.Message):
    uid = message.from_user.id
    user = await User.get_or_none(id=uid)

    clubs = await Club.filter(is_active=True).prefetch_related("teacher", "kindergarten").all()
    if not clubs:
        await message.answer("📚 Hozircha to'garaklar mavjud emas.")
        return

    kb = InlineKeyboardBuilder()
    for c in clubs:
        enrolled = await Enrollment.filter(club=c, status="active").count()
        available = c.capacity - enrolled
        icon = "✅" if available > 0 else "🔒"
        kb.button(
            text=f"{icon} {c.name} — {c.price:,.0f} so'm",
            callback_data=f"club_detail_{c.id}"
        )
    kb.adjust(1)

    await message.answer(
        "📚 <b>To'garaklar ro'yxati</b>\n\n✅ — joy bor  🔒 — joy yo'q",
        reply_markup=kb.as_markup(),
        parse_mode="HTML"
    )


@router.callback_query(F.data.startswith("club_detail_"))
async def cb_club_detail(callback: types.CallbackQuery):
    club_id = int(callback.data.split("_")[-1])
    club = await Club.get_or_none(id=club_id)
    if not club:
        await callback.answer("Topilmadi")
        return

    teacher = await club.teacher
    kinder = await club.kindergarten
    enrolled = await Enrollment.filter(club=club, status="active").count()
    available = club.capacity - enrolled

    days_map = {
        "monday": "Dushanba", "tuesday": "Seshanba", "wednesday": "Chorshanba",
        "thursday": "Payshanba", "friday": "Juma", "saturday": "Shanba"
    }
    days = club.schedule_days or []
    days_str = ", ".join(days_map.get(d, d) for d in days) if days else "Belgilanmagan"

    text = (
        f"📚 <b>{club.name}</b>\n\n"
        f"👩‍🏫 Muallim: {teacher.full_name if teacher else 'Belgilanmagan'}\n"
        f"🏫 Bog'cha: {kinder.number if kinder else '?'}-son\n"
        f"🕐 Vaqt: {club.schedule_time or 'Belgilanmagan'}\n"
        f"📅 Kunlar: {days_str}\n"
        f"🚪 Xona: {club.room or 'Belgilanmagan'}\n"
        f"💰 Narx: {club.price:,.0f} so'm/oy\n\n"
        f"👥 Sig'im: {enrolled}/{club.capacity}\n"
        f"{'✅ Joy bor: ' + str(available) + ' ta' if available > 0 else '🔒 Joy yoq'}"
    )

    uid = callback.from_user.id
    user = await User.get_or_none(id=uid)

    kb = InlineKeyboardBuilder()
    if user and user.role == "parent":
        if available > 0:
            # Farzandlarini ko'rsat
            children = await Child.filter(parent=user).all()
            for child in children:
                already = await Enrollment.get_or_none(
                    child=child, club=club, status__in=["active", "blocked"]
                )
                if not already:
                    kb.button(
                        text=f"📝 {child.full_name}ni yozish",
                        callback_data=f"club_enroll_{club_id}_{child.id}"
                    )
        else:
            children = await Child.filter(parent=user).all()
            for child in children:
                waiting = await WaitingList.get_or_none(child=child, club=club)
                if not waiting:
                    kb.button(
                        text=f"🔔 {child.full_name} uchun kutish ro'yxatiga",
                        callback_data=f"club_wait_{club_id}_{child.id}"
                    )

        # Chiqish imkoni
        enrolled_child = await Enrollment.filter(
            child__parent=user, club=club, status="active"
        ).first()
        if enrolled_child:
            kb.button(
                text="🚪 To'garakdan chiqish",
                callback_data=f"club_leave_{enrolled_child.id}"
            )

    kb.button(text="⬅️ Orqaga", callback_data="clubs_back")
    kb.adjust(1)

    await callback.message.edit_text(text, reply_markup=kb.as_markup(), parse_mode="HTML")
    await callback.answer()


# ─── YOZILISH ────────────────────────────────────────────────
@router.callback_query(F.data.startswith("club_enroll_"))
async def cb_enroll(callback: types.CallbackQuery):
    _, _, club_id, child_id = callback.data.split("_")
    club_id, child_id = int(club_id), int(child_id)

    club = await Club.get_or_none(id=club_id)
    child = await Child.get_or_none(id=child_id)

    if not club or not child:
        await callback.answer("Topilmadi")
        return

    # Joy tekshirish
    enrolled_count = await Enrollment.filter(club=club, status="active").count()
    if enrolled_count >= club.capacity:
        await callback.message.answer(
            "❌ Joy to'lib qoldi. Kutish ro'yxatiga qo'shilmoqchimisiz?",
            reply_markup=InlineKeyboardBuilder().button(
                text="🔔 Kutish ro'yxatiga", callback_data=f"club_wait_{club_id}_{child_id}"
            ).as_markup()
        )
        await callback.answer()
        return

    # Payment ID yaratish
    while True:
        pid = str(random.randint(100000, 999999))
        if not await Enrollment.get_or_none(payment_id=pid):
            break

    enrollment = await Enrollment.create(
        child=child, club=club, payment_id=pid, status="active"
    )

    teacher = await club.teacher
    if teacher and teacher.id:
        try:
            parent = await child.parent
            await callback.bot.send_message(
                teacher.id,
                f"👶 <b>Yangi o'quvchi!</b>\n\n"
                f"📚 To'garak: {club.name}\n"
                f"👦 Ism: {child.full_name}\n"
                f"👨‍👩‍👧 Ota-ona: {parent.full_name if parent else '?'}",
                parse_mode="HTML"
            )
        except Exception:
            pass

    await callback.message.answer(
        f"✅ <b>{child.full_name} {club.name} to'garagiga yozildi!</b>\n\n"
        f"💳 <b>To'lov ID: {pid}</b>\n\n"
        f"Bu ID ni Click, Paynet yoki Payme ilovasida kiriting.\n"
        f"To'lov tasdiqlangach, to'garak faol bo'ladi.",
        parse_mode="HTML"
    )
    await callback.answer()


# ─── KUTISH RO'YXATI ─────────────────────────────────────────
@router.callback_query(F.data.startswith("club_wait_"))
async def cb_waiting_list(callback: types.CallbackQuery):
    _, _, club_id, child_id = callback.data.split("_")
    club_id, child_id = int(club_id), int(child_id)

    club = await Club.get_or_none(id=club_id)
    child = await Child.get_or_none(id=child_id)

    if not club or not child:
        await callback.answer("Topilmadi")
        return

    waiting, created = await WaitingList.get_or_create(child=child, club=club)
    if created:
        await callback.message.answer(
            f"🔔 <b>{child.full_name}</b> kutish ro'yxatiga qo'shildi!\n\n"
            f"Bo'sh joy bo'lganda sizga xabar beramiz."
        )
    else:
        await callback.message.answer("✅ Siz allaqachon kutish ro'yxatidasiz.")
    await callback.answer()


# ─── TO'GARAKDAN CHIQISH ─────────────────────────────────────
@router.callback_query(F.data.startswith("club_leave_"))
async def cb_leave_club(callback: types.CallbackQuery, state: FSMContext):
    enrollment_id = int(callback.data.split("_")[-1])
    enrollment = await Enrollment.get_or_none(id=enrollment_id)
    if not enrollment:
        await callback.answer("Topilmadi")
        return

    child = await enrollment.child
    club = await enrollment.club

    await state.update_data(enrollment_id=enrollment_id)
    await state.set_state(ClubsStates.exit_reason)

    kb = InlineKeyboardBuilder()
    kb.button(text="⏭ Bekor qilish", callback_data="clubs_cancel_leave")
    kb.adjust(1)

    await callback.message.answer(
        f"🚪 <b>{club.name if club else '?'} to'garagidan chiqish</b>\n\n"
        f"⚠️ Kamida 2 dars kuni oldin ogohlantirish shart.\n\n"
        f"Chiqish sababini yozing:",
        reply_markup=kb.as_markup(),
        parse_mode="HTML"
    )
    await callback.answer()


@router.message(ClubsStates.exit_reason)
async def handle_exit_reason(message: types.Message, state: FSMContext):
    data = await state.get_data()
    enrollment_id = data.get("enrollment_id")
    await state.clear()

    enrollment = await Enrollment.get_or_none(id=enrollment_id)
    if not enrollment:
        await message.answer("❌ Topilmadi.")
        return

    child = await enrollment.child
    club = await enrollment.club

    # Statusni o'zgartirish
    enrollment.status = "cancelled"
    await enrollment.save()

    # Muallimga xabar
    if club:
        teacher = await club.teacher
        if teacher and teacher.id:
            try:
                await message.bot.send_message(
                    teacher.id,
                    f"🚪 <b>{child.full_name} to'garakdan chiqdi</b>\n\n"
                    f"📚 {club.name}\n"
                    f"📝 Sabab: {message.text}",
                    parse_mode="HTML"
                )
            except Exception:
                pass

    # Kutish ro'yxatidagi birinchisiga xabar
    waiting = await WaitingList.filter(club=club, notified=False).order_by("id").first()
    if waiting and club:
        waiting_child = await waiting.child
        waiting_parent = await waiting_child.parent
        if waiting_parent and waiting_parent.id:
            try:
                await message.bot.send_message(
                    waiting_parent.id,
                    f"🎉 <b>{club.name} to'garagida joy bo'shadi!</b>\n\n"
                    f"24 soat ichida yozilmasangiz, keyingisiga o'tiladi.\n\n"
                    f"📝 Yozilish uchun: 📚 To'garaklar → {club.name}",
                )
                waiting.notified = True
                await waiting.save()
            except Exception:
                pass

    await message.answer(
        f"✅ <b>{club.name if club else '?'} to'garagidan chiqildingiz.</b>\n\n"
        f"To'lov ID bekor qilindi."
    )


@router.callback_query(F.data == "clubs_cancel_leave")
async def cb_cancel_leave(callback: types.CallbackQuery, state: FSMContext):
    await state.clear()
    await callback.message.edit_text("✅ Chiqish bekor qilindi.")
    await callback.answer()


@router.callback_query(F.data == "clubs_back")
async def cb_clubs_back(callback: types.CallbackQuery):
    """To'garaklar ro'yxatiga qaytish"""
    clubs = await Club.filter(is_active=True).all()
    kb = InlineKeyboardBuilder()
    for c in clubs:
        enrolled = await Enrollment.filter(club=c, status="active").count()
        available = c.capacity - enrolled
        icon = "✅" if available > 0 else "🔒"
        kb.button(
            text=f"{icon} {c.name} — {c.price:,.0f} so'm",
            callback_data=f"club_detail_{c.id}"
        )
    kb.adjust(1)

    await callback.message.edit_text(
        "📚 <b>To'garaklar ro'yxati</b>\n\n✅ — joy bor  🔒 — joy yo'q",
        reply_markup=kb.as_markup(),
        parse_mode="HTML"
    )
    await callback.answer()
