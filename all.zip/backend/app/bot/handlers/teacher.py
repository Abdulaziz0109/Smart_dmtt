"""
SmartDMTT v4.0 — Muallim bot handlerlari
Real DB ga ulangan.
"""
import logging
from datetime import date, timedelta

from aiogram import Router, F, types
from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton

from app.models.user import User
from app.models.child import Child, Attendance
from app.models.club import Club, Enrollment
from app.models.payment import Payment

logger = logging.getLogger(__name__)
router = Router()


async def _get_teacher(tg_id: int) -> User | None:
    return await User.get_or_none(telegram_id=tg_id, role__in=["teacher", "togarak_rahbari"])


async def _get_teacher_clubs(user: User) -> list[Club]:
    if user.club_id:
        club = await Club.get_or_none(id=user.club_id, is_active=True)
        return [club] if club else []
    # Fallback: kindergarten bo'yicha
    if user.kindergarten_id:
        return await Club.filter(kindergarten_id=user.kindergarten_id, is_active=True).all()
    return []


# ─── 📚 To'garaklarim ─────────────────────────────────────────────────────────

@router.message(F.text == "📚 To'garaklarim")
async def my_clubs(message: types.Message):
    user = await _get_teacher(message.from_user.id)
    if not user:
        return

    clubs = await _get_teacher_clubs(user)
    if not clubs:
        await message.answer("Sizga biriktirilgan to'garak yo'q.\nAdmin bilan bog'laning.")
        return

    today      = date.today()
    month_str  = today.strftime("%Y-%m")
    text_parts = []

    for club in clubs:
        enrollments = await Enrollment.filter(club_id=club.id, status="active").all()
        enr_ids     = [e.id for e in enrollments]

        # Bugungi davomat
        att_today   = await Attendance.filter(enrollment_id__in=enr_ids, date=today).count()
        present_today = await Attendance.filter(enrollment_id__in=enr_ids, date=today, status="present").count()

        # Bu oy to'lov
        paid_count  = await Payment.filter(
            enrollment_id__in=enr_ids, month=month_str, status="completed"
        ).count() if enr_ids else 0
        debt_count  = len(enrollments) - paid_count

        text_parts.append(
            f"📚 <b>{club.name}</b>\n"
            f"👶 O'quvchilar: {len(enrollments)}\n"
            f"📅 Jadval: {club.schedule_days or '—'} {club.schedule_time or ''}\n"
            f"✅ Bugun: {present_today}/{att_today} belgilangan\n"
            f"💰 To'lov: {paid_count} ✅ | {debt_count} ❌ qarzdor"
        )

    kb = InlineKeyboardMarkup(inline_keyboard=[[
        InlineKeyboardButton(text="📋 Davomat belgilash", callback_data="teacher_att_start")
    ]])
    await message.answer("\n\n".join(text_parts), parse_mode="HTML", reply_markup=kb)


# ─── 📋 Davomat ───────────────────────────────────────────────────────────────

@router.message(F.text == "📋 Davomat")
async def mark_attendance(message: types.Message):
    user = await _get_teacher(message.from_user.id)
    if not user:
        return

    clubs = await _get_teacher_clubs(user)
    if not clubs:
        await message.answer("To'garaklar topilmadi.")
        return

    if len(clubs) == 1:
        await _show_attendance_sheet(message, user, clubs[0])
        return

    kb_rows = [
        [InlineKeyboardButton(text=f"📚 {c.name}", callback_data=f"att_club:{c.id}")]
        for c in clubs
    ]
    await message.answer(
        "Qaysi to'garak uchun davomat?",
        reply_markup=InlineKeyboardMarkup(inline_keyboard=kb_rows)
    )


@router.callback_query(F.data == "teacher_att_start")
async def cb_att_start(callback: types.CallbackQuery):
    await callback.answer()
    user = await _get_teacher(callback.from_user.id)
    if not user:
        return
    clubs = await _get_teacher_clubs(user)
    if len(clubs) == 1:
        await _show_attendance_sheet(callback.message, user, clubs[0])
    elif clubs:
        kb_rows = [
            [InlineKeyboardButton(text=f"📚 {c.name}", callback_data=f"att_club:{c.id}")]
            for c in clubs
        ]
        await callback.message.answer(
            "Qaysi to'garak?",
            reply_markup=InlineKeyboardMarkup(inline_keyboard=kb_rows)
        )


@router.callback_query(F.data.startswith("att_club:"))
async def cb_select_club(callback: types.CallbackQuery):
    club_id = int(callback.data.split(":")[1])
    await callback.answer()
    user  = await _get_teacher(callback.from_user.id)
    club  = await Club.get_or_none(id=club_id)
    if user and club:
        await _show_attendance_sheet(callback.message, user, club)


async def _show_attendance_sheet(message: types.Message, user: User, club: Club):
    """To'garak o'quvchilari ro'yxatini ko'rsatish."""
    enrollments = await Enrollment.filter(club_id=club.id, status="active").all()
    if not enrollments:
        await message.answer(f"<b>{club.name}</b>: O'quvchilar yo'q.", parse_mode="HTML")
        return

    today = date.today()
    kb_rows = []
    for enr in enrollments:
        child = await Child.get_or_none(id=enr.child_id)
        if not child:
            continue
        # Bugun belgilanganmi?
        att = await Attendance.filter(enrollment_id=enr.id, date=today).first()
        status_icon = {"present": "✅", "absent": "❌", "late": "⏰", "excused": "📝"}.get(att.status if att else None, "⬜")
        kb_rows.append([
            InlineKeyboardButton(
                text=f"{status_icon} {child.full_name}",
                callback_data=f"att_child:{enr.id}:{club.id}"
            )
        ])

    kb_rows.append([
        InlineKeyboardButton(text="✅ Barchasi keldi", callback_data=f"att_all_present:{club.id}"),
        InlineKeyboardButton(text="❌ Barchasi kelmadi", callback_data=f"att_all_absent:{club.id}"),
    ])

    await message.answer(
        f"📋 <b>{club.name}</b> — {today.strftime('%d.%m.%Y')}\n"
        f"👶 {len(enrollments)} o'quvchi\n\n"
        f"Davomat belgilash uchun ismga bosing:",
        parse_mode="HTML",
        reply_markup=InlineKeyboardMarkup(inline_keyboard=kb_rows)
    )


@router.callback_query(F.data.startswith("att_child:"))
async def cb_mark_child(callback: types.CallbackQuery):
    _, enr_id_str, club_id_str = callback.data.split(":")
    enr_id  = int(enr_id_str)
    await callback.answer()

    kb = InlineKeyboardMarkup(inline_keyboard=[[
        InlineKeyboardButton(text="✅ Keldi",      callback_data=f"att_set:{enr_id}:present"),
        InlineKeyboardButton(text="❌ Kelmadi",    callback_data=f"att_set:{enr_id}:absent"),
        InlineKeyboardButton(text="⏰ Kech",       callback_data=f"att_set:{enr_id}:late"),
        InlineKeyboardButton(text="📝 Sababli",   callback_data=f"att_set:{enr_id}:excused"),
    ]])
    enr   = await Enrollment.get_or_none(id=enr_id)
    child = await Child.get_or_none(id=enr.child_id) if enr else None
    await callback.message.answer(
        f"👶 <b>{child.full_name if child else '?'}</b> — davomat:",
        parse_mode="HTML",
        reply_markup=kb
    )


@router.callback_query(F.data.startswith("att_set:"))
async def cb_set_status(callback: types.CallbackQuery):
    _, enr_id_str, status = callback.data.split(":")
    enr_id = int(enr_id_str)
    await callback.answer()

    today = date.today()
    att, created = await Attendance.get_or_create(enrollment_id=enr_id, date=today)
    att.status           = status
    att.teacher_confirmed = True
    await att.save()

    icons = {"present": "✅ Keldi", "absent": "❌ Kelmadi", "late": "⏰ Kech keldi", "excused": "📝 Sababli"}
    enr   = await Enrollment.get_or_none(id=enr_id)
    child = await Child.get_or_none(id=enr.child_id) if enr else None

    try:
        await callback.message.edit_text(
            f"✅ Belgilandi: <b>{child.full_name if child else '?'}</b> — {icons.get(status, status)}",
            parse_mode="HTML"
        )
    except Exception:
        pass


@router.callback_query(F.data.startswith("att_all_present:"))
async def cb_all_present(callback: types.CallbackQuery):
    club_id = int(callback.data.split(":")[1])
    await callback.answer()
    await _mark_all(callback, club_id, "present")


@router.callback_query(F.data.startswith("att_all_absent:"))
async def cb_all_absent(callback: types.CallbackQuery):
    club_id = int(callback.data.split(":")[1])
    await callback.answer()
    await _mark_all(callback, club_id, "absent")


async def _mark_all(callback: types.CallbackQuery, club_id: int, status: str):
    today       = date.today()
    enrollments = await Enrollment.filter(club_id=club_id, status="active").all()
    count       = 0
    for enr in enrollments:
        att, _ = await Attendance.get_or_create(enrollment_id=enr.id, date=today)
        att.status            = status
        att.teacher_confirmed = True
        await att.save()
        count += 1

    icon = "✅" if status == "present" else "❌"
    await callback.message.answer(f"{icon} {count} ta o'quvchi belgilandi.")


# ─── 📊 Hisobot ───────────────────────────────────────────────────────────────

@router.message(F.text == "📊 Hisobot")
async def weekly_report(message: types.Message):
    user = await _get_teacher(message.from_user.id)
    if not user:
        return

    today      = date.today()
    week_start = today - timedelta(days=today.weekday())
    month_str  = today.strftime("%Y-%m")
    clubs      = await _get_teacher_clubs(user)
    text_parts = []

    for club in clubs:
        enrollments = await Enrollment.filter(club_id=club.id, status="active").all()
        enr_ids     = [e.id for e in enrollments]

        # Haftalik davomat
        att_week = await Attendance.filter(enrollment_id__in=enr_ids, date__gte=week_start).all() if enr_ids else []
        total    = len(att_week)
        present  = sum(1 for a in att_week if a.status == "present")
        pct      = round(present / total * 100) if total else 0

        # To'lov holati
        paid     = await Payment.filter(enrollment_id__in=enr_ids, month=month_str, status="completed").count() if enr_ids else 0
        unpaid   = len(enrollments) - paid

        # Eng ko'p yo'qligi bo'lgan o'quvchilar (top 3)
        absent_counts = {}
        for att in att_week:
            if att.status == "absent":
                absent_counts[att.enrollment_id] = absent_counts.get(att.enrollment_id, 0) + 1

        top_absent = sorted(absent_counts.items(), key=lambda x: x[1], reverse=True)[:3]
        absent_text = ""
        for enr_id, cnt in top_absent:
            enr   = next((e for e in enrollments if e.id == enr_id), None)
            child = await Child.get_or_none(id=enr.child_id) if enr else None
            if child:
                absent_text += f"\n  ❌ {child.full_name} — {cnt} kun"

        text_parts.append(
            f"📚 <b>{club.name}</b>\n"
            f"👶 Faol o'quvchilar: {len(enrollments)}\n"
            f"📅 Bu hafta davomat: {present}/{total} ({pct}%)\n"
            f"💰 To'lov: {paid} ✅ | {unpaid} ❌"
            + (f"\n⚠️ Ko'p yo'qligi:{absent_text}" if absent_text else "")
        )

    if text_parts:
        await message.answer("\n\n".join(text_parts), parse_mode="HTML")
    else:
        await message.answer("To'garaklar topilmadi.")


# ─── 🤖 AI Yordam ─────────────────────────────────────────────────────────────

@router.message(F.text == "🤖 AI Yordam")
async def ai_help(message: types.Message):
    await message.answer(
        "🤖 Menga savolingizni yozing.\n\n"
        "Masalan:\n"
        "• 'Davomat past bolalar bilan qanday ishlash kerak?'\n"
        "• 'O'qitish metodikasi bo'yicha maslahat'\n"
        "• '? <savol>' formatida ham yubora olasiz"
    )


@router.message(F.text.startswith("?"))
async def answer_question(message: types.Message):
    user = await User.get_or_none(telegram_id=message.from_user.id)
    if not user or user.role not in ("teacher", "togarak_rahbari"):
        return

    from app.services.ai_helper import get_ai_answer
    wait = await message.answer("🤔 Javob tayyorlanmoqda...")
    try:
        answer = await get_ai_answer(message.text.lstrip("? "), user.id)
        await wait.delete()
        await message.answer(answer)
    except Exception as e:
        logger.error(f"AI xato: {e}")
        await wait.edit_text("Xatolik. Qayta urinib ko'ring.")
