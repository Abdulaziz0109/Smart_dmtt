"""
SmartDMTT v4 — Bola kuzatuvi handleri (muallim)
Darsdan 15 daqiqa keyin scheduler chaqiradi.
"""
import logging
from datetime import date

from aiogram import Router, F, Bot
from aiogram.types import (
    CallbackQuery, InlineKeyboardMarkup, InlineKeyboardButton
)

from app.models import User, Club
from app.models.club import Enrollment
from app.models.observation import ChildObservation
from app.models.child import Child
from app.core.strings import get_string

logger = logging.getLogger(__name__)
router = Router()

# callback_data formati:
#   obs_score:{enrollment_id}:{field}:{score}   — ball tanlash
#   obs_flag:{enrollment_id}:{flag}:{val}        — belgi on/off
#   obs_save:{enrollment_id}                     — saqlash


def _obs_keyboard(enr_id: int, scores: dict, flags: dict) -> InlineKeyboardMarkup:
    """Kuzatuv klaviaturasi."""
    field_labels = {
        "energy":     "Faollik",
        "focus":      "Diqqat",
        "creativity": "Ijodiylik",
        "social":     "Muloqot",
    }
    flag_labels = {
        "asked_question": "Savol berdi",
        "made_discovery": "Kashfiyot",
        "helped_others":  "Yordam berdi",
        "struggled":      "Qiynaldi",
        "completed_task": "Vazifa bajardi",
    }

    rows = []

    # Ball qatorlari (1-5)
    for field, label in field_labels.items():
        current = scores.get(field, 0)
        btn_row = [InlineKeyboardButton(text=label, callback_data=f"obs_noop")]
        score_row = [
            InlineKeyboardButton(
                text=f"{'●' if current == i else '○'}{i}",
                callback_data=f"obs_score:{enr_id}:{field}:{i}"
            )
            for i in range(1, 6)
        ]
        rows.append(btn_row)
        rows.append(score_row)

    # Belgilar
    flag_row = []
    for flag, label in flag_labels.items():
        active = flags.get(flag, False)
        flag_row.append(InlineKeyboardButton(
            text=f"{'✅' if active else '⬜'} {label}",
            callback_data=f"obs_flag:{enr_id}:{flag}"
        ))
        if len(flag_row) == 2:
            rows.append(flag_row)
            flag_row = []
    if flag_row:
        rows.append(flag_row)

    rows.append([InlineKeyboardButton(
        text="💾 Saqlash",
        callback_data=f"obs_save:{enr_id}"
    )])
    return InlineKeyboardMarkup(inline_keyboard=rows)


# ─── Tashqi funksiya: scheduler chaqiradi ────────────────────────────────────

async def send_observation_request(bot: Bot, club_id: int):
    """Darsdan 15 daqiqa keyin muallimga kuzatuv so'rovi yuboradi."""
    club = await Club.get_or_none(id=club_id)
    if not club or not club.teacher_id:
        return

    teacher = await User.get_or_none(id=club.teacher_id)
    if not teacher or not teacher.telegram_id:
        return

    lang = teacher.language or "uz_latin"
    enrollments = await Enrollment.filter(club_id=club_id, status="active").all()
    if not enrollments:
        return

    for enr in enrollments:
        child = await Child.get_or_none(id=enr.child_id)
        if not child:
            continue
        try:
            text = (
                f"{get_string(lang, 'observation_prompt', club=club.name)}\n"
                f"<b>{child.full_name}</b>"
            )
            kb = _obs_keyboard(enr.id, {}, {})
            await bot.send_message(teacher.telegram_id, text, reply_markup=kb, parse_mode="HTML")
        except Exception as e:
            logger.warning(f"Kuzatuv xabari yuborilmadi ({teacher.telegram_id}): {e}")


# ─── Callback handlerlar ──────────────────────────────────────────────────────

# Joriy sessiya ma'lumotlari: {enrollment_id: {scores, flags}}
_session: dict = {}


@router.callback_query(F.data == "obs_noop")
async def noop(cb: CallbackQuery):
    await cb.answer()


@router.callback_query(F.data.startswith("obs_score:"))
async def handle_score(cb: CallbackQuery):
    _, enr_id_str, field, score_str = cb.data.split(":")
    enr_id = int(enr_id_str)
    score  = int(score_str)

    if enr_id not in _session:
        _session[enr_id] = {"scores": {}, "flags": {}}
    _session[enr_id]["scores"][field] = score

    kb = _obs_keyboard(enr_id, _session[enr_id]["scores"], _session[enr_id]["flags"])
    await cb.message.edit_reply_markup(reply_markup=kb)
    await cb.answer(f"{score} ✔")


@router.callback_query(F.data.startswith("obs_flag:"))
async def handle_flag(cb: CallbackQuery):
    _, enr_id_str, flag = cb.data.split(":")
    enr_id = int(enr_id_str)

    if enr_id not in _session:
        _session[enr_id] = {"scores": {}, "flags": {}}
    current = _session[enr_id]["flags"].get(flag, False)
    _session[enr_id]["flags"][flag] = not current

    kb = _obs_keyboard(enr_id, _session[enr_id]["scores"], _session[enr_id]["flags"])
    await cb.message.edit_reply_markup(reply_markup=kb)
    await cb.answer()


@router.callback_query(F.data.startswith("obs_save:"))
async def handle_save(cb: CallbackQuery):
    enr_id = int(cb.data.split(":")[1])
    session = _session.pop(enr_id, {"scores": {}, "flags": {}})
    scores = session["scores"]
    flags  = session["flags"]

    enrollment = await Enrollment.get_or_none(id=enr_id)
    if not enrollment:
        await cb.answer("Xatolik!")
        return

    await ChildObservation.create(
        enrollment=enrollment,
        date=date.today(),
        energy=scores.get("energy"),
        focus=scores.get("focus"),
        creativity=scores.get("creativity"),
        social=scores.get("social"),
        asked_question=flags.get("asked_question", False),
        made_discovery=flags.get("made_discovery", False),
        helped_others=flags.get("helped_others", False),
        struggled=flags.get("struggled", False),
        completed_task=flags.get("completed_task", False),
    )

    user = await User.get_or_none(telegram_id=cb.from_user.id)
    lang = user.language if user else "uz_latin"
    await cb.message.edit_text(get_string(lang, "observation_saved"))
    await cb.answer()
