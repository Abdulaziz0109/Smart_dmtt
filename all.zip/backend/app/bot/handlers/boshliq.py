"""
SmartDMTT v4 — MMTB Boshliq bot handlerlari
Spec 5.5 bo'yicha: tuman bo'yicha barcha bog'chalar statistikasi
"""
import logging
from datetime import datetime, timedelta
from aiogram import Router, F, types
from aiogram.filters import Command
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.utils.keyboard import InlineKeyboardBuilder, ReplyKeyboardBuilder

from app.models import User, Kindergarten, Club, Child, Attendance, Payment, AILog
from app.models.club import Enrollment

logger = logging.getLogger(__name__)
router = Router()


# ─── FSM ─────────────────────────────────────────────────────
class BoshliqStates(StatesGroup):
    broadcast_text = State()
    broadcast_target = State()
    kinder_detail = State()


# ─── FILTR ───────────────────────────────────────────────────
def is_boshliq(user: User) -> bool:
    return user.role in ("boshliq", "admin")


# ─── ASOSIY MENYU ────────────────────────────────────────────
async def boshliq_menu(message: types.Message):
    kb = ReplyKeyboardBuilder()
    kb.button(text="📊 Statistika")
    kb.button(text="🏫 Bog'chalar")
    kb.button(text="👩‍🏫 Muallimlar")
    kb.button(text="💰 Moliya")
    kb.button(text="⚠️ Anomaliyalar")
    kb.button(text="📣 E'lon")
    kb.button(text="📨 Broadcast")
    kb.button(text="📱 WebApp")
    kb.button(text="👤 Profil")
    kb.adjust(2)
    await message.answer(
        "🏛 <b>MMTB Boshliq paneli</b>\n\nNimani ko'rmoqchisiz?",
        reply_markup=kb.as_markup(resize_keyboard=True),
        parse_mode="HTML"
    )


# ─── STATISTIKA ──────────────────────────────────────────────
@router.message(F.text == "📊 Statistika")
async def cmd_statistika(message: types.Message):
    uid = message.from_user.id
    user = await User.get_or_none(id=uid)
    if not user or not is_boshliq(user):
        return

    await message.answer("⏳ Statistika hisoblanmoqda...")

    # Jami hisoblar
    total_kinders = await Kindergarten.filter(is_active=True).count()
    total_teachers = await User.filter(role="teacher", is_test=False).count()
    total_parents = await User.filter(role="parent", is_test=False).count()
    total_clubs = await Club.filter(is_active=True).count()
    total_children = await Child.all().count()
    total_enrolled = await Enrollment.filter(status="active").count()

    # Davomat (joriy oy)
    today = datetime.now()
    month_start = today.replace(day=1)
    total_att = await Attendance.filter(date__gte=month_start.date()).count()
    present_att = await Attendance.filter(
        date__gte=month_start.date(), status="present"
    ).count()
    att_pct = round(present_att / total_att * 100) if total_att > 0 else 0

    # O'tgan hafta
    week_ago = today - timedelta(days=7)
    prev_att = await Attendance.filter(
        date__gte=(week_ago - timedelta(days=7)).date(),
        date__lt=week_ago.date()
    ).count()
    prev_present = await Attendance.filter(
        date__gte=(week_ago - timedelta(days=7)).date(),
        date__lt=week_ago.date(),
        status="present"
    ).count()
    prev_pct = round(prev_present / prev_att * 100) if prev_att > 0 else 0
    trend = att_pct - prev_pct
    trend_icon = "📈" if trend > 0 else ("📉" if trend < 0 else "➡️")

    # Moliya (joriy oy)
    month_str = today.strftime("%Y-%m")
    total_payments = await Payment.filter(month=month_str, status="completed").count()
    # Qarzdorlar
    paid_enrollments = await Payment.filter(
        month=month_str, status="completed"
    ).values_list("enrollment_id", flat=True)
    debtors = await Enrollment.filter(status__in=["active", "blocked"]).exclude(
        id__in=list(paid_enrollments)
    ).count()

    # Anomaliyalar
    anomaly_critical = await AILog.filter(
        log_type="anomaly", is_test=False
    ).count()

    text = (
        f"📊 <b>Tuman Statistikasi</b>\n"
        f"📅 {today.strftime('%d.%m.%Y')}\n\n"
        f"🏫 Bog'chalar: <b>{total_kinders}</b>\n"
        f"👩‍🏫 Muallimlar: <b>{total_teachers}</b>\n"
        f"👨‍👩‍👧 Ota-onalar: <b>{total_parents}</b>\n"
        f"📚 To'garaklar: <b>{total_clubs}</b>\n"
        f"👶 Bolalar: <b>{total_children}</b> "
        f"(yozilgan: {total_enrolled})\n\n"
        f"📅 <b>Davomat (joriy oy):</b>\n"
        f"  O'rtacha: <b>{att_pct}%</b> {trend_icon} "
        f"({'+'if trend>0 else ''}{trend}% o'tgan haftaga nisbatan)\n\n"
        f"💰 <b>To'lov (joriy oy):</b>\n"
        f"  To'langan: <b>{total_payments}</b> ta\n"
        f"  Qarzdor: <b>{debtors}</b> ta\n\n"
        f"⚠️ <b>Anomaliyalar:</b> {anomaly_critical} ta"
    )

    kb = InlineKeyboardBuilder()
    kb.button(text="🏫 Bog'chalar reytingi", callback_data="boshliq_kinders_rating")
    kb.button(text="⚠️ Anomaliyalarni ko'r", callback_data="boshliq_anomalies")
    kb.adjust(1)

    await message.answer(text, reply_markup=kb.as_markup(), parse_mode="HTML")


# ─── BOG'CHALAR ──────────────────────────────────────────────
@router.message(F.text == "🏫 Bog'chalar")
async def cmd_kinders(message: types.Message):
    uid = message.from_user.id
    user = await User.get_or_none(id=uid)
    if not user or not is_boshliq(user):
        return

    kinders = await Kindergarten.filter(is_active=True).order_by("number").all()
    if not kinders:
        await message.answer("Bog'chalar topilmadi.")
        return

    kb = InlineKeyboardBuilder()
    for k in kinders:
        kb.button(
            text=f"🏫 {k.number}-son bog'cha",
            callback_data=f"bq_kinder_{k.id}"
        )
    kb.adjust(2)

    await message.answer(
        f"🏫 <b>Barcha bog'chalar ({len(kinders)} ta)</b>\n\nBatafsil ko'rish uchun bosing:",
        reply_markup=kb.as_markup(),
        parse_mode="HTML"
    )


@router.callback_query(F.data.startswith("bq_kinder_"))
async def cb_kinder_detail(callback: types.CallbackQuery):
    kinder_id = int(callback.data.split("_")[-1])
    k = await Kindergarten.get_or_none(id=kinder_id)
    if not k:
        await callback.answer("Topilmadi")
        return

    # Statistika
    teachers = await User.filter(kindergarten_id=kinder_id, role="teacher").count()
    clubs = await Club.filter(kindergarten_id=kinder_id, is_active=True).count()
    enrolled = await Enrollment.filter(
        club__kindergarten_id=kinder_id, status="active"
    ).count()

    # Davomat
    today = datetime.now()
    month_start = today.replace(day=1)
    # Enrollment ID larni olish (3-darajali filter o'rniga)
    enr_ids = await Enrollment.filter(
        club__kindergarten_id=kinder_id, status="active"
    ).values_list("id", flat=True)
    att_total = await Attendance.filter(
        enrollment_id__in=enr_ids,
        date__gte=month_start.date()
    ).count() if enr_ids else 0
    att_present = await Attendance.filter(
        enrollment_id__in=enr_ids,
        date__gte=month_start.date(),
        status="present"
    ).count() if enr_ids else 0
    att_pct = round(att_present / att_total * 100) if att_total > 0 else 0

    # Direktor
    director = None
    if k.director_id:
        director = await User.get_or_none(id=k.director_id)

    text = (
        f"🏫 <b>{k.number}-son bog'cha</b>\n"
        f"📍 {k.address or 'Manzil kiritilmagan'}\n\n"
        f"👩‍🏫 Muallimlar: {teachers}\n"
        f"📚 To'garaklar: {clubs}\n"
        f"👶 O'quvchilar: {enrolled}\n"
        f"📅 Davomat: {att_pct}%\n\n"
        f"👤 Direktor: {director.full_name if director else 'Belgilanmagan'}"
    )

    kb = InlineKeyboardBuilder()
    if director and director.id:
        kb.button(
            text="📨 Direktorganma xabar",
            callback_data=f"bq_msg_director_{k.director_id}"
        )
    kb.button(text="📊 Batafsil statistika", callback_data=f"bq_kinder_stat_{kinder_id}")
    kb.button(text="⬅️ Orqaga", callback_data="bq_kinders_back")
    kb.adjust(1)

    await callback.answer()
    try:
        await callback.message.edit_text(text, reply_markup=kb.as_markup(), parse_mode="HTML")
    except Exception:
        pass  # Matn o'zgarmagan bo'lsa Telegram xato qaytaradi — e'tibor bermaymiz


@router.callback_query(F.data.startswith("bq_msg_director_"))
async def cb_msg_director(callback: types.CallbackQuery, state: FSMContext):
    director_id = int(callback.data.split("_")[-1])
    await state.update_data(target_director_id=director_id)
    await state.set_state(BoshliqStates.broadcast_text)
    await callback.message.answer(
        "✏️ Direktorganma yuboriladigan xabarni yozing:"
    )
    await callback.answer()


@router.callback_query(F.data == "boshliq_kinders_rating")
async def cb_kinders_rating(callback: types.CallbackQuery):
    kinders = await Kindergarten.filter(is_active=True).all()
    today = datetime.now()
    month_start = today.replace(day=1)

    ratings = []
    for k in kinders:
        enr_ids_k = await Enrollment.filter(
            club__kindergarten_id=k.id, status="active"
        ).values_list("id", flat=True)
        att_total = await Attendance.filter(
            enrollment_id__in=enr_ids_k,
            date__gte=month_start.date()
        ).count() if enr_ids_k else 0
        att_present = await Attendance.filter(
            enrollment_id__in=enr_ids_k,
            date__gte=month_start.date(),
            status="present"
        ).count() if enr_ids_k else 0
        pct = round(att_present / att_total * 100) if att_total > 0 else 0
        ratings.append((k.number, pct))

    ratings.sort(key=lambda x: x[1], reverse=True)

    lines = ["🏆 <b>Bog'chalar reytingi (davomat %)</b>\n"]
    for i, (num, pct) in enumerate(ratings, 1):
        medal = "🥇" if i == 1 else ("🥈" if i == 2 else ("🥉" if i == 3 else f"{i}.")  )
        warn = " ⚠️" if pct < 70 else ""
        lines.append(f"{medal} {num}-son bog'cha — <b>{pct}%</b>{warn}")

    await callback.message.answer("\n".join(lines), parse_mode="HTML")
    await callback.answer()


# ─── MUALLIMLAR ──────────────────────────────────────────────
@router.message(F.text == "👩‍🏫 Muallimlar")
async def cmd_muallimlar(message: types.Message):
    uid = message.from_user.id
    user = await User.get_or_none(id=uid)
    if not user or not is_boshliq(user):
        return

    teachers = await User.filter(role="teacher", is_test=False).order_by("full_name").all()

    if not teachers:
        await message.answer("Muallimlar topilmadi.")
        return

    kb = InlineKeyboardBuilder()
    for t in teachers[:20]:  # Max 20
        kb.button(text=f"👩‍🏫 {t.full_name}", callback_data=f"bq_teacher_{t.id}")
    kb.adjust(1)

    await message.answer(
        f"👩‍🏫 <b>Barcha muallimlar ({len(teachers)} ta)</b>",
        reply_markup=kb.as_markup(),
        parse_mode="HTML"
    )


@router.callback_query(F.data.startswith("bq_teacher_"))
async def cb_teacher_detail(callback: types.CallbackQuery):
    teacher_id = int(callback.data.split("_")[-1])
    teacher = await User.get_or_none(id=teacher_id)
    if not teacher:
        await callback.answer("Topilmadi")
        return

    clubs = await Club.filter(teacher_id=teacher_id, is_active=True).all()
    today = datetime.now()
    month_start = today.replace(day=1)

    club_info = []
    for c in clubs:
        enrolled = await Enrollment.filter(club=c, status="active").count()
        att = await Attendance.filter(
            enrollment__club=c, date__gte=month_start.date()
        ).count()
        pres = await Attendance.filter(
            enrollment__club=c, date__gte=month_start.date(), status="present"
        ).count()
        pct = round(pres / att * 100) if att > 0 else 0
        club_info.append(f"  📚 {c.name}: {enrolled} bola, davomat {pct}%")

    kinder = None
    if teacher.kindergarten_id:
        kinder = await Kindergarten.get_or_none(id=teacher.kindergarten_id)

    text = (
        f"👩‍🏫 <b>{teacher.full_name}</b>\n"
        f"📞 {teacher.contact_phone or teacher.phone}\n"
        f"🏫 {kinder.number if kinder else '?'}-son bog'cha\n\n"
        f"To'garaklar:\n" + "\n".join(club_info if club_info else ["  Hali to'garak yo'q"])
    )

    kb = InlineKeyboardBuilder()
    if teacher.id:
        kb.button(text="📨 Xabar yuborish", callback_data=f"bq_msg_teacher_{teacher_id}")
    kb.button(text="⬅️ Orqaga", callback_data="bq_teachers_back")
    kb.adjust(1)

    await callback.message.edit_text(text, reply_markup=kb.as_markup(), parse_mode="HTML")
    await callback.answer()


# ─── MOLIYA ──────────────────────────────────────────────────
@router.message(F.text == "💰 Moliya")
async def cmd_moliya(message: types.Message):
    uid = message.from_user.id
    user = await User.get_or_none(id=uid)
    if not user or not is_boshliq(user):
        return

    today = datetime.now()
    month_str = today.strftime("%Y-%m")

    # Tushgan to'lovlar
    payments = await Payment.filter(month=month_str, status="completed").all()
    total_sum = sum(float(p.amount) for p in payments)

    # Kutilgan
    active_enrollments = await Enrollment.filter(status__in=["active", "blocked"]).prefetch_related("club").all()
    expected_sum = sum(float(e.club.price) for e in active_enrollments if e.club)

    # Qarzdorlar
    paid_ids = [p.enrollment_id for p in payments]
    debtors = [e for e in active_enrollments if e.id not in paid_ids]

    text = (
        f"💰 <b>Moliyaviy hisobot</b>\n"
        f"📅 {today.strftime('%B %Y')}\n\n"
        f"✅ Tushgan: <b>{total_sum:,.0f} so'm</b>\n"
        f"📊 Kutilgan: <b>{expected_sum:,.0f} so'm</b>\n"
        f"📉 Farq: <b>{expected_sum - total_sum:,.0f} so'm</b>\n\n"
        f"👥 Qarzdorlar: <b>{len(debtors)} ta</b>"
    )

    kb = InlineKeyboardBuilder()
    kb.button(text="📋 Qarzdorlar ro'yxati", callback_data="bq_debtors_list")
    kb.button(text="📣 Hammaga eslatma", callback_data="bq_remind_all")
    kb.adjust(1)

    await message.answer(text, reply_markup=kb.as_markup(), parse_mode="HTML")


@router.callback_query(F.data == "bq_debtors_list")
async def cb_debtors(callback: types.CallbackQuery):
    today = datetime.now()
    month_str = today.strftime("%Y-%m")
    paid_ids = await Payment.filter(
        month=month_str, status="completed"
    ).values_list("enrollment_id", flat=True)

    debtors = await Enrollment.filter(
        status__in=["active", "blocked"]
    ).exclude(id__in=list(paid_ids)).prefetch_related("child", "club").all()

    if not debtors:
        await callback.message.answer("✅ Qarzdorlar yo'q!")
        return

    lines = [f"📋 <b>Qarzdorlar ({len(debtors)} ta)</b>\n"]
    for e in debtors[:30]:
        child = await e.child
        club = await e.club
        lines.append(
            f"• {child.full_name} — {club.name if club else '?'} "
            f"({'🔒 bloklangan' if e.status == 'blocked' else '⚠️ qarz'})"
        )

    await callback.message.answer("\n".join(lines), parse_mode="HTML")
    await callback.answer()


@router.callback_query(F.data == "bq_remind_all")
async def cb_remind_all(callback: types.CallbackQuery):
    await callback.answer()  # Darhol javob — sekin loop dan oldin
    """Barcha qarzdorlarga eslatma"""
    today = datetime.now()
    month_str = today.strftime("%Y-%m")
    paid_ids = await Payment.filter(
        month=month_str, status="completed"
    ).values_list("enrollment_id", flat=True)

    debtors = await Enrollment.filter(
        status__in=["active", "blocked"]
    ).exclude(id__in=list(paid_ids)).prefetch_related("child", "club").all()

    sent = 0
    for e in debtors:
        child = await e.child
        parent = await child.parent
        club = await e.club
        if parent and parent.id:
            try:
                await callback.bot.send_message(
                    parent.id,
                    f"⚠️ <b>To'lov eslatmasi</b>\n\n"
                    f"👶 {child.full_name}\n"
                    f"📚 {club.name if club else ''}\n"
                    f"💰 To'lov ID: <b>{e.payment_id}</b>\n\n"
                    f"Iltimos, to'lovni amalga oshiring.",
                    parse_mode="HTML"
                )
                sent += 1
            except Exception:
                pass

    await callback.message.answer(f"✅ {sent} ta ota-onaga eslatma yuborildi.")


# ─── ANOMALIYALAR ────────────────────────────────────────────
@router.message(F.text == "⚠️ Anomaliyalar")
@router.callback_query(F.data == "boshliq_anomalies")
async def cmd_anomaliyalar(event):
    msg = event.message if hasattr(event, "message") else event
    uid = event.from_user.id
    user = await User.get_or_none(id=uid)
    if not user or not is_boshliq(user):
        return

    logs = await AILog.filter(
        log_type="anomaly", is_test=False
    ).order_by("-created_at").limit(10).all()

    if not logs:
        await msg.answer("✅ Anomaliyalar topilmadi.")
        return

    kb = InlineKeyboardBuilder()
    for log in logs:
        preview = (log.response or "")[:50]
        kb.button(
            text=f"⚠️ {log.created_at.strftime('%d.%m') if log.created_at else '?'} — {preview}...",
            callback_data=f"bq_anomaly_{log.id}"
        )
    kb.adjust(1)

    await msg.answer(
        f"⚠️ <b>Anomaliyalar ({len(logs)} ta)</b>",
        reply_markup=kb.as_markup(),
        parse_mode="HTML"
    )
    # event - Message, answer() text talab qiladi, shuning uchun o'tkazib yuboramiz


@router.callback_query(F.data.startswith("bq_anomaly_"))
async def cb_anomaly_detail(callback: types.CallbackQuery):
    log_id = int(callback.data.split("_")[-1])
    log = await AILog.get_or_none(id=log_id)
    if not log:
        await callback.answer("Topilmadi")
        return

    import json
    try:
        data = json.loads(log.response or "{}")
        daraja = data.get("daraja", "noma'lum")
        sabab = data.get("sabab", "")
        xulosa = data.get("xulosa", "")
        tavsiya = data.get("tavsiya", "")
    except Exception:
        daraja, sabab, xulosa, tavsiya = "?", log.response or "", "", ""

    icon = "🔴" if daraja == "kritik" else "🟡"
    text = (
        f"{icon} <b>Anomaliya ({daraja})</b>\n\n"
        f"📋 Sabab: {sabab}\n\n"
        f"📊 Xulosa: {xulosa}\n\n"
        f"💡 Tavsiya: {tavsiya}"
    )

    kb = InlineKeyboardBuilder()
    # AILog da kindergarten_id yo'q — log_type orqali tekshirish
    if log.log_type == "anomaly":
        kb.button(
            text="📨 Direktorganma savol",
            callback_data=f"bq_anomaly_ask_{log_id}"
        )
    kb.button(text="✅ Tekshirildi", callback_data=f"bq_anomaly_close_{log_id}")
    kb.button(text="⬅️ Orqaga", callback_data="boshliq_anomalies")
    kb.adjust(1)

    await callback.answer()
    try:
        await callback.message.edit_text(text, reply_markup=kb.as_markup(), parse_mode="HTML")
    except Exception:
        pass  # Matn o'zgarmagan


@router.callback_query(F.data.startswith("bq_anomaly_close_"))
async def cb_anomaly_close(callback: types.CallbackQuery):
    log_id = int(callback.data.split("_")[-1])
    log = await AILog.get_or_none(id=log_id)
    if log:
        log.reply_text = f"✅ MMTB Boshliq tekshirdi ({datetime.now().strftime('%d.%m.%Y')})"
        await log.save()
    await callback.message.edit_text("✅ Anomaliya yopildi.")
    await callback.answer()


# ─── BROADCAST ───────────────────────────────────────────────
@router.message(F.text == "📨 Broadcast")
async def cmd_broadcast(message: types.Message, state: FSMContext):
    uid = message.from_user.id
    user = await User.get_or_none(id=uid)
    if not user or not is_boshliq(user):
        return

    kb = InlineKeyboardBuilder()
    kb.button(text="🏫 Barcha direktorlar", callback_data="bq_bc_directors")
    kb.button(text="👩‍🏫 Barcha muallimlar", callback_data="bq_bc_teachers")
    kb.button(text="👨‍👩‍👧 Barcha ota-onalar", callback_data="bq_bc_parents")
    kb.button(text="🌐 Hamma", callback_data="bq_bc_all")
    kb.adjust(2)

    await message.answer(
        "📨 <b>Broadcast</b>\n\nKimga yubormoqchisiz?",
        reply_markup=kb.as_markup(),
        parse_mode="HTML"
    )


@router.callback_query(F.data.startswith("bq_bc_"))
async def cb_broadcast_target(callback: types.CallbackQuery, state: FSMContext):
    target_map = {
        "bq_bc_directors": ("director", "Barcha direktorlar"),
        "bq_bc_teachers": ("teacher", "Barcha muallimlar"),
        "bq_bc_parents": ("parent", "Barcha ota-onalar"),
        "bq_bc_all": ("all", "Hamma"),
    }
    role, label = target_map.get(callback.data, ("all", "Hamma"))
    await state.update_data(bc_role=role, bc_label=label)
    await state.set_state(BoshliqStates.broadcast_text)
    await callback.message.answer(
        f"✏️ <b>{label}</b> ga yuboriladigan xabarni yozing:",
        parse_mode="HTML"
    )
    await callback.answer()


@router.message(BoshliqStates.broadcast_text)
async def handle_broadcast_text(message: types.Message, state: FSMContext):
    data = await state.get_data()
    bc_role = data.get("bc_role", "all")
    bc_label = data.get("bc_label", "Hamma")
    director_id = data.get("target_director_id")

    await state.clear()

    # Maqsad foydalanuvchilarni aniqlash
    if director_id:
        users = await User.filter(id=director_id).all()
    elif bc_role == "all":
        users = await User.filter(is_test=False, is_blocked=False).all()
    else:
        users = await User.filter(role=bc_role, is_test=False, is_blocked=False).all()

    sent, failed = 0, 0
    for u in users:
        if not u.id:
            continue
        try:
            await message.bot.send_message(
                u.id,
                f"📣 <b>MMTB Boshliq xabari</b>\n\n{message.text}",
                parse_mode="HTML"
            )
            sent += 1
        except Exception:
            failed += 1

    await message.answer(
        f"✅ Yuborildi: {sent} ta\n❌ Xato: {failed} ta\n👥 {bc_label}"
    )


# ─── E'LON ───────────────────────────────────────────────────
@router.message(F.text == "📣 E'lon")
async def cmd_elon(message: types.Message, state: FSMContext):
    uid = message.from_user.id
    user = await User.get_or_none(id=uid)
    if not user or not is_boshliq(user):
        return

    await state.update_data(bc_role="all", bc_label="Hamma foydalanuvchilar")
    await state.set_state(BoshliqStates.broadcast_text)
    await message.answer(
        "📣 <b>E'lon matni</b>ni yozing:\n"
        "(Barcha foydalanuvchilarga yuboriladi)",
        parse_mode="HTML"
    )
