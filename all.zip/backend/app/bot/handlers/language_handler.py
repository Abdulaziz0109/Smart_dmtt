"""
SmartDMTT v4 — Til almashtirish handler (barcha rollar uchun)
/til, /language, /lang + callback lang_* 
"""
from aiogram import Router, F, types
from aiogram.filters import Command
from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton
from app.models.user import User
from app.bot.i18n import t, get_lang, lang_keyboard, SUPPORTED_LANGS

router = Router()

LANG_NAMES = {
    "uz":   "🇺🇿 O'zbek (lotin)",
    "kril": "🇺🇿 Ўзбек (кирил)",
    "ru":   "🇷🇺 Русский",
    "en":   "🇬🇧 English",
    "turk": "🇹🇷 Türkçe",
}

def _lang_kb(current: str) -> InlineKeyboardMarkup:
    rows = []
    items = list(LANG_NAMES.items())
    for i in range(0, len(items), 2):
        row = []
        for code, name in items[i:i+2]:
            label = ("✅ " if code == current else "") + name
            row.append(InlineKeyboardButton(text=label, callback_data=f"lang_{code}"))
        rows.append(row)
    return InlineKeyboardMarkup(inline_keyboard=rows)

@router.message(Command("til"))
@router.message(Command("language"))
@router.message(Command("lang"))
async def cmd_language(message: types.Message):
    user = await User.get_or_none(telegram_id=message.from_user.id)
    if not user:
        await message.answer("Avval ro'yxatdan o'ting."); return
    lang = get_lang(user)
    await message.answer(
        f"🌐 {t('choose_language', lang)}\nJoriy: {LANG_NAMES.get(lang, lang)}",
        reply_markup=_lang_kb(lang)
    )

@router.callback_query(F.data.startswith("lang_"))
async def cb_lang(callback: types.CallbackQuery):
    new_lang = callback.data.split("_", 1)[1]
    if new_lang not in SUPPORTED_LANGS:
        await callback.answer("Noma'lum til"); return

    user = await User.get_or_none(telegram_id=callback.from_user.id)
    if not user:
        await callback.answer("Foydalanuvchi topilmadi"); return

    user.language = new_lang
    await user.save()
    await callback.answer()

    lang_name = LANG_NAMES.get(new_lang, new_lang)
    await callback.message.edit_text(
        f"✅ {t('language_changed', new_lang)}\n🌐 {lang_name}",
        reply_markup=_lang_kb(new_lang)
    )
