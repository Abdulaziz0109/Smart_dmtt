import logging
from aiogram import Router, F, types
from aiogram.filters import Command
from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton
import json
import os

logger = logging.getLogger(__name__)
router = Router()

def get_kindergartens():
    try:
        file_path = "backend/data/kindergartens.json"
        if not os.path.exists(file_path):
             # Try absolute path or relative from cwd
             file_path = "data/kindergartens.json"
             if not os.path.exists(file_path):
                 file_path = "../data/kindergartens.json"
        
        if os.path.exists(file_path):
            with open(file_path, "r", encoding="utf-8") as f:
                data = json.load(f)
                return data.get("kindergartens", [])
        return []
    except Exception as e:
        logger.error(f"Error loading kindergartens: {e}")
        return []

@router.message(Command("location"))
@router.message(F.text.lower().contains("lokatsiya"))
@router.message(F.text.lower().contains("joylashuv"))
async def location_handler(message: types.Message):
    """
    Shows list of kindergartens or asks to select one.
    """
    kgs = get_kindergartens()
    
    if not kgs:
        await message.answer("Hozircha bog'chalar ro'yxati mavjud emas.")
        return

    # Create a simple keyboard with kindergarten names (pagination needed if too many)
    # For now, let's just list the first 10 or provide a search hint
    
    text = "📍 <b>Bog'chalar joylashuvi</b>\n\n"
    text += "Qaysi bog'cha kerak? Raqamini yozing (masalan: 5) yoki nomini kiriting:"
    
    await message.answer(text, parse_mode="HTML")

@router.message(F.text.regexp(r"(\d+)-bog'cha"))
@router.message(F.text.regexp(r"^(\d+)$"))
async def specific_location_handler(message: types.Message):
    """
    Handles specific kindergarten request like "5-bog'cha" or "5".
    """
    try:
        # Extract number
        import re
        match = re.search(r"(\d+)", message.text)
        if not match:
            return
            
        kg_id = int(match.group(1))
        kgs = get_kindergartens()
        
        found = None
        for k in kgs:
            # Match by ID or Name containing the number
            if k.get("id") == kg_id or f"{kg_id}-bog'cha" in k.get("name", ""):
                found = k
                break
        
        if found:
            lat = found.get("lat")
            lon = found.get("lon")
            
            if not lat or not lon:
                await message.answer(f"⚠️ <b>{found['name']}</b> uchun koordinatalar kiritilmagan.")
                return
                
            # Send location
            await message.answer_location(latitude=lat, longitude=lon)
            
            # Send Maps Links
            google_link = f"https://www.google.com/maps?q={lat},{lon}"
            yandex_link = f"https://yandex.uz/maps/?ll={lon},{lat}&z=17&mode=search&text={lat},{lon}"
            # Yandex Navigator Intent
            yandex_navi = f"yandexnavi://build_route_on_map?lat_to={lat}&lon_to={lon}"
            
            kb = InlineKeyboardMarkup(inline_keyboard=[
                [InlineKeyboardButton(text="🗺 Google Maps", url=google_link)],
                [InlineKeyboardButton(text="Ya Yandex Maps", url=yandex_link)],
                # [InlineKeyboardButton(text="🚙 Yandex Navigator", url=yandex_navi)] # Only works on mobile with app
            ])
            
            await message.answer(
                f"📍 <b>{found['name']}</b>\n"
                f"Google Maps va Yandex Maps orqali ochish:",
                reply_markup=kb,
                parse_mode="HTML"
            )
        else:
            await message.answer(f"❌ {kg_id}-raqamli bog'cha topilmadi.")
            
    except Exception as e:
        logger.error(f"Error in location handler: {e}")
        await message.answer("Xatolik yuz berdi.")
