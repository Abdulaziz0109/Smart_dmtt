"""
SmartDMTT v4.0 — /start to'liq oqimi
"""
import logging
import random
import string
from datetime import datetime

import bcrypt
from aiogram import Router, F, types
from aiogram.filters import Command
from aiogram.fsm.context import FSMContext
from aiogram.types import (
    KeyboardButton, ReplyKeyboardMarkup, ReplyKeyboardRemove,
    InlineKeyboardButton, InlineKeyboardMarkup, WebAppInfo
)

from app.core import config
from app.models.user import User
from app.models.kindergarten import Kindergarten
from app.models.child import Child
from app.bot.states.registration import RegistrationState, PasswordState

logger = logging.getLogger(__name__)
router = Router()


def _hash_password(password: str) -> str:
    return bcrypt.hashpw(password.encode(), bcrypt.gensalt()).decode()


def _generate_password(length: int = 8) -> str:
    chars = string.ascii_letters + string.digits
    return "".join(random.choices(chars, k=length))


def _normalize_phone(phone: str) -> str:
    p = phone.replace(" ", "").replace("-", "").replace("(", "").replace(")", "")
    if not p.startswith("+"):
        p = "+" + p
    return p


async def _show_main_menu(message: types.Message, user: User, bot):
    """Rolga qarab asosiy menyuni ko'rsatish + WebApp inline tugma."""
    from app.bot.handlers.menus import get_menu_keyboard, get_greeting
    role = user.role
    greeting = get_greeting(user.full_name or "Siz")
    kb = get_menu_keyboard(role)
    await message.answer(greeting, reply_markup=kb)

    # WebApp inline tugma — alohida xabar
    webapp_kb = InlineKeyboardMarkup(inline_keyboard=[[
        InlineKeyboardButton(
            text="📱 WebApp ni ochish",
            web_app=WebAppInfo(url=config.WEBAPP_URL)
        )
    ]])
    await message.answer("📱 WebApp:", reply_markup=webapp_kb)


# ─── /start ──────────────────────────────────────────────────────────────────

@router.message(Command("start"))
async def cmd_start(message: types.Message, state: FSMContext):
    await state.clear()
    tg_id = message.from_user.id

    user = await User.get_or_none(telegram_id=tg_id)
    if user:
        await _show_main_menu(message, user, message.bot)
        return

    kb = InlineKeyboardMarkup(inline_keyboard=[[
        InlineKeyboardButton(text="🤝 Tanishamiz", callback_data="start_agree")
    ]])
    await message.answer(
        f"👋 Assalomu alaykum!\n\n"
        f"Men <b>SmartDMTT</b> — Bulungur tumani maktabgacha ta'lim muassasalari "
        f"uchun raqamli boshqaruv tizimiman.\n\n"
        f"Davom etish uchun quyidagi tugmani bosing:",
        parse_mode="HTML",
        reply_markup=kb
    )


@router.callback_query(F.data == "start_agree")
async def start_agree(callback: types.CallbackQuery, state: FSMContext):
    await callback.message.edit_reply_markup(reply_markup=None)
    kb = InlineKeyboardMarkup(inline_keyboard=[[
        InlineKeyboardButton(text="✅ Roziman", callback_data="start_consent")
    ]])
    await callback.message.answer(
        "📋 <b>Foydalanish shartlari</b>\n\n"
        "Tizimdan foydalanish uchun siz quyidagilarga rozilik bildirasiz:\n"
        "• Telefon raqamingiz tizimda saqlanadi\n"
        "• Ma'lumotlaringiz faqat bog'cha boshqaruvi uchun ishlatiladi\n"
        "• Minimal shaxsiy ma'lumot saqlanadi\n\n"
        "Davom etishga rozimisiz?",
        parse_mode="HTML",
        reply_markup=kb
    )
    await state.set_state(RegistrationState.waiting_consent)


@router.callback_query(F.data == "start_consent", RegistrationState.waiting_consent)
async def start_consent(callback: types.CallbackQuery, state: FSMContext):
    await callback.message.edit_reply_markup(reply_markup=None)
    kb = ReplyKeyboardMarkup(
        keyboard=[[KeyboardButton(text="📱 Raqamni ulashish", request_contact=True)]],
        resize_keyboard=True,
        one_time_keyboard=True
    )
    await callback.message.answer("📱 Telefon raqamingizni ulashing:", reply_markup=kb)
    await state.set_state(RegistrationState.waiting_phone)


@router.message(RegistrationState.waiting_phone, F.contact)
async def handle_phone(message: types.Message, state: FSMContext):
    contact = message.contact
    phone = _normalize_phone(contact.phone_number)
    tg_id = message.from_user.id

    await message.answer("🔍 Tekshirilmoqda...", reply_markup=ReplyKeyboardRemove())

    user = await User.get_or_none(phone=phone)

    if user:
        user.telegram_id = tg_id
        if not user.full_name:
            user.full_name = message.from_user.full_name
        await user.save()
        await state.clear()
        await message.answer(
            f"✅ Xush kelibsiz, <b>{user.full_name}</b>!\nSizning hisobingiz topildi.",
            parse_mode="HTML"
        )
        await _show_main_menu(message, user, message.bot)
    else:
        await state.update_data(phone=phone, tg_id=tg_id)
        kb = ReplyKeyboardMarkup(
            keyboard=[
                [KeyboardButton(text="👨‍👩‍👧 Ota-ona")],
                [KeyboardButton(text="👤 Mehmon")]
            ],
            resize_keyboard=True
        )
        await message.answer(
            "Siz tizimda topilmadingiz.\nQaysi sifatida ro'yxatdan o'tmoqchisiz?",
            reply_markup=kb
        )
        await state.set_state(RegistrationState.choosing_role)


@router.message(RegistrationState.choosing_role, F.text == "👤 Mehmon")
async def choose_guest(message: types.Message, state: FSMContext):
    data = await state.get_data()
    tg_id = data.get("tg_id", message.from_user.id)
    phone = data.get("phone")
    user = await User.create(
        id=tg_id, telegram_id=tg_id,
        full_name=message.from_user.full_name,
        phone=phone, role="guest"
    )
    await state.clear()
    from app.bot.handlers.menus import get_menu_keyboard
    kb = get_menu_keyboard("guest")
    await message.answer(
        "👤 Mehmon sifatida kirdingiz.\nBog'chalar va to'garaklar haqida ma'lumot olishingiz mumkin.",
        reply_markup=kb
    )


@router.message(RegistrationState.choosing_role, F.text == "👨‍👩‍👧 Ota-ona")
async def choose_parent(message: types.Message, state: FSMContext):
    kb = ReplyKeyboardMarkup(
        keyboard=[
            [KeyboardButton(text="🏛 Davlat"), KeyboardButton(text="🏠 Xususiy")],
            [KeyboardButton(text="✏️ Boshqa")]
        ],
        resize_keyboard=True
    )
    await message.answer("Farzandingiz qayerda?", reply_markup=kb)
    await state.set_state(RegistrationState.choosing_place_type)


@router.message(RegistrationState.choosing_place_type)
async def choose_place(message: types.Message, state: FSMContext):
    choice = message.text
    if choice in ("🏛 Davlat", "🏠 Xususiy"):
        await state.update_data(place_type="official")
        await message.answer("Bog'cha raqamini kiriting (masalan: 12):", reply_markup=ReplyKeyboardRemove())
        await state.set_state(RegistrationState.entering_kindergarten_number)
    elif choice == "✏️ Boshqa":
        await state.update_data(place_type="other")
        await message.answer("Muassasa nomini yozing:", reply_markup=ReplyKeyboardRemove())
        await state.set_state(RegistrationState.entering_other_place)
    else:
        await message.answer("Iltimos, quyidagi tugmalardan birini tanlang.")


@router.message(RegistrationState.entering_kindergarten_number)
async def enter_kg_number(message: types.Message, state: FSMContext):
    text = message.text.strip()
    if not text.isdigit():
        await message.answer("Iltimos, faqat raqam kiriting.")
        return
    num = int(text)
    kg = await Kindergarten.get_or_none(number=num)
    if not kg:
        await message.answer(
            f"⚠️ {num}-son bog'cha tizimda topilmadi.\nBoshqa raqam kiriting yoki '✏️ Boshqa' opsiyasini tanlang."
        )
        return
    await state.update_data(kindergarten_id=kg.id, kindergarten_name=kg.name)
    await message.answer(f"✅ {kg.name}\n\nFarzandingizning to'liq ismini kiriting (ism familiya):")
    await state.set_state(RegistrationState.entering_child_name)


@router.message(RegistrationState.entering_other_place)
async def enter_other_place(message: types.Message, state: FSMContext):
    await state.update_data(other_place=message.text.strip(), kindergarten_id=None)
    await message.answer("Farzandingizning to'liq ismini kiriting (ism familiya):")
    await state.set_state(RegistrationState.entering_child_name)


@router.message(RegistrationState.entering_child_name)
async def enter_child_name(message: types.Message, state: FSMContext):
    name = message.text.strip()
    if len(name) < 3:
        await message.answer("Iltimos, to'liq ism familiya kiriting.")
        return
    await state.update_data(child_name=name)
    await message.answer("Farzandingizning tug'ilgan yilini kiriting (masalan: 2019):")
    await state.set_state(RegistrationState.entering_child_birth_year)


@router.message(RegistrationState.entering_child_birth_year)
async def enter_child_birth_year(message: types.Message, state: FSMContext):
    text = message.text.strip()
    current_year = datetime.now().year
    if not text.isdigit() or not (current_year - 15 <= int(text) <= current_year):
        await message.answer(f"Iltimos, to'g'ri yil kiriting ({current_year - 15}–{current_year}).")
        return
    birth_year = int(text)
    data = await state.get_data()
    password = _generate_password(8)
    tg_id = data.get("tg_id", message.from_user.id)
    phone = data.get("phone")

    user = await User.create(
        id=tg_id, telegram_id=tg_id,
        full_name=message.from_user.full_name,
        phone=phone, role="parent",
        kindergarten_id=data.get("kindergarten_id"),
        username=_hash_password(password)
    )
    child_data = {
        "parent_id": tg_id,
        "full_name": data.get("child_name"),
        "birth_year": birth_year,
        "kindergarten_id": data.get("kindergarten_id"),
    }
    if data.get("other_place"):
        child_data["other_place"] = data.get("other_place")
    await Child.create(**child_data)

    kb = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="🔄 Parolni almashtirish", callback_data="change_password")],
        [InlineKeyboardButton(text="📱 WebApp", web_app=WebAppInfo(url=config.WEBAPP_URL))]
    ])
    await message.answer(
        f"✅ <b>Muvaffaqiyatli ro'yxatdan o'tdingiz!</b>\n\n"
        f"👤 {user.full_name}\n"
        f"👶 Farzand: {data.get('child_name')}\n\n"
        f"🔐 <b>Sizning parolingiz:</b>\n"
        f"<code>{password}</code>\n\n"
        f"Iltimos, parolni xavfsiz joyda saqlang. WebApp ga kirish uchun kerak.",
        parse_mode="HTML",
        reply_markup=kb
    )
    await state.clear()

    from app.bot.handlers.menus import get_menu_keyboard
    await message.answer("Asosiy menyu:", reply_markup=get_menu_keyboard("parent"))
    logger.info(f"✅ Yangi ota-ona: {phone} (id={tg_id})")


@router.callback_query(F.data == "change_password")
async def ask_new_password(callback: types.CallbackQuery, state: FSMContext):
    await callback.answer()
    await callback.message.answer("Yangi parolni kiriting (kamida 6 belgi):", reply_markup=ReplyKeyboardRemove())
    await state.set_state(RegistrationState.choosing_new_password)


@router.message(RegistrationState.choosing_new_password)
async def save_new_password(message: types.Message, state: FSMContext):
    password = message.text.strip()
    if len(password) < 6:
        await message.answer("Parol kamida 6 belgidan iborat bo'lishi kerak.")
        return
    user = await User.get_or_none(telegram_id=message.from_user.id)
    if user:
        user.username = _hash_password(password)
        await user.save()
    await state.clear()
    await message.answer("✅ Parol muvaffaqiyatli o'zgartirildi!", reply_markup=ReplyKeyboardRemove())
    from app.bot.handlers.menus import get_menu_keyboard
    await message.answer("Asosiy menyu:", reply_markup=get_menu_keyboard(user.role if user else "guest"))


# ─── /parol ──────────────────────────────────────────────────────────────────

@router.message(Command("parol"))
async def cmd_parol(message: types.Message, state: FSMContext):
    user = await User.get_or_none(telegram_id=message.from_user.id)
    if not user:
        await message.answer("Avval /start buyrug'ini yuboring.")
        return
    await message.answer(
        "🔐 Yangi parolni kiriting (kamida 6 belgi):\n\nWebApp ga kirish uchun ushbu parol ishlatiladi.",
        reply_markup=ReplyKeyboardRemove()
    )
    await state.set_state(PasswordState.entering_new_password)


@router.message(PasswordState.entering_new_password)
async def save_parol(message: types.Message, state: FSMContext):
    password = message.text.strip()
    if len(password) < 6:
        await message.answer("Parol kamida 6 belgidan iborat bo'lishi kerak.")
        return
    user = await User.get_or_none(telegram_id=message.from_user.id)
    if user:
        user.username = _hash_password(password)
        await user.save()
        await message.answer("✅ Parol muvaffaqiyatli o'zgartirildi!")
    else:
        await message.answer("❌ Xatolik. Qayta /start yuboring.")
    await state.clear()
