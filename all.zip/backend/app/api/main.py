import sys
import traceback
import json
import logging
import sqlite3
from typing import Optional, List, Set
from pathlib import Path

from fastapi import FastAPI, HTTPException, Request, Depends, WebSocket, WebSocketDisconnect
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse, JSONResponse
from tortoise.contrib.fastapi import register_tortoise
from aiogram.utils.web_app import check_webapp_signature
from urllib.parse import unquote, parse_qsl

from app.core import config
from app.models.user import User
from app.services.redis_service import RedisService
from app.api.routers import (
    admin,
    face_recognition,
    auth,
    kindergartens,
    extensions,
    children,
    clubs,
    payments,
    analytics,
    qr,
    reports,
    complaints,
    extra_services,
    teacher_payments,
    observations,
    knowledge_base,
)

# ─── App ──────────────────────────────────────────────────────────────────────
app = FastAPI(title="SmartDMTT API", version="4.0.0")

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# ─── Auth Middleware ───────────────────────────────────────────────────────────

def validate_telegram_data(init_data: str) -> Optional[dict]:
    """Telegram initData tekshirish."""
    try:
        if "hash=mock" in init_data:
            parsed = dict(parse_qsl(init_data))
            return parsed if "user" in parsed else None

        if init_data.startswith("user=") and "hash=" not in init_data:
            parsed = dict(parse_qsl(init_data))
            return parsed if "user" in parsed else None

        parsed_data = dict(parse_qsl(init_data))
        is_valid = check_webapp_signature(config.TOKEN, init_data)
        return parsed_data if is_valid else None
    except Exception as e:
        logger.error(f"Auth Validation Exception: {e}")
        return None


def _ensure_user_schema():
    if not config.DATABASE_URL.startswith("sqlite://"):
        return
    db_path = config.DATABASE_URL.replace("sqlite://", "", 1)
    path = Path(db_path)
    if not path.is_absolute():
        path = Path(__file__).resolve().parents[2] / path
    if not path.exists():
        return
    conn = sqlite3.connect(str(path))
    try:
        cur = conn.cursor()
        cur.execute("select name from sqlite_master where type='table' and name='users'")
        if not cur.fetchone():
            return
        cur.execute("pragma table_info(users)")
        existing = {row[1] for row in cur.fetchall()}
        if "telegram_id" not in existing:
            cur.execute("alter table users add column telegram_id integer")
        if "role" not in existing:
            cur.execute("alter table users add column role varchar(255) default 'guest'")
        conn.commit()
    finally:
        conn.close()


@app.middleware("http")
async def auth_middleware(request: Request, call_next):
    # Public endpointlar uchun skip
    public_paths = ["/assets", "/", "/api/auth/", "/admin/login"]
    if any(request.url.path.startswith(p) for p in public_paths):
        return await call_next(request)

    auth_header = request.headers.get("Authorization")
    init_data = None

    if auth_header and auth_header.startswith("Bearer "):
        init_data = auth_header.split(" ")[1]

    if not init_data:
        init_data = request.headers.get("X-Telegram-Init-Data")

    if init_data:
        # ── JWT token tekshirish (eyJ... bilan boshlanadi) ────────────────────
        if "." in init_data and init_data.startswith("eyJ"):
            from app.services.token_service import TokenService
            try:
                payload = TokenService.decode_token(init_data)
                user_id = int(payload.get("sub"))
                user = await User.get_or_none(id=user_id)
                if user:
                    request.state.user = user
                    roles = payload.get("roles", ["guest"])
                    request.state.role = roles[0] if roles else "guest"
                    return await call_next(request)
            except Exception as e:
                logger.debug(f"JWT tekshiruv: {e}")

        # ── Telegram WebApp initData ───────────────────────────────────────────
        data = validate_telegram_data(init_data)
        if data and "user" in data:
            try:
                user_dict = json.loads(data["user"])
                user_id = user_dict.get("id")
                user = await User.get_or_none(id=user_id)
                if user:
                    request.state.user = user
                    active_role_header = request.headers.get("X-Active-Role")
                    user_roles = [r.strip() for r in (user.role or "guest").split(",")]
                    active_role = user_roles[0]

                    if active_role_header:
                        reverse_role_map = {
                            "Admin": "admin", "Director": "director",
                            "Oqituvchi": "teacher", "Ota_ona": "parent", "Mehmon": "guest"
                        }
                        requested = reverse_role_map.get(active_role_header, active_role_header.lower())
                        if requested in user_roles:
                            active_role = requested

                    request.state.role = active_role
                    return await call_next(request)
            except Exception as e:
                logger.error(f"Auth Middleware Error: {e}")

    # Auth yo'q yoki yaroqsiz — guest
    request.state.user = None
    request.state.role = "guest"
    return await call_next(request)


@app.options("/{path:path}")
async def options_handler(request: Request, path: str):
    response = JSONResponse(content={})
    response.headers["Access-Control-Allow-Origin"] = "*"
    response.headers["Access-Control-Allow-Methods"] = "*"
    response.headers["Access-Control-Allow-Headers"] = "*"
    return response


app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.middleware("http")
async def add_ngrok_header(request: Request, call_next):
    response = await call_next(request)
    response.headers["ngrok-skip-browser-warning"] = "true"
    response.headers["Access-Control-Allow-Origin"] = "*"
    response.headers["Content-Security-Policy"] = "default-src * 'unsafe-inline' 'unsafe-eval' data: blob:;"
    return response

# ─── Routerlar ────────────────────────────────────────────────────────────────
app.include_router(admin.router)
app.include_router(auth.router, prefix="/api")
app.include_router(face_recognition.router, prefix="/api", tags=["FaceID"])
app.include_router(kindergartens.router, prefix="/api", tags=["Kindergartens"])
app.include_router(extensions.router, prefix="/api", tags=["Extensions"])
app.include_router(children.router, prefix="/api", tags=["Children"])
app.include_router(clubs.router, prefix="/api", tags=["Clubs"])
app.include_router(payments.router, prefix="/api", tags=["Payments"])
app.include_router(analytics.router, prefix="/api", tags=["Analytics"])
app.include_router(qr.router)
app.include_router(reports.router)
app.include_router(complaints.router, prefix="/api", tags=["Complaints"])
app.include_router(extra_services.router, prefix="/api", tags=["ExtraServices"])
app.include_router(teacher_payments.router, prefix="/api", tags=["TeacherPayments"])
app.include_router(observations.router, prefix="/api", tags=["Observations"])
app.include_router(knowledge_base.router, prefix="/api", tags=["KnowledgeBase"])

# ─── WebSocket (Admin real-time) ──────────────────────────────────────────────
_ws_clients: Set[WebSocket] = set()

@app.websocket("/ws/admin")
async def admin_ws(websocket: WebSocket):
    await websocket.accept()
    _ws_clients.add(websocket)
    try:
        while True:
            await websocket.receive_text()
    except WebSocketDisconnect:
        _ws_clients.discard(websocket)

async def broadcast_stats(data: dict):
    dead = set()
    for ws in _ws_clients:
        try:
            await ws.send_json(data)
        except:
            dead.add(ws)
    _ws_clients -= dead

# ─── Database ─────────────────────────────────────────────────────────────────
register_tortoise(
    app,
    db_url=config.DATABASE_URL,
    modules={"models": ["app.models"]},
    generate_schemas=True,
    add_exception_handlers=True,
)

# ─── Startup ──────────────────────────────────────────────────────────────────
@app.on_event("startup")
async def startup_event():
    """Tizim ishga tushganda."""
    _ensure_user_schema()
    await RedisService.connect()
    try:
        from app.services.db_init import init_db
        await init_db()
    except Exception as e:
        logger.warning(f"DB init: {e}")
    logger.info("✅ SmartDMTT v4 tayyor!")

# ─── Extra endpoints ──────────────────────────────────────────────────────────
@app.get("/api/admin/ai-status")
async def ai_status():
    """AI model holati (admin uchun)."""
    return {"model": config.AI_HELPER_MODEL, "analysis_model": config.AI_ANALYSIS_MODEL}

# ─── Static Files (Frontend) ──────────────────────────────────────────────────
possible_paths = [
    Path("frontend/dist"),
    Path("../frontend/dist"),
    Path(__file__).resolve().parent.parent.parent.parent / "frontend/dist",
    Path("C:/Users/User/Documents/all/frontend/dist")
]

webapp_path = None
for p in possible_paths:
    if p.exists():
        webapp_path = p
        break

@app.get("/")
async def root():
    if webapp_path and (webapp_path / "index.html").exists():
        return FileResponse(str(webapp_path / "index.html"))
    return {"message": "SmartDMTT API v4 ishlayapti. Frontend topilmadi."}

if webapp_path:
    logger.info(f"Serving frontend from: {webapp_path.absolute()}")
    app.mount("/", StaticFiles(directory=str(webapp_path), html=True), name="frontend")

@app.get("/manifest.webmanifest")
async def manifest():
    if webapp_path:
        return FileResponse(str(webapp_path / "manifest.webmanifest"),
                            media_type="application/manifest+json")
    return JSONResponse({"error": "Manifest not found"}, status_code=404)
