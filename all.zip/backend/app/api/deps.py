"""
SmartDMTT v4 — app/api/deps.py
FastAPI dependency: get_current_user
JWT Bearer token → User object
"""
from fastapi import Request, HTTPException, Depends
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from app.models.user import User
from app.services.token_service import TokenService

security = HTTPBearer(auto_error=False)


async def get_current_user(
    request: Request,
    credentials: HTTPAuthorizationCredentials = Depends(security),
) -> User:
    """
    JWT token orqali joriy foydalanuvchini qaytaradi.
    auth_middleware request.state.user ni o'rnatgan bo'lsa — undan foydalanamiz.
    Aks holda Authorization header dan o'zimiz tekshiramiz.
    """
    # 1. Middleware allaqachon tekshirgan bo'lsa
    user = getattr(request.state, "user", None)
    if user and isinstance(user, User):
        return user

    # 2. Bearer token dan tekshirish
    token = None
    if credentials:
        token = credentials.credentials
    elif request.headers.get("Authorization", "").startswith("Bearer "):
        token = request.headers["Authorization"].split(" ", 1)[1]

    if not token:
        raise HTTPException(status_code=401, detail="Avtorizatsiya talab qilinadi")

    try:
        payload = TokenService.decode_token(token)
        user_id = int(payload.get("sub"))
    except (ValueError, TypeError) as e:
        raise HTTPException(status_code=401, detail=str(e))

    user = await User.get_or_none(id=user_id)
    if not user:
        raise HTTPException(status_code=401, detail="Foydalanuvchi topilmadi")
    if getattr(user, "is_blocked", False):
        raise HTTPException(status_code=403, detail="Hisob bloklangan")

    return user


async def get_current_user_optional(
    request: Request,
    credentials: HTTPAuthorizationCredentials = Depends(security),
) -> User | None:
    """Ixtiyoriy auth — token yo'q bo'lsa None qaytaradi"""
    try:
        return await get_current_user(request, credentials)
    except HTTPException:
        return None
