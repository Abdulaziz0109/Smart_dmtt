"""
SmartDMTT v4 — Barcha routerlar (backend/app/api/router.py yoki main.py ga qo'shiladi)

from app.api.main_router import api_router
app.include_router(api_router)
"""
from fastapi import APIRouter

from app.api.routers.auth        import router as auth_router
from app.api.routers.analytics   import router as analytics_router
from app.api.routers.admin       import router as admin_router
from app.api.routers.attendance  import router as attendance_router
from app.api.routers.clubs       import router as clubs_router
from app.api.routers.children    import router as children_router
from app.api.routers.payments    import router as payments_router
from app.api.routers.kindergartens import router as kg_router
from app.api.routers.users       import router as users_router

api_router = APIRouter(prefix="/api")

api_router.include_router(auth_router)
api_router.include_router(users_router)
api_router.include_router(analytics_router)
api_router.include_router(admin_router)
api_router.include_router(attendance_router)
api_router.include_router(clubs_router)
api_router.include_router(children_router)
api_router.include_router(payments_router)
api_router.include_router(kg_router)
