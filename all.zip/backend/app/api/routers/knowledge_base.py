"""
SmartDMTT v4 — Bilimlar bazasi API Router
Faqat admin va boshliq ko'radi.
"""
import logging
import uuid
from typing import Optional

from fastapi import APIRouter, HTTPException, Depends
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from pydantic import BaseModel

from app.models.user import User
from app.models.knowledge_base_entry import KnowledgeBaseEntry
from app.services.token_service import TokenService

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/kb", tags=["knowledge_base"])
security = HTTPBearer(auto_error=False)


async def _get_current_user(
    credentials: HTTPAuthorizationCredentials = Depends(security)
) -> User:
    if not credentials:
        raise HTTPException(401, "Avtorizatsiya talab etiladi")
    try:
        payload = TokenService.decode_token(credentials.credentials)
        user = await User.get_or_none(id=int(payload["sub"]))
        if not user:
            raise HTTPException(401, "Foydalanuvchi topilmadi")
        return user
    except ValueError as e:
        raise HTTPException(401, str(e))


def _require_admin(user: User):
    if user.role not in ("admin", "boshliq"):
        raise HTTPException(403, "Faqat admin va boshliq ko'ra oladi")


class KBCreate(BaseModel):
    question_en: str
    answer_en: str
    keywords_json: dict = {}
    lang: str = "uz_latin"


class KBUpdate(BaseModel):
    question_en: Optional[str] = None
    answer_en: Optional[str] = None
    keywords_json: Optional[dict] = None
    status: Optional[str] = None   # active | pending | rejected
    lang: Optional[str] = None


@router.get("/entries")
async def list_entries(
    status: Optional[str] = None,
    lang: Optional[str] = None,
    source: Optional[str] = None,
    search: Optional[str] = None,
    page: int = 1,
    limit: int = 20,
    user: User = Depends(_get_current_user)
):
    """Bilimlar bazasi yozuvlari."""
    _require_admin(user)
    qs = KnowledgeBaseEntry.all()
    if status:
        qs = qs.filter(status=status)
    if lang:
        qs = qs.filter(lang=lang)
    if source:
        qs = qs.filter(source=source)
    if search:
        qs = qs.filter(question_en__icontains=search)

    total = await qs.count()
    items = await qs.order_by("-created_at").offset((page - 1) * limit).limit(limit).all()
    return {
        "total": total,
        "page": page,
        "entries": [
            {
                "id": e.id,
                "entry_id": e.entry_id,
                "question_en": e.question_en,
                "answer_en": e.answer_en,
                "keywords_json": e.keywords_json,
                "source": e.source,
                "status": e.status,
                "use_count": e.use_count,
                "lang": e.lang,
                "created_at": e.created_at.isoformat() if e.created_at else None,
            }
            for e in items
        ],
    }


@router.get("/entries/{entry_id}")
async def get_entry(entry_id: int, user: User = Depends(_get_current_user)):
    _require_admin(user)
    entry = await KnowledgeBaseEntry.get_or_none(id=entry_id)
    if not entry:
        raise HTTPException(404, "Topilmadi")
    return {
        "id": entry.id,
        "entry_id": entry.entry_id,
        "question_en": entry.question_en,
        "answer_en": entry.answer_en,
        "keywords_json": entry.keywords_json,
        "source": entry.source,
        "status": entry.status,
        "use_count": entry.use_count,
        "lang": entry.lang,
    }


@router.post("/entries")
async def create_entry(data: KBCreate, user: User = Depends(_get_current_user)):
    """Qo'lda yangi yozuv qo'shish."""
    _require_admin(user)
    entry = await KnowledgeBaseEntry.create(
        entry_id=str(uuid.uuid4())[:8],
        question_en=data.question_en,
        answer_en=data.answer_en,
        keywords_json=data.keywords_json,
        source="manual",
        status="active",
        lang=data.lang,
    )
    return {"id": entry.id, "entry_id": entry.entry_id}


@router.patch("/entries/{entry_id}")
async def update_entry(
    entry_id: int,
    data: KBUpdate,
    user: User = Depends(_get_current_user)
):
    """Yozuvni tahrirlash yoki holatini o'zgartirish."""
    _require_admin(user)
    entry = await KnowledgeBaseEntry.get_or_none(id=entry_id)
    if not entry:
        raise HTTPException(404, "Topilmadi")

    if data.question_en is not None:
        entry.question_en = data.question_en
    if data.answer_en is not None:
        entry.answer_en = data.answer_en
    if data.keywords_json is not None:
        entry.keywords_json = data.keywords_json
    if data.status is not None:
        valid_statuses = ("active", "pending", "rejected")
        if data.status not in valid_statuses:
            raise HTTPException(400, f"status: {valid_statuses}")
        entry.status = data.status
    if data.lang is not None:
        entry.lang = data.lang

    await entry.save()
    return {"ok": True}


@router.delete("/entries/{entry_id}")
async def delete_entry(entry_id: int, user: User = Depends(_get_current_user)):
    """Yozuvni o'chirish."""
    _require_admin(user)
    entry = await KnowledgeBaseEntry.get_or_none(id=entry_id)
    if not entry:
        raise HTTPException(404, "Topilmadi")
    await entry.delete()
    return {"ok": True}


@router.get("/stats")
async def kb_stats(user: User = Depends(_get_current_user)):
    """Statistika: jami, aktiv, kutmoqda, rad etilgan."""
    _require_admin(user)
    total   = await KnowledgeBaseEntry.all().count()
    active  = await KnowledgeBaseEntry.filter(status="active").count()
    pending = await KnowledgeBaseEntry.filter(status="pending").count()
    rejected= await KnowledgeBaseEntry.filter(status="rejected").count()
    return {"total": total, "active": active, "pending": pending, "rejected": rejected}
