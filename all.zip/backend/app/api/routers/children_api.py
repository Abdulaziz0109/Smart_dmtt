"""
SmartDMTT v4 — Children router
/children/mine — ota-ona o'z farzandlari
/children/{id} — batafsil
"""
from fastapi import APIRouter, Depends, HTTPException, Query
from app.api.deps import get_current_user
from app.models.user import User
from app.models.child import Child
from app.models.club import Club, Enrollment
from app.models.payment import Payment
from datetime import date

router = APIRouter(prefix="/children", tags=["children"])


@router.get("/mine")
async def my_children(current_user: User = Depends(get_current_user)):
    children = await Child.filter(parent_id=current_user.id).order_by("full_name").all()
    return [
        {
            "id":         c.id,
            "full_name":  c.full_name,
            "birth_year": c.birth_year,
            "kindergarten_id": c.kindergarten_id,
        }
        for c in children
    ]


@router.get("/{child_id}")
async def get_child(child_id: int, current_user: User = Depends(get_current_user)):
    child = await Child.get_or_none(id=child_id)
    if not child:
        raise HTTPException(404, "Bola topilmadi")
    if current_user.role == "parent" and child.parent_id != current_user.id:
        raise HTTPException(403, "Ruxsat yo'q")

    month_str   = date.today().strftime("%Y-%m")
    enrollments = await Enrollment.filter(child_id=child_id, status="active").all()
    clubs_info  = []
    for enr in enrollments:
        club = await Club.get_or_none(id=enr.club_id)
        paid = await Payment.filter(
            enrollment_id=enr.id, month=month_str, status="completed"
        ).exists()
        clubs_info.append({
            "enrollment_id": enr.id,
            "club_id":       enr.club_id,
            "club_name":     club.name if club else "—",
            "payment_id":    enr.payment_id,
            "is_paid":       paid,
            "price":         float(club.price) if club else 0,
        })

    return {
        "id":           child.id,
        "full_name":    child.full_name,
        "birth_year":   child.birth_year,
        "kindergarten_id": child.kindergarten_id,
        "parent_id":    child.parent_id,
        "enrollments":  clubs_info,
    }
