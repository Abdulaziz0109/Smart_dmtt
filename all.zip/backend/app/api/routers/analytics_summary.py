"""
SmartDMTT v4 — Analytics /summary endpoint to'liq versiya
teacher/togarak_rahbari uchun club_* maydonlar qo'shildi
"""
from datetime import date
from fastapi import APIRouter, Depends
from app.api.deps import get_current_user
from app.models.user import User
from app.models.child import Child
from app.models.club import Club, Enrollment
from app.models.payment import Payment
from app.models.attendance import Attendance
from app.models.kindergarten import Kindergarten

router = APIRouter(prefix="/analytics", tags=["analytics"])


@router.get("/summary")
async def summary(current_user: User = Depends(get_current_user)):
    role  = (current_user.role or "guest").lower()
    today = date.today()
    month_str = today.strftime("%Y-%m")

    # ── Muallim / To'garak rahbari ────────────────────────
    if role in ("teacher", "togarak_rahbari"):
        club_id = current_user.club_id
        if not club_id:
            clubs = await Club.filter(teacher_id=current_user.id).all()
            club_id = clubs[0].id if clubs else None

        if not club_id:
            return {"total_children":0,"total_clubs":0,"attendance_today":0,"debtors":0}

        enr_ids = await Enrollment.filter(club_id=club_id, status="active").values_list("id", flat=True)
        total   = len(enr_ids)
        present = await Attendance.filter(enrollment_id__in=list(enr_ids), date=today, status="present").count() if enr_ids else 0
        paid    = await Payment.filter(enrollment_id__in=list(enr_ids), month=month_str, status="completed").count() if enr_ids else 0
        return {
            "club_children":   total,
            "club_attendance": round(present/total*100) if total else 0,
            "club_paid":       paid,
            "club_debt":       total - paid,
            "total_children":  total,
            "total_clubs":     1,
            "attendance_today": round(present/total*100) if total else 0,
            "debtors":         total - paid,
        }

    # ── Ota-ona ───────────────────────────────────────────
    if role == "parent":
        children = await Child.filter(parent_id=current_user.id).all()
        ch_ids   = [c.id for c in children]
        enr_ids  = await Enrollment.filter(child_id__in=ch_ids, status="active").values_list("id", flat=True) if ch_ids else []
        paid_cnt = await Payment.filter(enrollment_id__in=list(enr_ids), month=month_str, status="completed").count() if enr_ids else 0

        att_today = 0
        if enr_ids:
            present = await Attendance.filter(enrollment_id__in=list(enr_ids), date=today, status="present").count()
            att_today = round(present/len(enr_ids)*100)

        debt_amt = 0
        for enr_id in enr_ids:
            enr  = await Enrollment.get_or_none(id=enr_id)
            paid = await Payment.filter(enrollment_id=enr_id, month=month_str, status="completed").exists()
            if not paid and enr:
                club = await Club.get_or_none(id=enr.club_id)
                if club: debt_amt += float(club.price or 0)

        return {
            "children_count":  len(children),
            "attendance_today": att_today,
            "paid_clubs":      paid_cnt,
            "debt_amount":     debt_amt,
            "total_children":  len(children),
            "total_clubs":     len(enr_ids),
        }

    # ── Iqtisodchi ────────────────────────────────────────
    if role == "iqtisodchi":
        kg_id    = current_user.kindergarten_id
        ch_ids   = await Child.filter(kindergarten_id=kg_id).values_list("id", flat=True) if kg_id else []
        enr_ids  = await Enrollment.filter(child_id__in=list(ch_ids), status="active").values_list("id", flat=True) if ch_ids else []
        payments = await Payment.filter(enrollment_id__in=list(enr_ids), month=month_str, status="completed").all() if enr_ids else []
        revenue  = sum(float(p.amount or 0) for p in payments)
        paid_cnt = len(payments)
        debt_cnt = len(enr_ids) - paid_cnt
        pay_pct  = round(paid_cnt/len(enr_ids)*100) if enr_ids else 0
        return {
            "monthly_revenue":    revenue,
            "paid_count":         paid_cnt,
            "debtors":            debt_cnt,
            "payment_pct":        pay_pct,
            "active_enrollments": len(enr_ids),
            "total_children":     len(ch_ids),
        }

    # ── Admin / Boshliq / MMTB / Direktor ────────────────
    kg_id = current_user.kindergarten_id

    if role == "director" and kg_id:
        ch_ids   = await Child.filter(kindergarten_id=kg_id).values_list("id", flat=True)
        enr_ids  = await Enrollment.filter(child_id__in=list(ch_ids), status="active").values_list("id", flat=True) if ch_ids else []
        total_ch = len(ch_ids)
        present  = await Attendance.filter(enrollment_id__in=list(enr_ids), date=today, status="present").count() if enr_ids else 0
        total_e  = len(enr_ids)
        paid_cnt = await Payment.filter(enrollment_id__in=list(enr_ids), month=month_str, status="completed").count() if enr_ids else 0
        clubs    = await Club.filter(kindergarten_id=kg_id).count()
        return {
            "total_children":    total_ch,
            "total_clubs":       clubs,
            "attendance_today":  round(present/total_e*100) if total_e else 0,
            "debtors":           total_e - paid_cnt,
            "active_enrollments":total_e,
        }

    # Admin / Boshliq: tuman bo'yicha
    all_enr_ids = await Enrollment.filter(status="active").values_list("id", flat=True)
    total_e     = len(all_enr_ids)
    total_ch    = await Child.all().count()
    total_clubs = await Club.all().count()
    total_kg    = await Kindergarten.all().count()
    total_users = await User.filter(is_blocked=False).count()

    present     = await Attendance.filter(enrollment_id__in=list(all_enr_ids), date=today, status="present").count() if all_enr_ids else 0
    paid_cnt    = await Payment.filter(enrollment_id__in=list(all_enr_ids), month=month_str, status="completed").count() if all_enr_ids else 0
    payments    = await Payment.filter(enrollment_id__in=list(all_enr_ids), month=month_str, status="completed").all() if all_enr_ids else []
    revenue     = sum(float(p.amount or 0) for p in payments)

    # Bog'chalar ro'yxati
    kgs = await Kindergarten.all()
    kg_list = []
    for kg in kgs:
        kg_ch_ids = await Child.filter(kindergarten_id=kg.id).values_list("id", flat=True)
        kg_enr_ids = await Enrollment.filter(child_id__in=list(kg_ch_ids), status="active").values_list("id", flat=True) if kg_ch_ids else []
        kg_pres = await Attendance.filter(enrollment_id__in=list(kg_enr_ids), date=today, status="present").count() if kg_enr_ids else 0
        kg_total = len(kg_enr_ids)
        kg_list.append({
            "id": kg.id, "name": kg.name,
            "children_count": len(kg_ch_ids),
            "attendance_pct": round(kg_pres/kg_total*100) if kg_total else 0,
        })

    return {
        "total_children":     total_ch,
        "total_clubs":        total_clubs,
        "total_kindergartens":total_kg,
        "total_users":        total_users,
        "attendance_today":   round(present/total_e*100) if total_e else 0,
        "debtors":            total_e - paid_cnt,
        "paid_count":         paid_cnt,
        "monthly_revenue":    revenue,
        "active_enrollments": total_e,
        "kindergartens":      kg_list,
    }


@router.get("/anomalies")
async def anomalies(
    limit: int = 20,
    current_user: User = Depends(get_current_user),
):
    """Anomaliyalar: 3+ kun kelmaganlar, kutilmagan to'lov kamayishi"""
    from datetime import timedelta
    role = (current_user.role or "").lower()
    if role not in ("admin","boshliq","mmtb_boshligi","director"):
        return []

    today      = date.today()
    week_start = today - timedelta(days=4)
    result     = []

    enr_q = Enrollment.filter(status="active")
    if role == "director" and current_user.kindergarten_id:
        ch_ids = await Child.filter(kindergarten_id=current_user.kindergarten_id).values_list("id", flat=True)
        enr_q  = enr_q.filter(child_id__in=list(ch_ids))

    enrollments = await enr_q.all()
    for enr in enrollments[:200]:  # performance limit
        records    = await Attendance.filter(enrollment_id=enr.id, date__gte=week_start).all()
        absent_cnt = sum(1 for r in records if r.status == "absent")
        if absent_cnt >= 3:
            child = await Child.get_or_none(id=enr.child_id)
            club  = await Club.get_or_none(id=enr.club_id)
            kg    = await Kindergarten.get_or_none(id=child.kindergarten_id) if child else None
            result.append({
                "title":             f"{child.full_name if child else '—'} — {absent_cnt} kun kelmagan",
                "description":       f"To'garak: {club.name if club else '—'}",
                "severity":          "high" if absent_cnt >= 4 else "medium",
                "kindergarten_name": kg.name if kg else "—",
                "created_at":        str(today),
            })
        if len(result) >= limit:
            break

    return result
