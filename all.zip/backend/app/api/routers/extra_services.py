"""
SmartDMTT v4 — Qo'shimcha xizmatlar API Router
"""
import logging
from datetime import datetime, date
from typing import Optional

from fastapi import APIRouter, HTTPException, Depends
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from pydantic import BaseModel

from app.models.user import User
from app.models.child import Child
from app.models.extra_service import ExtraService
from app.services.token_service import TokenService

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/extra-services", tags=["extra_services"])
security = HTTPBearer(auto_error=False)


async def _get_current_user(
    credentials: HTTPAuthorizationCredentials = Depends(security)
) -> User:
    if not credentials:
        raise HTTPException(401, "Avtorizatsiya talab etiladi")
    try:
        payload = TokenService.decode_token(credentials.credentials)
        user = await User.get_or_none(id=int(payload["sub"]))
        if not user:
            raise HTTPException(401, "Foydalanuvchi topilmadi")
        return user
    except ValueError as e:
        raise HTTPException(401, str(e))


class ExtraServiceCreate(BaseModel):
    child_id: int
    service_type: str        # late_pickup | early_dropoff | individual | transport | lunch
    service_date: str        # "2025-03-15"
    start_time: Optional[str] = None   # "17:30"
    end_time: Optional[str] = None     # "18:00"
    duration_minutes: Optional[int] = None
    amount: float = 0


SERVICE_TYPES = ("late_pickup", "early_dropoff", "individual", "transport", "lunch")


@router.post("")
async def create_extra_service(
    data: ExtraServiceCreate,
    user: User = Depends(_get_current_user)
):
    """Qo'shimcha xizmat so'rash."""
    if data.service_type not in SERVICE_TYPES:
        raise HTTPException(400, f"service_type: {SERVICE_TYPES}")

    child = await Child.get_or_none(id=data.child_id)
    if not child:
        raise HTTPException(404, "Bola topilmadi")
    if user.role == "parent" and child.parent_id != user.id:
        raise HTTPException(403, "Bu bola sizniki emas")

    try:
        svc_date = date.fromisoformat(data.service_date)
    except ValueError:
        raise HTTPException(400, "service_date formati: YYYY-MM-DD")

    service = await ExtraService.create(
        child=child,
        service_type=data.service_type,
        date=svc_date,
        start_time=data.start_time,
        end_time=data.end_time,
        duration_minutes=data.duration_minutes,
        amount=data.amount,
        status="pending",
    )
    return {"id": service.id, "status": service.status}


@router.get("")
async def list_extra_services(
    child_id: Optional[int] = None,
    status: Optional[str] = None,
    user: User = Depends(_get_current_user)
):
    """Qo'shimcha xizmatlar ro'yxati."""
    if user.role in ("admin", "director", "boshliq"):
        qs = ExtraService.all()
    elif user.role == "parent":
        children = await Child.filter(parent_id=user.id).all()
        ids = [c.id for c in children]
        qs = ExtraService.filter(child_id__in=ids)
    else:
        qs = ExtraService.all()

    if child_id:
        qs = qs.filter(child_id=child_id)
    if status:
        qs = qs.filter(status=status)

    items = await qs.order_by("-created_at").all()
    return {
        "services": [
            {
                "id": s.id,
                "child_id": s.child_id,
                "service_type": s.service_type,
                "date": s.date.isoformat() if s.date else None,
                "start_time": s.start_time,
                "end_time": s.end_time,
                "duration_minutes": s.duration_minutes,
                "amount": float(s.amount),
                "status": s.status,
                "confirmed_at": s.confirmed_at.isoformat() if s.confirmed_at else None,
            }
            for s in items
        ]
    }


@router.patch("/{service_id}/confirm")
async def confirm_service(service_id: int, user: User = Depends(_get_current_user)):
    """Xizmatni tasdiqlash (direktor/admin)."""
    if user.role not in ("admin", "director", "boshliq"):
        raise HTTPException(403, "Ruxsat yo'q")
    service = await ExtraService.get_or_none(id=service_id)
    if not service:
        raise HTTPException(404, "Topilmadi")
    service.status = "confirmed"
    service.confirmed_at = datetime.utcnow()
    await service.save()
    return {"ok": True}


@router.patch("/{service_id}/cancel")
async def cancel_service(service_id: int, user: User = Depends(_get_current_user)):
    """Xizmatni bekor qilish."""
    service = await ExtraService.get_or_none(id=service_id)
    if not service:
        raise HTTPException(404, "Topilmadi")
    if user.role == "parent":
        child = await Child.get_or_none(id=service.child_id)
        if not child or child.parent_id != user.id:
            raise HTTPException(403, "Ruxsat yo'q")
    service.status = "cancelled"
    await service.save()
    return {"ok": True}
