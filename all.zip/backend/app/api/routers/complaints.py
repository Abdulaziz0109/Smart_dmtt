"""
SmartDMTT v4 — Shikoyat, taklif, maqtov API Router
"""
import logging
from datetime import datetime
from typing import Optional

from fastapi import APIRouter, HTTPException, Depends
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from pydantic import BaseModel

from app.models.user import User
from app.models.complaint import Complaint
from app.services.token_service import TokenService

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/complaints", tags=["complaints"])
security = HTTPBearer(auto_error=False)


async def _get_current_user(
    credentials: HTTPAuthorizationCredentials = Depends(security)
) -> User:
    if not credentials:
        raise HTTPException(401, "Avtorizatsiya talab etiladi")
    try:
        payload = TokenService.decode_token(credentials.credentials)
        user = await User.get_or_none(id=int(payload["sub"]))
        if not user:
            raise HTTPException(401, "Foydalanuvchi topilmadi")
        return user
    except ValueError as e:
        raise HTTPException(401, str(e))


class ComplaintCreate(BaseModel):
    complaint_type: str        # complaint | suggestion | praise
    target_type: str           # teacher | club | kindergarten | system
    target_id: Optional[int] = None
    text: str
    is_anonymous: bool = True


class ComplaintResponse(BaseModel):
    response: str


@router.post("")
async def create_complaint(data: ComplaintCreate, user: User = Depends(_get_current_user)):
    """Shikoyat / taklif / maqtov yuborish."""
    valid_types = ("complaint", "suggestion", "praise")
    valid_targets = ("teacher", "club", "kindergarten", "system")
    if data.complaint_type not in valid_types:
        raise HTTPException(400, f"complaint_type: {valid_types}")
    if data.target_type not in valid_targets:
        raise HTTPException(400, f"target_type: {valid_targets}")

    complaint = await Complaint.create(
        user=user,
        complaint_type=data.complaint_type,
        target_type=data.target_type,
        target_id=data.target_id,
        text=data.text,
        is_anonymous=data.is_anonymous,
        status="new",
    )
    return {"id": complaint.id, "status": complaint.status}


@router.get("")
async def list_complaints(
    status: Optional[str] = None,
    user: User = Depends(_get_current_user)
):
    """Shikoyatlar ro'yxati (admin/direktor/boshliq — barchasi; ota-ona — o'ziniki)."""
    if user.role in ("admin", "director", "boshliq"):
        qs = Complaint.all()
        if status:
            qs = qs.filter(status=status)
    else:
        qs = Complaint.filter(user=user)

    items = await qs.order_by("-created_at").all()
    return {
        "complaints": [
            {
                "id": c.id,
                "complaint_type": c.complaint_type,
                "target_type": c.target_type,
                "target_id": c.target_id,
                "text": c.text if not c.is_anonymous or user.role in ("admin", "director", "boshliq") else "***",
                "is_anonymous": c.is_anonymous,
                "status": c.status,
                "response": c.response,
                "created_at": c.created_at.isoformat() if c.created_at else None,
            }
            for c in items
        ]
    }


@router.patch("/{complaint_id}/respond")
async def respond_complaint(
    complaint_id: int,
    data: ComplaintResponse,
    user: User = Depends(_get_current_user)
):
    """Shikoyatga javob berish (direktor, boshliq, admin)."""
    if user.role not in ("admin", "director", "boshliq"):
        raise HTTPException(403, "Ruxsat yo'q")
    complaint = await Complaint.get_or_none(id=complaint_id)
    if not complaint:
        raise HTTPException(404, "Shikoyat topilmadi")

    complaint.response = data.response
    complaint.responded_by_id = user.id
    complaint.responded_at = datetime.utcnow()
    complaint.status = "resolved"
    await complaint.save()
    return {"ok": True}


@router.patch("/{complaint_id}/status")
async def update_status(
    complaint_id: int,
    status: str,
    user: User = Depends(_get_current_user)
):
    """Holat yangilash (admin/boshliq)."""
    if user.role not in ("admin", "boshliq"):
        raise HTTPException(403, "Ruxsat yo'q")
    valid = ("new", "in_progress", "resolved", "rejected")
    if status not in valid:
        raise HTTPException(400, f"status: {valid}")
    complaint = await Complaint.get_or_none(id=complaint_id)
    if not complaint:
        raise HTTPException(404, "Topilmadi")
    complaint.status = status
    await complaint.save()
    return {"ok": True}
