"""
SmartDMTT v4.0 — To'lovlar API Router
Click / Paynet / Payme webhook endpointlari.

IDEMPOTENCY:
  - Click: click_trans_id unikal kalit sifatida ishlatiladi
  - Paynet: performTransaction id unikal kalit
  - Bir xil transaction ikki marta kelsa → birinchisini qaytaradi, qayta yozilmaydi
"""
import hashlib
import logging
from datetime import date, datetime
from typing import Optional

from fastapi import APIRouter, HTTPException, Request, Depends
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from pydantic import BaseModel

from app.core import config
from app.models.child import Child
from app.models.club import Enrollment, Club
from app.models.payment import Payment
from app.models.user import User
from app.services.token_service import TokenService

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/payments", tags=["payments"])
security = HTTPBearer(auto_error=False)


# ─── Auth dependency ──────────────────────────────────────────────────────────

async def _get_current_user(
    credentials: HTTPAuthorizationCredentials = Depends(security)
) -> User:
    if not credentials:
        raise HTTPException(401, "Avtorizatsiya talab etiladi")
    try:
        payload = TokenService.decode_token(credentials.credentials)
        user_id = int(payload["sub"])
        user = await User.get_or_none(id=user_id)
        if not user:
            raise HTTPException(401, "Foydalanuvchi topilmadi")
        return user
    except ValueError as e:
        raise HTTPException(401, str(e))


# ─── Pydantic ─────────────────────────────────────────────────────────────────

class ClickPrepareRequest(BaseModel):
    click_trans_id: int
    service_id: int
    click_paydoc_id: int
    merchant_trans_id: str         # payment_id (6-raqam)
    amount: float
    action: int
    sign_time: str
    sign_string: str


class ClickCompleteRequest(BaseModel):
    click_trans_id: int
    service_id: int
    click_paydoc_id: int
    merchant_trans_id: str
    merchant_prepare_id: int
    amount: float
    action: int
    error: int
    error_note: str
    sign_time: str
    sign_string: str


class PaynetCheckRequest(BaseModel):
    id: int
    method: str
    params: dict


# ─── Idempotency yordamchi ────────────────────────────────────────────────────

async def _find_payment_by_transaction(transaction_id: str) -> Optional[Payment]:
    """
    Bir xil transaction_id bilan to'lov allaqachon qayd etilganmi?
    Ha bo'lsa → qayta yozmasdan shu yozuvni qaytaramiz.
    """
    return await Payment.get_or_none(transaction_id=transaction_id)


# ─── To'lov tarixi ────────────────────────────────────────────────────────────

@router.get("/history")
async def payment_history(
    current_user: User = Depends(_get_current_user),
    kindergarten_id: int = None,
    month: str = None
):
    """
    To'lov tarixi.
    - Ota-ona: o'z farzandlari
    - Admin/Iqtisodchi: barcha to'lovlar (filtrlash imkoniyati bilan)
    """
    user_role = current_user.role.split(",")[0].strip().lower()
    is_staff = user_role in ["admin", "iqtisodchi", "boshliq", "mmtb_boshligi"]

    if is_staff:
        # --- Staff Logic ---
        query = Payment.all()
        if month:
            query = query.filter(month=month)
        
        # Kindergarten filter
        if kindergarten_id:
             clubs = await Club.filter(kindergarten_id=kindergarten_id).all()
             club_ids = [c.id for c in clubs]
             enrollments = await Enrollment.filter(club_id__in=club_ids).all()
             enrollment_ids = [e.id for e in enrollments]
             query = query.filter(enrollment_id__in=enrollment_ids)

        payments = await query.order_by("-created_at").limit(200).all()
        
        # Enrich data
        enr_ids = [p.enrollment_id for p in payments]
        enrollments = await Enrollment.filter(id__in=enr_ids).all()
        enr_map = {e.id: e for e in enrollments}
        
        child_ids = [e.child_id for e in enrollments if e.child_id]
        club_ids = [e.club_id for e in enrollments if e.club_id]
        
        children = await Child.filter(id__in=child_ids).all()
        child_map = {c.id: c for c in children}
        
        clubs = await Club.filter(id__in=club_ids).all()
        club_map = {c.id: c for c in clubs}

        result = []
        for p in payments:
            enr = enr_map.get(p.enrollment_id)
            child = child_map.get(enr.child_id) if enr else None
            club = club_map.get(enr.club_id) if enr else None
            
            result.append({
                "id": p.id,
                "amount": p.amount,
                "month": p.month,
                "status": p.status,
                "method": p.provider or "unknown", # frontend expects 'method'
                "provider": p.provider,
                "date": p.paid_at.isoformat() if p.paid_at else p.created_at.isoformat(),
                "child_name": child.full_name if child else "Noma'lum",
                "club_name": club.name if club else "Noma'lum",
                "kindergarten_id": club.kindergarten_id if club else None
            })
            
        total_paid = sum(p.amount for p in payments if p.status == 'completed')
        return {"payments": result, "total_paid": total_paid}

    else:
        # --- Parent Logic ---
        children = await Child.filter(parent_id=current_user.id).all()
        child_ids = [c.id for c in children]
        enrollments = await Enrollment.filter(child_id__in=child_ids).all()
        enr_ids = [e.id for e in enrollments]

        payments = await Payment.filter(enrollment_id__in=enr_ids).order_by("-paid_at").all()

        # Fetch clubs for club_name
        club_ids = [e.club_id for e in enrollments]
        clubs = await Club.filter(id__in=club_ids).all()
        club_map = {c.id: c for c in clubs}
        enr_map = {e.id: e for e in enrollments}

        result = []
        for p in payments:
            enr = enr_map.get(p.enrollment_id)
            child_name = ""
            club_name = ""
            
            if enr:
                child = next((c for c in children if c.id == enr.child_id), None)
                child_name = child.full_name if child else ""
                club = club_map.get(enr.club_id)
                club_name = club.name if club else ""

            result.append({
                "id": p.id,
                "enrollment_id": p.enrollment_id,
                "child_name": child_name,
                "club_name": club_name,
                "amount": p.amount,
                "month": p.month,
                "status": p.status,
                "method": p.provider or "unknown",
                "provider": p.provider,
                "transaction_id": p.transaction_id,
                "date": p.paid_at.isoformat() if p.paid_at else p.created_at.isoformat(),
                "paid_at": p.paid_at.isoformat() if p.paid_at else None,
            })
            
        total_paid = sum(p.amount for p in payments if p.status == 'completed')
        return {"payments": result, "total_paid": total_paid}


@router.get("/status/{payment_id}")
async def check_payment_status(payment_id: str):
    """6-raqamli To'lov ID bo'yicha holat tekshirish (faqat o'qish — GET)."""
    enrollment = await Enrollment.get_or_none(payment_id=payment_id)
    if not enrollment:
        raise HTTPException(404, "To'lov ID topilmadi")

    month_str = date.today().strftime("%Y-%m")
    payment = await Payment.get_or_none(
        enrollment_id=enrollment.id, month=month_str
    )

    return {
        "payment_id": payment_id,
        "enrollment_id": enrollment.id,
        "month": month_str,
        "status": payment.status if payment else "pending",
        "amount": payment.amount if payment else None,
        "paid_at": payment.paid_at.isoformat() if (payment and payment.paid_at) else None,
    }


@router.get("/admin-summary")
async def admin_payment_summary(current_user: User = Depends(_get_current_user)):
    """
    Finance overview for admin/iqtisodchi.
    Returns: monthly totals, recent payments, debtor count.
    """
    user_roles = [r.strip().lower() for r in current_user.role.split(",")]
    allowed = {"admin", "boshliq", "mmtb_boshligi", "iqtisodchi", "director"}
    if not any(r in allowed for r in user_roles):
        raise HTTPException(403, "Ruxsat yo'q")

    month = date.today().strftime("%Y-%m")

    # This month stats
    completed = await Payment.filter(month=month, status="completed").all()
    pending = await Payment.filter(month=month, status="pending").all()
    monthly_total = sum(int(p.amount) for p in completed)
    pending_total = sum(int(p.amount) for p in pending)

    # Recent 20 payments with details
    recent = await Payment.filter(status="completed").order_by("-paid_at").limit(20).all()
    recent_list = []
    
    # Batch fetch related data
    enr_ids = [p.enrollment_id for p in recent]
    enrollments = await Enrollment.filter(id__in=enr_ids).all()
    enr_map = {e.id: e for e in enrollments}
    
    child_ids = [e.child_id for e in enrollments]
    club_ids = [e.club_id for e in enrollments]
    
    children = await Child.filter(id__in=child_ids).all()
    child_map = {c.id: c for c in children}
    
    clubs = await Club.filter(id__in=club_ids).all()
    club_map = {c.id: c for c in clubs}

    for p in recent:
        enrollment = enr_map.get(p.enrollment_id)
        child_name = "—"
        club_name = "—"
        if enrollment:
            child = child_map.get(enrollment.child_id)
            club = club_map.get(enrollment.club_id)
            if child:
                child_name = child.full_name
            if club:
                club_name = club.name
                
        recent_list.append({
            "id": p.id,
            "child_name": child_name,
            "club_name": club_name,
            "amount": int(p.amount),
            "month": p.month,
            "provider": p.provider or "—",
            "paid_at": p.paid_at.strftime("%d.%m.%Y %H:%M") if p.paid_at else "—",
            "transaction_id": p.transaction_id or "—",
        })

    # Debtors count
    active_enrollments = await Enrollment.filter(status="active").all()
    paid_ids = set(p.enrollment_id for p in completed)
    debtors = len([e for e in active_enrollments if e.id not in paid_ids])

    return {
        "month": month,
        "monthly_total": monthly_total,
        "pending_total": pending_total,
        "completed_count": len(completed),
        "debtors_count": debtors,
        "recent_payments": recent_list,
    }


# ─── Click Webhooks ───────────────────────────────────────────────────────────

def _click_sign(secret: str, *parts) -> str:
    raw = "".join(str(p) for p in parts) + secret
    return hashlib.md5(raw.encode()).hexdigest()


@router.post("/click/prepare")
async def click_prepare(data: ClickPrepareRequest, request: Request):
    """Click prepare webhook."""
    payment_id_str = str(data.merchant_trans_id)

    enrollment = await Enrollment.get_or_none(payment_id=payment_id_str)
    if not enrollment:
        return {"error": -5, "error_note": "To'lov ID topilmadi"}

    if enrollment.status == "blocked":
        return {"error": -9, "error_note": "Hisob bloklangan"}

    return {
        "error": 0,
        "error_note": "Success",
        "click_trans_id": data.click_trans_id,
        "merchant_trans_id": data.merchant_trans_id,
        "merchant_prepare_id": enrollment.id,
    }


@router.post("/click/complete")
async def click_complete(data: ClickCompleteRequest, request: Request):
    """
    Click complete webhook.

    IDEMPOTENCY: click_trans_id unikal kalit.
    Agar bir xil click_trans_id ikki marta kelsa — birinchi natijani qaytaramiz.
    """
    if data.error < 0:
        return {"error": data.error, "error_note": data.error_note}

    enrollment = await Enrollment.get_or_none(payment_id=str(data.merchant_trans_id))
    if not enrollment:
        return {"error": -5, "error_note": "To'lov ID topilmadi"}

    # ── IDEMPOTENCY TEKSHIRUVI ────────────────────────────────────────────────
    transaction_key = f"click_{data.click_trans_id}"
    existing = await _find_payment_by_transaction(transaction_key)
    if existing:
        # Bir xil transaction ikki marta keldi → qayta yozmaymiz
        logger.info(f"Idempotency: click_trans_id={data.click_trans_id} allaqachon qayd etilgan (id={existing.id})")
        return {
            "error": 0,
            "error_note": "Success (duplicate ignored)",
            "click_trans_id": data.click_trans_id,
            "merchant_trans_id": data.merchant_trans_id,
            "merchant_confirm_id": existing.id,
        }
    # ─────────────────────────────────────────────────────────────────────────

    month_str = date.today().strftime("%Y-%m")
    payment = await Payment.create(
        enrollment_id=enrollment.id,
        amount=data.amount,
        month=month_str,
        status="completed",
        provider="click",
        transaction_id=transaction_key,          # ← saqlayapmiz
        paid_at=datetime.now(),
    )

    await _notify_payment_received(enrollment, data.amount, "Click")

    return {
        "error": 0,
        "error_note": "Success",
        "click_trans_id": data.click_trans_id,
        "merchant_trans_id": data.merchant_trans_id,
        "merchant_confirm_id": payment.id,
    }


# ─── Paynet Webhooks ──────────────────────────────────────────────────────────

@router.post("/paynet")
async def paynet_webhook(req: PaynetCheckRequest):
    """
    Paynet JSON-RPC webhook.

    IDEMPOTENCY: performTransaction → params.id unikal kalit.
    """
    method = req.method
    params = req.params

    if method == "checkPerformTransaction":
        payment_id = params.get("account", {}).get("id", "")
        enrollment = await Enrollment.get_or_none(payment_id=str(payment_id))
        if not enrollment:
            return {"id": req.id, "error": {"code": -31050, "message": "To'lov ID topilmadi"}, "result": None}
        return {
            "id": req.id,
            "error": None,
            "result": {"allow": True}
        }

    elif method == "performTransaction":
        payment_id = params.get("account", {}).get("id", "")
        paynet_transaction_id = str(params.get("id", ""))   # Paynet o'zining ID si
        amount = params.get("amount", 0) / 100              # tiyin → so'm

        enrollment = await Enrollment.get_or_none(payment_id=str(payment_id))
        if not enrollment:
            return {"id": req.id, "error": {"code": -31050, "message": "Topilmadi"}, "result": None}

        # ── IDEMPOTENCY TEKSHIRUVI ────────────────────────────────────────────
        transaction_key = f"paynet_{paynet_transaction_id}"
        existing = await _find_payment_by_transaction(transaction_key)
        if existing:
            logger.info(f"Idempotency: paynet_id={paynet_transaction_id} allaqachon qayd etilgan (id={existing.id})")
            return {
                "id": req.id,
                "error": None,
                "result": {
                    "transaction": existing.id,
                    "perform_time": int(existing.paid_at.timestamp() * 1000) if existing.paid_at else 0,
                    "state": 2
                }
            }
        # ─────────────────────────────────────────────────────────────────────

        month_str = date.today().strftime("%Y-%m")
        payment = await Payment.create(
            enrollment_id=enrollment.id,
            amount=amount,
            month=month_str,
            status="completed",
            provider="paynet",
            transaction_id=transaction_key,      # ← saqlayapmiz
            paid_at=datetime.now(),
        )
        await _notify_payment_received(enrollment, amount, "Paynet")
        return {
            "id": req.id,
            "error": None,
            "result": {
                "transaction": payment.id,
                "perform_time": int(datetime.now().timestamp() * 1000),
                "state": 2
            }
        }

    return {"id": req.id, "error": {"code": -32601, "message": "Method not found"}, "result": None}


# ─── Yordamchi ────────────────────────────────────────────────────────────────

async def _notify_payment_received(enrollment: Enrollment, amount: float, provider: str):
    """To'lov qabul qilinganda ota-onaga xabar."""
    from aiogram import Bot

    try:
        child = await Child.get_or_none(id=enrollment.child_id)
        if not child:
            return
        parent = await User.get_or_none(id=child.parent_id)
        if not parent or not parent.telegram_id:
            return

        month_str = date.today().strftime("%Y-%m")
        async with Bot(token=config.TOKEN) as bot:
            await bot.send_message(
                parent.telegram_id,
                f"✅ <b>To'lov qabul qilindi!</b>\n\n"
                f"👶 Farzand: {child.full_name}\n"
                f"💰 Miqdor: {amount:,.0f} so'm\n"
                f"📅 Oy: {month_str}\n"
                f"💳 Tizim: {provider}\n\n"
                f"Rahmat! 🙏",
                parse_mode="HTML"
            )
    except Exception as e:
        logger.warning(f"To'lov xabari yuborilmadi: {e}")
