"""
SmartDMTT v4 — Admin router
Foydalanuvchi: telefon, parol, rol, blok boshqaruvi
DB viewer: jadvallarni ko'rish va tahrirlash
"""
import logging, bcrypt, sqlite3, os
from datetime import datetime
from typing import Any, Optional
from fastapi import APIRouter, Depends, HTTPException, Query
from pydantic import BaseModel

from app.api.deps import get_current_user
from app.models.user import User

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/admin", tags=["admin"])

ROLES = [
    "admin", "boshliq", "mmtb_boshligi", "director",
    "iqtisodchi", "teacher", "togarak_rahbari", "parent", "guest"
]

DB_PATH = os.path.join(os.path.dirname(__file__), "..", "..", "data", "database.sqlite")


# ── Auth helper ────────────────────────────────────────────────────────────
def _require_admin(user: User):
    role = (user.role or "").lower()
    if role not in ("admin", "boshliq", "mmtb_boshligi"):
        raise HTTPException(403, "Ruxsat yo'q")


# ══════════════════════════════════════════════════════════════════
#  FOYDALANUVCHI BOSHQARUVI
# ══════════════════════════════════════════════════════════════════

@router.get("/users")
async def list_users(
    search: str = Query(None),
    role:   str = Query(None),
    page:   int = Query(1, ge=1),
    limit:  int = Query(30, le=100),
    current_user: User = Depends(get_current_user),
):
    _require_admin(current_user)
    try:
        q = User.all()
        if search:
            from tortoise.expressions import Q
            q = q.filter(
                Q(full_name__icontains=search) |
                Q(phone__icontains=search) |
                Q(username__icontains=search)
            )
        if role:
            q = q.filter(role=role)

        total  = await q.count()
        offset = (page - 1) * limit
        users  = await q.order_by("-id").offset(offset).limit(limit)

        return {
            "total": total,
            "page":  page,
            "pages": (total + limit - 1) // limit,
            "users": [
                {
                    "id":           u.id,
                    "full_name":    u.full_name or "",
                    "phone":        u.phone or "",
                    "role":         u.role or "guest",
                    "language":     u.language or "uz",
                    "is_blocked":   u.is_blocked,
                    "kindergarten_id": u.kindergarten_id,
                    "telegram_id":  u.telegram_id,
                    "created_at":   u.created_at.isoformat() if u.created_at else None,
                }
                for u in users
            ]
        }
    except Exception as e:
        logger.error(f"list_users: {e}")
        raise HTTPException(500, str(e))


# ── Rol o'zgartirish ──────────────────────────────────────────────
class RoleUpdate(BaseModel):
    role: str

@router.patch("/users/{user_id}/role")
async def update_role(
    user_id: int,
    body: RoleUpdate,
    current_user: User = Depends(get_current_user),
):
    _require_admin(current_user)
    if body.role not in ROLES:
        raise HTTPException(400, f"Noto'g'ri rol. Mumkin: {', '.join(ROLES)}")
    user = await User.get_or_none(id=user_id)
    if not user:
        raise HTTPException(404, "Foydalanuvchi topilmadi")
    old_role = user.role
    user.role = body.role
    await user.save()
    return {"ok": True, "old_role": old_role, "new_role": body.role}


# ── Telefon o'zgartirish ──────────────────────────────────────────
class PhoneUpdate(BaseModel):
    phone: str

@router.patch("/users/{user_id}/phone")
async def update_phone(
    user_id: int,
    body: PhoneUpdate,
    current_user: User = Depends(get_current_user),
):
    _require_admin(current_user)
    phone = body.phone.strip()
    if not phone.startswith("+"):
        phone = "+" + phone

    # Boshqa foydalanuvchida bu telefon bormi?
    existing = await User.get_or_none(phone=phone)
    if existing and existing.id != user_id:
        raise HTTPException(400, "Bu telefon raqam boshqa foydalanuvchiga tegishli")

    user = await User.get_or_none(id=user_id)
    if not user:
        raise HTTPException(404, "Foydalanuvchi topilmadi")

    old_phone = user.phone
    user.phone = phone
    await user.save()
    return {"ok": True, "old_phone": old_phone, "new_phone": phone}


# ── Parol o'zgartirish ────────────────────────────────────────────
class PasswordUpdate(BaseModel):
    password: str

@router.patch("/users/{user_id}/password")
async def update_password(
    user_id: int,
    body: PasswordUpdate,
    current_user: User = Depends(get_current_user),
):
    _require_admin(current_user)
    if len(body.password) < 4:
        raise HTTPException(400, "Parol kamida 4 ta belgi bo'lishi kerak")

    user = await User.get_or_none(id=user_id)
    if not user:
        raise HTTPException(404, "Foydalanuvchi topilmadi")

    pw_hash = bcrypt.hashpw(body.password.encode(), bcrypt.gensalt()).decode()
    user.username = pw_hash
    await user.save()
    return {"ok": True}


# ── Bloklash / Blokdan chiqarish ─────────────────────────────────
@router.patch("/users/{user_id}/block")
async def toggle_block(
    user_id: int,
    current_user: User = Depends(get_current_user),
):
    _require_admin(current_user)
    user = await User.get_or_none(id=user_id)
    if not user:
        raise HTTPException(404, "Foydalanuvchi topilmadi")
    user.is_blocked = not user.is_blocked
    await user.save()
    return {"ok": True, "is_blocked": user.is_blocked}


# ── Foydalanuvchini o'chirish ─────────────────────────────────────
@router.delete("/users/{user_id}")
async def delete_user(
    user_id: int,
    current_user: User = Depends(get_current_user),
):
    _require_admin(current_user)
    if user_id == current_user.id:
        raise HTTPException(400, "O'zingizni o'chira olmaysiz")
    user = await User.get_or_none(id=user_id)
    if not user:
        raise HTTPException(404, "Foydalanuvchi topilmadi")
    await user.delete()
    return {"ok": True}


# ══════════════════════════════════════════════════════════════════
#  DB VIEWER
# ══════════════════════════════════════════════════════════════════

def _get_conn():
    path = os.path.normpath(os.path.join(os.path.dirname(__file__), "../../data/database.sqlite"))
    conn = sqlite3.connect(path)
    conn.row_factory = sqlite3.Row
    return conn


@router.get("/db/tables")
async def db_tables(current_user: User = Depends(get_current_user)):
    """Barcha jadvallar ro'yxati + ustunlar + satr soni"""
    _require_admin(current_user)
    try:
        conn = _get_conn()
        cur  = conn.cursor()
        cur.execute("SELECT name FROM sqlite_master WHERE type='table' ORDER BY name")
        tables = [r[0] for r in cur.fetchall()]

        result = []
        for tbl in tables:
            cur.execute(f"SELECT COUNT(*) FROM [{tbl}]")
            count = cur.fetchone()[0]
            cur.execute(f"PRAGMA table_info([{tbl}])")
            cols = [{"name": c["name"], "type": c["type"], "notnull": c["notnull"], "pk": c["pk"]}
                    for c in cur.fetchall()]
            result.append({"table": tbl, "rows": count, "columns": cols})

        conn.close()
        return result
    except Exception as e:
        raise HTTPException(500, str(e))


@router.get("/db/table/{table_name}")
async def db_table_data(
    table_name: str,
    page:   int = Query(1, ge=1),
    limit:  int = Query(50, le=200),
    search: str = Query(None),
    current_user: User = Depends(get_current_user),
):
    """Jadval ma'lumotlari — pagination bilan"""
    _require_admin(current_user)

    # SQL injection himoya
    allowed = set()
    try:
        conn = _get_conn()
        cur  = conn.cursor()
        cur.execute("SELECT name FROM sqlite_master WHERE type='table'")
        allowed = {r[0] for r in cur.fetchall()}
    except Exception as e:
        raise HTTPException(500, str(e))

    if table_name not in allowed:
        raise HTTPException(404, "Jadval topilmadi")

    try:
        offset     = (page - 1) * limit
        where      = ""
        params: list = []

        if search:
            cur.execute(f"PRAGMA table_info([{table_name}])")
            cols = [c["name"] for c in cur.fetchall()]
            clauses = [f"CAST([{c}] AS TEXT) LIKE ?" for c in cols]
            where  = "WHERE " + " OR ".join(clauses)
            params = [f"%{search}%"] * len(cols)

        cur.execute(f"SELECT COUNT(*) FROM [{table_name}] {where}", params)
        total = cur.fetchone()[0]

        cur.execute(
            f"SELECT * FROM [{table_name}] {where} LIMIT ? OFFSET ?",
            params + [limit, offset]
        )
        rows = [dict(r) for r in cur.fetchall()]
        conn.close()

        return {
            "table":  table_name,
            "total":  total,
            "page":   page,
            "pages":  (total + limit - 1) // limit,
            "rows":   rows,
        }
    except Exception as e:
        raise HTTPException(500, str(e))


@router.patch("/db/table/{table_name}/{row_id}")
async def db_update_row(
    table_name: str,
    row_id:     int,
    body:       dict,
    current_user: User = Depends(get_current_user),
):
    """Jadval qatorini tahrirlash"""
    _require_admin(current_user)

    # Faqat admin o'zgartira oladi
    if current_user.role != "admin":
        raise HTTPException(403, "Faqat admin o'zgartira oladi")

    # Himoya: ba'zi maydonlar tahrirlanmasin
    PROTECTED = {"id", "created_at", "telegram_id"}
    data = {k: v for k, v in body.items() if k not in PROTECTED}

    if not data:
        raise HTTPException(400, "O'zgartirishga ruxsat etilgan maydon yo'q")

    try:
        conn = _get_conn()
        cur  = conn.cursor()

        # Jadval tekshirish
        cur.execute("SELECT name FROM sqlite_master WHERE type='table'")
        allowed = {r[0] for r in cur.fetchall()}
        if table_name not in allowed:
            raise HTTPException(404, "Jadval topilmadi")

        # Ustun tekshirish
        cur.execute(f"PRAGMA table_info([{table_name}])")
        valid_cols = {c["name"] for c in cur.fetchall()}
        data = {k: v for k, v in data.items() if k in valid_cols}

        if not data:
            raise HTTPException(400, "Hech qanday to'g'ri ustun yo'q")

        sets   = ", ".join(f"[{k}] = ?" for k in data)
        values = list(data.values()) + [row_id]
        cur.execute(f"UPDATE [{table_name}] SET {sets} WHERE id = ?", values)
        conn.commit()
        conn.close()
        return {"ok": True, "updated": cur.rowcount}
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(500, str(e))


@router.delete("/db/table/{table_name}/{row_id}")
async def db_delete_row(
    table_name: str,
    row_id:     int,
    current_user: User = Depends(get_current_user),
):
    """Jadval qatorini o'chirish"""
    if current_user.role != "admin":
        raise HTTPException(403, "Faqat admin o'chira oladi")
    try:
        conn = _get_conn()
        cur  = conn.cursor()
        cur.execute("SELECT name FROM sqlite_master WHERE type='table'")
        allowed = {r[0] for r in cur.fetchall()}
        if table_name not in allowed:
            raise HTTPException(404, "Jadval topilmadi")
        cur.execute(f"DELETE FROM [{table_name}] WHERE id = ?", [row_id])
        conn.commit()
        conn.close()
        return {"ok": True}
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(500, str(e))
