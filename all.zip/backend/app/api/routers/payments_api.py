"""
SmartDMTT v4 — Payments router
/my-debts, /my-history, /my-summary — ota-ona uchun
"""
import logging
from datetime import date
from fastapi import APIRouter, Depends, HTTPException, Query
from app.api.deps import get_current_user
from app.models.user import User
from app.models.child import Child
from app.models.club import Club, Enrollment
from app.models.payment import Payment

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/payments", tags=["payments"])


@router.get("/my-debts")
async def my_debts(current_user: User = Depends(get_current_user)):
    """Joriy oy to'lanmagan enrollmentlar"""
    month_str = date.today().strftime("%Y-%m")
    children  = await Child.filter(parent_id=current_user.id).all()
    result    = []

    for child in children:
        enrollments = await Enrollment.filter(child_id=child.id, status="active").all()
        for enr in enrollments:
            paid = await Payment.filter(
                enrollment_id=enr.id, month=month_str, status="completed"
            ).exists()
            if paid:
                continue
            club = await Club.get_or_none(id=enr.club_id)
            result.append({
                "enrollment_id": enr.id,
                "child_name":    child.full_name,
                "child_id":      child.id,
                "club_name":     club.name if club else "—",
                "club_id":       enr.club_id,
                "club_price":    float(club.price) if club else 0,
                "payment_id":    enr.payment_id,
                "month":         month_str,
                "is_paid":       False,
            })
    return result


@router.get("/my-history")
async def my_history(
    limit: int = Query(20, le=100),
    current_user: User = Depends(get_current_user),
):
    """To'langan to'lovlar tarixi"""
    children = await Child.filter(parent_id=current_user.id).all()
    child_ids = [c.id for c in children]
    if not child_ids:
        return []

    enr_ids = await Enrollment.filter(child_id__in=child_ids).values_list("id", flat=True)
    if not enr_ids:
        return []

    payments = await Payment.filter(
        enrollment_id__in=list(enr_ids), status="completed"
    ).order_by("-paid_at").limit(limit).all()

    result = []
    for p in payments:
        enr   = await Enrollment.get_or_none(id=p.enrollment_id)
        club  = await Club.get_or_none(id=enr.club_id) if enr else None
        child = await Child.get_or_none(id=enr.child_id) if enr else None
        result.append({
            "payment_id":  p.id,
            "month":       p.month,
            "amount":      float(p.amount) if p.amount else 0,
            "paid_at":     p.paid_at.isoformat() if p.paid_at else None,
            "club_name":   club.name  if club  else "—",
            "child_name":  child.full_name if child else "—",
        })
    return result


@router.get("/my-summary")
async def my_summary(current_user: User = Depends(get_current_user)):
    """Umumiy to'lov xulosa"""
    month_str = date.today().strftime("%Y-%m")
    children  = await Child.filter(parent_id=current_user.id).all()
    child_ids = [c.id for c in children]

    enr_ids = await Enrollment.filter(
        child_id__in=child_ids, status="active"
    ).values_list("id", flat=True) if child_ids else []

    total_enrollments = len(enr_ids)
    paid_this_month   = await Payment.filter(
        enrollment_id__in=list(enr_ids), month=month_str, status="completed"
    ).count() if enr_ids else 0

    paid_amount = 0
    if enr_ids:
        payments = await Payment.filter(
            enrollment_id__in=list(enr_ids), month=month_str, status="completed"
        ).all()
        paid_amount = sum(float(p.amount or 0) for p in payments)

    return {
        "month":              month_str,
        "total_enrollments":  total_enrollments,
        "paid_count":         paid_this_month,
        "unpaid_count":       total_enrollments - paid_this_month,
        "paid_amount":        paid_amount,
        "children_count":     len(children),
    }


@router.get("/debtors")
async def debtors_list(
    kg_id: int = Query(None),
    current_user: User = Depends(get_current_user),
):
    """Admin/boshliq: joriy oy qarzdorlar ro'yxati"""
    role = (current_user.role or "").lower()
    if role not in ("admin", "boshliq", "mmtb_boshligi", "director", "iqtisodchi"):
        raise HTTPException(403, "Ruxsat yo'q")

    month_str = date.today().strftime("%Y-%m")
    enr_q = Enrollment.filter(status="active")
    if kg_id:
        child_ids = await Child.filter(kindergarten_id=kg_id).values_list("id", flat=True)
        enr_q = enr_q.filter(child_id__in=list(child_ids))

    enrollments = await enr_q.all()
    paid_ids    = set(await Payment.filter(
        enrollment_id__in=[e.id for e in enrollments],
        month=month_str, status="completed"
    ).values_list("enrollment_id", flat=True)) if enrollments else set()

    result = []
    for enr in enrollments:
        if enr.id in paid_ids:
            continue
        child  = await Child.get_or_none(id=enr.child_id)
        club   = await Club.get_or_none(id=enr.club_id)
        parent = await User.get_or_none(id=child.parent_id) if child else None
        result.append({
            "child_name":   child.full_name if child else "—",
            "club_name":    club.name  if club  else "—",
            "club_price":   float(club.price) if club else 0,
            "payment_id":   enr.payment_id,
            "parent_phone": parent.phone if parent else "—",
            "parent_name":  parent.full_name if parent else "—",
        })

    return {"month": month_str, "count": len(result), "debtors": result}
