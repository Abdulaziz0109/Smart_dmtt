"""
SmartDMTT v4.0 — To'garaklar API Router
Spec 4.x bo'yicha: yozilish, kutish ro'yxati, chiqish.
"""
import logging
from typing import Optional

from fastapi import APIRouter, HTTPException, Depends, Request
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from pydantic import BaseModel

from app.models.club import Club, Enrollment
from app.models.child import Child
from app.models.user import User
from app.models.waiting_list import WaitingList
from app.services.token_service import TokenService

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/clubs", tags=["clubs"])
security = HTTPBearer(auto_error=False)


# ─── Auth dependency ──────────────────────────────────────────────────────────

async def _get_current_user(
    credentials: HTTPAuthorizationCredentials = Depends(security)
) -> User:
    if not credentials:
        raise HTTPException(401, "Avtorizatsiya talab etiladi")
    try:
        payload = TokenService.decode_token(credentials.credentials)
        user_id = int(payload["sub"])
        user = await User.get_or_none(id=user_id)
        if not user:
            raise HTTPException(401, "Foydalanuvchi topilmadi")
        if user.is_blocked:
            raise HTTPException(403, "Hisob bloklangan")
        return user
    except ValueError as e:
        raise HTTPException(401, str(e))


# ─── Pydantic modellari ───────────────────────────────────────────────────────

class EnrollRequest(BaseModel):
    club_id: int
    child_id: int


class LeaveRequest(BaseModel):
    enrollment_id: int


class WaitingRequest(BaseModel):
    club_id: int
    child_id: int


# ─── Endpointlar ─────────────────────────────────────────────────────────────

@router.get("")
async def get_clubs(
    kindergarten_id: Optional[int] = None,
    current_user: User = Depends(_get_current_user)
):
    """Barcha faol to'garaklar ro'yxati."""
    query = Club.filter(is_active=True)
    if kindergarten_id:
        query = query.filter(kindergarten_id=kindergarten_id)
    elif current_user.kindergarten_id:
        query = query.filter(kindergarten_id=current_user.kindergarten_id)

    clubs = await query.all()
    result = []
    for club in clubs:
        enrolled_count = await Enrollment.filter(club_id=club.id, status="active").count()
        waiting_count = await WaitingList.filter(club_id=club.id).count()
        spots_left = max(0, (club.max_members or 20) - enrolled_count)

        result.append({
            "id": club.id,
            "name": club.name,
            "description": club.description,
            "price": club.price,
            "schedule_days": club.schedule_days,
            "schedule_time": club.schedule_time,
            "age_min": club.age_min,
            "age_max": club.age_max,
            "max_members": club.max_members,
            "enrolled_count": enrolled_count,
            "spots_left": spots_left,
            "waiting_count": waiting_count,
            "is_full": spots_left == 0,
            "kindergarten_id": club.kindergarten_id,
        })
    return result


@router.get("/{club_id}")
async def get_club(
    club_id: int,
    current_user: User = Depends(_get_current_user)
):
    """To'garak tafsilotlari."""
    club = await Club.get_or_none(id=club_id, is_active=True)
    if not club:
        raise HTTPException(404, "To'garak topilmadi")

    enrolled_count = await Enrollment.filter(club_id=club_id, status="active").count()
    spots_left = max(0, (club.max_members or 20) - enrolled_count)
    waiting_count = await WaitingList.filter(club_id=club_id).count()

    return {
        "id": club.id,
        "name": club.name,
        "description": club.description,
        "price": club.price,
        "schedule_days": club.schedule_days,
        "schedule_time": club.schedule_time,
        "age_min": club.age_min,
        "age_max": club.age_max,
        "max_members": club.max_members,
        "min_members": club.min_members,
        "enrolled_count": enrolled_count,
        "spots_left": spots_left,
        "waiting_count": waiting_count,
        "is_full": spots_left == 0,
        "kindergarten_id": club.kindergarten_id,
    }


@router.post("/enroll")
async def enroll(
    req: EnrollRequest,
    current_user: User = Depends(_get_current_user)
):
    """
    Farzandni to'garakka yozish.
    Agar to'garak to'la bo'lsa → 400.
    """
    club = await Club.get_or_none(id=req.club_id, is_active=True)
    if not club:
        raise HTTPException(404, "To'garak topilmadi")

    child = await Child.get_or_none(id=req.child_id)
    if not child:
        raise HTTPException(404, "Farzand topilmadi")

    # Ruxsat tekshiruvi: admin yoki ota-ona
    if current_user.role not in ("admin", "director", "boshliq") and child.parent_id != current_user.id:
        raise HTTPException(403, "Ruxsat yo'q")

    # Allaqachon yozilganmi?
    existing = await Enrollment.get_or_none(child_id=req.child_id, club_id=req.club_id, status="active")
    if existing:
        raise HTTPException(400, "Farzand bu to'garakka allaqachon yozilgan")

    # Joy bormi?
    enrolled_count = await Enrollment.filter(club_id=req.club_id, status="active").count()
    max_members = club.max_members or 20
    if enrolled_count >= max_members:
        raise HTTPException(400, f"To'garak to'la ({enrolled_count}/{max_members}). Kutish ro'yxatiga qo'shilishingiz mumkin.")

    # Yozish + 6-raqamli payment_id
    enrollment = await Enrollment.create_with_payment_id(
        child_id=req.child_id,
        club_id=req.club_id,
        status="active"
    )

    return {
        "status": "success",
        "message": "Muvaffaqiyatli yozildi",
        "enrollment_id": enrollment.id,
        "payment_id": enrollment.payment_id,
        "child_id": req.child_id,
        "club_id": req.club_id,
    }


@router.post("/waiting")
async def add_to_waiting(
    req: WaitingRequest,
    current_user: User = Depends(_get_current_user)
):
    """Kutish ro'yxatiga qo'shish."""
    club = await Club.get_or_none(id=req.club_id, is_active=True)
    if not club:
        raise HTTPException(404, "To'garak topilmadi")

    child = await Child.get_or_none(id=req.child_id)
    if not child:
        raise HTTPException(404, "Farzand topilmadi")

    if current_user.role not in ("admin", "director", "boshliq") and child.parent_id != current_user.id:
        raise HTTPException(403, "Ruxsat yo'q")

    # Allaqachon yozilganmi?
    existing_enr = await Enrollment.get_or_none(child_id=req.child_id, club_id=req.club_id, status="active")
    if existing_enr:
        raise HTTPException(400, "Farzand bu to'garakka allaqachon yozilgan")

    # Kutish ro'yxatida allaqachon bormi?
    existing_wait = await WaitingList.get_or_none(child_id=req.child_id, club_id=req.club_id)
    if existing_wait:
        raise HTTPException(400, "Farzand allaqachon kutish ro'yxatida")

    await WaitingList.create(child_id=req.child_id, club_id=req.club_id)
    waiting_count = await WaitingList.filter(club_id=req.club_id).count()

    return {
        "status": "success",
        "message": "Kutish ro'yxatiga qo'shildi",
        "position": waiting_count,
    }


@router.post("/leave")
async def leave_club(
    req: LeaveRequest,
    current_user: User = Depends(_get_current_user)
):
    """
    To'garakdan chiqish.
    Joy bo'shaganda kutish ro'yxatidagi birinchiga xabar yuboriladi.
    """
    enrollment = await Enrollment.get_or_none(id=req.enrollment_id)
    if not enrollment:
        raise HTTPException(404, "Yozilish topilmadi")

    child = await Child.get_or_none(id=enrollment.child_id)
    if not child:
        raise HTTPException(404, "Farzand topilmadi")

    if current_user.role not in ("admin", "director", "boshliq") and child.parent_id != current_user.id:
        raise HTTPException(403, "Ruxsat yo'q")

    if enrollment.status != "active":
        raise HTTPException(400, "Yozilish faol emas")

    enrollment.status = "removed"
    await enrollment.save()

    # Kutish ro'yxatidagi birinchiga xabar
    await _notify_waiting_list(enrollment.club_id)

    return {"status": "success", "message": "To'garakdan chiqildi"}


@router.get("/my-enrollments")
async def my_enrollments(current_user: User = Depends(_get_current_user)):
    """Joriy foydalanuvchi farzandlarining yozilishlari."""
    children = await Child.filter(parent_id=current_user.id).all()
    if not children:
        return []

    result = []
    for child in children:
        enrollments = await Enrollment.filter(child_id=child.id, status="active").all()
        for enr in enrollments:
            club = await Club.get_or_none(id=enr.club_id)
            if club:
                result.append({
                    "enrollment_id": enr.id,
                    "payment_id": enr.payment_id,
                    "child_id": child.id,
                    "child_name": child.full_name,
                    "club_id": club.id,
                    "club_name": club.name,
                    "club_price": club.price,
                    "schedule_days": club.schedule_days,
                    "schedule_time": club.schedule_time,
                    "enrolled_at": enr.enrolled_at.isoformat() if enr.enrolled_at else None,
                })
    return result


@router.get("/{club_id}/enrollments")
async def get_club_enrollments(
    club_id: int,
    current_user: User = Depends(_get_current_user)
):
    """To'garak o'quvchilari ro'yxati (muallim uchun)."""""
    # Ruxsat: teacher o'z to'garagi, admin/boshliq/director hamma
    if current_user.role not in ("admin", "boshliq", "director", "mmtb_boshligi"):
        if current_user.club_id != club_id:
            raise HTTPException(403, "Ruxsat yo'q")

    club = await Club.get_or_none(id=club_id, is_active=True)
    if not club:
        raise HTTPException(404, "To'garak topilmadi")

    from app.models.child import Child
    from app.models.payment import Payment
    from datetime import date

    enrollments = await Enrollment.filter(club_id=club_id, status="active").all()
    month_str = date.today().strftime("%Y-%m")
    result = []
    for enr in enrollments:
        child = await Child.get_or_none(id=enr.child_id)
        if not child:
            continue
        paid = await Payment.filter(
            enrollment_id=enr.id, month=month_str, status="completed"
        ).exists()
        result.append({
            "id": enr.id,
            "child_id": child.id,
            "child_name": child.full_name,
            "birth_year": child.birth_year,
            "payment_id": enr.payment_id,
            "paid_this_month": paid,
        })
    return {"students": result, "total": len(result)}


# ─── Yordamchi funksiyalar ────────────────────────────────────────────────────

async def _notify_waiting_list(club_id: int):
    """Joy bo'shaganda kutish ro'yxatidagi birinchiga Telegram xabar."""
    from app.core import config
    from aiogram import Bot

    first_waiting = await WaitingList.filter(club_id=club_id, notified=False).order_by("id").first()
    if not first_waiting:
        return

    child = await Child.get_or_none(id=first_waiting.child_id)
    if not child:
        return

    parent = await User.get_or_none(id=child.parent_id)
    if not parent or not parent.telegram_id:
        return

    club = await Club.get_or_none(id=club_id)
    if not club:
        return

    try:
        async with Bot(token=config.TOKEN) as bot:
            await bot.send_message(
                parent.telegram_id,
                f"🎉 <b>Joy bo'shadi!</b>\n\n"
                f"👶 {child.full_name} uchun <b>{club.name}</b> to'garagida joy ochildi.\n\n"
                f"📱 Yozilish uchun botga qayting yoki saytga kiring.",
                parse_mode="HTML"
            )
        from datetime import datetime
        first_waiting.notified = True
        first_waiting.notified_at = datetime.now()
        await first_waiting.save()
    except Exception as e:
        logger.warning(f"Kutish ro'yxati xabari yuborilmadi: {e}")
