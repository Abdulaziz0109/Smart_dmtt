"""
backend/app/api/routers/__init__.py
analytics_summary.py ni analytics deb re-export qiladi.
Bu fayl bo'lmasa main.py "from app.api.routers import analytics" deb import qila olmaydi.
"""
from app.api.routers import analytics_summary as analytics  # noqa: F401
