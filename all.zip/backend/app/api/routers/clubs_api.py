"""
SmartDMTT v4 — Clubs router (to'liq)
/clubs, /clubs/enroll, /clubs/my-enrollments, /clubs/enrollments
"""
import logging, uuid
from datetime import date
from fastapi import APIRouter, Depends, HTTPException, Query
from pydantic import BaseModel
from app.api.deps import get_current_user
from app.models.user import User
from app.models.child import Child
from app.models.club import Club, Enrollment
from app.models.payment import Payment
from app.models.kindergarten import Kindergarten

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/clubs", tags=["clubs"])


# ── 1. Barcha to'garaklar ─────────────────────────────────
@router.get("")
async def list_clubs(
    kg_id: int = Query(None),
    current_user: User = Depends(get_current_user),
):
    q = Club.all()
    target_kg = kg_id or current_user.kindergarten_id
    if target_kg:
        q = q.filter(kindergarten_id=target_kg)

    clubs  = await q.order_by("name").all()
    result = []
    for c in clubs:
        count = await Enrollment.filter(club_id=c.id, status="active").count()
        result.append({
            "id":            c.id,
            "name":          c.name,
            "description":   c.description or "",
            "price":         float(c.price or 0),
            "capacity":      c.capacity,
            "current_count": count,
            "schedule_days": c.schedule_days or "",
            "schedule_time": c.schedule_time or "",
            "teacher_id":    c.teacher_id,
            "kindergarten_id": c.kindergarten_id,
        })
    return result


# ── 2. Yozilish (enroll) ──────────────────────────────────
class EnrollBody(BaseModel):
    club_id:  int
    child_id: int

@router.post("/enroll")
async def enroll(body: EnrollBody, current_user: User = Depends(get_current_user)):
    # Ota-ona faqat o'z farzandini yozadi
    child = await Child.get_or_none(id=body.child_id)
    if not child:
        raise HTTPException(404, "Bola topilmadi")
    if current_user.role == "parent" and child.parent_id != current_user.id:
        raise HTTPException(403, "Bu farzand sizga tegishli emas")

    club = await Club.get_or_none(id=body.club_id)
    if not club:
        raise HTTPException(404, "To'garak topilmadi")

    # Allaqachon yozilganmi?
    existing = await Enrollment.get_or_none(club_id=body.club_id, child_id=body.child_id, status="active")
    if existing:
        raise HTTPException(400, "Bu bolа allaqachon yozilgan")

    # Sig'im tekshirish
    if club.capacity:
        count = await Enrollment.filter(club_id=club.id, status="active").count()
        if count >= club.capacity:
            raise HTTPException(400, "To'garak to'lgan. Bo'sh o'rin yo'q.")

    pay_id = f"ENR-{body.club_id}-{body.child_id}-{uuid.uuid4().hex[:8].upper()}"
    enr    = await Enrollment.create(
        club_id=body.club_id,
        child_id=body.child_id,
        status="active",
        payment_id=pay_id,
        enrolled_at=date.today(),
    )
    return {
        "ok":         True,
        "enrollment_id": enr.id,
        "payment_id": pay_id,
        "club_name":  club.name,
        "child_name": child.full_name,
        "price":      float(club.price or 0),
    }


# ── 3. Ota-ona o'z farzandlarining yozilishlari ───────────
@router.get("/my-enrollments")
async def my_enrollments(current_user: User = Depends(get_current_user)):
    children  = await Child.filter(parent_id=current_user.id).all()
    child_ids = [c.id for c in children]
    if not child_ids:
        return []

    enrollments = await Enrollment.filter(child_id__in=child_ids, status="active").all()
    month_str   = date.today().strftime("%Y-%m")
    result      = []

    for enr in enrollments:
        club  = await Club.get_or_none(id=enr.club_id)
        child = next((c for c in children if c.id == enr.child_id), None)
        paid  = await Payment.filter(
            enrollment_id=enr.id, month=month_str, status="completed"
        ).exists()
        result.append({
            "id":         enr.id,
            "club_id":    enr.club_id,
            "child_id":   enr.child_id,
            "club_name":  club.name  if club  else "—",
            "child_name": child.full_name if child else "—",
            "payment_id": enr.payment_id,
            "is_paid":    paid,
            "amount":     float(club.price) if club else 0,
        })
    return result


# ── 4. Muallim/Admin: to'garak enrollmentlari ────────────
@router.get("/enrollments")
async def enrollments(
    club_id:  int = Query(None),
    child_id: int = Query(None),
    current_user: User = Depends(get_current_user),
):
    q = Enrollment.filter(status="active")
    if club_id:
        q = q.filter(club_id=club_id)
    elif current_user.role in ("teacher", "togarak_rahbari") and current_user.club_id:
        q = q.filter(club_id=current_user.club_id)
    if child_id:
        q = q.filter(child_id=child_id)

    enrollments = await q.all()
    month_str   = date.today().strftime("%Y-%m")
    result      = []

    for enr in enrollments:
        child = await Child.get_or_none(id=enr.child_id)
        paid  = await Payment.filter(
            enrollment_id=enr.id, month=month_str, status="completed"
        ).exists()
        result.append({
            "id":         enr.id,
            "club_id":    enr.club_id,
            "child_id":   enr.child_id,
            "child_name": child.full_name if child else "—",
            "payment_id": enr.payment_id,
            "is_paid":    paid,
            "enrolled_at": str(enr.enrolled_at) if enr.enrolled_at else None,
        })
    return result


# ── 5. Yozilishdan chiqarish ──────────────────────────────
@router.delete("/enrollments/{enr_id}")
async def unenroll(enr_id: int, current_user: User = Depends(get_current_user)):
    role = (current_user.role or "").lower()
    if role not in ("admin", "boshliq", "mmtb_boshligi", "director"):
        raise HTTPException(403, "Ruxsat yo'q")
    enr = await Enrollment.get_or_none(id=enr_id)
    if not enr:
        raise HTTPException(404, "Topilmadi")
    enr.status = "cancelled"
    await enr.save()
    return {"ok": True}
