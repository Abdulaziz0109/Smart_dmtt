"""
SmartDMTT v4.0 — Bog'chalar API Router
+ /nearest endpoint: foydalanuvchi koordinatiga yaqin bog'chalar
"""
import math
from typing import Optional
from fastapi import APIRouter, HTTPException, Query
from app.models.kindergarten import Kindergarten

router = APIRouter(prefix="/kindergartens", tags=["kindergartens"])


# ─── Haversine formulasi ──────────────────────────────────────────────────────

def _haversine_km(lat1: float, lon1: float, lat2: float, lon2: float) -> float:
    """
    Ikkita koordinata orasidagi masofani km da hisoblash.
    Yer radiusi: 6371 km.
    """
    R = 6371.0
    d_lat = math.radians(lat2 - lat1)
    d_lon = math.radians(lon2 - lon1)
    a = (math.sin(d_lat / 2) ** 2
         + math.cos(math.radians(lat1))
         * math.cos(math.radians(lat2))
         * math.sin(d_lon / 2) ** 2)
    return R * 2 * math.atan2(math.sqrt(a), math.sqrt(1 - a))


def _kg_to_dict(kg: Kindergarten, distance_km: Optional[float] = None) -> dict:
    result = {
        "id": kg.id,
        "number": kg.number,
        "name": kg.name,
        "address": kg.address,
        "phone": kg.phone,
        "lat": kg.lat,
        "lon": kg.lon,
    }
    if distance_km is not None:
        result["distance_km"] = round(distance_km, 2)
    return result


# ─── Endpointlar ─────────────────────────────────────────────────────────────

@router.get("")
async def get_kindergartens():
    """Barcha bog'chalar ro'yxati."""
    kgs = await Kindergarten.filter(is_active=True).all()
    return {"kindergartens": [_kg_to_dict(kg) for kg in kgs]}


@router.get("/nearest")
async def get_nearest_kindergartens(
    lat: float = Query(..., description="Foydalanuvchi kengligi"),
    lon: float = Query(..., description="Foydalanuvchi uzunligi"),
    limit: int = Query(5, ge=1, le=30, description="Nechta bog'cha qaytarilsin"),
    max_km: float = Query(50.0, description="Maksimal masofa (km)"),
):
    """
    Foydalanuvchi joylashuviga eng yaqin bog'chalar.

    Misol: GET /api/kindergartens/nearest?lat=39.762&lon=67.274&limit=5

    Qaytaradi: masofa bo'yicha tartiblangan bog'chalar ro'yxati.
    """
    # Koordinata mantiqiy ekanligini tekshirish
    if not (-90 <= lat <= 90) or not (-180 <= lon <= 180):
        raise HTTPException(400, "Koordinatalar noto'g'ri")

    kgs = await Kindergarten.filter(is_active=True).all()

    # Har bir bog'cha uchun masofa hisoblash
    with_distance = []
    for kg in kgs:
        if kg.lat is None or kg.lon is None:
            continue
        try:
            km = _haversine_km(lat, lon, float(kg.lat), float(kg.lon))
            if km <= max_km:
                with_distance.append((kg, km))
        except (TypeError, ValueError):
            continue

    # Masofaga qarab tartiblash
    with_distance.sort(key=lambda x: x[1])

    return {
        "user_location": {"lat": lat, "lon": lon},
        "nearest": [_kg_to_dict(kg, km) for kg, km in with_distance[:limit]],
        "total_found": len(with_distance),
    }


@router.get("/{kg_id}")
async def get_kindergarten(kg_id: int):
    """Bog'cha tafsilotlari."""
    kg = await Kindergarten.get_or_none(id=kg_id)
    if not kg:
        raise HTTPException(404, "Bog'cha topilmadi")
    return {
        "id": kg.id,
        "number": kg.number,
        "name": kg.name,
        "address": kg.address,
        "phone": kg.phone,
        "lat": kg.lat,
        "lon": kg.lon,
        "is_active": kg.is_active,
    }
