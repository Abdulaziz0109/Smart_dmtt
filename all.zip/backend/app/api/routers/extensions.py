"""
SmartMMTB - API kengaytmalar (v3 - JSON + Tortoise hybrid)
Bot bilan sinxronizatsiya: children.json, attendance.json, clubs.json
"""
import json, os, random, string, math
from datetime import datetime, date
from typing import Optional, List
from fastapi import APIRouter, HTTPException, Request, Header
from pydantic import BaseModel
from pathlib import Path
from app.models.attendance import Attendance
from app.models.club import Enrollment

router = APIRouter()
DATA_DIR = Path("data")

# ─── JSON helpers ────────────────────────────────────────────────────────────

def _jload(fname):
    p = DATA_DIR / fname
    if not p.exists(): return []
    with open(p, encoding="utf-8") as f:
        d = json.load(f)
    return d if isinstance(d, list) else []

def _jload_dict(fname):
    p = DATA_DIR / fname
    if not p.exists(): return {}
    with open(p, encoding="utf-8") as f:
        return json.load(f)

def _jsave(fname, data):
    DATA_DIR.mkdir(exist_ok=True)
    with open(DATA_DIR / fname, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)

def _get_user(request: Request):
    return getattr(request.state, "user", None)

def _gen_billing():
    n = random.randint(1000, 9999)
    return f"MMTB-{n}"

def _gen_child_id():
    return f"CH{random.randint(1000000, 9999999)}"

def _gen_att_id():
    return f"ATT{random.randint(10000, 99999)}"

# ─── Models ──────────────────────────────────────────────────────────────────

class ChildCreate(BaseModel):
    full_name: str
    birth_date: Optional[str] = None
    gender: Optional[str] = "boy"
    kindergarten: Optional[str] = None
    group_name: Optional[str] = None

class ChildUpdate(BaseModel):
    full_name: Optional[str] = None
    birth_date: Optional[str] = None
    gender: Optional[str] = None
    kindergarten: Optional[str] = None
    group_name: Optional[str] = None

class PaymentWebhook(BaseModel):
    billing_id: str
    amount: float
    transaction_id: str
    method: str
    status: str = "completed"

class ClubCreate(BaseModel):
    name: str
    description: Optional[str] = None
    price: float = 0
    schedule: Optional[dict] = None
    room: Optional[str] = None
    capacity: int = 20
    kindergarten: Optional[str] = None
    teacher_id: Optional[str] = None
    day: Optional[str] = None
    time: Optional[str] = None

class AttendanceMark(BaseModel):
    child_id: str
    club_id: str
    date: str
    status: str  # present, absent, late, excused

class BulkAttendance(BaseModel):
    records: List[AttendanceMark]
    teacher_id: Optional[str] = None

class ProfileUpdate(BaseModel):
    full_name: Optional[str] = None
    language: Optional[str] = None
    phone: Optional[str] = None

class WaitlistReq(BaseModel):
    child_id: str
    club_id: str
    parent_note: Optional[str] = None

class AnnouncementCreate(BaseModel):
    title: str
    body: str
    type: Optional[str] = "info"  # info, warning, event

class EnrollReq(BaseModel):
    child_id: str
    club_id: str

# ─── /api/children ───────────────────────────────────────────────────────────

@router.get("/api/children")
async def get_my_children(request: Request):
    user = _get_user(request)
    uid = str(user.id) if user else None
    if not uid:
        raise HTTPException(401, "Avtorizatsiya talab qilinadi")

    children = _jload("children.json")
    clubs = {c["club_id"]: c for c in _jload("clubs.json")}
    att_records = _jload("attendance.json")
    registrations = _jload("registrations.json")

    my_children = [c for c in children if str(c.get("parent_id")) == uid]

    today = date.today().isoformat()
    result = []
    for ch in my_children:
        cid = ch.get("child_id") or ch.get("id")

        # To'garaklar
        enrolled = [r for r in registrations if str(r.get("child_id")) == str(cid) and r.get("status", "active") == "active"]
        enrolled_clubs = []
        for e in enrolled:
            club = clubs.get(e.get("club_id"))
            if club:
                enrolled_clubs.append({
                    "club_id": club["club_id"],
                    "club_name": club["name"],
                    "schedule": f"{club.get('day','')} {club.get('time','')}".strip(),
                    "price": club.get("price", 0),
                })

        # Bugungi davomat
        today_att = next((a["status"] for a in att_records if str(a.get("child_id")) == str(cid) and a.get("date") == today), None)

        # Gamification: to'garakdagi davomatlardan ball
        total_pts = sum(1 for a in att_records if str(a.get("child_id")) == str(cid) and a.get("status") == "present")

        result.append({
            "id": cid,
            "child_id": cid,
            "full_name": ch.get("full_name", ""),
            "birth_date": ch.get("birth_date"),
            "gender": ch.get("gender", "boy"),
            "group_name": ch.get("guruh") or ch.get("group_name"),
            "kindergarten": ch.get("kindergarten"),
            "billing_id": ch.get("billing_id") or _gen_billing(),
            "total_points": total_pts * 10,
            "enrollments": enrolled_clubs,
            "attendance": {"today": today_att},
        })
    return {"children": result}

@router.post("/api/children")
async def create_child(child: ChildCreate, request: Request):
    user = _get_user(request)
    uid = str(user.id) if user else None
    if not uid:
        raise HTTPException(401, "Avtorizatsiya talab qilinadi")

    children = _jload("children.json")
    cid = _gen_child_id()
    billing_id = _gen_billing()

    new_child = {
        "child_id": cid,
        "parent_id": uid,
        "full_name": child.full_name,
        "birth_date": child.birth_date or "",
        "gender": child.gender or "boy",
        "guruh": child.group_name or "",
        "kindergarten": child.kindergarten or "",
        "billing_id": billing_id,
        "created_at": datetime.now().isoformat(),
    }
    children.append(new_child)
    _jsave("children.json", children)

    return {"id": cid, "child_id": cid, "full_name": child.full_name, "billing_id": billing_id, "ok": True}

@router.put("/api/children/{child_id}")
async def update_child(child_id: str, update: ChildUpdate, request: Request):
    user = _get_user(request)
    uid = str(user.id) if user else None

    children = _jload("children.json")
    ch = next((c for c in children if str(c.get("child_id")) == str(child_id) and str(c.get("parent_id")) == uid), None)
    if not ch:
        raise HTTPException(404, "Farzand topilmadi")

    if update.full_name: ch["full_name"] = update.full_name
    if update.birth_date: ch["birth_date"] = update.birth_date
    if update.gender: ch["gender"] = update.gender
    if update.kindergarten: ch["kindergarten"] = update.kindergarten
    if update.group_name: ch["guruh"] = update.group_name

    _jsave("children.json", children)
    return {"ok": True}

@router.delete("/api/children/{child_id}")
async def delete_child(child_id: str, request: Request):
    user = _get_user(request)
    uid = str(user.id) if user else None

    children = _jload("children.json")
    before = len(children)
    children = [c for c in children if not (str(c.get("child_id")) == str(child_id) and str(c.get("parent_id")) == uid)]
    if len(children) == before:
        raise HTTPException(404, "Farzand topilmadi yoki ruxsat yo'q")

    _jsave("children.json", children)
    return {"ok": True}

# ─── /api/attendance ──────────────────────────────────────────────────────────

@router.get("/api/attendance/child/{child_id}")
async def get_child_attendance(child_id: str, month: Optional[str] = None, request: Request = None):
    att_records = _jload("attendance.json")
    clubs = {c["club_id"]: c for c in _jload("clubs.json")}

    records = [a for a in att_records if str(a.get("child_id")) == str(child_id)]

    if month:
        records = [a for a in records if a.get("date", "").startswith(month)]

    records.sort(key=lambda x: x.get("date", ""), reverse=True)
    records = records[:90]

    result = []
    for r in records:
        club = clubs.get(r.get("club_id"), {})
        result.append({
            "date": r.get("date"),
            "status": r.get("status"),
            "club_name": club.get("name", "—"),
            "reason": r.get("reason", ""),
        })

    total = len(result)
    present = sum(1 for r in result if r["status"] == "present")
    absent = sum(1 for r in result if r["status"] == "absent")

    return {
        "records": result,
        "stats": {
            "total": total,
            "present": present,
            "absent": absent,
            "rate": round(present / total * 100) if total else 0,
        }
    }

@router.post("/api/attendance/mark")
async def mark_attendance_bulk(data: BulkAttendance, request: Request):
    att_records = _jload("attendance.json")
    today = data.records[0].date if data.records else date.today().isoformat()

    for item in data.records:
        # Mavjud yozuvni yangilash yoki yangi qo'shish
        existing = next((a for a in att_records
                         if str(a.get("child_id")) == str(item.child_id)
                         and a.get("date") == item.date
                         and a.get("club_id") == item.club_id), None)
        if existing:
            existing["status"] = item.status
        else:
            att_records.append({
                "att_id": _gen_att_id(),
                "child_id": item.child_id,
                "club_id": item.club_id,
                "date": item.date,
                "status": item.status,
                "reason": "",
                "parent_status": "",
                "teacher_id": str(data.teacher_id or ""),
                "recorded_at": datetime.now().isoformat(),
            })

    _jsave("attendance.json", att_records)
    return {"ok": True, "saved": len(data.records)}


@router.post("/attendance/bulk")
async def save_attendance_bulk(request: Request):
    """
    Saves attendance records to SQLite (not JSON files).
    Called from TeacherTab after teacher marks students.
    """
    data = await request.json()
    records = data.get("records", [])
    today = date.today().isoformat()
    saved = 0

    for rec in records:
        child_id = rec.get("child_id")
        club_id = rec.get("club_id")
        rec_date = rec.get("date", today)
        status = rec.get("status", "absent")

        if status not in ("present", "absent", "late", "excused"):
            continue

        # Find enrollment
        enrollment = await Enrollment.get_or_none(
            child_id=child_id,
            club_id=club_id,
            status="active"
        )
        if not enrollment:
            continue

        # Upsert: update if exists, create if not
        existing = await Attendance.get_or_none(
            enrollment_id=enrollment.id,
            date=rec_date
        )
        if existing:
            existing.status = status
            existing.teacher_confirmed = True
            await existing.save()
        else:
            await Attendance.create(
                enrollment_id=enrollment.id,
                date=rec_date,
                status=status,
                teacher_confirmed=True,
            )
        saved += 1

    return {"ok": True, "saved": saved}


# ─── /api/payments ────────────────────────────────────────────────────────────

@router.get("/api/payments/history")
async def get_payment_history(request: Request):
    user = _get_user(request)
    uid = str(user.id) if user else None
    if not uid:
        raise HTTPException(401, "Avtorizatsiya talab qilinadi")

    children = _jload("children.json")
    my_child_ids = {str(c.get("child_id")) for c in children if str(c.get("parent_id")) == uid}

    payments = _jload("payments.json")
    clubs = {c["club_id"]: c for c in _jload("clubs.json")}
    child_map = {str(c.get("child_id")): c for c in children}

    my_payments = [p for p in payments if str(p.get("child_id")) in my_child_ids]
    my_payments.sort(key=lambda x: x.get("date", ""), reverse=True)

    result = []
    for p in my_payments[:50]:
        ch = child_map.get(str(p.get("child_id")), {})
        club = clubs.get(p.get("club_id"), {})
        result.append({
            "id": p.get("payment_id") or p.get("id"),
            "child_name": ch.get("full_name", "—"),
            "club_name": club.get("name", "—"),
            "amount": float(p.get("amount", 0)),
            "method": p.get("method", "cash"),
            "status": p.get("status", "completed"),
            "date": p.get("date"),
            "transaction_id": p.get("transaction_id", ""),
        })

    total_paid = sum(float(p["amount"]) for p in result if p["status"] == "completed")
    return {"payments": result, "total_paid": total_paid}

@router.post("/api/payments/webhook")
async def payment_webhook(req: PaymentWebhook):
    children = _jload("children.json")
    payments = _jload("payments.json")
    clubs = _jload("clubs.json")
    registrations = _jload("registrations.json")

    # billing_id bo'yicha farzand topish
    child = next((c for c in children if c.get("billing_id") == req.billing_id), None)
    if not child:
        # MMTB-1234 formatdan raqam ajratish
        cid = req.billing_id.replace("MMTB-", "")
        child = next((c for c in children if str(c.get("child_id", "")).replace("CH", "") == cid.replace("CH", "")), None)
    if not child:
        raise HTTPException(404, f"Billing ID topilmadi: {req.billing_id}")

    # Faol klub topish
    enrollment = next((r for r in registrations if str(r.get("child_id")) == str(child.get("child_id")) and r.get("status") == "active"), None)
    club_id = enrollment.get("club_id") if enrollment else ""

    pay_id = f"PAY{random.randint(10000, 99999)}"
    payments.append({
        "payment_id": pay_id,
        "child_id": child.get("child_id"),
        "club_id": club_id,
        "amount": req.amount,
        "method": req.method,
        "status": req.status,
        "transaction_id": req.transaction_id,
        "date": datetime.now().isoformat(),
    })
    _jsave("payments.json", payments)

    # Telegram xabar
    try:
        import config, requests as _req
        parent_id = child.get("parent_id")
        club = next((c for c in clubs if c["club_id"] == club_id), {})
        _req.post(f"https://api.telegram.org/bot{config.TOKEN}/sendMessage", json={
            "chat_id": parent_id,
            "parse_mode": "HTML",
            "text": (
                f"✅ <b>To'lov tasdiqlandi!</b>\n\n"
                f"👦 {child.get('full_name')}\n"
                f"💰 {req.amount:,.0f} so'm\n"
                f"💳 {req.method.title()}\n"
                f"🎯 {club.get('name', '—')}\n"
                f"🆔 {req.transaction_id[:20]}"
            )
        }, timeout=5)
    except:
        pass

    return {"ok": True, "payment_id": pay_id}

# ─── /api/users/me ────────────────────────────────────────────────────────────

@router.get("/api/users/me")
async def get_me(request: Request):
    user = _get_user(request)
    if not user:
        raise HTTPException(401, "Avtorizatsiya talab qilinadi")
    return {
        "id": str(user.id),
        "full_name": user.full_name,
        "phone": user.phone,
        "username": user.username,
        "role": user.role,
        "language": user.language,
        "kindergarten": user.kindergarten,
    }

@router.put("/api/users/me")
async def update_me(update: ProfileUpdate, request: Request):
    user = _get_user(request)
    if not user:
        raise HTTPException(401, "Avtorizatsiya talab qilinadi")

    # Tortoise da yangilash
    if update.full_name: user.full_name = update.full_name
    if update.language: user.language = update.language
    if update.phone: user.phone = update.phone
    await user.save()

    # JSON da ham yangilash (bot sinxronizatsiyasi)
    users = _jload("users.json")
    u = next((u for u in users if str(u.get("user_id")) == str(user.id)), None)
    if u:
        if update.full_name: u["full_name"] = update.full_name
        if update.language: u["language"] = update.language
        if update.phone: u["phone"] = update.phone
        _jsave("users.json", users)

    return {"ok": True}

# ─── /api/clubs CRUD ─────────────────────────────────────────────────────────

@router.post("/api/clubs")
async def create_club(club: ClubCreate, request: Request):
    user = _get_user(request)
    if not user or not any(r in (user.role or "") for r in ["admin", "director", "Iqtisodchi", "Admin"]):
        raise HTTPException(403, "Faqat admin uchun")

    clubs = _jload("clubs.json")
    max_id = max((int(c["club_id"].replace("CL", "")) for c in clubs if c.get("club_id", "").startswith("CL") and c["club_id"][2:].isdigit()), default=0)
    new_id = f"CL{max_id + 1}"

    new_club = {
        "club_id": new_id,
        "name": club.name,
        "description": club.description or "",
        "day": (club.schedule or {}).get("days") or club.day or "",
        "time": (club.schedule or {}).get("time") or club.time or "",
        "room": club.room or "",
        "kindergarten": club.kindergarten or "",
        "price": str(club.price),
        "capacity": str(club.capacity),
        "teacher_id": str(club.teacher_id or ""),
        "is_active": True,
        "created_at": datetime.now().isoformat(),
    }
    clubs.append(new_club)
    _jsave("clubs.json", clubs)
    return {"id": new_id, "club_id": new_id, "name": club.name, "ok": True}

@router.put("/api/clubs/{club_id}")
async def update_club(club_id: str, update: ClubCreate, request: Request):
    user = _get_user(request)
    if not user or not any(r in (user.role or "") for r in ["admin", "director", "Iqtisodchi", "Admin"]):
        raise HTTPException(403, "Faqat admin uchun")

    clubs = _jload("clubs.json")
    club = next((c for c in clubs if c.get("club_id") == club_id), None)
    if not club:
        raise HTTPException(404, "To'garak topilmadi")

    club["name"] = update.name
    club["price"] = str(update.price)
    club["capacity"] = str(update.capacity)
    if update.room: club["room"] = update.room
    if update.kindergarten: club["kindergarten"] = update.kindergarten
    if update.description: club["description"] = update.description
    if update.schedule:
        club["day"] = update.schedule.get("days", club.get("day", ""))
        club["time"] = update.schedule.get("time", club.get("time", ""))
    elif update.day:
        club["day"] = update.day
        club["time"] = update.time or club.get("time", "")

    _jsave("clubs.json", clubs)
    return {"ok": True}

@router.delete("/api/clubs/{club_id}")
async def delete_club(club_id: str, request: Request):
    user = _get_user(request)
    if not user or not any(r in (user.role or "") for r in ["admin", "director", "Iqtisodchi", "Admin"]):
        raise HTTPException(403, "Faqat admin uchun")

    clubs = _jload("clubs.json")
    club = next((c for c in clubs if c.get("club_id") == club_id), None)
    if not club:
        raise HTTPException(404, "To'garak topilmadi")

    club["is_active"] = False
    _jsave("clubs.json", clubs)
    return {"ok": True}

# ─── /api/kindergartens ───────────────────────────────────────────────────────

@router.get("/api/kindergartens-json")
async def get_kindergartens_json(lat: Optional[float] = None, lon: Optional[float] = None):
    data = _jload_dict("kindergartens.json")
    kgs = data.get("kindergartens", data) if isinstance(data, dict) else data

    if lat and lon:
        def dist(k):
            R = 6371
            dlat = (k["lat"] - lat) * math.pi / 180
            dlon = (k["lon"] - lon) * math.pi / 180
            a = math.sin(dlat/2)**2 + math.cos(lat*math.pi/180)*math.cos(k["lat"]*math.pi/180)*math.sin(dlon/2)**2
            return R * 2 * math.asin(math.sqrt(a))
        for k in kgs:
            k["distance_km"] = round(dist(k), 2)
        kgs.sort(key=lambda x: x.get("distance_km", 0))

    return {"kindergartens": kgs}

# ─── /api/waitlist ────────────────────────────────────────────────────────────

@router.post("/api/waitlist")
async def join_waitlist(req: WaitlistReq, request: Request):
    waitlist = _jload("waitlist.json") if (DATA_DIR / "waitlist.json").exists() else []
    children = _jload("children.json")
    clubs = _jload("clubs.json")

    child = next((c for c in children if str(c.get("child_id")) == str(req.child_id)), None)
    club = next((c for c in clubs if str(c.get("club_id")) == str(req.club_id)), None)
    if not child: raise HTTPException(404, "Bola topilmadi")
    if not club: raise HTTPException(404, "To'garak topilmadi")

    already = next((w for w in waitlist if str(w.get("child_id")) == str(req.child_id) and str(w.get("club_id")) == str(req.club_id)), None)
    if already:
        position = waitlist.index(already) + 1
        return {"ok": True, "already_in_queue": True, "position": position}

    waitlist.append({
        "child_id": req.child_id, "club_id": req.club_id,
        "child_name": child.get("full_name"), "club_name": club.get("name"),
        "parent_id": child.get("parent_id"), "note": req.parent_note or "",
        "added_at": datetime.now().isoformat(),
    })
    _jsave("waitlist.json", waitlist)

    club_queue = [w for w in waitlist if str(w.get("club_id")) == str(req.club_id)]
    position = len(club_queue)

    # Adminni xabardor qilish
    try:
        import config, requests as _req
        _req.post(f"https://api.telegram.org/bot{config.TOKEN}/sendMessage", json={
            "chat_id": config.ADMIN_CHAT_ID,
            "text": f"📋 Navbat: {child['full_name']} → {club['name']} ({position}-o'rin)",
        }, timeout=5)
    except: pass

    return {"ok": True, "position": position, "message": f"{position}-o'rinda navbatga yozildingiz"}

# ─── /api/enroll (WebApp version) ─────────────────────────────────────────────

@router.post("/api/enroll/webapp")
async def enroll_webapp(req: EnrollReq, request: Request):
    user = _get_user(request)
    uid = str(user.id) if user else None
    if not uid:
        raise HTTPException(401, "Avtorizatsiya talab qilinadi")

    children = _jload("children.json")
    clubs = _jload("clubs.json")
    registrations = _jload("registrations.json")

    child = next((c for c in children if str(c.get("child_id")) == str(req.child_id) and str(c.get("parent_id")) == uid), None)
    if not child: raise HTTPException(404, "Farzand topilmadi")

    club = next((c for c in clubs if str(c.get("club_id")) == str(req.club_id)), None)
    if not club: raise HTTPException(404, "To'garak topilmadi")

    # Allaqachon ro'yxatda?
    already = next((r for r in registrations if str(r.get("child_id")) == str(req.child_id) and str(r.get("club_id")) == str(req.club_id) and r.get("status") == "active"), None)
    if already:
        return {"ok": True, "message": "Allaqachon yozilgan", "already": True}

    # Sig'im tekshirish
    capacity = int(club.get("capacity", 20))
    enrolled_count = sum(1 for r in registrations if str(r.get("club_id")) == str(req.club_id) and r.get("status") == "active")
    if enrolled_count >= capacity:
        return {"ok": False, "full": True, "message": "Guruh to'lgan. Navbatga yozilishingiz mumkin."}

    registrations.append({
        "reg_id": f"REG{random.randint(10000, 99999)}",
        "child_id": req.child_id,
        "club_id": req.club_id,
        "status": "active",
        "enrolled_at": datetime.now().isoformat(),
    })
    _jsave("registrations.json", registrations)
    return {"ok": True, "message": "Muvaffaqiyatli yozildi"}

# ─── /api/announcements ───────────────────────────────────────────────────────

@router.get("/api/announcements")
async def get_announcements():
    ann = _jload("announcements.json") if (DATA_DIR / "announcements.json").exists() else []
    ann.sort(key=lambda x: x.get("created_at", ""), reverse=True)
    return {"announcements": ann[:20]}

@router.post("/api/announcements")
async def create_announcement(ann: AnnouncementCreate, request: Request):
    user = _get_user(request)
    if not user or not any(r in (user.role or "") for r in ["admin", "director", "Iqtisodchi", "Admin"]):
        raise HTTPException(403, "Faqat admin uchun")

    items = _jload("announcements.json") if (DATA_DIR / "announcements.json").exists() else []
    items.insert(0, {
        "id": f"ANN{random.randint(1000, 9999)}",
        "title": ann.title, "body": ann.body, "type": ann.type,
        "author": user.full_name or "", "created_at": datetime.now().isoformat(),
    })
    _jsave("announcements.json", items)
    return {"ok": True}

# ─── /api/analytics ───────────────────────────────────────────────────────────

@router.get("/api/analytics/overview")
async def analytics_overview():
    children = _jload("children.json")
    clubs = _jload("clubs.json")
    registrations = _jload("registrations.json")
    payments = _jload("payments.json")
    att = _jload("attendance.json")

    today = date.today().isoformat()
    today_att = [a for a in att if a.get("date") == today]

    total_revenue = sum(float(p.get("amount", 0)) for p in payments if p.get("status") == "completed")

    return {
        "total_children": len(children),
        "total_students": len(set(r.get("child_id") for r in registrations if r.get("status") == "active")),
        "active_clubs": sum(1 for c in clubs if c.get("is_active", True) != False),
        "today_present": sum(1 for a in today_att if a.get("status") == "present"),
        "today_absent": sum(1 for a in today_att if a.get("status") == "absent"),
        "total_revenue": total_revenue,
        "total_debtors": 0,  # Hisoblash uchun to'lov logikasi kerak
    }

@router.get("/api/analytics/debtors-list")
async def debtors_list():
    children = _jload("children.json")
    registrations = _jload("registrations.json")
    payments = _jload("payments.json")
    clubs = _jload("clubs.json")
    users = _jload("users.json")

    club_map = {c["club_id"]: c for c in clubs}
    user_map = {str(u.get("user_id")): u for u in users}
    child_map = {c.get("child_id"): c for c in children}

    # Har aktiv yozilgan uchun oxirgi oy to'lovini tekshirish
    today = date.today()
    current_month = today.strftime("%Y-%m")

    debtors = []
    for reg in registrations:
        if reg.get("status") != "active":
            continue
        cid = str(reg.get("child_id"))
        club_id = reg.get("club_id")
        club = club_map.get(club_id, {})
        child = child_map.get(cid, {})
        parent = user_map.get(str(child.get("parent_id")), {})

        # Bu oy to'lov qilinganmi?
        paid = any(
            str(p.get("child_id")) == cid
            and p.get("club_id") == club_id
            and p.get("date", "").startswith(current_month)
            and p.get("status") == "completed"
            for p in payments
        )
        if not paid:
            debtors.append({
                "child_name": child.get("full_name", "—"),
                "parent_name": parent.get("full_name", "—"),
                "club_name": club.get("name", "—"),
                "debt": float(club.get("price", 0)),
                "months": 1,
            })

    return {"debtors": debtors[:50]}

@router.get("/api/analytics/clubs-stats")
async def clubs_stats():
    clubs = _jload("clubs.json")
    registrations = _jload("registrations.json")
    payments = _jload("payments.json")

    result = []
    for club in clubs:
        if club.get("is_active") == False:
            continue
        cid = club["club_id"]
        enrolled = sum(1 for r in registrations if r.get("club_id") == cid and r.get("status") == "active")
        revenue = sum(float(p.get("amount", 0)) for p in payments if p.get("club_id") == cid and p.get("status") == "completed")
        result.append({
            "id": cid,
            "name": club.get("name"),
            "kindergarten": club.get("kindergarten"),
            "enrolled_count": enrolled,
            "capacity": int(club.get("capacity", 20)),
            "price": float(club.get("price", 0)),
            "total_revenue": revenue,
            "student_count": enrolled,
        })

    result.sort(key=lambda x: x["total_revenue"], reverse=True)
    return result


@router.post("/api/attendance/bulk")
async def save_attendance_bulk(request: Request):
    """
    Saves attendance records to SQLite (not JSON files).
    Called from TeacherTab after teacher marks students.
    
    Body: {
      "records": [
        {"child_id": 1, "club_id": 3, "date": "2025-03-08", "status": "present"},
        ...
      ],
      "teacher_id": 123
    }
    """
    data = await request.json()
    records = data.get("records", [])
    today = date.today().isoformat()
    saved = 0

    for rec in records:
        child_id = rec.get("child_id")
        club_id = rec.get("club_id")
        rec_date = rec.get("date", today)
        status = rec.get("status", "absent")

        if status not in ("present", "absent", "late", "excused"):
            continue

        # Find enrollment
        enrollment = await Enrollment.get_or_none(
            child_id=child_id,
            club_id=club_id,
            status="active"
        )
        if not enrollment:
            continue

        # Upsert: update if exists, create if not
        existing = await Attendance.get_or_none(
            enrollment_id=enrollment.id,
            date=rec_date
        )
        if existing:
            existing.status = status
            existing.teacher_confirmed = True
            await existing.save()
        else:
            await Attendance.create(
                enrollment_id=enrollment.id,
                date=rec_date,
                status=status,
                teacher_confirmed=True,
            )
        saved += 1

    return {"ok": True, "saved": saved}
