from fastapi import APIRouter, HTTPException, Header
from pydantic import BaseModel
from typing import Optional
from datetime import date
import os

from app.models import Child, Enrollment, Attendance

router = APIRouter()

DEVICE_TOKEN = os.getenv("FACE_DEVICE_TOKEN", "device_secret_token_change_me")

# ─── Modellar ────────────────────────────────────────────────

class FaceMarkRequest(BaseModel):
    child_id: str
    full_name: str
    date: str          # "2025-01-15"
    time: str          # "08:05"
    kindergarten: str
    status: str = "present"

class KindergartenCreate(BaseModel):
    name: str
    address: str
    lat: float
    lon: float
    phone: Optional[str] = None

class WaitlistRequest(BaseModel):
    child_id: int
    club_id: int
    parent_note: Optional[str] = None

# ─── Face ID Davomat ─────────────────────────────────────────

@router.post("/attendance/face-mark")
async def face_mark_attendance(
    req: FaceMarkRequest,
    authorization: Optional[str] = Header(None)
):
    """
    Yuz tanish qurilmasidan davomat belgilash.
    Device token bilan himoyalangan.
    """
    # Device autentifikatsiya
    if not authorization or not authorization.startswith("Bearer "):
        raise HTTPException(status_code=401, detail="Device token kerak")
    token = authorization.split(" ")[1]
    if token != DEVICE_TOKEN:
        raise HTTPException(status_code=403, detail="Noto'g'ri device token")

    # Bolani topish
    child = await Child.get_or_none(billing_id=req.child_id)
    if not child:
        # ID raqam bo'yicha topish
        try:
            cid = int(req.child_id.replace("CH","").replace("MMTB-",""))
            child = await Child.get_or_none(id=cid)
        except:
            pass

    if not child:
        return {"ok": False, "message": f"Bola topilmadi: {req.child_id}"}

    # Bugungi davomat bor mi?
    today = date.fromisoformat(req.date)
    existing = await Attendance.filter(
        enrollment__child=child,
        date=today
    ).first()

    if existing:
        return {"ok": True, "already_marked": True, "message": f"{req.full_name} bugun allaqachon belgilangan"}

    # Faol enrollment topish
    enrollment = await Enrollment.filter(child=child, status="active").first()
    if not enrollment:
        return {"ok": False, "message": "Faol to'garakka yozilgan emas"}

    # Davomatni yozish
    await Attendance.create(
        enrollment=enrollment,
        date=today,
        status="present", # Face ID orqali kelgan davomat har doim "present" bo'ladi
        reason="FaceID Device"
    )

    return {"ok": True, "message": f"{req.full_name} uchun davomat belgilandi"}
