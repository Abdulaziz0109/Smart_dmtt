"""
SmartDMTT v4 — Attendance API router
/mark — muallim davomat belgilash
/bulk  — bir vaqtda ko'pchilik
/summary — kunlik hisobot
"""
import logging
from datetime import date, timedelta
from typing import Literal

from fastapi import APIRouter, Depends, HTTPException, Query
from pydantic import BaseModel

from app.api.deps import get_current_user
from app.models.user import User
from app.models.child import Child
from app.models.club import Club, Enrollment
from app.models.attendance import Attendance, AbsenceNotice

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/attendance", tags=["attendance"])

AttStatus = Literal["present", "absent", "late", "excused"]

# ── Auth helper ──────────────────────────────────────────
def _require_teacher(user: User):
    role = (user.role or "").lower()
    if role not in ("teacher", "togarak_rahbari", "director", "admin", "boshliq", "mmtb_boshligi"):
        raise HTTPException(403, "Ruxsat yo'q")


# ── 1. Bitta davomat belgilash ──────────────────────────
class MarkBody(BaseModel):
    enrollment_id: int
    status: AttStatus
    date: str | None = None          # YYYY-MM-DD, bo'sh bo'lsa bugun

@router.post("/mark")
async def mark_attendance(
    body: MarkBody,
    current_user: User = Depends(get_current_user),
):
    _require_teacher(current_user)

    target_date = date.fromisoformat(body.date) if body.date else date.today()

    enr = await Enrollment.get_or_none(id=body.enrollment_id)
    if not enr:
        raise HTTPException(404, "Yozilish topilmadi")

    # Muallim faqat o'z to'garagini belgilaydi
    if current_user.role in ("teacher", "togarak_rahbari"):
        club = await Club.get_or_none(id=enr.club_id)
        if not club or club.teacher_id != current_user.id:
            raise HTTPException(403, "Siz bu to'garakni boshqarmaysiz")

    att, created = await Attendance.get_or_create(
        enrollment_id=enr.id,
        date=target_date,
        defaults={"status": body.status}
    )
    if not created:
        att.status = body.status
        await att.save()

    # Ota-onaga xabar (notifier)
    try:
        from app.services.notifier import notify_attendance
        teacher_name = current_user.full_name or ""
        await notify_attendance(enr.id, body.status, teacher_name)
    except Exception as e:
        logger.warning(f"Notifier xato: {e}")

    return {"ok": True, "id": att.id, "status": body.status, "date": str(target_date)}


# ── 2. Bulk davomat (bir vaqtda ko'pchilik) ─────────────
class BulkItem(BaseModel):
    enrollment_id: int
    status: AttStatus

class BulkBody(BaseModel):
    records: list[BulkItem]
    date: str | None = None

@router.post("/bulk")
async def bulk_mark(
    body: BulkBody,
    current_user: User = Depends(get_current_user),
):
    _require_teacher(current_user)
    target_date = date.fromisoformat(body.date) if body.date else date.today()
    saved = 0

    for item in body.records:
        enr = await Enrollment.get_or_none(id=item.enrollment_id)
        if not enr:
            continue
        att, created = await Attendance.get_or_create(
            enrollment_id=enr.id,
            date=target_date,
            defaults={"status": item.status}
        )
        if not created:
            att.status = item.status
            await att.save()
        saved += 1

        try:
            from app.services.notifier import notify_attendance
            await notify_attendance(enr.id, item.status, current_user.full_name or "")
        except Exception:
            pass

    return {"ok": True, "saved": saved}


# ── 3. To'garak bo'yicha kunlik davomat holati ──────────
@router.get("/club/{club_id}/today")
async def club_today(
    club_id: int,
    target_date: str = Query(None),
    current_user: User = Depends(get_current_user),
):
    _require_teacher(current_user)
    d = date.fromisoformat(target_date) if target_date else date.today()

    enrollments = await Enrollment.filter(club_id=club_id, status="active").all()
    if not enrollments:
        return {"date": str(d), "records": []}

    enr_ids   = [e.id for e in enrollments]
    att_map   = {
        a.enrollment_id: a.status
        for a in await Attendance.filter(enrollment_id__in=enr_ids, date=d).all()
    }
    absence_ids = {
        a.enrollment_id
        for a in await AbsenceNotice.filter(enrollment_id__in=enr_ids, date=d).all()
    }

    records = []
    for enr in enrollments:
        child = await Child.get_or_none(id=enr.child_id)
        records.append({
            "enrollment_id": enr.id,
            "child_id":      enr.child_id,
            "child_name":    child.full_name if child else "—",
            "payment_id":    enr.payment_id,
            "status":        att_map.get(enr.id),         # None = belgilanmagan
            "has_notice":    enr.id in absence_ids,
        })

    present = sum(1 for r in records if r["status"] == "present")
    absent  = sum(1 for r in records if r["status"] == "absent")
    total   = len(records)

    return {
        "date":    str(d),
        "total":   total,
        "present": present,
        "absent":  absent,
        "pct":     round(present / total * 100) if total else 0,
        "records": records,
    }


# ── 4. Haftalik hisobot ─────────────────────────────────
@router.get("/club/{club_id}/weekly")
async def club_weekly(
    club_id: int,
    current_user: User = Depends(get_current_user),
):
    _require_teacher(current_user)
    today      = date.today()
    week_start = today - timedelta(days=today.weekday())

    enrollments = await Enrollment.filter(club_id=club_id, status="active").all()
    enr_ids     = [e.id for e in enrollments]
    total       = len(enrollments)

    days = []
    for i in range(7):
        d = week_start + timedelta(days=i)
        if d > today:
            break
        present = await Attendance.filter(
            enrollment_id__in=enr_ids, date=d, status="present"
        ).count() if enr_ids else 0
        pct = round(present / total * 100) if total else 0
        days.append({
            "date":    str(d),
            "present": present,
            "total":   total,
            "pct":     pct,
        })

    return {"club_id": club_id, "week_start": str(week_start), "days": days}


# ── 5. Ota-ona: farzand davomati ─────────────────────────
@router.get("/child/{child_id}")
async def child_attendance(
    child_id: int,
    days:     int = Query(30, le=90),
    current_user: User = Depends(get_current_user),
):
    child = await Child.get_or_none(id=child_id)
    if not child:
        raise HTTPException(404, "Bola topilmadi")

    # Ota-ona faqat o'z farzandini ko'radi
    if current_user.role == "parent" and child.parent_id != current_user.id:
        raise HTTPException(403, "Ruxsat yo'q")

    since       = date.today() - timedelta(days=days)
    enrollments = await Enrollment.filter(child_id=child_id, status="active").all()
    enr_ids     = [e.id for e in enrollments]

    records = await Attendance.filter(
        enrollment_id__in=enr_ids, date__gte=since
    ).order_by("-date").all()

    present = sum(1 for r in records if r.status == "present")
    total   = len(records)

    return {
        "child_id":   child_id,
        "child_name": child.full_name,
        "total":      total,
        "present":    present,
        "pct":        round(present / total * 100) if total else 0,
        "records": [
            {"date": str(r.date), "status": r.status, "enrollment_id": r.enrollment_id}
            for r in records
        ]
    }
