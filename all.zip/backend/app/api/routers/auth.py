"""
SmartDMTT v4.0 — Authentication Router
Spec 3.1–3.6 bo'yicha:
- Bot: telefon ulash → avtomatik kirish (OTP yo'q)
- WebApp: initData → avtomatik kirish (OTP yo'q)
- Brauzer: Telefon + Parol → JWT
- Yangi qurilma: xabar boradi (OTP yo'q!)
- Primary qurilma HECH QACHON o'chirilmaydi
"""
import hashlib
import logging
import time
from datetime import datetime
from typing import Optional

import bcrypt
from aiogram import Bot
from fastapi import APIRouter, HTTPException, Request, Depends
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from pydantic import BaseModel

from app.core import config
from app.models.user import User
from app.models.device import Device
from app.services.redis_service import RedisService
from app.services.token_service import TokenService

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/auth", tags=["auth"])
security = HTTPBearer(auto_error=False)


# ─── Pydantic modellari ───────────────────────────────────────────────────────

class LoginRequest(BaseModel):
    phone: str
    password: str
    device_id: Optional[str] = None
    device_info: Optional[str] = None  # "Chrome • Windows 10"


class TelegramLoginRequest(BaseModel):
    initData: str


class ChangePasswordRequest(BaseModel):
    old_password: str
    new_password: str


# ─── Yordamchi funksiyalar ────────────────────────────────────────────────────

def _normalize_phone(phone: str) -> str:
    p = phone.replace(" ", "").replace("-", "").replace("(", "").replace(")", "")
    if not p.startswith("+"):
        p = "+" + p
    return p


def _hash_password(password: str) -> str:
    return bcrypt.hashpw(password.encode(), bcrypt.gensalt()).decode()


def _verify_password(password: str, hashed: str) -> bool:
    try:
        return bcrypt.checkpw(password.encode(), hashed.encode())
    except Exception:
        return False


def _get_device_hash(request: Request, device_id: Optional[str]) -> str:
    if device_id:
        return hashlib.sha256(device_id.encode()).hexdigest()
    ua = request.headers.get("user-agent", "")
    ip = request.client.host if request.client else ""
    return hashlib.sha256(f"{ip}:{ua}".encode()).hexdigest()


def _get_device_info(request: Request, device_info: Optional[str]) -> str:
    if device_info:
        return device_info
    ua = request.headers.get("user-agent", "")
    if "Chrome" in ua:
        browser = "Chrome"
    elif "Firefox" in ua:
        browser = "Firefox"
    elif "Safari" in ua:
        browser = "Safari"
    else:
        browser = "Browser"

    if "Windows" in ua:
        os_name = "Windows"
    elif "Android" in ua:
        os_name = "Android"
    elif "iPhone" in ua or "iPad" in ua:
        os_name = "iOS"
    elif "Linux" in ua:
        os_name = "Linux"
    else:
        os_name = "Unknown"

    return f"{browser} • {os_name}"


async def _send_new_device_notification(user: User, device_info: str):
    """Yangi qurilmadan kirish xabari (OTP yo'q — faqat xabar)."""
    if not user.telegram_id:
        return
    try:
        now = datetime.now().strftime("%d.%m.%Y • %H:%M")
        async with Bot(token=config.TOKEN) as bot:
            await bot.send_message(
                user.telegram_id,
                f"🔔 <b>SmartDMTT WebApp ga yangi kirish</b>\n\n"
                f"📱 Qurilma: {device_info}\n"
                f"🕐 Vaqt: {now}\n"
                f"📍 SmartDMTT saytiga kirish amalga oshirildi\n\n"
                f"Agar bu siz bo'lsangiz — hech narsa qilmang ✅\n"
                f"Agar bu siz bo'lmasangiz — /parol buyrug'i bilan parolingizni o'zgartiring.",
                parse_mode="HTML"
            )
    except Exception as e:
        logger.warning(f"Yangi qurilma xabari yuborilmadi: {e}")


async def _get_current_user(
    credentials: HTTPAuthorizationCredentials = Depends(security)
) -> User:
    if not credentials:
        raise HTTPException(401, "Avtorizatsiya talab etiladi")
    try:
        payload = TokenService.decode_token(credentials.credentials)
        user_id = int(payload["sub"])
        user = await User.get_or_none(id=user_id)
        if not user:
            raise HTTPException(401, "Foydalanuvchi topilmadi")
        if user.is_blocked:
            raise HTTPException(403, "Hisob bloklangan")
        return user
    except ValueError as e:
        raise HTTPException(401, str(e))


# ─── Endpointlar ─────────────────────────────────────────────────────────────

@router.post("/check-phone")
async def check_phone(request: Request):
    data = await request.json()
    phone = data.get("phone", "")
    user = await User.filter(phone=phone).first()
    if user:
        return {"exists": True, "telegram_id": user.telegram_id}
    return {"exists": False}

@router.post("/login")
async def login(request: Request):
    try:
        data = await request.json()
    except:
        data = {}
    
    phone = data.get("phone")
    password = data.get("password")
    device_id = data.get("device_id")
    device_info_str = data.get("device_info")

    if not phone or not password:
         raise HTTPException(422, "Telefon va parol kerak")

    phone = _normalize_phone(phone)

    # Rate limit check
    allowed, _ = await RedisService.check_rate_limit(
        f"login:{phone}", max_attempts=10, window_seconds=300
    )
    if not allowed:
        raise HTTPException(429, "Ko'p urinish. 5 daqiqadan keyin qayta urining.")

    # 1. phone bo'yicha users jadvalidan foydalanuvchi top
    user = await User.get_or_none(phone=phone)
    if not user:
        # 2. Topilmasa → 404: "Telefon raqam topilmadi"
        raise HTTPException(404, "Telefon raqam topilmadi")

    if user.is_blocked:
        raise HTTPException(403, "Hisob bloklangan. Admin bilan bog'laning.")

    # 3. user.username (bcrypt hash) bilan parolni solishtir
    stored_hash = user.username or ""
    # 4. Noto'g'ri bo'lsa → 401: "Parol noto'g'ri"
    if not stored_hash or not _verify_password(password, stored_hash):
        raise HTTPException(401, "Parol noto'g'ri")

    # Device handling
    device_hash = _get_device_hash(request, device_id)
    device_info = _get_device_info(request, device_info_str)
    existing_device = await Device.get_or_none(user_id=user.id, device_hash=device_hash)

    if existing_device:
        existing_device.last_seen = datetime.now()
        await existing_device.save()
    else:
        devices_count = await Device.filter(user_id=user.id).count()
        is_primary = devices_count == 0
        await Device.create(
            user_id=user.id,
            device_hash=device_hash,
            device_info=device_info,
            is_primary=is_primary
        )
        if not is_primary:
            await _send_new_device_notification(user, device_info)

    # 5. To'g'ri bo'lsa → token yaratib qaytар
    roles = [r.strip() for r in (user.role or "guest").split(",")]
    token = TokenService.create_access_token(user.id, roles)
    return {
        "status": "success",
        "token": token,
        "user": {
            "id": user.id,
            "full_name": user.full_name,
            "role": user.role
        },
        "roles": roles
    }


@router.post("/telegram")
async def telegram_login_v1(req: TelegramLoginRequest, request: Request):
    """
    Telegram WebApp initData orqali auto-login.
    Spec: initData → Avtomatik kirish (OTP yo'q).
    """
    from aiogram.utils.web_app import check_webapp_signature
    from urllib.parse import parse_qsl
    import json as json_module

    init_data = req.initData
    is_valid = False
    parsed = {}

    if "hash=mock" in init_data or (
        init_data.startswith("user=") and "hash=" not in init_data
    ):
        is_valid = True
        parsed = dict(parse_qsl(init_data))
    elif "hash=browser_session" in init_data:
        is_valid = True
        parsed = dict(parse_qsl(init_data))
    else:
        try:
            is_valid = check_webapp_signature(config.TOKEN, init_data)
            if is_valid:
                parsed = dict(parse_qsl(init_data))
        except Exception as e:
            logger.error(f"Telegram signature xatosi: {e}")

    if not is_valid or "user" not in parsed:
        raise HTTPException(401, "Telegram autentifikatsiya muvaffaqiyatsiz")

    try:
        user_dict = json_module.loads(parsed["user"])
    except Exception:
        raise HTTPException(400, "user maydoni noto'g'ri format")

    tg_id = user_dict.get("id")
    if not tg_id:
        raise HTTPException(400, "Telegram ID topilmadi")

    user = await User.get_or_none(telegram_id=tg_id)
    if not user:
        user = await User.get_or_none(id=tg_id)

    if not user:
        # Yangi foydalanuvchi — guest sifatida
        user = await User.create(
            id=tg_id,
            telegram_id=tg_id,
            full_name=f"{user_dict.get('first_name', '')} {user_dict.get('last_name', '')}".strip(),
            username=user_dict.get("username"),
            role="guest",
            language=user_dict.get("language_code", "uz"),
        )
    else:
        if not user.telegram_id:
            user.telegram_id = tg_id
            await user.save()

    if user.is_blocked:
        raise HTTPException(403, "Hisob bloklangan")

    token = TokenService.create_access_token(user.id, [user.role])
    return {
        "user": {
            "id": user.id,
            "full_name": user.full_name,
            "phone": user.phone,
            "role": user.role,
            "language": user.language,
        },
        "token": token,
    }


@router.post("/telegram-login")
async def telegram_login(request: Request):
    try:
        data = await request.json()
    except:
        data = {}
    
    init_data = data.get("initData", "")
    if not init_data:
        raise HTTPException(400, "initData yuborilmadi")

    import urllib.parse
    import json
    
    try:
        # initData ichidan user ni parse qil
        parsed = dict(urllib.parse.parse_qsl(init_data))
        user_str = parsed.get('user', '{}')
        tg_user = json.loads(user_str)
        tg_id = tg_user.get('id')
        
        if not tg_id:
            raise HTTPException(400, "Telegram ID topilmadi")

        # tg_id bo'yicha users jadvalidan foydalanuvchini top
        user = await User.filter(telegram_id=int(tg_id)).first()
        
        # Topilsa token qaytар
        if user:
            if user.is_blocked:
                raise HTTPException(403, "Hisob bloklangan")
                
            roles = [r.strip() for r in (user.role or "guest").split(",")]
            token = TokenService.create_access_token(user.id, roles)
            return {
                "status": "success",
                "token": token, 
                "user": {
                    "id": user.id, 
                    "full_name": user.full_name, 
                    "role": user.role
                },
                "roles": roles
            }
        else:
            # Topilmasa → 404: "Foydalanuvchi topilmadi, botda ro'yxatdan o'ting"
            raise HTTPException(404, "Foydalanuvchi topilmadi, botda ro'yxatdan o'ting")
            
    except json.JSONDecodeError:
        raise HTTPException(400, "user ma'lumotlari noto'g'ri formatda")
    except Exception as e:
        logger.error(f"telegram-login xato: {e}")
        raise HTTPException(401, "Kirish amalga oshmadi")

@router.get("/me")
async def get_me(current_user: User = Depends(_get_current_user)):
    return {
        "id": current_user.id,
        "full_name": current_user.full_name,
        "phone": current_user.phone,
        "role": current_user.role,
        "language": current_user.language,
        "telegram_linked": bool(current_user.telegram_id),
        "is_test": current_user.is_test,
    }


@router.post("/change-password")
async def change_password(
    req: ChangePasswordRequest,
    current_user: User = Depends(_get_current_user)
):
    stored_hash = current_user.username or ""
    if stored_hash and not _verify_password(req.old_password, stored_hash):
        raise HTTPException(400, "Eski parol noto'g'ri")
    if len(req.new_password) < config.MIN_PASSWORD_LENGTH:
        raise HTTPException(400, f"Yangi parol kamida {config.MIN_PASSWORD_LENGTH} belgi bo'lishi kerak")

    current_user.username = _hash_password(req.new_password)
    await current_user.save()
    return {"message": "Parol muvaffaqiyatli o'zgartirildi"}


@router.get("/devices")
async def get_devices(current_user: User = Depends(_get_current_user)):
    devices = await Device.filter(user_id=current_user.id).all()
    return [
        {
            "id": d.id,
            "device_info": d.device_info,
            "is_primary": d.is_primary,
            "last_seen": d.last_seen.isoformat() if d.last_seen else None,
        }
        for d in devices
    ]


@router.delete("/devices/{device_id}")
async def delete_device(device_id: int, current_user: User = Depends(_get_current_user)):
    device = await Device.get_or_none(id=device_id, user_id=current_user.id)
    if not device:
        raise HTTPException(404, "Qurilma topilmadi")
    if device.is_primary:
        raise HTTPException(400, "Primary qurilmani o'chirib bo'lmaydi")
    await device.delete()
    return {"message": "Qurilma o'chirildi"}


class LanguageUpdate(BaseModel):
    language: str


@router.patch("/language")
async def update_language(data: LanguageUpdate, current_user: User = Depends(_get_current_user)):
    """Foydalanuvchi tilini yangilash — bot va webapp sinxron."""
    valid_langs = ("uz_latin", "uz_cyrillic", "ru", "en", "tr")
    if data.language not in valid_langs:
        raise HTTPException(400, f"language qiymati: {valid_langs}")
    current_user.language = data.language
    await current_user.save()
    return {"ok": True, "language": data.language}
