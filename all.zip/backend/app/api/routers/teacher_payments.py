"""
SmartDMTT v4 — Muallim oylik hisob API Router
"""
import logging
from datetime import datetime
from typing import Optional

from fastapi import APIRouter, HTTPException, Depends
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from pydantic import BaseModel

from app.models.user import User
from app.models.teacher_payment import TeacherPayment
from app.services.token_service import TokenService

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/teacher-payments", tags=["teacher_payments"])
security = HTTPBearer(auto_error=False)


async def _get_current_user(
    credentials: HTTPAuthorizationCredentials = Depends(security)
) -> User:
    if not credentials:
        raise HTTPException(401, "Avtorizatsiya talab etiladi")
    try:
        payload = TokenService.decode_token(credentials.credentials)
        user = await User.get_or_none(id=int(payload["sub"]))
        if not user:
            raise HTTPException(401, "Foydalanuvchi topilmadi")
        return user
    except ValueError as e:
        raise HTTPException(401, str(e))


class TeacherPaymentCreate(BaseModel):
    teacher_id: int
    month: str              # "2025-03"
    base_amount: float
    bonus_amount: float = 0
    attendance_rate: float = 0
    parent_rating: float = 0
    lessons_count: int = 0


@router.get("")
async def list_teacher_payments(
    teacher_id: Optional[int] = None,
    month: Optional[str] = None,
    user: User = Depends(_get_current_user)
):
    """Muallim oylik hisoblari."""
    if user.role == "teacher":
        qs = TeacherPayment.filter(teacher_id=user.id)
    elif user.role in ("admin", "director", "boshliq"):
        qs = TeacherPayment.all()
        if teacher_id:
            qs = qs.filter(teacher_id=teacher_id)
    else:
        raise HTTPException(403, "Ruxsat yo'q")

    if month:
        qs = qs.filter(month=month)

    items = await qs.order_by("-month").all()
    return {
        "payments": [
            {
                "id": p.id,
                "teacher_id": p.teacher_id,
                "month": p.month,
                "base_amount": float(p.base_amount),
                "bonus_amount": float(p.bonus_amount),
                "total": float(p.base_amount) + float(p.bonus_amount),
                "attendance_rate": p.attendance_rate,
                "parent_rating": p.parent_rating,
                "lessons_count": p.lessons_count,
                "status": p.status,
                "paid_at": p.paid_at.isoformat() if p.paid_at else None,
            }
            for p in items
        ]
    }


@router.post("")
async def create_teacher_payment(
    data: TeacherPaymentCreate,
    user: User = Depends(_get_current_user)
):
    """Oylik hisob yozuvi (admin/boshliq)."""
    if user.role not in ("admin", "boshliq"):
        raise HTTPException(403, "Ruxsat yo'q")

    teacher = await User.get_or_none(id=data.teacher_id, role="teacher")
    if not teacher:
        raise HTTPException(404, "Muallim topilmadi")

    existing = await TeacherPayment.get_or_none(teacher_id=data.teacher_id, month=data.month)
    if existing:
        raise HTTPException(400, f"{data.month} uchun hisob allaqachon mavjud")

    payment = await TeacherPayment.create(
        teacher=teacher,
        month=data.month,
        base_amount=data.base_amount,
        bonus_amount=data.bonus_amount,
        attendance_rate=data.attendance_rate,
        parent_rating=data.parent_rating,
        lessons_count=data.lessons_count,
        status="pending",
    )
    return {"id": payment.id, "total": data.base_amount + data.bonus_amount}


@router.patch("/{payment_id}/mark-paid")
async def mark_paid(payment_id: int, user: User = Depends(_get_current_user)):
    """To'landi deb belgilash (admin/boshliq)."""
    if user.role not in ("admin", "boshliq"):
        raise HTTPException(403, "Ruxsat yo'q")
    payment = await TeacherPayment.get_or_none(id=payment_id)
    if not payment:
        raise HTTPException(404, "Topilmadi")
    payment.status = "paid"
    payment.paid_at = datetime.utcnow()
    await payment.save()
    return {"ok": True}
