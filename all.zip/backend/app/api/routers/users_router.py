"""
SmartDMTT v4 — Users router qo'shimchalari
/me/language  — til o'zgartirish
/me/password  — parol o'zgartirish
/me/notifications — bildirishnomalar
"""
import bcrypt
from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from app.api.deps import get_current_user
from app.models.user import User

router = APIRouter(prefix="/users", tags=["users"])

SUPPORTED_LANGS = ("uz", "kril", "ru", "en", "turk")

class LangBody(BaseModel):
    language: str

@router.patch("/me/language")
async def set_language(body: LangBody, current_user: User = Depends(get_current_user)):
    if body.language not in SUPPORTED_LANGS:
        raise HTTPException(400, f"Qo'llab-quvvatlanadigan tillar: {', '.join(SUPPORTED_LANGS)}")
    current_user.language = body.language
    await current_user.save()
    return {"ok": True, "language": body.language}


class PwBody(BaseModel):
    old_password: str
    new_password: str

@router.patch("/me/password")
async def change_password(body: PwBody, current_user: User = Depends(get_current_user)):
    if len(body.new_password) < 4:
        raise HTTPException(400, "Parol kamida 4 ta belgi bo'lishi kerak")
    stored = current_user.username or ""
    try:
        ok = bcrypt.checkpw(body.old_password.encode(), stored.encode())
    except Exception:
        ok = (body.old_password == stored)    # plain text fallback (test)
    if not ok:
        raise HTTPException(400, "Eski parol noto'g'ri")
    new_hash = bcrypt.hashpw(body.new_password.encode(), bcrypt.gensalt()).decode()
    current_user.username = new_hash
    await current_user.save()
    return {"ok": True}


class NotifBody(BaseModel):
    enabled: bool

@router.patch("/me/notifications")
async def set_notifications(body: NotifBody, current_user: User = Depends(get_current_user)):
    # User modelida notifications maydoni bo'lsa saqlanadi
    if hasattr(current_user, 'notifications'):
        current_user.notifications = body.enabled
        await current_user.save()
    return {"ok": True, "enabled": body.enabled}
