"""
backend/app/api/routers/reports.py — tuzatilgan
"""
from fastapi import APIRouter, Depends
from fastapi.responses import StreamingResponse
import io

from app.api.deps import get_current_user
from app.models.user import User

try:
    from reportlab.lib import colors
    from reportlab.lib.pagesizes import A4
    from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph
    from reportlab.lib.styles import getSampleStyleSheet
    REPORTLAB = True
except ImportError:
    REPORTLAB = False

router = APIRouter()


def _check_admin(current_user: User):
    from fastapi import HTTPException
    role = (current_user.role or "").lower()
    if role not in ("admin", "boshliq", "mmtb_boshligi"):
        raise HTTPException(403, "Ruxsat yo'q")


@router.get("/api/admin/reports/monthly/{year}/{month}")
async def monthly_report(
    year: int,
    month: int,
    current_user: User = Depends(get_current_user),
):
    """Oylik hisobot PDF."""
    _check_admin(current_user)

    if not REPORTLAB:
        from fastapi.responses import JSONResponse
        return JSONResponse({"error": "reportlab o'rnatilmagan: pip install reportlab"}, 400)

    from app.services import database

    buf  = io.BytesIO()
    doc  = SimpleDocTemplate(buf, pagesize=A4)
    styles = getSampleStyleSheet()
    elements = [Paragraph(f"Oylik Hisobot: {year}-{month:02d}", styles['Title'])]

    try:
        all_payments  = await database.get_all_payments()
        all_children  = await database.get_all_children()
        all_clubs     = await database.get_all_clubs()
    except Exception:
        all_payments, all_children, all_clubs = [], [], []

    payments     = [p for p in all_payments if p.get("date","").startswith(f"{year}-{month:02d}")]
    children_map = {c["child_id"]: c for c in all_children}
    clubs_map    = {c["club_id"]:  c for c in all_clubs}

    data = [["Ism", "To'garak", "Summa", "Holat", "Sana"]]
    for p in payments:
        child = children_map.get(p.get("child_id"), {})
        club  = clubs_map.get(p.get("club_id"), {})
        data.append([
            child.get("full_name", "—"),
            club.get("name", "—"),
            f"{p.get('amount', 0):,} so'm",
            "✅ To'langan" if p.get("status") == "completed" else "❌ Kutilmoqda",
            p.get("date", "")[:10],
        ])

    table = Table(data)
    table.setStyle(TableStyle([
        ('BACKGROUND', (0,0), (-1,0), colors.HexColor('#083D34')),
        ('TEXTCOLOR',  (0,0), (-1,0), colors.white),
        ('FONTNAME',   (0,0), (-1,0), 'Helvetica-Bold'),
        ('GRID',       (0,0), (-1,-1), 1, colors.grey),
        ('ALIGN',      (0,0), (-1,-1), 'CENTER'),
        ('FONTSIZE',   (0,0), (-1,0),  10),
        ('FONTSIZE',   (0,1), (-1,-1), 8),
    ]))
    elements.append(table)
    doc.build(elements)
    buf.seek(0)

    return StreamingResponse(
        buf,
        media_type="application/pdf",
        headers={"Content-Disposition": f"attachment; filename=hisobot_{year}_{month}.pdf"},
    )
