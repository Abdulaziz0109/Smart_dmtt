import qrcode
import io
import time
from fastapi import APIRouter, Request, Response
from app.services import database

router = APIRouter()

@router.get("/api/qr/{child_id}")
async def get_child_qr(child_id: str, request: Request):
    """Bola uchun QR kod."""
    # QR da token va child_id encode qilinadi
    data = f"sdmtt://checkin?child={child_id}&ts={int(time.time())}"
    
    img = qrcode.QRCode(version=1, box_size=10, border=4)
    img.add_data(data)
    img.make(fit=True)
    
    pil_img = img.make_image(fill_color="black", back_color="white")
    buf = io.BytesIO()
    pil_img.save(buf, format='PNG')
    
    return Response(content=buf.getvalue(), media_type="image/png")

@router.post("/api/qr/scan")
async def scan_qr(request: Request):
    """QR kod scan — davomat belgilash."""
    body = await request.json()
    child_id = body.get("child_id")
    # teacher_id = str(request.state.user.id) # Assuming auth middleware sets this
    
    # Simple logic: mark present for today for all enrolled clubs or just a general "ENTRY"
    # For now, let's just log it as "ENTRY" in a special "general" club or similar.
    # Or find the first active club for today.
    
    from datetime import datetime
    today = datetime.now().strftime("%Y-%m-%d")
    
    # Placeholder: mark for a generic 'entry' event
    # In a real app, we'd check schedule.
    # Using "ENTRY" as club_id for general check-in
    await database.add_attendance(child_id, "ENTRY", today, status="present")
    
    return {"success": True, "child_id": child_id}
