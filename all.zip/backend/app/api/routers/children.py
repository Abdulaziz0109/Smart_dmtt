"""
SmartDMTT v4.0 — Farzandlar API Router
Davomat, to'lov holati, farzand ma'lumotlari.
"""
import logging
from datetime import date, timedelta
from typing import Optional

from fastapi import APIRouter, HTTPException, Depends
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from pydantic import BaseModel

from app.models.user import User
from app.models.child import Child
from app.models.club import Club, Enrollment
from app.models.attendance import Attendance
from app.models.payment import Payment
from app.services.token_service import TokenService

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/children", tags=["children"])
security = HTTPBearer(auto_error=False)


# ─── Auth dependency ──────────────────────────────────────────────────────────

async def _get_current_user(
    credentials: HTTPAuthorizationCredentials = Depends(security)
) -> User:
    if not credentials:
        raise HTTPException(401, "Avtorizatsiya talab etiladi")
    try:
        payload = TokenService.decode_token(credentials.credentials)
        user_id = int(payload["sub"])
        user = await User.get_or_none(id=user_id)
        if not user:
            raise HTTPException(401, "Foydalanuvchi topilmadi")
        return user
    except ValueError as e:
        raise HTTPException(401, str(e))


# ─── Pydantic ─────────────────────────────────────────────────────────────────

class ChildCreate(BaseModel):
    full_name: str
    birth_year: Optional[int] = None
    place_type: Optional[str] = "state"  # state, private, other
    kindergarten_id: Optional[int] = None
    other_place: Optional[str] = None


# ─── Endpointlar ─────────────────────────────────────────────────────────────

@router.get("")
async def get_children(current_user: User = Depends(_get_current_user)):
    """Joriy foydalanuvchi farzandlari."""
    if current_user.role in ("admin", "director", "boshliq"):
        children = await Child.all()
    else:
        children = await Child.filter(parent_id=current_user.id).all()

    result = []
    for child in children:
        enrollments = await Enrollment.filter(child_id=child.id, status="active").all()
        clubs = []
        for enr in enrollments:
            club = await Club.get_or_none(id=enr.club_id)
            if club:
                clubs.append({"id": club.id, "name": club.name, "payment_id": enr.payment_id})

        result.append({
            "id": child.id,
            "full_name": child.full_name,
            "birth_year": child.birth_year,
            "parent_id": child.parent_id,
            "place_type": child.place_type,
            "kindergarten_id": child.kindergarten_id,
            "other_place": child.other_place,
            "active_clubs": clubs,
        })
    return {"children": result}


@router.get("/{child_id}")
async def get_child(child_id: int, current_user: User = Depends(_get_current_user)):
    """Farzand ma'lumotlari."""
    child = await Child.get_or_none(id=child_id)
    if not child:
        raise HTTPException(404, "Farzand topilmadi")

    if current_user.role not in ("admin", "director", "boshliq") and child.parent_id != current_user.id:
        raise HTTPException(403, "Ruxsat yo'q")

    enrollments = await Enrollment.filter(child_id=child_id, status="active").all()
    clubs_data = []
    for enr in enrollments:
        club = await Club.get_or_none(id=enr.club_id)
        if club:
            month_str = date.today().strftime("%Y-%m")
            paid = await Payment.filter(
                enrollment_id=enr.id, month=month_str, status="completed"
            ).exists()
            clubs_data.append({
                "enrollment_id": enr.id,
                "payment_id": enr.payment_id,
                "club_id": club.id,
                "club_name": club.name,
                "club_price": club.price,
                "schedule_days": club.schedule_days,
                "schedule_time": club.schedule_time,
                "paid_this_month": paid,
            })

    return {
        "id": child.id,
        "full_name": child.full_name,
        "birth_year": child.birth_year,
        "parent_id": child.parent_id,
        "place_type": child.place_type,
        "kindergarten_id": child.kindergarten_id,
        "other_place": child.other_place,
        "enrollments": clubs_data,
    }


@router.post("")
async def create_child(req: ChildCreate, current_user: User = Depends(_get_current_user)):
    """Yangi farzand qo'shish."""
    if current_user.role != "parent":
        raise HTTPException(403, "Faqat ota-ona farzand qo'sha oladi")
    child = await Child.create(
        full_name=req.full_name,
        birth_year=req.birth_year,
        parent_id=current_user.id,
        place_type=req.place_type or "state",
        kindergarten_id=req.kindergarten_id or current_user.kindergarten_id,
        other_place=req.other_place,
    )
    return {"id": child.id, "full_name": child.full_name}


@router.get("/{child_id}/attendance")
async def child_attendance(
    child_id: int,
    weeks: int = 4,
    current_user: User = Depends(_get_current_user)
):
    """Farzand davomat tarixi."""
    child = await Child.get_or_none(id=child_id)
    if not child:
        raise HTTPException(404, "Farzand topilmadi")

    if current_user.role not in ("admin", "director", "boshliq", "teacher") and child.parent_id != current_user.id:
        raise HTTPException(403, "Ruxsat yo'q")

    start_date = date.today() - timedelta(weeks=weeks)
    enrollments = await Enrollment.filter(child_id=child_id).all()
    enr_ids = [e.id for e in enrollments]

    records = await Attendance.filter(
        enrollment_id__in=enr_ids,
        date__gte=start_date
    ).order_by("-date").all()

    total = len(records)
    present = sum(1 for r in records if r.status == "present")
    pct = round(present / total * 100, 1) if total > 0 else 0

    return {
        "child_id": child_id,
        "total": total,
        "present": present,
        "absent": total - present,
        "attendance_pct": pct,
        "records": [
            {
                "id": r.id,
                "enrollment_id": r.enrollment_id,
                "date": r.date.isoformat() if r.date else None,
                "status": r.status,
                "teacher_confirmed": r.teacher_confirmed,
                "parent_confirmed": r.parent_confirmed,
                "excuse_reason": r.excuse_reason,
            }
            for r in records
        ]
    }


@router.get("/{child_id}/payments")
async def child_payments(
    child_id: int,
    current_user: User = Depends(_get_current_user)
):
    """Farzand to'lov tarixi."""
    child = await Child.get_or_none(id=child_id)
    if not child:
        raise HTTPException(404, "Farzand topilmadi")

    if current_user.role not in ("admin", "director", "boshliq") and child.parent_id != current_user.id:
        raise HTTPException(403, "Ruxsat yo'q")

    enrollments = await Enrollment.filter(child_id=child_id).all()
    enr_ids = [e.id for e in enrollments]
    payments = await Payment.filter(enrollment_id__in=enr_ids).order_by("-paid_at").all()

    return {
        "child_id": child_id,
        "payments": [
            {
                "id": p.id,
                "enrollment_id": p.enrollment_id,
                "amount": p.amount,
                "month": p.month,
                "status": p.status,
                "provider": p.provider,
                "paid_at": p.paid_at.isoformat() if p.paid_at else None,
            }
            for p in payments
        ]
    }
