"""
SmartDMTT v4 — Bola kuzatuvi API Router (muallim tomonidan)
"""
import logging
from datetime import date
from typing import Optional

from fastapi import APIRouter, HTTPException, Depends
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from pydantic import BaseModel

from app.models.user import User
from app.models.club import Enrollment
from app.models.observation import ChildObservation
from app.services.token_service import TokenService

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/observations", tags=["observations"])
security = HTTPBearer(auto_error=False)


async def _get_current_user(
    credentials: HTTPAuthorizationCredentials = Depends(security)
) -> User:
    if not credentials:
        raise HTTPException(401, "Avtorizatsiya talab etiladi")
    try:
        payload = TokenService.decode_token(credentials.credentials)
        user = await User.get_or_none(id=int(payload["sub"]))
        if not user:
            raise HTTPException(401, "Foydalanuvchi topilmadi")
        return user
    except ValueError as e:
        raise HTTPException(401, str(e))


class ObservationCreate(BaseModel):
    enrollment_id: int
    obs_date: str            # "2025-03-15"
    # Baholash 1-5 (ixtiyoriy)
    energy: Optional[int] = None
    focus: Optional[int] = None
    creativity: Optional[int] = None
    social: Optional[int] = None
    # Belgilar
    asked_question: bool = False
    made_discovery: bool = False
    helped_others: bool = False
    struggled: bool = False
    completed_task: bool = False


def _validate_score(val: Optional[int], field: str):
    if val is not None and val not in range(1, 6):
        raise HTTPException(400, f"{field} 1-5 orasida bo'lishi kerak")


@router.post("")
async def create_observation(
    data: ObservationCreate,
    user: User = Depends(_get_current_user)
):
    """Kuzatuv saqlash (faqat muallim)."""
    if user.role not in ("teacher", "admin"):
        raise HTTPException(403, "Faqat muallim kuzatuv qo'sha oladi")

    for field in ("energy", "focus", "creativity", "social"):
        _validate_score(getattr(data, field), field)

    enrollment = await Enrollment.get_or_none(id=data.enrollment_id)
    if not enrollment:
        raise HTTPException(404, "Enrollment topilmadi")

    try:
        obs_date = date.fromisoformat(data.obs_date)
    except ValueError:
        raise HTTPException(400, "obs_date formati: YYYY-MM-DD")

    obs = await ChildObservation.create(
        enrollment=enrollment,
        date=obs_date,
        energy=data.energy,
        focus=data.focus,
        creativity=data.creativity,
        social=data.social,
        asked_question=data.asked_question,
        made_discovery=data.made_discovery,
        helped_others=data.helped_others,
        struggled=data.struggled,
        completed_task=data.completed_task,
    )
    return {"id": obs.id}


@router.get("")
async def list_observations(
    enrollment_id: Optional[int] = None,
    user: User = Depends(_get_current_user)
):
    """Kuzatuvlar ro'yxati."""
    if user.role not in ("teacher", "admin", "director", "boshliq"):
        raise HTTPException(403, "Ruxsat yo'q")

    qs = ChildObservation.all()
    if enrollment_id:
        qs = qs.filter(enrollment_id=enrollment_id)

    items = await qs.order_by("-date").all()
    return {
        "observations": [
            {
                "id": o.id,
                "enrollment_id": o.enrollment_id,
                "date": o.date.isoformat() if o.date else None,
                "energy": o.energy,
                "focus": o.focus,
                "creativity": o.creativity,
                "social": o.social,
                "asked_question": o.asked_question,
                "made_discovery": o.made_discovery,
                "helped_others": o.helped_others,
                "struggled": o.struggled,
                "completed_task": o.completed_task,
                "created_at": o.created_at.isoformat() if o.created_at else None,
            }
            for o in items
        ]
    }
