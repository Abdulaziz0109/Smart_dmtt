"""
SmartDMTT v4.0 — Foydalanuvchi modeli
Rollar: admin, boshliq, director, teacher, parent, guest
"""
from tortoise import fields
from tortoise.models import Model


class User(Model):
    id = fields.BigIntField(pk=True)           # Telegram ID yoki timestamp ID
    telegram_id = fields.BigIntField(null=True, unique=True)  # Haqiqiy Telegram chat ID
    full_name = fields.CharField(max_length=255, null=True)
    username = fields.CharField(max_length=255, null=True)    # bcrypt parol hash saqlanadi
    phone = fields.CharField(max_length=50, null=True, unique=True)
    contact_phone = fields.CharField(max_length=50, null=True)  # Aloqa raqami (ixtiyoriy)
    language = fields.CharField(max_length=10, default="uz")
    role = fields.CharField(max_length=50, default="guest")     # admin, boshliq, director, teacher, parent, guest
    kindergarten_id = fields.IntField(null=True)                # Bog'cha ID
    club_id = fields.IntField(null=True)                        # To'garak ID (teacher uchun)
    is_test = fields.BooleanField(default=False)                # Test akkaunt — statistikaga kirmaydi
    is_blocked = fields.BooleanField(default=False)             # Bloklangan
    telegram_link_allowed = fields.BooleanField(default=True)   # Ota-ona muallim bilan to'g'ridan bog'lanishi
    created_at = fields.DatetimeField(auto_now_add=True)

    class Meta:
        table = "users"

    def __str__(self):
        return f"{self.full_name} ({self.role})"
