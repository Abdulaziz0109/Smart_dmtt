"""
SmartDMTT v4 — Club modeli (to'ldirilgan)
age_min, age_max, max_members, description maydonlari qo'shildi
"""
from tortoise import fields
from tortoise.models import Model


class Club(Model):
    id = fields.IntField(pk=True)
    name = fields.CharField(max_length=100)
    description = fields.TextField(null=True)

    kindergarten = fields.ForeignKeyField("models.Kindergarten", related_name="clubs")
    teacher = fields.ForeignKeyField("models.User", related_name="clubs", null=True)

    # Moliya
    price = fields.DecimalField(max_digits=10, decimal_places=0, default=0)

    # Jadval
    schedule_days = fields.JSONField(default=list)   # ["monday", "wednesday", "friday"]
    schedule_time = fields.CharField(max_length=20, null=True)  # "14:00"

    # Xona va sig'im
    room = fields.CharField(max_length=50, null=True)
    capacity = fields.IntField(default=20)           # Maksimal sig'im (=max_members)
    max_members = fields.IntField(default=20)        # capacity bilan bir xil, alias
    min_members = fields.IntField(default=5)         # Minimum bola soni

    # Yosh chegarasi
    age_min = fields.IntField(null=True)   # Minimal yosh (masalan: 4)
    age_max = fields.IntField(null=True)   # Maksimal yosh (masalan: 7)

    is_active = fields.BooleanField(default=True)
    created_at = fields.DatetimeField(auto_now_add=True)

    class Meta:
        table = "clubs"

    def __str__(self):
        return self.name


class Enrollment(Model):
    """Bolaning to'garakka yozilishi"""
    id = fields.IntField(pk=True)
    child = fields.ForeignKeyField("models.Child", related_name="enrollments")
    club = fields.ForeignKeyField("models.Club", related_name="enrollments")

    # To'lov identifikatori (6 raqam, umrbod)
    payment_id = fields.CharField(max_length=10, unique=True)

    status = fields.CharField(
        max_length=20,
        default="active",
        description="active | blocked | removed | cancelled"
    )
    blocked_at = fields.DatetimeField(null=True)
    created_at = fields.DatetimeField(auto_now_add=True)

    class Meta:
        table = "enrollments"

    def __str__(self):
        return f"Enrollment {self.payment_id}"


class WaitingList(Model):
    """To'garakka joy bo'shashini kutish ro'yxati"""
    id = fields.IntField(pk=True)
    child = fields.ForeignKeyField("models.Child", related_name="waiting_list")
    club = fields.ForeignKeyField("models.Club", related_name="waiting_list")
    notified = fields.BooleanField(default=False)
    created_at = fields.DatetimeField(auto_now_add=True)

    class Meta:
        table = "waiting_list"
        unique_together = (("child", "club"),)
