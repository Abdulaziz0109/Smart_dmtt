"""
SmartDMTT v4.0 — Davomat modeli
Ikki tomonlama tasdiqlash: muallim + ota-ona
"""
from tortoise import fields, models

class Attendance(models.Model):
    id = fields.IntField(pk=True)
    # Enrollment bilan bog'liqlik (ForeignKey bo'lishi shart)
    enrollment = fields.ForeignKeyField('models.Enrollment', related_name='attendances')
    date = fields.DateField()
    status = fields.CharField(max_length=20) # present, absent
    teacher_confirmed = fields.BooleanField(default=False)
    parent_confirmed = fields.BooleanField(null=True)
    parent_confirmed_at = fields.DatetimeField(null=True)
    recorded_at = fields.DatetimeField(auto_now_add=True)

    class Meta:
        table = "attendance"
        unique_together = (("enrollment", "date"),)

class AbsenceNotice(models.Model):
    id = fields.IntField(pk=True)
    enrollment = fields.ForeignKeyField('models.Enrollment', related_name='absence_notices')
    date = fields.DateField()
    reason = fields.CharField(max_length=50) # sick, other
    created_at = fields.DatetimeField(auto_now_add=True)

    class Meta:
        table = "absence_notices"
