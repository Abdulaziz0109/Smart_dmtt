"""
SmartDMTT v4.0 — Bog'cha modeli
"""
from tortoise import fields
from tortoise.models import Model


class Kindergarten(Model):
    id = fields.IntField(pk=True)
    number = fields.IntField(unique=True)                  # Bog'cha raqami (12-son)
    name = fields.CharField(max_length=255)                # Nomi
    address = fields.CharField(max_length=500, null=True)
    phone = fields.CharField(max_length=50, null=True)
    lat = fields.FloatField(null=True)                     # Joylashuv
    lon = fields.FloatField(null=True)
    director_id = fields.BigIntField(null=True)            # Direktor User ID
    is_active = fields.BooleanField(default=True)
    created_at = fields.DatetimeField(auto_now_add=True)

    class Meta:
        table = "kindergartens"

    def __str__(self):
        return f"{self.number}-son bog'cha"
