"""
SmartDMTT v4 — Bola kuzatuvi modeli (muallim tomonidan)
"""
from tortoise import fields
from tortoise.models import Model


class ChildObservation(Model):
    id = fields.IntField(pk=True)
    enrollment = fields.ForeignKeyField("models.Enrollment", related_name="observations")
    date = fields.DateField()

    # Baholash (1-5, ixtiyoriy)
    energy     = fields.IntField(null=True)    # Faollik
    focus      = fields.IntField(null=True)    # Diqqat
    creativity = fields.IntField(null=True)    # Ijodiylik
    social     = fields.IntField(null=True)    # Ijtimoiylashish

    # Belgilar (ha/yo'q)
    asked_question  = fields.BooleanField(default=False)  # Savol berdi
    made_discovery  = fields.BooleanField(default=False)  # Kashfiyot qildi
    helped_others   = fields.BooleanField(default=False)  # Boshqalarga yordam berdi
    struggled       = fields.BooleanField(default=False)  # Qiynaldi
    completed_task  = fields.BooleanField(default=False)  # Vazifani bajardi

    created_at = fields.DatetimeField(auto_now_add=True)

    class Meta:
        table = "child_observations"
