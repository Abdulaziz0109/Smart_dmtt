"""
SmartDMTT v4 — Child modeli (to'ldirilgan)
place_type maydoni qo'shildi
"""
from tortoise import fields
from tortoise.models import Model


class Child(Model):
    id = fields.IntField(pk=True)
    parent = fields.ForeignKeyField("models.User", related_name="children")
    full_name = fields.CharField(max_length=100)
    birth_year = fields.IntField()

    # Bog'cha joylashuvi
    place_type = fields.CharField(
        max_length=20,
        default="state",
        description="state | private | other"
    )
    kindergarten = fields.ForeignKeyField(
        "models.Kindergarten", null=True, related_name="children"
    )
    other_place = fields.CharField(max_length=200, null=True)  # Xususiy yoki boshqa joy nomi

    created_at = fields.DatetimeField(auto_now_add=True)

    class Meta:
        table = "children"

    def __str__(self):
        return self.full_name


class Attendance(Model):
    id = fields.IntField(pk=True)
    enrollment = fields.ForeignKeyField("models.Enrollment", related_name="attendances")
    date = fields.DateField()

    # Muallim belgisi
    status = fields.CharField(
        max_length=20,
        default="present",
        description="present | absent | excused"
    )
    teacher_confirmed = fields.BooleanField(default=True)

    # Ota-ona tasdiq
    parent_confirmed = fields.BooleanField(null=True)   # None=kutilmoqda, True=tasdiqladi, False=xato dedi
    parent_notified_at = fields.DatetimeField(null=True)
    auto_confirmed_at = fields.DatetimeField(null=True)  # 24s o'tib avtomatik

    # Sabablar
    excuse_reason = fields.CharField(
        max_length=50, null=True,
        description="sick | other | skip"
    )
    excuse_note = fields.TextField(null=True)

    created_at = fields.DatetimeField(auto_now_add=True)

    class Meta:
        table = "attendance"
        unique_together = (("enrollment", "date"),)


class AbsenceNotice(Model):
    """Ota-ona oldindan kela olmashini bildiradi"""
    id = fields.IntField(pk=True)
    enrollment = fields.ForeignKeyField("models.Enrollment", related_name="absence_notices")
    date = fields.DateField()
    reason = fields.CharField(max_length=50, description="sick | other")
    note = fields.TextField(null=True)
    created_at = fields.DatetimeField(auto_now_add=True)

    class Meta:
        table = "absence_notices"
