"""
SmartDMTT v4 — Qo'shimcha xizmatlar modeli
"""
from tortoise import fields
from tortoise.models import Model


class ExtraService(Model):
    id = fields.IntField(pk=True)
    child = fields.ForeignKeyField("models.Child", related_name="extra_services")

    service_type = fields.CharField(
        max_length=20,
        description="late_pickup | early_dropoff | individual | transport | lunch"
    )

    date       = fields.DateField()
    start_time = fields.CharField(max_length=5, null=True)    # "17:30"
    end_time   = fields.CharField(max_length=5, null=True)    # "18:00"
    duration_minutes = fields.IntField(null=True)

    amount = fields.DecimalField(max_digits=10, decimal_places=0, default=0)
    status = fields.CharField(
        max_length=15,
        default="pending",
        description="pending | confirmed | cancelled"
    )

    confirmed_at = fields.DatetimeField(null=True)
    created_at   = fields.DatetimeField(auto_now_add=True)

    class Meta:
        table = "extra_services"
