"""
SmartDMTT v4.0 — AI Jurnal modeli
Admin barcha AI so'rovlarni ko'radi.
"""
from tortoise import fields
from tortoise.models import Model


class AILog(Model):
    id = fields.IntField(pk=True)
    log_type = fields.CharField(max_length=20)       # helper, anomaly, message
    user_id = fields.BigIntField(null=True)
    model = fields.CharField(max_length=100, null=True)
    prompt = fields.TextField(null=True)
    response = fields.TextField(null=True)
    source = fields.CharField(max_length=20, null=True)  # db (bazadan) yoki api (Claude dan)
    sent_to_ids = fields.TextField(null=True)            # JSON: kimga yuborildi
    reply_text = fields.TextField(null=True)             # Muallim yoki ota-ona javobi
    tokens_used = fields.IntField(default=0)
    is_test = fields.BooleanField(default=False)
    added_to_kb = fields.BooleanField(default=False)     # Bilimlar bazasiga qo'shildi
    created_at = fields.DatetimeField(auto_now_add=True)

    class Meta:
        table = "ai_logs"


class KnowledgeBase(Model):
    """Bilimlar bazasi — tez-tez so'raladigan savollar."""
    id = fields.IntField(pk=True)
    question = fields.TextField()
    answer = fields.TextField()
    keywords = fields.CharField(max_length=500, null=True)  # Kalit so'zlar, vergul bilan
    is_active = fields.BooleanField(default=True)
    created_at = fields.DatetimeField(auto_now_add=True)

    class Meta:
        table = "knowledge_base"
