"""
SmartDMTT v4.0 — To'lov modeli
Click / Paynet / Payme webhook orqali to'lovlar qayd etiladi.
"""
from tortoise import fields
from tortoise.models import Model


class Payment(Model):
    id = fields.IntField(pk=True)
    enrollment_id = fields.IntField()                      # Enrollment ID
    amount = fields.IntField()                              # To'lov miqdori (tiyin yoki so'm)
    month = fields.CharField(max_length=7)                  # "2025-03" formatida
    status = fields.CharField(max_length=20, default="pending")  # pending, completed, failed
    provider = fields.CharField(max_length=20, null=True)   # click, paynet, payme
    transaction_id = fields.CharField(max_length=100, null=True)
    paid_at = fields.DatetimeField(null=True)
    created_at = fields.DatetimeField(auto_now_add=True)

    class Meta:
        table = "payments"
