"""
SmartDMTT v4 — Kengaytirilgan bilimlar bazasi modeli
"""
from tortoise import fields
from tortoise.models import Model


class KnowledgeBaseEntry(Model):
    id       = fields.IntField(pk=True)
    entry_id = fields.CharField(max_length=50, unique=True)  # Noyob identifikator

    question_en = fields.TextField()
    answer_en   = fields.TextField()

    # Kalit so'zlar har til uchun: {"uz_latin": [...], "ru": [...], ...}
    keywords_json = fields.JSONField(default=dict)

    source = fields.CharField(
        max_length=10,
        default="manual",
        description="manual | auto"
    )
    status = fields.CharField(
        max_length=10,
        default="pending",
        description="active | pending | rejected"
    )

    use_count  = fields.IntField(default=0)
    lang       = fields.CharField(max_length=15, default="uz_latin")

    created_at = fields.DatetimeField(auto_now_add=True)
    updated_at = fields.DatetimeField(auto_now=True)

    class Meta:
        table = "knowledge_base_entries"
