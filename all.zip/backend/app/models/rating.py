"""
SmartDMTT v4.0 — Baholash modeli
Muallim bolani baholaydi, ota-ona muallimni baholaydi.
"""
from tortoise import fields
from tortoise.models import Model


class Rating(Model):
    id = fields.IntField(pk=True)
    rater_id = fields.BigIntField()          # Kim baholadi (User ID)
    rated_user_id = fields.BigIntField(null=True)  # Muallim (ota-ona baholaydi)
    rated_child_id = fields.IntField(null=True)    # Bola (muallim baholaydi)
    club_id = fields.IntField(null=True)
    rating = fields.IntField()               # 1-5
    week = fields.CharField(max_length=10)   # "2025-W11" formatida
    created_at = fields.DatetimeField(auto_now_add=True)

    class Meta:
        table = "ratings"
