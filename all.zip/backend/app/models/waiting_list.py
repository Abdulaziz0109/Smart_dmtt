"""
SmartDMTT v4.0 — Kutish ro'yxati
To'garakda joy bo'lmaganda ota-ona kutish ro'yxatiga qo'shiladi.
"""
from tortoise import fields
from tortoise.models import Model


class WaitingList(Model):
    id = fields.IntField(pk=True)
    child_id = fields.IntField()
    club_id = fields.IntField()
    notified = fields.BooleanField(default=False)  # Joy bo'shalganda xabar yuborildi
    notified_at = fields.DatetimeField(null=True)   # Xabar yuborilgan vaqt (24 soat amal qiladi)
    created_at = fields.DatetimeField(auto_now_add=True)

    class Meta:
        table = "waiting_list"
