"""
SmartDMTT v4.0 — Qurilma modeli
Primary qurilma hech qachon o'chirilmaydi.
"""
from tortoise import fields
from tortoise.models import Model


class Device(Model):
    id = fields.IntField(pk=True)
    user_id = fields.BigIntField()                 # User ID
    device_hash = fields.CharField(max_length=64)  # SHA256 hash
    device_info = fields.CharField(max_length=255, null=True)  # "Chrome • Windows 10"
    is_primary = fields.BooleanField(default=False)  # Birinchi qurilma — o'chirilmaydi
    last_seen = fields.DatetimeField(auto_now=True)
    created_at = fields.DatetimeField(auto_now_add=True)

    class Meta:
        table = "devices"
        unique_together = (("user_id", "device_hash"),)
