from tortoise import fields, models

class AbsenceNotice(models.Model):
    id = fields.IntField(pk=True)
    # qaysi to'garak a'zosi kela olmasligi
    enrollment = fields.ForeignKeyField('models.Enrollment', related_name='absence_notices')
    # qaysi sana uchun xabar berildi
    date = fields.DateField()
    # sababi (sick yoki other)
    reason = fields.CharField(max_length=20)
    created_at = fields.DatetimeField(auto_now_add=True)

    class Meta:
        table = "absence_notices"