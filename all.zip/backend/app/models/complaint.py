"""
SmartDMTT v4 — Shikoyat, taklif va maqtov modeli
"""
from tortoise import fields
from tortoise.models import Model


class Complaint(Model):
    id = fields.IntField(pk=True)
    user = fields.ForeignKeyField("models.User", related_name="complaints")

    complaint_type = fields.CharField(
        max_length=15,
        description="complaint | suggestion | praise"
    )
    target_type = fields.CharField(
        max_length=15,
        description="teacher | club | kindergarten | system"
    )
    target_id = fields.IntField(null=True)

    text         = fields.TextField()
    is_anonymous = fields.BooleanField(default=True)

    status = fields.CharField(
        max_length=15,
        default="new",
        description="new | in_progress | resolved | rejected"
    )

    response     = fields.TextField(null=True)
    responded_by = fields.ForeignKeyField(
        "models.User", related_name="complaint_responses", null=True
    )
    responded_at = fields.DatetimeField(null=True)
    created_at   = fields.DatetimeField(auto_now_add=True)

    class Meta:
        table = "complaints"
