from tortoise import fields, models

class Analytics(models.Model):
    id = fields.IntField(pk=True)
    event_type = fields.CharField(max_length=50)
    user_id = fields.CharField(max_length=50)
    details = fields.TextField()
    timestamp = fields.DatetimeField(auto_now_add=True)

    class Meta:
        table = "analytics"
