"""
SmartDMTT v4 — Tizim sozlamalari modeli
"""
from tortoise import fields
from tortoise.models import Model


class SystemSettings(Model):
    id    = fields.IntField(pk=True)
    key   = fields.CharField(max_length=50, unique=True)
    value = fields.CharField(max_length=200)

    updated_by = fields.ForeignKeyField("models.User", related_name="settings_changes", null=True)
    updated_at = fields.DatetimeField(auto_now=True)

    class Meta:
        table = "system_settings"
