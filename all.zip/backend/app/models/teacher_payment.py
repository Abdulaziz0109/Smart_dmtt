"""
SmartDMTT v4 — Muallim oylik hisob modeli
"""
from tortoise import fields
from tortoise.models import Model


class TeacherPayment(Model):
    id = fields.IntField(pk=True)
    teacher = fields.ForeignKeyField("models.User", related_name="teacher_payments")
    month = fields.CharField(max_length=7)   # Masalan: 2025-03

    # Summalar
    base_amount  = fields.DecimalField(max_digits=12, decimal_places=0, default=0)
    bonus_amount = fields.DecimalField(max_digits=12, decimal_places=0, default=0)

    # Hisob ko'rsatkichlari
    attendance_rate  = fields.FloatField(default=0)   # Davomat foizi (0-100)
    parent_rating    = fields.FloatField(default=0)   # Ota-ona reytingi (0-5)
    lessons_count    = fields.IntField(default=0)     # O'tilgan darslar soni

    status  = fields.CharField(max_length=10, default="pending")  # pending | paid
    paid_at = fields.DatetimeField(null=True)

    created_at = fields.DatetimeField(auto_now_add=True)

    class Meta:
        table = "teacher_payments"
        unique_together = (("teacher", "month"),)
