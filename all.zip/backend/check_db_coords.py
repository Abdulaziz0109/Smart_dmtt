import sqlite3
import os

# Path to database
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DB_PATH = os.path.join(BASE_DIR, "data", "database.sqlite")

def check_coords():
    if not os.path.exists(DB_PATH):
        print(f"❌ Database file not found: {DB_PATH}")
        return

    print(f"📂 Connecting to: {DB_PATH}")
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()

    try:
        cur.execute("SELECT id, name, lat, lon FROM kindergartens")
        rows = cur.fetchall()
        
        print("\n--- Current Database Coordinates ---")
        for row in rows:
            print(f"ID: {row[0]}, Name: {row[1]}, Lat: {row[2]}, Lon: {row[3]}")
            
    except Exception as e:
        print(f"❌ Error querying database: {e}")

    conn.close()

if __name__ == "__main__":
    check_coords()