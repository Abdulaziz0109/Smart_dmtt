print("⚠️ This script is disabled for safety. Please use 'check_db_coords.py' to inspect database values first.")
import sqlite3
import json
import os

# Paths
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
JSON_PATH = os.path.join(BASE_DIR, "data", "kindergartens.json")
DB_PATH = os.path.join(BASE_DIR, "data", "database.sqlite")

def sync_coords():
    if not os.path.exists(JSON_PATH):
        print(f"❌ JSON file not found: {JSON_PATH}")
        return
    
    if not os.path.exists(DB_PATH):
        print(f"❌ Database file not found: {DB_PATH}")
        return

    print(f"📂 Reading from: {JSON_PATH}")
    with open(JSON_PATH, "r", encoding="utf-8") as f:
        data = json.load(f)
        kgs = data.get("kindergartens", data) if isinstance(data, dict) else data

    print(f"📂 Connecting to: {DB_PATH}")
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()

    updated_count = 0
    for kg in kgs:
        kg_id = kg.get("id")
        lat = kg.get("lat")
        lon = kg.get("lon")
        
        if lat is not None and lon is not None:
            # Check current values
            cur.execute("SELECT lat, lon FROM kindergartens WHERE id = ?", (kg_id,))
            row = cur.fetchone()
            
            if row:
                current_lat, current_lon = row
                if current_lat != lat or current_lon != lon:
                    print(f"🔄 Updating ID {kg_id}: ({current_lat}, {current_lon}) -> ({lat}, {lon})")
                    cur.execute("UPDATE kindergartens SET lat = ?, lon = ? WHERE id = ?", (lat, lon, kg_id))
                    updated_count += 1
                else:
                    # print(f"✅ ID {kg_id} matches.")
                    pass
            else:
                print(f"⚠️ ID {kg_id} not found in database.")

    conn.commit()
    conn.close()
    print(f"✅ Sync complete. Updated {updated_count} kindergartens.")

if __name__ == "__main__":
    sync_coords()