import sqlite3
import os

db_path = "data/database.sqlite"
if not os.path.exists(db_path):
    print(f"Database not found at {db_path}")
    exit(1)

conn = sqlite3.connect(db_path)
cur = conn.cursor()

print("--- Checking Kindergartens in SQLite ---")
try:
    cur.execute("SELECT id, name, lat, lon FROM kindergartens")
    rows = cur.fetchall()
    for row in rows:
        print(f"ID: {row[0]}, Name: {row[1]}, Lat: {row[2]}, Lon: {row[3]}")
except Exception as e:
    print(f"Error querying kindergartens: {e}")

conn.close()