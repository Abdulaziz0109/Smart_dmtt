#!/usr/bin/env python3
"""
SmartMMTB - Yuz tanish orqali davomat tizimi
Wi-Fi orqali serverga ulanadi, qo'shimcha kabel shart emas.

Talab qilinadigan kutubxonalar:
  pip install face-recognition opencv-python-headless requests pillow numpy

Qurilma: Devorga o'rnatilgan Android planshet yoki Raspberry Pi + kamera
Rejim: Kiosk (to'liq ekran, avtomatik)
"""

import cv2
import face_recognition
import numpy as np
import requests
import json
import os
import time
import logging
from datetime import datetime
from pathlib import Path
from threading import Thread
from typing import Optional, Dict, List
from dotenv import load_dotenv

# Load .env from project root
env_path = Path(__file__).parent.parent / ".env"
load_dotenv(dotenv_path=env_path)

# ─── Sozlamalar ──────────────────────────────────────────────
SERVER_URL = os.getenv("SERVER_URL", "http://localhost:8000")
API_TOKEN = os.getenv("FACE_DEVICE_TOKEN", "device_secret_token_change_me")
KINDERGARTEN = os.getenv("KINDERGARTEN_NAME", "Bog'cha 1")
FACES_DIR = Path("backend/face_data")   # Yuz rasmlari papkasi
COOLDOWN_SEC = 30               # Bir bola qayta tanilgunga qadar kutish (soniya)
CONFIDENCE = 0.45               # Tanish ishonchlilik chegarasi (pastroq = qat'iyroq)
CAMERA_INDEX = 0                # Kamera raqami (USB = 0,1,2...)
SHOW_WINDOW = os.getenv("SHOW_WINDOW", "true").lower() == "true"

logging.basicConfig(level=logging.INFO, format='%(asctime)s [%(levelname)s] %(message)s')
log = logging.getLogger("FaceAttendance")

# ─── Yuz bazasi ──────────────────────────────────────────────

class FaceDatabase:
    """Bolalar yuz kodlari bazasini boshqaradi."""

    def __init__(self):
        self.encodings: List[np.ndarray] = []
        self.child_ids: List[str] = []
        self.child_names: List[str] = []
        FACES_DIR.mkdir(exist_ok=True, parents=True)
        self.load_from_disk()

    def load_from_disk(self):
        """Diskdan barcha yuz rasmlarini yuklaydi."""
        self.encodings.clear()
        self.child_ids.clear()
        self.child_names.clear()

        for folder in FACES_DIR.iterdir():
            if not folder.is_dir():
                continue
            child_id = folder.name
            meta_file = folder / "meta.json"
            name = child_id
            if meta_file.exists():
                try:
                    meta = json.loads(meta_file.read_text())
                    name = meta.get("full_name", child_id)
                except:
                    pass

            imgs_loaded = 0
            for img_file in folder.glob("*.jpg"):
                img = face_recognition.load_image_file(str(img_file))
                encs = face_recognition.face_encodings(img)
                if encs:
                    self.encodings.append(encs[0])
                    self.child_ids.append(child_id)
                    self.child_names.append(name)
                    imgs_loaded += 1

            if imgs_loaded:
                log.info(f"Yuklandi: {name} ({child_id}) - {imgs_loaded} ta rasm")

        log.info(f"Jami bazada: {len(set(self.child_ids))} ta bola, {len(self.encodings)} ta yuz")

    def add_face(self, child_id: str, full_name: str, image_path: str) -> bool:
        """Yangi yuz qo'shadi."""
        folder = FACES_DIR / child_id
        folder.mkdir(exist_ok=True, parents=True)
        (folder / "meta.json").write_text(json.dumps({"full_name": full_name, "child_id": child_id}))

        # Rasm nusxasini saqlash
        import shutil
        target = folder / f"photo_{len(list(folder.glob('*.jpg')))+1}.jpg"
        shutil.copy(image_path, target)
        self.load_from_disk()
        return True

    def recognize(self, frame_encoding: np.ndarray) -> Optional[Dict]:
        """Yuz kodini bazada qidiradi."""
        if not self.encodings:
            return None
        distances = face_recognition.face_distance(self.encodings, frame_encoding)
        best_idx = int(np.argmin(distances))
        best_dist = float(distances[best_idx])

        if best_dist <= CONFIDENCE:
            return {
                "child_id": self.child_ids[best_idx],
                "full_name": self.child_names[best_idx],
                "confidence": round((1 - best_dist) * 100, 1)
            }
        return None


# ─── Server bilan aloqa ──────────────────────────────────────

class AttendanceAPI:
    """Serverga davomat yuboradi va Telegram xabar yuboradi."""

    def __init__(self):
        self.cooldowns: Dict[str, float] = {}

    def is_cooldown(self, child_id: str) -> bool:
        last = self.cooldowns.get(child_id, 0)
        return (time.time() - last) < COOLDOWN_SEC

    def mark_arrival(self, child_id: str, full_name: str, photo_bytes: bytes) -> bool:
        """Keldi deb belgilaydi va Telegram xabar yuboradi."""
        if self.is_cooldown(child_id):
            return False

        self.cooldowns[child_id] = time.time()
        now = datetime.now()

        def send():
            try:
                r = requests.post(
                    f"{SERVER_URL}/api/attendance/face-mark",
                    headers={"Authorization": f"Bearer {API_TOKEN}"},
                    json={
                        "child_id": child_id,
                        "full_name": full_name,
                        "date": now.strftime("%Y-%m-%d"),
                        "time": now.strftime("%H:%M"),
                        "kindergarten": KINDERGARTEN,
                        "status": "present"
                    },
                    timeout=10
                )
                if r.ok:
                    log.info(f"✅ Server: {full_name} - belgilandi")
                else:
                    log.warning(f"Server xatosi: {r.status_code} {r.text[:100]}")
            except requests.exceptions.ConnectionError:
                # Offline rejim - mahalliy faylga yozish
                log.warning("Server mavjud emas, mahalliy faylga yozildi")
                self._save_offline(child_id, full_name, now)
            except Exception as e:
                log.error(f"API xatosi: {e}")

        Thread(target=send, daemon=True).start()
        return True

    def _save_offline(self, child_id: str, full_name: str, dt: datetime):
        """Internet yo'q bo'lganda mahalliy faylga saqlaydi."""
        offline_file = Path("backend/data/offline_attendance.json")
        offline_file.parent.mkdir(exist_ok=True, parents=True)
        records = []
        if offline_file.exists():
            try:
                records = json.loads(offline_file.read_text())
            except:
                pass
        records.append({
            "child_id": child_id,
            "full_name": full_name,
            "date": dt.strftime("%Y-%m-%d"),
            "time": dt.strftime("%H:%M:%S"),
            "kindergarten": KINDERGARTEN,
            "synced": False
        })
        offline_file.write_text(json.dumps(records, ensure_ascii=False, indent=2))

    def sync_offline(self):
        """Internet kelganda offline yozuvlarni serverga yuboradi."""
        offline_file = Path("backend/data/offline_attendance.json")
        if not offline_file.exists():
            return
        records = json.loads(offline_file.read_text())
        pending = [r for r in records if not r.get("synced")]
        synced_count = 0
        for r in pending:
            try:
                resp = requests.post(
                    f"{SERVER_URL}/api/attendance/face-mark",
                    headers={"Authorization": f"Bearer {API_TOKEN}"},
                    json=r,
                    timeout=5
                )
                if resp.ok:
                    r["synced"] = True
                    synced_count += 1
            except:
                break
        if synced_count:
            offline_file.write_text(json.dumps(records, ensure_ascii=False, indent=2))
            log.info(f"🔄 Offline sync: {synced_count} ta yozuv yuborildi")


# ─── Asosiy Kamera Sikli ─────────────────────────────────────

class FaceAttendanceSystem:
    """Asosiy tizim - kamera o'qish, yuz tanish, davomat belgilash."""

    def __init__(self):
        self.db = FaceDatabase()
        self.api = AttendanceAPI()
        self.last_result: Optional[str] = None
        self.last_result_time: float = 0
        self.result_display_sec = 3  # Natija ekranda ko'rinish davomiyligi

        # Kamera
        log.info(f"Kamera {CAMERA_INDEX} ochilmoqda...")
        self.cap = cv2.VideoCapture(CAMERA_INDEX)
        if not self.cap.isOpened():
            raise RuntimeError(f"Kamera {CAMERA_INDEX} ochmadi! USB/kamera ulanganini tekshiring.")
        self.cap.set(cv2.CAP_PROP_FRAME_WIDTH, 640)
        self.cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 480)
        log.info("Kamera tayyor ✅")

    def process_frame(self, frame: np.ndarray) -> Optional[Dict]:
        """Kadrni qayta ishlaydi: yuzni topadi va taniydi."""
        # Kichiklashtirish (tezlik uchun)
        small = cv2.resize(frame, (0, 0), fx=0.5, fy=0.5)
        rgb_small = cv2.cvtColor(small, cv2.COLOR_BGR2RGB)

        # Yuzlarni aniqlash
        locations = face_recognition.face_locations(rgb_small, model="hog")
        if not locations:
            return None

        # Yuz kodini olish (faqat birinchi yuz)
        encodings = face_recognition.face_encodings(rgb_small, locations[:1])
        if not encodings:
            return None

        result = self.db.recognize(encodings[0])

        if result:
            # Yuz atrofiga ramka chizish
            top, right, bottom, left = locations[0]
            top, right, bottom, left = top*2, right*2, bottom*2, left*2

            color = (0, 200, 0)  # Yashil
            cv2.rectangle(frame, (left, top), (right, bottom), color, 2)
            cv2.rectangle(frame, (left, bottom-30), (right, bottom), color, cv2.FILLED)
            cv2.putText(frame, f"{result['full_name']} {result['confidence']}%",
                       (left+4, bottom-8), cv2.FONT_HERSHEY_SIMPLEX, 0.55, (255,255,255), 1)
        else:
            # Tanilmagan yuz - qizil ramka
            for (top, right, bottom, left) in locations[:1]:
                top, right, bottom, left = top*2, right*2, bottom*2, left*2
                cv2.rectangle(frame, (left, top), (right, bottom), (0, 0, 220), 2)
                cv2.putText(frame, "Tanilmadi", (left+4, bottom+20),
                           cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0,0,220), 1)

        return result

    def draw_overlay(self, frame: np.ndarray, result: Optional[Dict]):
        """Ekranda ma'lumot ko'rsatadi."""
        h, w = frame.shape[:2]
        now = datetime.now().strftime("%H:%M:%S — %d.%m.%Y")

        # Yuqori bar
        cv2.rectangle(frame, (0, 0), (w, 45), (26, 58, 107), cv2.FILLED)
        cv2.putText(frame, f"SmartMMTB | {KINDERGARTEN}", (10, 16),
                   cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255,255,255), 1)
        cv2.putText(frame, now, (10, 36), cv2.FONT_HERSHEY_SIMPLEX, 0.45, (200,210,255), 1)

        # Natija banneri
        if result and (time.time() - self.last_result_time) < self.result_display_sec:
            banner_h = 80
            overlay = frame.copy()
            cv2.rectangle(overlay, (0, h-banner_h), (w, h), (0, 150, 0), cv2.FILLED)
            cv2.addWeighted(overlay, 0.8, frame, 0.2, 0, frame)
            cv2.putText(frame, f"✓ {result['full_name']}",
                       (20, h-50), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (255,255,255), 2)
            cv2.putText(frame, f"Vaqt: {datetime.now().strftime('%H:%M')} | {result['confidence']}% ishonch",
                       (20, h-22), cv2.FONT_HERSHEY_SIMPLEX, 0.45, (200,255,200), 1)
        else:
            cv2.rectangle(frame, (0, h-40), (w, h), (26, 58, 107), cv2.FILLED)
            cv2.putText(frame, "Kameraga qarang...", (20, h-16),
                       cv2.FONT_HERSHEY_SIMPLEX, 0.5, (200,210,255), 1)

        return frame

    def run(self):
        """Asosiy siklni ishga tushiradi."""
        log.info("🚀 Yuz tanish tizimi ishga tushdi!")
        log.info("Chiqish uchun 'q' tugmasini bosing.")

        # Offline sync (har 5 daqiqada)
        last_sync = time.time()
        frame_count = 0

        while True:
            ret, frame = self.cap.read()
            if not ret:
                log.error("Kameradan kadr o'qilmadi!")
                time.sleep(0.5)
                continue

            frame_count += 1
            result = None

            # Har 5-kadrda bir marta yuz tanish (tezlik)
            if frame_count % 5 == 0:
                result = self.process_frame(frame)
                if result:
                    # Davomatga belgilash
                    marked = self.api.mark_arrival(
                        result["child_id"],
                        result["full_name"],
                        cv2.imencode('.jpg', frame)[1].tobytes()
                    )
                    if marked:
                        self.last_result = result
                        self.last_result_time = time.time()
                        log.info(f"📍 Keldi: {result['full_name']} ({result['confidence']}%)")

            if SHOW_WINDOW:
                display = self.draw_overlay(frame, self.last_result)
                cv2.imshow("SmartMMTB - Davomat", display)
                if cv2.waitKey(1) & 0xFF == ord('q'):
                    break

            # Offline sync
            if time.time() - last_sync > 300:
                Thread(target=self.api.sync_offline, daemon=True).start()
                last_sync = time.time()

        self.cap.release()
        if SHOW_WINDOW:
            cv2.destroyAllWindows()
        log.info("Tizim to'xtatildi.")


# ─── Yuz qo'shish yordamchisi ────────────────────────────────

def add_child_face(child_id: str, full_name: str, camera_index: int = 0):
    """Interaktiv yuz ro'yxatga olish - foto surib bazaga qo'shadi."""
    db = FaceDatabase()
    cap = cv2.VideoCapture(camera_index)
    if not cap.isOpened():
        print("Kamera ochmadi!")
        return

    print(f"\n📷 {full_name} uchun yuz suratga olinmoqda...")
    print("SPACE - foto olish | Q - chiqish")
    photos_taken = 0

    while True:
        ret, frame = cap.read()
        if not ret:
            break

        cv2.putText(frame, f"Joyga turing: {full_name}", (10, 30),
                   cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 200, 0), 2)
        cv2.putText(frame, f"Olingan: {photos_taken}/3 | SPACE=foto, Q=chiqish",
                   (10, 60), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (200, 200, 0), 1)
        cv2.imshow(f"Ro'yxat: {full_name}", frame)

        key = cv2.waitKey(1) & 0xFF
        if key == ord(' '):
            # Yuz bor mi?
            rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            locs = face_recognition.face_locations(rgb)
            if locs:
                save_path = f"backend/data/temp_face_{child_id}_{photos_taken}.jpg"
                cv2.imwrite(save_path, frame)
                db.add_face(child_id, full_name, save_path)
                photos_taken += 1
                print(f"✅ Foto {photos_taken} olindi")
                if photos_taken >= 3:
                    print(f"✅ {full_name} bazaga qo'shildi!")
                    break
            else:
                print("⚠️  Yuz topilmadi, qaytadan urinib ko'ring")
        elif key == ord('q'):
            break

    cap.release()
    cv2.destroyAllWindows()


# ─── Ishga tushirish ─────────────────────────────────────────

if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(description="SmartMMTB Face Attendance System")
    parser.add_argument("--add-face", action="store_true", help="Yangi yuz qo'shish")
    parser.add_argument("--child-id", type=str, help="Bola ID (masalan: CH1234)")
    parser.add_argument("--child-name", type=str, help="Bola to'liq ismi")
    parser.add_argument("--camera", type=int, default=0, help="Kamera indeksi")
    args = parser.parse_args()

    if args.add_face:
        if not args.child_id or not args.child_name:
            print("--child-id va --child-name kerak!")
        else:
            add_child_face(args.child_id, args.child_name, args.camera)
    else:
        # Asosiy rejim - davomat
        system = FaceAttendanceSystem()
        system.run()
