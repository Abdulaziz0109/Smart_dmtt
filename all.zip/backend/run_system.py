"""
SmartDMTT - Asosiy ishga tushirish skripti
Bot va Admin API ni birgalikda ishga tushiradi
"""
import asyncio
import logging
import sys
from pathlib import Path

# Logs papkasini yaratish
Path("logs").mkdir(exist_ok=True)

# Logging sozlash
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s | %(levelname)s | %(name)s | %(message)s',
    datefmt='%H:%M:%S',
    handlers=[
        logging.StreamHandler(sys.stdout),
        logging.FileHandler('logs/smartdmtt.log', encoding='utf-8', mode='a')
    ]
)
logger = logging.getLogger(__name__)

# Logs papkasini yaratish
Path("logs").mkdir(exist_ok=True)


async def start_bot():
    """Telegram botni ishga tushirish."""
    from app.core import config
    from app.services import database as db
    from app.services import scheduler
    
    if not config.validate():
        logger.error("Konfiguratsiya xatosi! .env faylni tekshiring.")
        sys.exit(1)
    
    logger.info("🤖 Bot ishga tushirilmoqda...")
    
    # Tortoise ORM va SQLite jadvallarini yaratish
    try:
        from tortoise import Tortoise
        # import database_tortoise # Legacy/Fixes version
        await Tortoise.init(
            db_url='sqlite://data/database.sqlite',
            modules={'models': ['app.models']} # Adapted to project structure
        )
        await Tortoise.generate_schemas(safe=True)
        logger.info("✅ Tortoise ORM va SQLite jadvallar tayyor")
    except Exception as e:
        logger.warning(f"⚠️ Tortoise ORM init xatosi (bu normal): {e}")
    
    # Asosiy handlerlarni import qilish va ularning bot/dp obyektlarini olish
    from app.bot import main as bot_main
    bot = bot_main.bot
    dp = bot_main.dp
    
    # DB ni ishga tushirish
    await db.refresh_cache()
    logger.info("✅ Database (JSON) yuklandi")
    
    # Schedulerni ishga tushirish
    # scheduler.setup_scheduler(bot) # Original from fixes
    scheduler.SchedulerService.setup(bot) # Adapted to project structure
    logger.info("✅ Scheduler ishga tushdi")
    
    logger.info("🚀 Bot polling boshlandi!")
    await dp.start_polling(bot, drop_pending_updates=True)


async def start_api():
    """Admin API ni ishga tushirish."""
    from app.core import config
    import uvicorn
    # from admin_api import app # Switch to api.py for Web App
    from app.api.main import app
    
    logger.info(f"🌐 Admin Panel: http://localhost:{config.API_PORT}")
    
    config_obj = uvicorn.Config(
        app=app,
        host=config.API_HOST,
        port=config.API_PORT,
        log_level="warning"
    )
    server = uvicorn.Server(config_obj)
    await server.serve()


async def main():
    """Bot va API ni parallel ishga tushirish."""
    print("""
╔══════════════════════════════════════════════╗
║          🏫 SmartDMTT v2.0                  ║
║     Bog'cha Boshqaruv Tizimi                ║
╚══════════════════════════════════════════════╝
""")
    
    # Ikkisini parallel ishga tushirish
    await asyncio.gather(
        start_bot(),
        start_api()
    )

if __name__ == "__main__":
    try:
        # Windows da SelectorEventLoop ishlatish (agar kerak bo'lsa)
        if sys.platform == 'win32':
            asyncio.set_event_loop_policy(asyncio.WindowsSelectorEventLoopPolicy())
        asyncio.run(main())
    except (KeyboardInterrupt, SystemExit):
        logger.info("🛑 Tizim to'xtatildi")
