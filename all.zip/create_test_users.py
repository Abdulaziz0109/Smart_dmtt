"""
SmartDMTT v4 — Test foydalanuvchilar yaratish (tuzatilgan)
Ishlatish: python create_test_users.py
"""
import sqlite3, bcrypt, os, sys

DB_PATH = os.path.join(os.path.dirname(__file__), "backend", "data", "database.sqlite")
if not os.path.exists(DB_PATH):
    DB_PATH = os.path.join(os.path.dirname(__file__), "data", "database.sqlite")
if not os.path.exists(DB_PATH):
    print(f"❌ DB topilmadi: {DB_PATH}")
    sys.exit(1)

def h(pw): return bcrypt.hashpw(pw.encode(), bcrypt.gensalt()).decode()

# telegram_id = NULL — conflict bo'lmasin
TEST_USERS = [
    # (id,        name,                  phone,            password,      role,              kg_id)
    (10000001, "Admin Tester",       "+998900000001", "admin123",    "admin",           None),
    (10000002, "Boshliq Tester",     "+998900000002", "boshliq123",  "boshliq",         1),
    (10000003, "Direktor Tester",    "+998900000003", "director123", "director",        1),
    (10000004, "Muallim Tester",     "+998900000004", "teacher123",  "teacher",         1),
    (10000005, "Ota-ona Tester",     "+998900000005", "parent123",   "parent",          None),
    (10000006, "Iqtisodchi Tester",  "+998900000006", "iqtisod123",  "iqtisodchi",      1),
    (10000007, "Togarak Rahbar",     "+998900000007", "togarak123",  "togarak_rahbari", 1),
    (10000008, "MMTB Boshliq",       "+998900000008", "mmtb123",     "mmtb_boshligi",   None),
]

def run():
    conn = sqlite3.connect(DB_PATH)
    cur  = conn.cursor()
    cur.execute("PRAGMA table_info(users)")
    cols = {r[1] for r in cur.fetchall()}
    print(f"📋 Jadval ustunlari: {cols}\n")

    has_is_test = "is_test" in cols
    has_kg      = "kindergarten_id" in cols

    created = updated = 0

    for uid, name, phone, password, role, kg_id in TEST_USERS:
        pw_hash = h(password)

        cur.execute("SELECT id FROM users WHERE id=? OR phone=?", (uid, phone))
        row = cur.fetchone()

        if row:
            sets = ["full_name=?", "phone=?", "username=?", "role=?"]
            vals = [name, phone, pw_hash, role]
            if has_kg and kg_id:
                sets.append("kindergarten_id=?"); vals.append(kg_id)
            if has_is_test:
                sets.append("is_test=?"); vals.append(1)
            vals += [uid, phone]
            cur.execute(f"UPDATE users SET {', '.join(sets)} WHERE id=? OR phone=?", vals)
            updated += 1
            print(f"  🔄 Yangilandi: [{role:<18}] {name}")
        else:
            base_cols = ["id","full_name","phone","username","role"]
            base_vals = [uid, name, phone, pw_hash, role]
            if has_kg:
                base_cols.append("kindergarten_id"); base_vals.append(kg_id)
            if has_is_test:
                base_cols.append("is_test"); base_vals.append(1)
            ph = ",".join("?"*len(base_cols))
            cur.execute(f"INSERT INTO users ({','.join(base_cols)}) VALUES ({ph})", base_vals)
            created += 1
            print(f"  ✅ Yaratildi:  [{role:<18}] {name}")

    conn.commit(); conn.close()

    print(f"\n{'='*55}")
    print(f"✅  {created} ta yangi | {updated} ta yangilandi")
    print(f"{'='*55}")
    print("📋 LOGIN MA'LUMOTLARI (webapp → Telefon + Parol):")
    print(f"{'='*55}")
    for _, name, phone, password, role, _ in TEST_USERS:
        print(f"  {role:<20} {phone}   parol: {password}")
    print(f"{'='*55}")
    print("\n💡 Kirish: ngrok URL → Telefon + Parol")

if __name__ == "__main__":
    run()
