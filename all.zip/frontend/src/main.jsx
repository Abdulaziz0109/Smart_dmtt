import React from 'react'
import { createRoot } from 'react-dom/client'
import App from './App.jsx'
import ErrorBoundary from './components/ErrorBoundary.jsx'
import './index.css'

// Global error handler for chunk loading failures
window.addEventListener('error', (event) => {
  // Check if the error is related to loading a module
  if (event.message && (
      event.message.includes('Failed to fetch dynamically imported module') ||
      event.message.includes('Importing a module script failed')
  )) {
    console.warn('Chunk load failed. Reloading page...', event.message);
    // Prevent infinite reload loop if server is down
    if (!sessionStorage.getItem('chunk_reload_attempted')) {
       sessionStorage.setItem('chunk_reload_attempted', 'true');
       window.location.reload(true);
    }
  }
});

// Clear the reload flag on successful load
window.addEventListener('load', () => {
    setTimeout(() => sessionStorage.removeItem('chunk_reload_attempted'), 5000);
});

createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <ErrorBoundary>
      <App />
    </ErrorBoundary>
  </React.StrictMode>
)
