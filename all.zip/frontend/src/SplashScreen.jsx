/**
 * SmartDMTT v4 — SplashScreen + App entry point
 * JWT tekshirish, token yangilash, auth flow
 */
import { useState, useEffect } from 'react'
import { AppProvider, useApp } from './context/AppContext'
import LoginScreen from './screens/LoginScreen'
import MainApp     from './screens/MainApp'

function AppRouter() {
  const { token, setToken, setUser } = useApp()
  const [checking, setChecking] = useState(true)
  const [valid,    setValid]    = useState(false)

  useEffect(() => {
    if (!token) { setChecking(false); return }

    // Token validligini tekshirish
    fetch('/api/users/me', {
      headers: {
        Authorization: `Bearer ${token}`,
        'ngrok-skip-browser-warning': 'true',
      }
    })
      .then(r => {
        if (!r.ok) throw new Error('invalid')
        return r.json()
      })
      .then(user => {
        setUser(user)
        setValid(true)
        setChecking(false)
      })
      .catch(() => {
        setToken(null)
        setValid(false)
        setChecking(false)
      })
  }, [])

  if (checking) return <SplashScreen />
  if (!token || !valid) return <LoginScreen />
  return <MainApp />
}

function SplashScreen() {
  const [dots, setDots] = useState('.')
  useEffect(() => {
    const id = setInterval(() => setDots(d => d.length >= 3 ? '.' : d + '.'), 400)
    return () => clearInterval(id)
  }, [])

  return (
    <div style={{
      minHeight: '100dvh', display: 'flex', flexDirection: 'column',
      alignItems: 'center', justifyContent: 'center',
      background: 'linear-gradient(160deg, #eef2ff 0%, #f8fafc 60%, #fdf4ff 100%)',
    }}>
      <div style={{ textAlign: 'center' }}>
        {/* Logo animatsiya */}
        <div style={{
          fontSize: 72, marginBottom: 16,
          animation: 'pulse 1.5s ease-in-out infinite',
        }}>🏫</div>
        <div style={{ fontSize: 28, fontWeight: 900, color: '#6366f1', letterSpacing: -1 }}>
          SmartDMTT
        </div>
        <div style={{ fontSize: 14, color: '#9ca3af', marginTop: 8, marginBottom: 32 }}>
          Bulung'ur tuman MTT tizimi
        </div>

        {/* Spinner */}
        <div style={{ display: 'flex', gap: 8, justifyContent: 'center', marginBottom: 16 }}>
          {[0, 1, 2].map(i => (
            <div key={i} style={{
              width: 10, height: 10, borderRadius: '50%', background: '#6366f1',
              animation: `bounce 1s ease-in-out ${i * 0.15}s infinite`,
            }} />
          ))}
        </div>
        <div style={{ fontSize: 13, color: '#9ca3af' }}>Yuklanmoqda{dots}</div>
      </div>

      <style>{`
        @keyframes pulse {
          0%, 100% { transform: scale(1); }
          50% { transform: scale(1.08); }
        }
        @keyframes bounce {
          0%, 100% { transform: translateY(0); opacity: 0.4; }
          50% { transform: translateY(-10px); opacity: 1; }
        }
      `}</style>
    </div>
  )
}

export default function App() {
  return (
    <AppProvider>
      <AppRouter />
    </AppProvider>
  )
}
