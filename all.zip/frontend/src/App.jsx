import { AppProvider, useApp } from './context/AppContext'
import SplashScreen from './screens/SplashScreen'
import LoginPage from './screens/LoginPage'
import MainApp from './screens/MainApp'
import ErrorBoundary from './components/ErrorBoundary'

function AppInner() {
  const { phase } = useApp()
  if (phase === 'splash') return <SplashScreen />
  if (phase === 'auth') return <LoginPage />
  return <MainApp />
}

export default function App() {
  return (
    <ErrorBoundary>
      <AppProvider>
        <AppInner />
      </AppProvider>
    </ErrorBoundary>
  )
}
