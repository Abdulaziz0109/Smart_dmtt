/**
 * MainApp — Asosiy konteyner
 * Pastki navigatsiya, rol asosida turli tablar
 */
import { useState, lazy, Suspense } from 'react'
import { useApp } from './AppContext'
import HelpTooltip from './components/HelpTooltip'
import LegalModal from './components/LegalModal'
import RoleSwitcher from './components/RoleSwitcher'

const HomeTab     = lazy(() => import('./screens/tabs/HomeTab'))
const ChildrenTab = lazy(() => import('./screens/tabs/ChildrenTab'))
const ClubsTab    = lazy(() => import('./screens/tabs/ClubsTab'))
const MapTab      = lazy(() => import('./screens/tabs/MapTab'))
const ProfileTab  = lazy(() => import('./screens/tabs/ProfileTab'))
const AdminTab    = lazy(() => import('./screens/tabs/AdminTab'))
const TeacherTab  = lazy(() => import('./screens/tabs/TeacherTab'))
const PaymentTab  = lazy(() => import('./screens/tabs/PaymentTab'))

function TabLoading() {
  return (
    <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', height: '60vh' }}>
      <div style={{
        width: 36, height: 36, border: '3px solid var(--primary-50)',
        borderTopColor: 'var(--primary)', borderRadius: '50%',
        animation: 'spin 0.7s linear infinite',
      }} />
    </div>
  )
}

function NavItem({ icon, label, active, onClick, badge }) {
  return (
    <button onClick={onClick} style={{
      flex: 1, display: 'flex', flexDirection: 'column',
      alignItems: 'center', gap: 3, padding: '8px 4px',
      border: 'none', background: 'none', cursor: 'pointer',
      position: 'relative', fontFamily: 'var(--font)',
      WebkitTapHighlightColor: 'transparent',
      transition: 'transform 0.15s',
    }}>
      <div style={{
        width: 44, height: 28, borderRadius: 14,
        background: active ? 'var(--primary-50)' : 'transparent',
        display: 'flex', alignItems: 'center', justifyContent: 'center',
        fontSize: 20, transition: 'all 0.2s',
        transform: active ? 'scale(1.08)' : 'scale(1)',
      }}>{icon}</div>
      <span style={{
        fontSize: 10, fontWeight: active ? 800 : 500,
        color: active ? 'var(--primary)' : 'var(--text-light)',
        transition: 'color 0.2s', lineHeight: 1,
      }}>{label}</span>
      {active && (
        <div style={{ width: 4, height: 4, borderRadius: '50%', background: 'var(--primary)', marginTop: -1 }} />
      )}
      {badge > 0 && (
        <div style={{
          position: 'absolute', top: 4, right: 'calc(50% - 12px)',
          background: '#EF4444', color: '#fff', borderRadius: '50%',
          width: 16, height: 16, fontSize: 9, fontWeight: 800,
          display: 'flex', alignItems: 'center', justifyContent: 'center',
        }}>{badge > 9 ? '9+' : badge}</div>
      )}
    </button>
  )
}

export default function MainApp() {
  const { user, tr } = useApp()
  const [activeTab, setActiveTab] = useState('home')
  const [legalType, setLegalType] = useState(null)

  const roles = user?.roles || [user?.role || 'guest']

  // ── Rol asosida navigatsiya ───────────────────────────────────────────────
  let navItems = []

  if (roles.includes('admin')) {
    navItems = [
      { id: 'home',       icon: '🏠', label: tr('nav_home') },
      { id: 'users',      icon: '👥', label: tr('users') || 'Users' },
      { id: 'admin',      icon: '📊', label: tr('stats') || 'Stat' },
      { id: 'ai_journal', icon: '📓', label: tr('ai_journal') || 'AI Log' },
      { id: 'system',     icon: '⚙️', label: tr('system') || 'Tizim' },
      { id: 'profile',    icon: '👤', label: tr('nav_profile') },
    ]
  } else if (roles.includes('boshliq') || roles.includes('mmtb_boshligi')) {
    navItems = [
      { id: 'home',          icon: '🏠', label: tr('nav_home') },
      { id: 'stats',         icon: '📊', label: tr('stats') || 'Stat' },
      { id: 'kindergartens', icon: '🏫', label: tr('kindergartens') || "Bog'cha" },
      { id: 'finance',       icon: '💰', label: tr('finance') || 'Moliya' },
      { id: 'anomalies',     icon: '⚠️', label: tr('anomalies') || 'Xato' },
      { id: 'profile',       icon: '👤', label: tr('nav_profile') },
    ]
  } else if (roles.includes('director')) {
    navItems = [
      { id: 'home',          icon: '🏠', label: tr('nav_home') },
      { id: 'stats',         icon: '📊', label: tr('stats') || 'Stat' },
      { id: 'staff',         icon: '👨‍🏫', label: tr('staff') || 'Xodim' },
      { id: 'children_list', icon: '👶', label: tr('children') || 'Bolalar' },
      { id: 'finance',       icon: '💰', label: tr('finance') || 'Moliya' },
      { id: 'profile',       icon: '👤', label: tr('nav_profile') },
    ]
  } else if (roles.includes('iqtisodchi')) {
    navItems = [
      { id: 'home',    icon: '🏠', label: tr('nav_home') },
      { id: 'finance', icon: '💰', label: tr('finance') || 'Moliya' },
      { id: 'stats',   icon: '📊', label: tr('stats') || 'Stat' },
      { id: 'profile', icon: '👤', label: tr('nav_profile') },
    ]
  } else if (roles.includes('teacher') || roles.includes('togarak_rahbari')) {
    navItems = [
      { id: 'home',       icon: '🏠', label: tr('nav_home') },
      { id: 'attendance', icon: '✅', label: tr('nav_attendance') },
      { id: 'my_group',   icon: '👥', label: tr('my_group') || 'Guruhim' },
      { id: 'stats',      icon: '📊', label: tr('stats') || 'Stat' },
      { id: 'profile',    icon: '👤', label: tr('nav_profile') },
    ]
  } else if (roles.includes('parent')) {
    navItems = [
      { id: 'home',     icon: '🏠', label: tr('nav_home') },
      { id: 'children', icon: '👶', label: tr('nav_children') },
      { id: 'clubs',    icon: '🎯', label: tr('nav_clubs') },
      { id: 'payment',  icon: '💳', label: tr('payment') || "To'lov" },
      { id: 'profile',  icon: '👤', label: tr('nav_profile') },
    ]
  } else {
    // guest
    navItems = [
      { id: 'map',        icon: '🗺️', label: tr('nav_map') },
      { id: 'clubs_view', icon: '🎯', label: tr('nav_clubs') },
      { id: 'news',       icon: '📢', label: tr('news') || "E'lon" },
    ]
  }

  // ── Tab render ────────────────────────────────────────────────────────────
  const renderTab = () => {
    switch (activeTab) {
      case 'home':          return <HomeTab onNavigate={setActiveTab} />
      case 'profile':       return <ProfileTab onOpenLegal={setLegalType} />
      // Parent
      case 'children':      return <ChildrenTab />
      case 'clubs':         return <ClubsTab />
      case 'payment':       return <PaymentTab />
      // Teacher
      case 'attendance':    return <TeacherTab mode="attendance" />
      case 'my_group':      return <TeacherTab mode="group" />
      // Admin / Boshliq / Director
      case 'admin':         return <AdminTab />
      case 'stats':         return <AdminTab mode="stats" />
      case 'users':         return <AdminTab mode="users" />
      case 'ai_journal':    return <AdminTab mode="ai" />
      case 'system':        return <AdminTab mode="system" />
      case 'kindergartens': return <AdminTab mode="kindergartens" />
      case 'finance':       return <AdminTab mode="finance" />
      case 'anomalies':     return <AdminTab mode="anomalies" />
      case 'staff':         return <AdminTab mode="staff" />
      case 'children_list': return <AdminTab mode="children" />
      // Guest
      case 'map':           return <MapTab />
      case 'clubs_view':    return <ClubsTab readonly={true} />
      case 'news':          return <HomeTab mode="news" />

      default:              return <HomeTab onNavigate={setActiveTab} />
    }
  }

  return (
    <div className="desktop-layout" style={{
      minHeight: '100dvh', display: 'flex',
      background: 'var(--bg)', fontFamily: 'var(--font)',
    }}>
      {/* ── Sidebar (Desktop) ── */}
      <div className="sidebar">
        <h2 style={{ fontSize: 22, fontWeight: 800, marginBottom: 24, color: 'var(--primary)' }}>
          SmartDMTT
        </h2>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
          {navItems.map(item => (
            <button
              key={item.id}
              onClick={() => setActiveTab(item.id)}
              style={{
                display: 'flex', alignItems: 'center', gap: 12,
                padding: '12px 16px', borderRadius: 12, border: 'none',
                background: activeTab === item.id ? 'var(--primary-50)' : 'transparent',
                color: activeTab === item.id ? 'var(--primary)' : 'var(--text-mid)',
                fontSize: 15, fontWeight: activeTab === item.id ? 600 : 500,
                cursor: 'pointer', textAlign: 'left', transition: 'all 0.2s',
              }}
            >
              <span style={{ fontSize: 20 }}>{item.icon}</span>
              {item.label}
            </button>
          ))}
        </div>
        <div style={{ marginTop: 'auto', paddingTop: 24, borderTop: '1px solid var(--border)' }}>
          <button
            style={{
              width: '100%', padding: 12, border: '1px solid var(--border)',
              borderRadius: 12, background: '#fff', fontWeight: 600, cursor: 'pointer',
            }}
            onClick={() => setLegalType('help')}
          >
            Yordam
          </button>
        </div>
      </div>

      {/* ── Kontent ── */}
      <div className="content-area" style={{ flex: 1, overflowY: 'auto', paddingBottom: 80, position: 'relative' }}>
        <Suspense fallback={<TabLoading />}>
          {renderTab()}
        </Suspense>
      </div>

      {/* ── Pastki navigatsiya (Mobile) ── */}
      <div className="mobile-nav" style={{
        position: 'fixed', bottom: 0, left: 0, right: 0,
        background: '#fff', borderTop: '1px solid var(--border)',
        display: 'flex', zIndex: 100,
        paddingBottom: 'calc(env(safe-area-inset-bottom) + 12px)',
        boxShadow: '0 -4px 24px rgba(10,50,80,0.08)',
      }}>
        {navItems.map(item => (
          <NavItem
            key={item.id}
            icon={item.icon}
            label={item.label}
            active={activeTab === item.id}
            onClick={() => setActiveTab(item.id)}
            badge={item.badge}
          />
        ))}
      </div>
      <div className="mobile-nav" style={{ height: 'calc(env(safe-area-inset-bottom) + 70px)' }} />

      {/* ── RoleSwitcher: admin/boshliq/mmtb uchun ── */}
      <RoleSwitcher />

      {legalType && <LegalModal type={legalType} onClose={() => setLegalType(null)} />}
    </div>
  )
}
