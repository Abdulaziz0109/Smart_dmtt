/**
 * SmartMMTB — Global holat boshqaruvi
 * Til, foydalanuvchi, onboarding holatlari
 */
import { createContext, useContext, useState, useCallback, useEffect } from 'react'
import { t as translate, LANGUAGES } from './translations'

const AppContext = createContext(null)

const SESSION_KEY = 'mmtb_v2_session'
const SESSION_TTL = 2 * 60 * 60 * 1000 // 2 soat
const LANG_KEY = 'mmtb_lang'
const ONBOARDING_KEY = 'mmtb_onboarding_done'

function getStoredSession() {
  try {
    const raw = localStorage.getItem(SESSION_KEY)
    if (!raw) return null
    const { user, token, expiresAt } = JSON.parse(raw)
    if (Date.now() > expiresAt) { localStorage.removeItem(SESSION_KEY); return null }
    return { user, token }
  } catch { return null }
}

export function AppProvider({ children }) {
  const [lang, setLangState] = useState(() => localStorage.getItem(LANG_KEY) || 'uz')
  const [user, setUser] = useState(null)
  const [token, setToken] = useState(null)
  const [phase, setPhase] = useState('splash') // splash | auth | app
  const [isTelegram, setIsTelegram] = useState(false)
  const [onboardingDone, setOnboardingDone] = useState(() =>
    localStorage.getItem(ONBOARDING_KEY) === '1'
  )
  const [seenHints, setSeenHints] = useState(() => {
    try { return JSON.parse(localStorage.getItem('mmtb_hints') || '{}') } catch { return {} }
  })

  // Tarjima funksiyasi - kontekstdan lang ni oladi
  const tr = useCallback((key, vars) => translate(key, lang, vars), [lang])

  const setLang = useCallback((code) => {
    localStorage.setItem(LANG_KEY, code)
    setLangState(code)
  }, [])

  const login = useCallback((u, t) => {
    localStorage.setItem(SESSION_KEY, JSON.stringify({
      user: u, token: t, expiresAt: Date.now() + SESSION_TTL
    }))
    setUser(u)
    setToken(t)
    setPhase('app')
  }, [])

  const logout = useCallback(() => {
    localStorage.removeItem(SESSION_KEY)
    setUser(null); setToken(null); setPhase('auth')
  }, [])

  const markOnboardingDone = useCallback(() => {
    localStorage.setItem(ONBOARDING_KEY, '1')
    setOnboardingDone(true)
  }, [])

  const markHintSeen = useCallback((key) => {
    const next = { ...seenHints, [key]: true }
    localStorage.setItem('mmtb_hints', JSON.stringify(next))
    setSeenHints(next)
  }, [seenHints])

  const isHintSeen = useCallback((key) => !!seenHints[key], [seenHints])

  // Init
  useEffect(() => {
    let mounted = true
    const init = async () => {
      // await new Promise(r => setTimeout(r, 1500)) // Remove delay to prevent flash
      const tg = window.Telegram?.WebApp
      if (tg?.initData) {
        if (!mounted) return
        setIsTelegram(true)
        try {
          tg.ready(); tg.expand()
          document.documentElement.classList.toggle('dark', tg.colorScheme === 'dark')
          tg.onEvent('themeChanged', () =>
            document.documentElement.classList.toggle('dark', tg.colorScheme === 'dark'))
          
          // Check if already logged in with same initData to avoid re-login loop
          const stored = getStoredSession()
          if (stored && stored.token === tg.initData) {
              setUser(stored.user)
              setToken(stored.token)
              setPhase('app')
              return
          }

          const res = await fetch('/api/auth/login', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json', 'ngrok-skip-browser-warning': 'true' },
            body: JSON.stringify({ initData: tg.initData })
          })
          if (res.ok) {
            const data = await res.json()
            const u = { ...data.user, roles: data.roles, firstName: data.user.first_name }
            if (mounted) login(u, tg.initData)
            return
          }
        } catch (e) { console.error('TG auth fail', e) }
      }
      
      if (!mounted) return
      const stored = getStoredSession()
      if (stored) { setUser(stored.user); setToken(stored.token); setPhase('app'); return }
      setPhase('auth')
    }
    init()
    return () => { mounted = false }
  }, []) // Empty dependency array to run only once!

  const value = {
    lang, setLang, LANGUAGES,
    tr,
    user, token, setUser,
    phase,
    isTelegram,
    login, logout,
    onboardingDone, markOnboardingDone,
    isHintSeen, markHintSeen,
  }

  return <AppContext.Provider value={value}>{children}</AppContext.Provider>
}

export function useApp() {
  const ctx = useContext(AppContext)
  if (!ctx) throw new Error('useApp must be used inside AppProvider')
  return ctx
}
