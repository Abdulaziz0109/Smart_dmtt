/**
 * SmartMMTB — Dizayn tizimi
 * Ranglar, o'lchamlar, animatsiyalar
 */

// CSS o'zgaruvchilari (index.css ga qo'shing)
export const CSS_VARS = `
  :root {
    --primary: #0B5E50;
    --primary-light: #0D8B6E;
    --primary-dark: #083D34;
    --primary-50: #E8F5F2;
    --primary-100: #C0E5DC;

    --navy: #1A3354;
    --navy-light: #234576;

    --accent: #F59E0B;
    --accent-light: #FCD34D;
    --accent-50: #FFFBEB;

    --success: #10B981;
    --success-bg: #ECFDF5;
    --danger: #EF4444;
    --danger-bg: #FEF2F2;
    --warning: #F59E0B;
    --warning-bg: #FFFBEB;
    --info: #3B82F6;
    --info-bg: #EFF6FF;

    --bg: #F4F7F9;
    --bg-card: #FFFFFF;
    --bg-subtle: #F0F4F7;

    --text: #1A2E3F;
    --text-mid: #4A6373;
    --text-light: #8A9BAB;
    --text-white: #FFFFFF;

    --border: #E2EBF0;
    --shadow-sm: 0 2px 8px rgba(10,50,80,0.07);
    --shadow-md: 0 4px 20px rgba(10,50,80,0.10);
    --shadow-lg: 0 8px 40px rgba(10,50,80,0.14);

    --radius-sm: 10px;
    --radius-md: 16px;
    --radius-lg: 22px;
    --radius-xl: 28px;

    --font: 'Plus Jakarta Sans', 'Nunito', system-ui, sans-serif;
  }
`

// JS konstanta ranglar
export const COLORS = {
  primary: '#0B5E50',
  primaryLight: '#0D8B6E',
  primaryDark: '#083D34',
  navy: '#1A3354',
  navyLight: '#234576',
  accent: '#F59E0B',
  accentLight: '#FCD34D',
  success: '#10B981',
  danger: '#EF4444',
  warning: '#F59E0B',
  info: '#3B82F6',
  bg: '#F4F7F9',
  card: '#FFFFFF',
  text: '#1A2E3F',
  textMid: '#4A6373',
  textLight: '#8A9BAB',
  border: '#E2EBF0',
}

// Umumiy stil ob'ektlari
export const styles = {
  card: {
    background: '#FFFFFF',
    borderRadius: 16,
    boxShadow: '0 2px 12px rgba(10,50,80,0.08)',
    border: '1px solid #E2EBF0',
  },
  cardPrimary: {
    background: 'linear-gradient(135deg, #0B5E50 0%, #0D8B6E 100%)',
    borderRadius: 20,
    boxShadow: '0 6px 24px rgba(11,94,80,0.28)',
  },
  btn: {
    border: 'none', cursor: 'pointer',
    fontFamily: 'inherit', fontWeight: 700,
    transition: 'all 0.18s cubic-bezier(0.4,0,0.2,1)',
    display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8,
  },
  btnPrimary: {
    background: 'linear-gradient(135deg, #0B5E50, #0D8B6E)',
    color: '#fff', borderRadius: 14, padding: '13px 20px', fontSize: 15,
  },
  btnSecondary: {
    background: '#E8F5F2', color: '#0B5E50',
    borderRadius: 14, padding: '13px 20px', fontSize: 15,
  },
  btnDanger: {
    background: '#FEF2F2', color: '#EF4444',
    borderRadius: 14, padding: '13px 20px', fontSize: 15,
  },
  input: {
    width: '100%', padding: '13px 16px',
    border: '2px solid #E2EBF0', borderRadius: 14,
    fontSize: 15, fontFamily: 'inherit', outline: 'none',
    transition: 'border-color 0.2s',
    boxSizing: 'border-box',
    background: '#FAFBFC',
    color: '#1A2E3F',
  },
  label: {
    fontSize: 13, fontWeight: 700, color: '#4A6373',
    display: 'block', marginBottom: 7,
  },
  chip: {
    display: 'inline-flex', alignItems: 'center',
    padding: '4px 12px', borderRadius: 50,
    fontSize: 12, fontWeight: 700,
  },
}

// Badge ranglar
export const BADGE = {
  green: { bg: '#ECFDF5', color: '#059669' },
  red: { bg: '#FEF2F2', color: '#DC2626' },
  yellow: { bg: '#FFFBEB', color: '#D97706' },
  blue: { bg: '#EFF6FF', color: '#2563EB' },
  teal: { bg: '#E8F5F2', color: '#0B5E50' },
  gray: { bg: '#F3F4F6', color: '#4B5563' },
}
