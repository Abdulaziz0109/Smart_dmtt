/**
 * SmartDMTT v4 — AppContext
 * token, user, lang — til saqlash qo'shildi
 */
import { createContext, useContext, useState, useEffect } from 'react'

const AppContext = createContext(null)

export function AppProvider({ children }) {
  const [token, setTokenState] = useState(() => localStorage.getItem('token') || null)
  const [user,  setUser]       = useState(() => {
    try { return JSON.parse(localStorage.getItem('user') || 'null') } catch { return null }
  })
  const [lang, setLangState]   = useState(() => localStorage.getItem('lang') || 'uz')

  // Token saqlash
  const setToken = (t) => {
    if (t) localStorage.setItem('token', t)
    else   localStorage.removeItem('token')
    setTokenState(t)
  }

  // User saqlash
  const saveUser = (u) => {
    if (u) localStorage.setItem('user', JSON.stringify(u))
    else   localStorage.removeItem('user')
    setUser(u)
  }

  // Til saqlash — serverga ham yuborish
  const setLang = async (newLang) => {
    localStorage.setItem('lang', newLang)
    setLangState(newLang)
    if (token) {
      try {
        await fetch('/api/users/me/language', {
          method: 'PATCH',
          headers: {
            'Authorization': `Bearer ${token}`,
            'Content-Type': 'application/json',
            'ngrok-skip-browser-warning': 'true',
          },
          body: JSON.stringify({ language: newLang }),
        })
      } catch (e) {
        console.warn('Til serverga saqlanmadi:', e)
      }
    }
  }

  // User login bo'lganda tilini sync qilish
  useEffect(() => {
    if (user?.language && user.language !== lang) {
      setLangState(user.language)
      localStorage.setItem('lang', user.language)
    }
  }, [user?.id])

  const logout = () => {
    setToken(null)
    saveUser(null)
  }

  return (
    <AppContext.Provider value={{ token, setToken, user, setUser: saveUser, lang, setLang, logout }}>
      {children}
    </AppContext.Provider>
  )
}

export function useApp() {
  const ctx = useContext(AppContext)
  if (!ctx) throw new Error('useApp must be inside AppProvider')
  return ctx
}
