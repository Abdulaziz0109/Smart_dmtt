/**
 * HelpTooltip — Yordam tugmasi
 * ? belgisini bosib sahifaning maqsadini bilish uchun
 */
import { useState } from 'react'
import { useApp } from '../context/AppContext'

export default function HelpTooltip({ tipKey, position = 'bottom' }) {
  const { tr, isHintSeen, markHintSeen } = useApp()
  const [open, setOpen] = useState(false)
  const text = tr(tipKey)

  const posStyles = {
    bottom: { top: '100%', left: '50%', transform: 'translateX(-50%)', marginTop: 8 },
    top: { bottom: '100%', left: '50%', transform: 'translateX(-50%)', marginBottom: 8 },
    left: { right: '100%', top: '50%', transform: 'translateY(-50%)', marginRight: 8 },
    right: { left: '100%', top: '50%', transform: 'translateY(-50%)', marginLeft: 8 },
  }

  return (
    <span style={{ position: 'relative', display: 'inline-flex' }}>
      <button
        onClick={() => setOpen(v => !v)}
        style={{
          width: 22, height: 22,
          borderRadius: '50%',
          background: open ? '#0B5E50' : '#E8F5F2',
          color: open ? '#fff' : '#0B5E50',
          border: '1.5px solid #0D8B6E',
          fontSize: 12, fontWeight: 800,
          cursor: 'pointer', display: 'flex',
          alignItems: 'center', justifyContent: 'center',
          transition: 'all 0.18s',
          flexShrink: 0,
        }}
        title={tr('help_home')}
      >
        ?
      </button>

      {open && (
        <>
          {/* Backdrop */}
          <div
            style={{ position: 'fixed', inset: 0, zIndex: 999 }}
            onClick={() => setOpen(false)}
          />
          {/* Tooltip */}
          <div style={{
            position: 'absolute',
            zIndex: 1000,
            width: 240,
            background: '#1A3354',
            color: '#fff',
            borderRadius: 14,
            padding: '14px 16px',
            fontSize: 13,
            lineHeight: 1.6,
            boxShadow: '0 8px 32px rgba(10,30,60,0.25)',
            ...posStyles[position]
          }}>
            {/* Arrow */}
            {position === 'bottom' && (
              <div style={{
                position: 'absolute', top: -6, left: '50%',
                transform: 'translateX(-50%)',
                width: 12, height: 12,
                background: '#1A3354',
                clipPath: 'polygon(50% 0%, 0% 100%, 100% 100%)',
              }} />
            )}
            {text}
            <button
              onClick={() => setOpen(false)}
              style={{
                display: 'block', marginTop: 10, width: '100%',
                background: '#0D8B6E', color: '#fff', border: 'none',
                borderRadius: 8, padding: '7px 0', fontSize: 12, fontWeight: 700,
                cursor: 'pointer', fontFamily: 'inherit',
              }}
            >
              {tr('understood')}
            </button>
          </div>
        </>
      )}
    </span>
  )
}

/**
 * AutoHint — Birinchi kirganida avtomatik chiqadigan hint
 */
export function AutoHint({ hintKey, children }) {
  const { isHintSeen, markHintSeen, tr } = useApp()
  const [dismissed, setDismissed] = useState(isHintSeen(hintKey))

  if (dismissed) return null

  return (
    <div style={{
      background: 'linear-gradient(135deg, #0B5E50, #0D8B6E)',
      borderRadius: 16, padding: '14px 16px', marginBottom: 16,
      position: 'relative', overflow: 'hidden',
    }}>
      {/* Bezak doira */}
      <div style={{
        position: 'absolute', right: -20, top: -20,
        width: 80, height: 80, borderRadius: '50%',
        background: 'rgba(255,255,255,0.08)'
      }} />
      <div style={{ display: 'flex', gap: 12, alignItems: 'flex-start' }}>
        <span style={{ fontSize: 24, flexShrink: 0 }}>💡</span>
        <div style={{ flex: 1 }}>
          <div style={{ color: '#fff', fontSize: 13, lineHeight: 1.6 }}>
            {children || tr(hintKey)}
          </div>
          <button
            onClick={() => { markHintSeen(hintKey); setDismissed(true) }}
            style={{
              marginTop: 10, background: 'rgba(255,255,255,0.2)',
              color: '#fff', border: '1px solid rgba(255,255,255,0.3)',
              borderRadius: 8, padding: '6px 14px', fontSize: 12, fontWeight: 700,
              cursor: 'pointer', fontFamily: 'inherit',
            }}
          >
            {tr('understood')}
          </button>
        </div>
      </div>
    </div>
  )
}
