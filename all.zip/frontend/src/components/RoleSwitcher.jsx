/**
 * RoleSwitcher — Admin panel: foydalanuvchi rolini almashtirish
 * Faqat admin/boshliq ko'radi.
 * Joylash: frontend/src/components/RoleSwitcher.jsx
 */
import { useState, useEffect } from 'react'
import { useApp } from '../context/AppContext'

const ALL_ROLES = [
  { value: 'admin',           label: '🔑 Admin',            color: '#7C3AED' },
  { value: 'boshliq',         label: '🏛 Boshliq',          color: '#0B5E50' },
  { value: 'mmtb_boshligi',   label: '🏢 MMTB Boshliq',     color: '#0B5E50' },
  { value: 'director',        label: '🏫 Direktor',         color: '#1A3354' },
  { value: 'iqtisodchi',      label: '📊 Iqtisodchi',       color: '#0284C7' },
  { value: 'teacher',         label: '👨‍🏫 Muallim',         color: '#059669' },
  { value: 'togarak_rahbari', label: '🎯 To\'garak rahbar', color: '#D97706' },
  { value: 'parent',          label: '👨‍👧 Ota-ona',         color: '#6B7280' },
  { value: 'guest',           label: '👤 Mehmon',           color: '#9CA3AF' },
]

const ADMIN_ROLES = ['admin', 'boshliq', 'mmtb_boshligi']

export default function RoleSwitcher() {
  const { user, token, setUser } = useApp()
  const [users, setUsers]           = useState([])
  const [search, setSearch]         = useState('')
  const [loading, setLoading]       = useState(false)
  const [saving, setSaving]         = useState(null)  // user id
  const [msg, setMsg]               = useState('')
  const [open, setOpen]             = useState(false)
  const [selfRole, setSelfRole]     = useState(user?.role || '')

  const H = {
    Authorization: `Bearer ${token}`,
    'Content-Type': 'application/json',
    'ngrok-skip-browser-warning': 'true',
  }

  // Faqat admin/boshliq ko'radi
  if (!ADMIN_ROLES.includes(user?.role)) return null

  const fetchUsers = async () => {
    setLoading(true)
    try {
      const q = search ? `?search=${encodeURIComponent(search)}` : ''
      const res = await fetch(`/api/admin/users${q}`, { headers: H })
      if (res.ok) {
        const d = await res.json()
        setUsers(d.users || d || [])
      }
    } catch {}
    finally { setLoading(false) }
  }

  useEffect(() => {
    if (open) fetchUsers()
  }, [open])

  useEffect(() => {
    const t = setTimeout(() => { if (open) fetchUsers() }, 400)
    return () => clearTimeout(t)
  }, [search])

  const changeRole = async (userId, newRole) => {
    setSaving(userId)
    setMsg('')
    try {
      const res = await fetch(`/api/admin/users/${userId}/role`, {
        method: 'PATCH', headers: H,
        body: JSON.stringify({ role: newRole }),
      })
      if (res.ok) {
        setUsers(prev => prev.map(u => u.id === userId ? { ...u, role: newRole } : u))
        setMsg(`✅ Rol o'zgartirildi`)
        setTimeout(() => setMsg(''), 2500)
      } else {
        setMsg('❌ Xato')
      }
    } catch { setMsg('❌ Tarmoq xatosi') }
    finally { setSaving(null) }
  }

  // O'z rolini almashtirish (test uchun)
  const changeSelfRole = async (newRole) => {
    setSaving('self')
    try {
      const res = await fetch(`/api/admin/users/${user.id}/role`, {
        method: 'PATCH', headers: H,
        body: JSON.stringify({ role: newRole }),
      })
      if (res.ok) {
        setSelfRole(newRole)
        // Context yangilash
        if (setUser) setUser(prev => ({ ...prev, role: newRole }))
        setMsg(`✅ Sizning rolingiz: ${newRole}. Sahifani yangilang.`)
        setTimeout(() => setMsg(''), 4000)
      }
    } catch {}
    finally { setSaving(null) }
  }

  if (!open) {
    return (
      <button
        onClick={() => setOpen(true)}
        style={{
          position: 'fixed', bottom: 90, right: 16, zIndex: 9000,
          background: 'linear-gradient(135deg, #7C3AED, #9333EA)',
          color: '#fff', border: 'none', borderRadius: '50%',
          width: 52, height: 52, fontSize: 22, cursor: 'pointer',
          boxShadow: '0 4px 20px rgba(124,58,237,0.5)',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
        }}
        title="Rol almashtirish (Admin)"
      >
        🔄
      </button>
    )
  }

  return (
    <div style={{
      position: 'fixed', inset: 0, zIndex: 9999,
      background: 'rgba(0,0,0,0.5)', display: 'flex',
      alignItems: 'flex-end',
    }}>
      <div style={{
        background: '#fff', borderRadius: '20px 20px 0 0',
        width: '100%', maxHeight: '85vh', overflow: 'hidden',
        display: 'flex', flexDirection: 'column',
      }}>
        {/* Header */}
        <div style={{
          background: 'linear-gradient(135deg, #7C3AED, #9333EA)',
          padding: '16px 20px', display: 'flex', alignItems: 'center', gap: 12,
        }}>
          <div style={{ width: 40, height: 40, background: 'rgba(255,255,255,0.2)', borderRadius: 12, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 20 }}>🔄</div>
          <div>
            <div style={{ color: '#fff', fontWeight: 800, fontSize: 16 }}>Rol almashtirish</div>
            <div style={{ color: 'rgba(255,255,255,0.7)', fontSize: 12 }}>Admin paneli — test rejimi</div>
          </div>
          <button onClick={() => setOpen(false)} style={{
            marginLeft: 'auto', background: 'rgba(255,255,255,0.2)', border: 'none',
            width: 32, height: 32, borderRadius: '50%', color: '#fff',
            cursor: 'pointer', fontSize: 16,
          }}>✕</button>
        </div>

        <div style={{ overflowY: 'auto', padding: '16px', flex: 1 }}>
          {/* Xabar */}
          {msg && (
            <div style={{
              background: msg.includes('✅') ? '#ECFDF5' : '#FEF2F2',
              border: `1px solid ${msg.includes('✅') ? '#A7F3D0' : '#FECACA'}`,
              borderRadius: 10, padding: '10px 14px', marginBottom: 14,
              fontSize: 13, color: msg.includes('✅') ? '#059669' : '#DC2626', fontWeight: 600,
            }}>{msg}</div>
          )}

          {/* O'z rolini almashtirish */}
          <div style={{ marginBottom: 20 }}>
            <div style={{ fontSize: 14, fontWeight: 800, color: '#111', marginBottom: 10 }}>
              👤 Mening rolim: <code style={{ background: '#F3F4F6', padding: '2px 8px', borderRadius: 6 }}>{selfRole}</code>
            </div>
            <div style={{ display: 'flex', flexWrap: 'wrap', gap: 7 }}>
              {ALL_ROLES.map(r => (
                <button
                  key={r.value}
                  onClick={() => changeSelfRole(r.value)}
                  disabled={saving === 'self'}
                  style={{
                    padding: '7px 13px', borderRadius: 10, fontSize: 12, fontWeight: 700,
                    border: `2px solid ${selfRole === r.value ? r.color : '#E5E7EB'}`,
                    background: selfRole === r.value ? r.color : '#F9FAFB',
                    color: selfRole === r.value ? '#fff' : '#374151',
                    cursor: 'pointer', fontFamily: 'var(--font)',
                    opacity: saving === 'self' ? 0.6 : 1,
                  }}
                >{r.label}</button>
              ))}
            </div>
            <div style={{ fontSize: 11, color: '#9CA3AF', marginTop: 6 }}>
              ⚠️ Rolni o'zgartirgach sahifani F5 bilan yangilang
            </div>
          </div>

          <hr style={{ border: 'none', borderTop: '1px solid #E5E7EB', margin: '0 0 16px' }} />

          {/* Boshqa foydalanuvchilar */}
          <div style={{ fontSize: 14, fontWeight: 800, color: '#111', marginBottom: 10 }}>
            👥 Boshqa foydalanuvchilar
          </div>
          <input
            type="text" placeholder="Ism yoki telefon..." value={search}
            onChange={e => setSearch(e.target.value)}
            style={{
              width: '100%', boxSizing: 'border-box', padding: '10px 14px',
              borderRadius: 12, border: '1px solid #E5E7EB', fontSize: 14,
              outline: 'none', background: '#F9FAFB', fontFamily: 'var(--font)',
              marginBottom: 12,
            }}
          />

          {loading ? (
            <div style={{ textAlign: 'center', padding: 20, color: '#9CA3AF' }}>Yuklanmoqda...</div>
          ) : users.length === 0 ? (
            <div style={{ textAlign: 'center', padding: 20, color: '#9CA3AF' }}>Foydalanuvchilar topilmadi</div>
          ) : (
            users.filter(u => u.id !== user?.id).map(u => {
              const roleInfo = ALL_ROLES.find(r => r.value === u.role) || { color: '#6B7280', label: u.role }
              return (
                <div key={u.id} style={{
                  background: '#F9FAFB', borderRadius: 14, padding: '12px 14px',
                  marginBottom: 8, border: '1px solid #E5E7EB',
                }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 8 }}>
                    <div style={{
                      width: 36, height: 36, borderRadius: 10, flexShrink: 0,
                      background: roleInfo.color + '20',
                      display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 16,
                    }}>👤</div>
                    <div style={{ flex: 1 }}>
                      <div style={{ fontWeight: 700, fontSize: 13, color: '#111' }}>{u.full_name || '—'}</div>
                      <div style={{ fontSize: 11, color: '#9CA3AF' }}>{u.phone || `ID: ${u.id}`}</div>
                    </div>
                    <span style={{
                      padding: '4px 10px', borderRadius: 8, fontSize: 11, fontWeight: 700,
                      background: roleInfo.color + '15', color: roleInfo.color,
                    }}>{roleInfo.label}</span>
                  </div>
                  <div style={{ display: 'flex', flexWrap: 'wrap', gap: 5 }}>
                    {ALL_ROLES.map(r => (
                      <button
                        key={r.value}
                        onClick={() => changeRole(u.id, r.value)}
                        disabled={saving === u.id || u.role === r.value}
                        style={{
                          padding: '5px 10px', borderRadius: 8, fontSize: 11, fontWeight: 600,
                          border: `1.5px solid ${u.role === r.value ? r.color : '#E5E7EB'}`,
                          background: u.role === r.value ? r.color : '#fff',
                          color: u.role === r.value ? '#fff' : '#374151',
                          cursor: u.role === r.value ? 'default' : 'pointer',
                          fontFamily: 'var(--font)',
                          opacity: saving === u.id ? 0.6 : 1,
                        }}
                      >{r.label.split(' ').slice(1).join(' ')}</button>
                    ))}
                  </div>
                </div>
              )
            })
          )}
        </div>
      </div>
    </div>
  )
}
