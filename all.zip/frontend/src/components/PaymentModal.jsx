/**
 * PaymentModal — QR kod bilan to'lov
 * Click, Payme, PayNet uchun QR kodlar generatsiya qiladi
 */
import { useEffect, useRef, useState } from 'react'
import { useApp } from '../context/AppContext'

const SYSTEMS = [
  { id: 'payme', name: 'Payme', color: '#00ADEF', emoji: '💳',
    url: (id, amt) => `https://checkout.paycom.uz/b/${id}?amount=${amt * 100}` },
  { id: 'click', name: 'Click', color: '#ED1C24', emoji: '🔴',
    url: (id, amt) => `https://my.click.uz/services/pay?service_id=MMTB&merchant_trans_id=${id}&amount=${amt}` },
  { id: 'paynet', name: 'PayNet', color: '#FF6B00', emoji: '🟠',
    url: (id, amt) => `https://paynet.uz/paying/pay?billId=${id}&amount=${amt}` },
]

function QRGen({ text, size = 150 }) {
  const ref = useRef(null)
  useEffect(() => {
    if (!text) return
    const render = () => {
      if (!ref.current) return
      ref.current.innerHTML = ''
      new window.QRCode(ref.current, {
        text, width: size, height: size,
        colorDark: '#0B5E50', colorLight: '#fff',
        correctLevel: window.QRCode?.CorrectLevel?.M,
      })
    }
    if (window.QRCode) { render(); return }
    const s = document.createElement('script')
    s.src = 'https://cdnjs.cloudflare.com/ajax/libs/qrcodejs/1.0.0/qrcode.min.js'
    s.onload = render
    document.head.appendChild(s)
  }, [text, size])
  return <div ref={ref} style={{ display: 'inline-block', lineHeight: 0 }} />
}

export default function PaymentModal({ child, amount = 150000, onClose }) {
  const { tr } = useApp()
  const [copied, setCopied] = useState(false)
  const billingId = child?.billing_id || `MMTB-${child?.id || '0000'}`

  const copyId = () => {
    navigator.clipboard?.writeText(billingId)
    setCopied(true)
    setTimeout(() => setCopied(false), 2000)
  }

  return (
    <div style={{
      position: 'fixed', inset: 0, zIndex: 500,
      background: 'rgba(0,0,0,0.55)', backdropFilter: 'blur(6px)',
      display: 'flex', alignItems: 'flex-end',
      fontFamily: 'var(--font)',
    }} onClick={e => e.target === e.currentTarget && onClose()}>
      <div style={{
        background: 'var(--bg)', width: '100%', borderRadius: '24px 24px 0 0',
        maxHeight: '92dvh', display: 'flex', flexDirection: 'column',
        animation: 'slideUp 0.35s cubic-bezier(0.4,0,0.2,1)',
      }}>
        {/* Handle */}
        <div style={{ display: 'flex', justifyContent: 'center', padding: '10px 0 0' }}>
          <div style={{ width: 36, height: 4, borderRadius: 4, background: 'var(--border)' }} />
        </div>

        {/* Header */}
        <div style={{
          background: 'linear-gradient(135deg, #083D34, #0B5E50)',
          margin: '8px 12px', borderRadius: 20, padding: '18px 20px',
          display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start',
        }}>
          <div>
            <div style={{ color: '#fff', fontWeight: 900, fontSize: 20 }}>💳 {tr('payment_title')}</div>
            <div style={{ color: 'rgba(255,255,255,0.7)', fontSize: 13, marginTop: 4 }}>
              {child?.full_name}
            </div>
            <div style={{
              marginTop: 10, display: 'inline-flex', alignItems: 'center', gap: 8,
              background: 'rgba(255,255,255,0.15)', borderRadius: 10, padding: '6px 14px',
            }}>
              <span style={{ color: 'rgba(255,255,255,0.65)', fontSize: 12 }}>Billing ID:</span>
              <span style={{ color: '#fff', fontWeight: 900, fontSize: 15, fontFamily: 'monospace', letterSpacing: 1 }}>
                {billingId}
              </span>
            </div>
          </div>
          <button onClick={onClose} style={{
            background: 'rgba(255,255,255,0.18)', border: 'none', borderRadius: '50%',
            width: 38, height: 38, color: '#fff', fontSize: 18, cursor: 'pointer',
            display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0,
          }}>✕</button>
        </div>

        {/* Summa */}
        <div style={{
          margin: '0 12px 12px', background: '#fff', borderRadius: 18,
          padding: '16px 20px', border: '1.5px solid var(--border)',
          display: 'flex', justifyContent: 'space-between', alignItems: 'center',
        }}>
          <div>
            <div style={{ fontSize: 13, color: 'var(--text-light)' }}>{tr('current_debt')}</div>
            <div style={{ fontSize: 28, fontWeight: 900, color: 'var(--primary)' }}>
              {amount.toLocaleString()} <span style={{ fontSize: 16, fontWeight: 700 }}>so'm</span>
            </div>
          </div>
          <button onClick={copyId} style={{
            background: copied ? '#ECFDF5' : 'var(--primary-50)',
            color: copied ? '#059669' : 'var(--primary)',
            border: 'none', borderRadius: 12, padding: '10px 16px',
            fontWeight: 700, fontSize: 13, cursor: 'pointer', fontFamily: 'var(--font)',
            transition: 'all 0.2s',
          }}>
            {copied ? '✓ Nusxa olindi' : `📋 ${tr('copy_id')}`}
          </button>
        </div>

        {/* To'lov tizimlari */}
        <div style={{ overflowY: 'auto', flex: 1, padding: '0 12px 24px' }}>
          <div style={{ fontSize: 14, fontWeight: 700, color: 'var(--text-mid)', marginBottom: 10 }}>
            {tr('pay_instruction')}
          </div>
          {SYSTEMS.map(ps => {
            const url = ps.url(billingId, amount)
            return (
              <div key={ps.id} style={{
                background: '#fff', borderRadius: 20, marginBottom: 12,
                border: '1.5px solid var(--border)', overflow: 'hidden',
              }}>
                <div style={{
                  background: ps.color, padding: '12px 18px',
                  display: 'flex', alignItems: 'center', gap: 10,
                }}>
                  <span style={{ fontSize: 24 }}>{ps.emoji}</span>
                  <span style={{ color: '#fff', fontWeight: 800, fontSize: 17 }}>{ps.name}</span>
                </div>
                <div style={{ padding: '16px 18px', textAlign: 'center' }}>
                  <QRGen text={url} size={160} />
                  <div style={{ fontSize: 12, color: 'var(--text-light)', marginTop: 10 }}>
                    📱 {ps.name} {tr('scan_qr')}
                  </div>
                  <div style={{ display: 'flex', gap: 8, marginTop: 12 }}>
                    <button onClick={() => navigator.clipboard?.writeText(billingId)} style={{
                      flex: 1, padding: '11px 0', background: 'var(--primary-50)', color: 'var(--primary)',
                      border: 'none', borderRadius: 12, fontWeight: 700, fontSize: 13,
                      cursor: 'pointer', fontFamily: 'var(--font)',
                    }}>📋 {tr('copy_id')}</button>
                    <a href={url} target="_blank" rel="noreferrer" style={{
                      flex: 1, padding: '11px 0', background: ps.color, color: '#fff',
                      textDecoration: 'none', borderRadius: 12, fontWeight: 700, fontSize: 13,
                      display: 'flex', alignItems: 'center', justifyContent: 'center',
                    }}>🚀 {tr('open_app')}</a>
                  </div>
                </div>
              </div>
            )
          })}
        </div>
      </div>
    </div>
  )
}
