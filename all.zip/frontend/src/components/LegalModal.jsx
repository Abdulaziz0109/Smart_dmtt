/**
 * LegalModal — Huquqiy hujjatlar (5 tilda)
 * Oferta, Maxfiylik siyosati, Foydalanish shartlari
 */
import { useApp } from '../context/AppContext'

const DOCS = {
  offer: {
    icon: '📜', color: '#1A3354', colorLight: '#234576',
    titleKey: 'offer',
    sections: {
      uz: [
        { h: "1. Umumiy qoidalar", p: "Ushbu Oferta Tuman MMTB tomonidan qo'shimcha ta'lim xizmatlaridan foydalanish shartlarini belgilaydi. Ro'yxatdan o'tish yoki to'lov orqali qabul qilinadi (aksept)." },
        { h: "2. Xizmat predmeti", p: "MMTB quyidagi pullik xizmatlarni ko'rsatadi:\n• Qo'shimcha to'garaklar (ingliz tili, robototexnika, mental arifmetika va boshqalar)\n• Kengaytirilgan saqlash xizmati\n• Boshqa qo'shimcha xizmatlar." },
        { h: "3. To'lov tartibi", p: "Xizmatlar uchun to'lov Click, Payme yoki PayNet orqali amalga oshiriladi. To'lov noyob Billing ID raqami asosida identifikatsiya qilinadi. Har oyning 1-5 sanasigacha to'lov amalga oshirilmagan taqdirda, vaqtincha to'xtatib qo'yilishi mumkin." },
        { h: "4. Tomonlar huquq va majburiyatlari", p: "MMTB: sifatli ta'lim xizmatini ko'rsatish, davomat ma'lumotlarini saqlab borish, to'lov tarixini ko'rsatish majburiyatini oladi.\n\nOta-ona: to'g'ri ma'lumot kiritish, to'lovlarni o'z vaqtida amalga oshirish, farzand sog'ligi haqida xabardor qilish majburiyatini oladi." },
        { h: "5. Shartnomani bekor qilish", p: "Ota-ona istalgan vaqtda xizmatdan voz kecha oladi. Buning uchun 3 kun oldin ariza topshirish yetarli." },
        { h: "6. Mas'uliyat", p: "MMTB fors-major holatlari uchun mas'ul emas. Bunday hollarda xizmat vaqtincha to'xtatiladi." },
      ],
      kr: [
        { h: "1. Умумий қоидалар", p: "Ушбу Оферта Туман ММТБ томонидан қўшимча таълим хизматларидан фойдаланиш шартларини белгилайди. Рўйхатдан ўтиш ёки тўлов орқали қабул қилинади (акцепт)." },
        { h: "2. Хизмат предмети", p: "ММТБ қуйидаги пуллик хизматларни кўрсатади:\n• Қўшимча тўгараклар (инглиз тили, робототехника ва бошқалар)\n• Кенгайтирилган сақлаш хизмати\n• Бошқа қўшимча хизматлар." },
        { h: "3. Тўлов тартиби", p: "Хизматлар учун тўлов Click, Payme ёки PayNet орқали амалга оширилади. Ҳар ойнинг 1-5 санасигача тўлов амалга оширилмаган тақдирда, вақтинча тўхтатиб қўйилиши мумкин." },
        { h: "4. Томонлар ҳуқуқ ва мажбуриятлари", p: "ММТБ: сифатли таълим хизматини кўрсатиш, давомат маълумотларини сақлаб бориш мажбуриятини олади.\n\nОта-она: тўғри маълумот киритиш, тўловларни ўз вақтида амалга ошириш мажбуриятини олади." },
        { h: "5. Шартномани бекор қилиш", p: "Ота-она истаган вақтда хизматдан воз кеча олади. Бунинг учун 3 кун олдин ариза топшириш етарли." },
        { h: "6. Масъулият", p: "ММТБ форс-мажор ҳолатлари учун масъул эмас." },
      ],
      ru: [
        { h: "1. Общие положения", p: "Настоящая Оферта определяет условия использования дополнительных образовательных услуг ММТО. Акцепт осуществляется путём регистрации или оплаты." },
        { h: "2. Предмет договора", p: "ММТО оказывает следующие платные услуги:\n• Дополнительные кружки (английский язык, робототехника и др.)\n• Расширенное пребывание\n• Другие дополнительные услуги." },
        { h: "3. Порядок оплаты", p: "Оплата услуг производится через Click, Payme или PayNet. Идентификация производится по уникальному Billing ID. При отсутствии оплаты до 5-го числа возможна временная приостановка." },
        { h: "4. Права и обязанности сторон", p: "ММТО: обязуется оказывать качественные образовательные услуги, вести журнал посещаемости, показывать историю платежей.\n\nРодитель: обязуется вносить достоверные данные, своевременно оплачивать услуги." },
        { h: "5. Расторжение договора", p: "Родитель может отказаться от услуги в любое время, подав заявление за 3 дня." },
        { h: "6. Ответственность", p: "ММТО не несёт ответственности за форс-мажорные обстоятельства." },
      ],
      en: [
        { h: "1. General provisions", p: "This Offer defines the terms of use for additional educational services of the District MMTB. Acceptance is made by registration or payment." },
        { h: "2. Subject of the agreement", p: "MMTB provides the following paid services:\n• Additional clubs (English, robotics, mental arithmetic, etc.)\n• Extended care service\n• Other additional services." },
        { h: "3. Payment procedure", p: "Payment is made via Click, Payme or PayNet. Identification is by unique Billing ID. If payment is not made by the 5th of the month, service may be temporarily suspended." },
        { h: "4. Rights and obligations", p: "MMTB: undertakes to provide quality educational services, maintain attendance records, show payment history.\n\nParent: undertakes to provide correct information, make timely payments." },
        { h: "5. Termination", p: "A parent can cancel the service at any time by submitting an application 3 days in advance." },
        { h: "6. Liability", p: "MMTB is not liable for force majeure circumstances." },
      ],
      tr: [
        { h: "1. Genel hükümler", p: "Bu Teklif, İlçe MMTB'nin ek eğitim hizmetlerinin kullanım koşullarını belirler. Kabul, kayıt veya ödeme yoluyla gerçekleşir." },
        { h: "2. Sözleşmenin konusu", p: "MMTB aşağıdaki ücretli hizmetleri sunar:\n• Ek kulüpler (İngilizce, robotik, zihinsel aritmetik vb.)\n• Genişletilmiş bakım hizmeti\n• Diğer ek hizmetler." },
        { h: "3. Ödeme prosedürü", p: "Ödeme Click, Payme veya PayNet üzerinden yapılır. Kimlik doğrulama benzersiz Billing ID ile yapılır. Ayın 5'ine kadar ödeme yapılmazsa hizmet geçici olarak askıya alınabilir." },
        { h: "4. Tarafların hak ve yükümlülükleri", p: "MMTB: kaliteli eğitim hizmeti sunmayı, devam kayıtlarını tutmayı taahhüt eder.\n\nEbeveyn: doğru bilgi girmek, ödemeleri zamanında yapmak yükümlülüğünü üstlenir." },
        { h: "5. Sözleşmenin feshi", p: "Ebeveyn, 3 gün önceden başvuruda bulunarak istediği zaman hizmetten çekilebilir." },
        { h: "6. Sorumluluk", p: "MMTB, mücbir sebep halleri için sorumlu değildir." },
      ],
    }
  },
  privacy: {
    icon: '🔒', color: '#1A3354', colorLight: '#234576',
    titleKey: 'privacy',
    sections: {
      uz: [
        { h: "1. Qanday ma'lumotlar yig'iladi?", p: "• Ota-ona: ism, telefon, Telegram ID\n• Farzand: ism, tug'ilgan sana, to'garaklar, davomat\n• Biometrik: yuz tasviri (Face ID, faqat rozilik bilan)\n• To'lov tarixi va Billing ID" },
        { h: "2. Ma'lumotlar qanday ishlatiladi?", p: "Faqat quyidagi maqsadlarda:\n• To'garaklar boshqaruvi\n• Davomat belgilash va xabar yuborish\n• To'lov identifikatsiyasi\n• Statistika (shaxsiylashtirilmagan)" },
        { h: "3. Biometrik ma'lumotlar (Face ID)", p: "Yuz tasviri FAQAT ota-onaning yozma roziligi bilan yig'iladi. Shifrlangan shaklda saqlanadi. Uchinchi shaxslarga berilmaydi. Xizmatdan voz kechilganda o'chiriladi." },
        { h: "4. Saqlanish muddati", p: "Shaxsiy ma'lumotlar xizmat faol bo'lgan davr + 1 yil mobaynida saqlanadi." },
        { h: "5. Sizning huquqlaringiz", p: "Siz har doim ma'lumotlaringizni ko'rish, o'zgartirish va o'chirish huquqiga egasiz." },
      ],
      ru: [
        { h: "1. Какие данные собираются?", p: "• Родитель: имя, телефон, Telegram ID\n• Ребёнок: имя, дата рождения, кружки, посещаемость\n• Биометрия: изображение лица (Face ID, только с согласия)\n• История платежей и Billing ID" },
        { h: "2. Как используются данные?", p: "Только для следующих целей:\n• Управление кружками\n• Учёт посещаемости и уведомления\n• Идентификация платежей\n• Статистика (обезличенная)" },
        { h: "3. Биометрические данные", p: "Изображение лица собирается ТОЛЬКО с письменного согласия родителя. Хранится в зашифрованном виде. Не передаётся третьим лицам. Удаляется при отказе от услуги." },
        { h: "4. Срок хранения", p: "Личные данные хранятся в течение срока действия услуги + 1 год." },
        { h: "5. Ваши права", p: "Вы вправе в любое время просматривать, изменять и удалять свои данные." },
      ],
      en: [
        { h: "1. What data is collected?", p: "• Parent: name, phone, Telegram ID\n• Child: name, date of birth, clubs, attendance\n• Biometric: face image (Face ID, with consent only)\n• Payment history and Billing ID" },
        { h: "2. How is data used?", p: "Only for the following purposes:\n• Club management\n• Attendance tracking and notifications\n• Payment identification\n• Statistics (anonymized)" },
        { h: "3. Biometric data (Face ID)", p: "Face images are collected ONLY with written parental consent. Stored in encrypted form. Not shared with third parties. Deleted upon service cancellation." },
        { h: "4. Retention period", p: "Personal data is retained for the duration of the service + 1 year." },
        { h: "5. Your rights", p: "You have the right to view, modify and delete your data at any time." },
      ],
    }
  },
  terms: {
    icon: '⚖️', color: '#1A3354', colorLight: '#234576',
    titleKey: 'terms',
    sections: {
      uz: [
        { h: "1. Foydalanish qoidalari", p: "Smart MMTB platformasidan faqat qonuniy maqsadlarda foydalanish mumkin. Tizimni buzishga, boshqa foydalanuvchilar ma'lumotlariga ruxsatsiz kirishga urinish taqiqlanadi." },
        { h: "2. Hisob yaratish", p: "Har bir ota-ona faqat bitta hisob yaratishi mumkin. Hisobda to'g'ri va haqiqiy ma'lumotlar bo'lishi shart. Soxta ma'lumot kiritilganda hisob bloklanadi." },
        { h: "3. Bot va WebApp qoidalari", p: "Telegram bot va WebApp faqat qonuniy maqsadlarda ishlatilishi kerak. Spam, reklama, botlash taqiqlanadi. Bot orqali pul o'tkazmalari amalga oshirilmaydi." },
        { h: "4. Foydalanuvchi mas'uliyati", p: "Hisobingizga kirish ma'lumotlarini (OTP) uchinchi shaxslarga bermang. Telefon yo'qolsa, darhol administratorga xabar bering." },
        { h: "5. Xizmat mavjudligi", p: "Texnik ishlar vaqtida xizmat vaqtincha to'xtatilishi mumkin (odatda kechasi 23:00-02:00). Muhim ma'lumotlar Telegram kanal orqali e'lon qilinadi." },
      ],
      ru: [
        { h: "1. Правила использования", p: "Платформа Smart MMTB может использоваться только в законных целях. Запрещены взлом системы и несанкционированный доступ к данным других пользователей." },
        { h: "2. Создание аккаунта", p: "Каждый родитель может создать только один аккаунт. Данные должны быть достоверными. При обнаружении ложных данных аккаунт блокируется." },
        { h: "3. Правила бота и WebApp", p: "Telegram-бот и WebApp используются только в законных целях. Спам, реклама и ботинг запрещены. Денежные переводы через бота не осуществляются." },
        { h: "4. Ответственность пользователя", p: "Не передавайте коды OTP третьим лицам. При потере телефона немедленно сообщите администратору." },
        { h: "5. Доступность сервиса", p: "Во время технических работ сервис может быть временно недоступен (обычно ночью 23:00-02:00)." },
      ],
      en: [
        { h: "1. Usage rules", p: "The Smart MMTB platform may only be used for lawful purposes. Hacking the system or unauthorized access to other users' data is prohibited." },
        { h: "2. Account creation", p: "Each parent may create only one account. Information must be accurate. Accounts with false data will be blocked." },
        { h: "3. Bot and WebApp rules", p: "Telegram bot and WebApp are for lawful use only. Spam, advertising, and botting are prohibited. No money transfers through the bot." },
        { h: "4. User responsibility", p: "Do not share OTP codes with others. If you lose your phone, notify the administrator immediately." },
        { h: "5. Service availability", p: "Service may be temporarily unavailable during technical maintenance (usually 23:00-02:00 at night)." },
      ],
    }
  }
}

// Krillcha uchun o'zbekcha matndan foydalanamiz (qo'shimcha variant)
// Turkcha uchun o'zbekcha matndan foydalanamiz (qo'shimcha variant)

export default function LegalModal({ type, onClose }) {
  const { tr, lang } = useApp()
  const doc = DOCS[type]
  if (!doc) return null

  // Til bo'yicha sections tanlash
  const sections = doc.sections[lang] || doc.sections.uz

  return (
    <div style={{
      position: 'fixed', inset: 0, zIndex: 500,
      background: 'rgba(0,0,0,0.55)', backdropFilter: 'blur(6px)',
      display: 'flex', alignItems: 'flex-end',
      fontFamily: 'var(--font)',
    }} onClick={e => e.target === e.currentTarget && onClose()}>
      <div style={{
        background: 'var(--bg)', width: '100%',
        maxHeight: '92dvh', borderRadius: '24px 24px 0 0',
        display: 'flex', flexDirection: 'column',
        animation: 'slideUp 0.35s cubic-bezier(0.4,0,0.2,1)',
      }}>
        {/* Handle */}
        <div style={{ display: 'flex', justifyContent: 'center', padding: '10px 0 0' }}>
          <div style={{ width: 36, height: 4, borderRadius: 4, background: 'var(--border)' }} />
        </div>

        {/* Header */}
        <div style={{
          background: `linear-gradient(135deg, ${doc.color}, ${doc.colorLight})`,
          margin: '8px 12px', borderRadius: 20,
          padding: '16px 20px', display: 'flex', justifyContent: 'space-between', alignItems: 'center',
        }}>
          <div style={{ color: '#fff', fontWeight: 900, fontSize: 18 }}>
            {doc.icon} {tr(doc.titleKey)}
          </div>
          <button onClick={onClose} style={{
            background: 'rgba(255,255,255,0.2)', border: 'none', borderRadius: '50%',
            width: 36, height: 36, color: '#fff', fontSize: 18, cursor: 'pointer',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
          }}>✕</button>
        </div>

        {/* Kontent */}
        <div style={{ overflowY: 'auto', flex: 1, padding: '0 12px' }}>
          {sections.map((s, i) => (
            <div key={i} style={{
              background: '#fff', borderRadius: 16, padding: '14px 16px',
              marginBottom: 10, border: '1.5px solid var(--border)',
            }}>
              <div style={{
                fontWeight: 800, fontSize: 14, color: 'var(--text)',
                marginBottom: 8, display: 'flex', alignItems: 'center', gap: 8,
              }}>
                <span style={{
                  background: 'var(--primary-50)', color: 'var(--primary)',
                  borderRadius: 6, padding: '2px 8px', fontSize: 12, fontWeight: 800,
                  flexShrink: 0,
                }}>{i + 1}</span>
                {s.h}
              </div>
              <div style={{
                fontSize: 13.5, color: 'var(--text-mid)', lineHeight: 1.75,
                whiteSpace: 'pre-line',
              }}>{s.p}</div>
            </div>
          ))}
          <div style={{
            background: 'var(--primary-50)', borderRadius: 14, padding: '12px 16px',
            fontSize: 12.5, color: 'var(--text-mid)', marginBottom: 16,
          }}>
            📅 Oxirgi yangilanish: 1 Yanvar 2025 · Tuman MMTB
          </div>
        </div>

        {/* Tasdiqlash */}
        <div style={{ padding: '12px 12px', paddingBottom: 'calc(12px + env(safe-area-inset-bottom, 0px))' }}>
          <button onClick={onClose} style={{
            width: '100%', padding: 15, border: 'none', borderRadius: 16,
            background: 'linear-gradient(135deg, var(--primary), var(--primary-light))',
            color: '#fff', fontWeight: 800, fontSize: 16, cursor: 'pointer',
            fontFamily: 'var(--font)',
          }}>
            {tr('understood')}
          </button>
        </div>
      </div>
    </div>
  )
}
