import React from 'react';

class ErrorBoundary extends React.Component {
  constructor(props) {
    super(props);
    this.state = { hasError: false, error: null, errorInfo: null };
  }

  static getDerivedStateFromError(error) {
    return { hasError: true };
  }

  componentDidCatch(error, errorInfo) {
    this.setState({ error, errorInfo });
    console.error("Uncaught error:", error, errorInfo);
  }

  render() {
    if (this.state.hasError) {
      return (
        <div className="p-4 bg-red-50 min-h-screen flex flex-col items-center justify-center text-left">
          <div className="w-full max-w-md bg-white p-6 rounded-lg shadow-xl border border-red-200">
            <h2 className="text-xl font-bold text-red-600 mb-4 flex items-center">
              <span className="mr-2">⚠️</span> Something went wrong
            </h2>
            <div className="bg-gray-100 p-3 rounded mb-4 overflow-auto max-h-60 text-xs font-mono border border-gray-300">
              <p className="font-bold text-red-500 mb-2">{this.state.error && this.state.error.toString()}</p>
              <pre className="text-gray-600 whitespace-pre-wrap">
                {this.state.errorInfo && this.state.errorInfo.componentStack}
              </pre>
            </div>
            {/* Remove auto-reload button or make it safer */}
            <div className="flex gap-2">
                <button 
                  className="flex-1 bg-gray-500 text-white px-4 py-2 rounded hover:bg-gray-600 transition-colors font-semibold"
                  onClick={() => { localStorage.clear(); window.location.reload() }}
                >
                  Clear Cache & Reload
                </button>
            </div>
          </div>
        </div>
      );
    }

    return this.props.children; 
  }
}

export default ErrorBoundary;
