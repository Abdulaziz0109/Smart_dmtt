/**
 * SmartDMTT v4 — ProfileTab
 * Til almashtirish, parol, bildirishnoma, chiqish
 */
import { useState } from 'react'
import { useApp } from '../../context/AppContext'
import { useTranslation, LANG_OPTIONS } from '../../hooks/useTranslation'

const API = (p) => `/api${p}`
const H   = (tk) => ({ Authorization: `Bearer ${tk}`, 'Content-Type': 'application/json', 'ngrok-skip-browser-warning': 'true' })

export default function ProfileTab() {
  const { token, user, setUser, lang, setLang, logout } = useApp()
  const { t } = useTranslation()

  const [pwMode,   setPwMode]   = useState(false)
  const [oldPw,    setOldPw]    = useState('')
  const [newPw,    setNewPw]    = useState('')
  const [newPw2,   setNewPw2]   = useState('')
  const [saving,   setSaving]   = useState(false)
  const [msg,      setMsg]      = useState(null)
  const [notif,    setNotif]    = useState(user?.notifications !== false)

  const flash = (text, ok = true) => {
    setMsg({ text, ok })
    setTimeout(() => setMsg(null), 3000)
  }

  // ── Til almashtirish ─────────────────────────────────
  const changeLang = async (newLang) => {
    await setLang(newLang)
    flash(t('change_saved'))
  }

  // ── Parol o'zgartirish ───────────────────────────────
  const changePassword = async () => {
    if (!oldPw || !newPw) return flash('Eski va yangi parolni kiriting', false)
    if (newPw !== newPw2)  return flash('Yangi parollar mos kelmadi', false)
    if (newPw.length < 4)  return flash('Parol kamida 4 ta belgi', false)

    setSaving(true)
    try {
      const r = await fetch(API('/users/me/password'), {
        method: 'PATCH', headers: H(token),
        body: JSON.stringify({ old_password: oldPw, new_password: newPw }),
      })
      const d = await r.json()
      if (!r.ok) throw new Error(d.detail || 'Xatolik')
      flash('✅ Parol o\'zgartirildi')
      setPwMode(false)
      setOldPw(''); setNewPw(''); setNewPw2('')
    } catch(e) { flash('❌ ' + e.message, false) }
    setSaving(false)
  }

  // ── Bildirishnomalar ─────────────────────────────────
  const toggleNotif = async () => {
    const next = !notif
    setNotif(next)
    try {
      await fetch(API('/users/me/notifications'), {
        method: 'PATCH', headers: H(token),
        body: JSON.stringify({ enabled: next }),
      })
      flash(next ? '🔔 Yoqildi' : '🔕 O\'chirildi')
    } catch(e) { setNotif(!next) }
  }

  // ── Styles ───────────────────────────────────────────
  const S = {
    wrap:    { padding: '20px 16px', maxWidth: 480, margin: '0 auto' },
    card:    { background: '#fff', borderRadius: 16, padding: '20px', marginBottom: 16, border: '1px solid var(--border)' },
    title:   { fontSize: 14, fontWeight: 700, color: 'var(--text-light)', marginBottom: 14, textTransform: 'uppercase', letterSpacing: 0.5 },
    row:     { display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '10px 0', borderBottom: '1px solid var(--border)' },
    label:   { fontSize: 14, color: 'var(--text-mid)' },
    value:   { fontSize: 14, fontWeight: 600, color: 'var(--text)' },
    input:   { width: '100%', padding: '10px 14px', borderRadius: 10, border: '1px solid var(--border)', fontSize: 14, outline: 'none', boxSizing: 'border-box', marginBottom: 10 },
    btn:     { width: '100%', padding: '12px', borderRadius: 12, border: 'none', cursor: 'pointer', fontSize: 14, fontWeight: 700 },
    langBtn: (active) => ({
      padding: '10px 14px', borderRadius: 12, border: `2px solid ${active ? 'var(--primary)' : 'var(--border)'}`,
      background: active ? 'var(--primary-50)' : '#fff', cursor: 'pointer', fontSize: 13,
      fontWeight: active ? 700 : 400, color: active ? 'var(--primary)' : 'var(--text-mid)',
      transition: 'all 0.15s',
    }),
    toggle:  (on) => ({
      width: 48, height: 26, borderRadius: 13, background: on ? 'var(--primary)' : '#d1d5db',
      position: 'relative', cursor: 'pointer', transition: 'background 0.2s', border: 'none', flexShrink: 0,
    }),
    dot: (on) => ({
      position: 'absolute', top: 3, left: on ? 22 : 3, width: 20, height: 20,
      borderRadius: '50%', background: '#fff', transition: 'left 0.2s',
      boxShadow: '0 1px 3px rgba(0,0,0,0.2)',
    }),
  }

  const ROLE_LABELS = {
    admin: 'Admin', boshliq: 'Boshliq', mmtb_boshligi: 'MMTB Boshliq',
    director: 'Direktor', iqtisodchi: 'Iqtisodchi',
    teacher: 'Muallim', togarak_rahbari: "To'garak rahbari",
    parent: 'Ota-ona', guest: 'Mehmon',
  }

  return (
    <div style={S.wrap}>
      {msg && (
        <div style={{ padding: '10px 16px', borderRadius: 12, marginBottom: 16,
          background: msg.ok ? '#dcfce7' : '#fee2e2', color: msg.ok ? '#166534' : '#991b1b', fontWeight: 600 }}>
          {msg.text}
        </div>
      )}

      {/* Profil ma'lumotlari */}
      <div style={S.card}>
        <div style={S.title}>👤 {t('my_profile')}</div>
        {[
          [t('full_name'), user?.full_name || '—'],
          [t('phone'),     user?.phone     || '—'],
          [t('role'),      ROLE_LABELS[user?.role] || user?.role || '—'],
        ].map(([label, value]) => (
          <div key={label} style={S.row}>
            <span style={S.label}>{label}</span>
            <span style={S.value}>{value}</span>
          </div>
        ))}
      </div>

      {/* Til tanlash */}
      <div style={S.card}>
        <div style={S.title}>🌐 {t('language_label')}</div>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 8 }}>
          {LANG_OPTIONS.map(opt => (
            <button key={opt.value} style={S.langBtn(lang === opt.value)}
              onClick={() => changeLang(opt.value)}>
              {opt.label}
            </button>
          ))}
        </div>
      </div>

      {/* Bildirishnomalar */}
      <div style={S.card}>
        <div style={S.title}>🔔 {t('notifications')}</div>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <div>
            <div style={{ fontWeight: 600, fontSize: 14 }}>
              {notif ? '🔔 Yoqilgan' : '🔕 O\'chirilgan'}
            </div>
            <div style={{ fontSize: 12, color: 'var(--text-light)', marginTop: 2 }}>
              Davomat va to'lov xabarlari
            </div>
          </div>
          <button style={S.toggle(notif)} onClick={toggleNotif}>
            <div style={S.dot(notif)} />
          </button>
        </div>
      </div>

      {/* Parol o'zgartirish */}
      <div style={S.card}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: pwMode ? 16 : 0 }}>
          <div style={S.title} >🔑 {t('change_password')}</div>
          <button style={{ background: 'none', border: 'none', cursor: 'pointer', color: 'var(--primary)', fontWeight: 600, fontSize: 13 }}
            onClick={() => setPwMode(v => !v)}>
            {pwMode ? t('cancel') : t('edit')}
          </button>
        </div>
        {pwMode && (
          <div>
            <input style={S.input} type="password" placeholder="Eski parol" value={oldPw} onChange={e => setOldPw(e.target.value)} />
            <input style={S.input} type="password" placeholder="Yangi parol" value={newPw} onChange={e => setNewPw(e.target.value)} />
            <input style={S.input} type="password" placeholder="Yangi parolni takrorlang" value={newPw2} onChange={e => setNewPw2(e.target.value)} />
            <button style={{ ...S.btn, background: 'var(--primary)', color: '#fff', opacity: saving ? 0.6 : 1 }}
              disabled={saving} onClick={changePassword}>
              {saving ? t('loading') : t('save')}
            </button>
          </div>
        )}
      </div>

      {/* Chiqish */}
      <button
        style={{ ...S.btn, background: '#fee2e2', color: '#ef4444', marginTop: 8 }}
        onClick={() => { if (confirm('Chiqasizmi?')) logout() }}>
        🚪 {t('logout')}
      </button>
    </div>
  )
}
