/**
 * ComplaintsTab — Shikoyat, taklif, maqtov (barcha rollar)
 */
import { useState, useEffect } from 'react'
import { useApp } from '../../context/AppContext'

const TYPES   = [{ v:'complaint', l:'📢 Shikoyat' }, { v:'suggestion', l:'💡 Taklif' }, { v:'praise', l:'👏 Maqtov' }]
const TARGETS = [{ v:'teacher', l:'👩‍🏫 Muallim' }, { v:'club', l:'📚 To\'garak' }, { v:'kindergarten', l:'🏫 Bog\'cha' }, { v:'system', l:'⚙️ Tizim' }]
const STATUS_COLOR = { new:'#F59E0B', in_progress:'#3B82F6', resolved:'#10B981', rejected:'#EF4444' }
const STATUS_LABEL = { new:'Yangi', in_progress:'Ko\'rilmoqda', resolved:'Hal qilindi', rejected:'Rad etildi' }

function Card({ children, style }) {
  return <div style={{ background:'#fff', borderRadius:16, padding:16, border:'1.5px solid #E2EBF0', boxShadow:'0 2px 8px rgba(10,50,80,0.06)', ...style }}>{children}</div>
}

export default function ComplaintsTab() {
  const { token, user } = useApp()
  const [list, setList]       = useState([])
  const [loading, setLoading] = useState(true)
  const [showForm, setShowForm] = useState(false)
  const [form, setForm]       = useState({ complaint_type:'complaint', target_type:'system', text:'', is_anonymous:true })
  const [saving, setSaving]   = useState(false)
  const [msg, setMsg]         = useState('')

  const h = { Authorization:`Bearer ${token}`, 'Content-Type':'application/json', 'ngrok-skip-browser-warning':'true' }

  const load = async () => {
    setLoading(true)
    try {
      const r = await fetch('/api/complaints', { headers: h })
      const d = await r.json()
      setList(d.complaints || [])
    } catch { setList([]) } finally { setLoading(false) }
  }

  useEffect(() => { load() }, [])

  const submit = async () => {
    if (!form.text.trim()) { setMsg('Matn kiriting'); return }
    setSaving(true); setMsg('')
    try {
      const r = await fetch('/api/complaints', { method:'POST', headers: h, body: JSON.stringify(form) })
      if (r.ok) { setMsg('Yuborildi ✅'); setShowForm(false); setForm({ complaint_type:'complaint', target_type:'system', text:'', is_anonymous:true }); load() }
      else { const d = await r.json(); setMsg(d.detail || 'Xatolik') }
    } catch { setMsg('Tarmoq xatosi') } finally { setSaving(false) }
  }

  const btn = (active, onClick, label) => (
    <button onClick={onClick} style={{ padding:'7px 14px', borderRadius:20, border:'none', cursor:'pointer', fontSize:12, fontWeight:700, background: active ? '#0B5E50' : '#F0F4F8', color: active ? '#fff' : '#4A6070', transition:'all 0.15s' }}>{label}</button>
  )

  return (
    <div style={{ padding:'16px 12px', fontFamily:'var(--font)' }}>
      <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:16 }}>
        <div>
          <div style={{ fontSize:20, fontWeight:900, color:'#0B5E50' }}>Shikoyat & Taklif</div>
          <div style={{ fontSize:12, color:'#8A9BAB' }}>Fikr va takliflaringizni yuboring</div>
        </div>
        <button onClick={() => setShowForm(!showForm)} style={{ padding:'8px 16px', borderRadius:20, border:'none', background:'#0B5E50', color:'#fff', fontWeight:700, fontSize:13, cursor:'pointer' }}>
          {showForm ? '✕ Yopish' : '+ Yangi'}
        </button>
      </div>

      {/* Yangi shakl */}
      {showForm && (
        <Card style={{ marginBottom:16 }}>
          <div style={{ fontSize:14, fontWeight:800, marginBottom:12 }}>Yangi murojaat</div>

          <div style={{ marginBottom:10 }}>
            <div style={{ fontSize:11, fontWeight:700, color:'#8A9BAB', marginBottom:6 }}>Tur</div>
            <div style={{ display:'flex', gap:6, flexWrap:'wrap' }}>
              {TYPES.map(t => btn(form.complaint_type === t.v, () => setForm(f => ({...f, complaint_type: t.v})), t.l))}
            </div>
          </div>

          <div style={{ marginBottom:10 }}>
            <div style={{ fontSize:11, fontWeight:700, color:'#8A9BAB', marginBottom:6 }}>Kimga</div>
            <div style={{ display:'flex', gap:6, flexWrap:'wrap' }}>
              {TARGETS.map(t => btn(form.target_type === t.v, () => setForm(f => ({...f, target_type: t.v})), t.l))}
            </div>
          </div>

          <textarea
            value={form.text}
            onChange={e => setForm(f => ({...f, text: e.target.value}))}
            placeholder="Fikringizni yozing..."
            style={{ width:'100%', minHeight:90, padding:12, borderRadius:10, border:'2px solid #E2EBF0', fontSize:13, fontFamily:'var(--font)', resize:'vertical', boxSizing:'border-box', outline:'none' }}
          />

          <div style={{ display:'flex', alignItems:'center', gap:8, margin:'10px 0' }}>
            <input type="checkbox" id="anon" checked={form.is_anonymous} onChange={e => setForm(f => ({...f, is_anonymous: e.target.checked}))} />
            <label htmlFor="anon" style={{ fontSize:13, cursor:'pointer' }}>Anonim yuborish</label>
          </div>

          {msg && <div style={{ color: msg.includes('✅') ? '#10B981' : '#EF4444', fontSize:12, marginBottom:8 }}>{msg}</div>}

          <button onClick={submit} disabled={saving} style={{ width:'100%', padding:12, borderRadius:10, border:'none', background:'#0B5E50', color:'#fff', fontWeight:800, fontSize:14, cursor:'pointer', opacity: saving ? 0.7 : 1 }}>
            {saving ? 'Yuborilmoqda...' : 'Yuborish'}
          </button>
        </Card>
      )}

      {/* Ro'yxat */}
      {loading ? (
        <div style={{ textAlign:'center', padding:40, color:'#8A9BAB' }}>Yuklanmoqda...</div>
      ) : list.length === 0 ? (
        <div style={{ textAlign:'center', padding:40, color:'#8A9BAB' }}>Murojaatlar yo'q</div>
      ) : (
        list.map(c => (
          <Card key={c.id} style={{ marginBottom:10 }}>
            <div style={{ display:'flex', justifyContent:'space-between', alignItems:'flex-start', marginBottom:8 }}>
              <div style={{ fontSize:13, fontWeight:800 }}>
                {TYPES.find(t => t.v === c.complaint_type)?.l || c.complaint_type}
                {' · '}
                {TARGETS.find(t => t.v === c.target_type)?.l || c.target_type}
              </div>
              <span style={{ fontSize:11, fontWeight:700, padding:'3px 8px', borderRadius:8, background: STATUS_COLOR[c.status] + '20', color: STATUS_COLOR[c.status] }}>
                {STATUS_LABEL[c.status] || c.status}
              </span>
            </div>
            <div style={{ fontSize:13, color:'#4A6070', lineHeight:1.5 }}>{c.text}</div>
            {c.response && (
              <div style={{ marginTop:10, padding:10, borderRadius:8, background:'#F0FAF7', fontSize:12, color:'#0B5E50' }}>
                <strong>Javob:</strong> {c.response}
              </div>
            )}
            <div style={{ fontSize:11, color:'#B0BEC5', marginTop:6 }}>
              {c.is_anonymous ? '🎭 Anonim' : '👤 Ochiq'} · {c.created_at ? new Date(c.created_at).toLocaleDateString('uz') : ''}
            </div>
          </Card>
        ))
      )}
    </div>
  )
}
