/**
 * SmartDMTT v4 — IqtisodchiTab
 * Moliya, qarzdorlar, CSV export
 */
import { useState, useEffect } from 'react'
import { useApp } from '../../context/AppContext'

const API = (p) => `/api${p}`
const H   = (tk) => ({ Authorization: `Bearer ${tk}`, 'Content-Type': 'application/json', 'ngrok-skip-browser-warning': 'true' })
const shimmer = `@keyframes shimmer{0%{background-position:200% 0}100%{background-position:-200% 0}}`

function Skeleton({ w='100%', h=16, r=8, mb=8 }) {
  return <div style={{ width:w, height:h, borderRadius:r, marginBottom:mb,
    background:'linear-gradient(90deg,#f0f0f0 25%,#e8e8e8 50%,#f0f0f0 75%)',
    backgroundSize:'200% 100%', animation:'shimmer 1.4s infinite' }} />
}

function exportCSV(data, filename) {
  if (!data?.length) return
  const headers = Object.keys(data[0]).join(',')
  const rows    = data.map(r => Object.values(r).map(v => `"${v ?? ''}"`).join(',')).join('\n')
  const blob    = new Blob(['\uFEFF' + headers + '\n' + rows], { type: 'text/csv;charset=utf-8' })
  const url     = URL.createObjectURL(blob)
  const a       = document.createElement('a')
  a.href = url; a.download = filename; a.click()
  URL.revokeObjectURL(url)
}

// ── Moliya xulosasi ───────────────────────────────────────
function FinanceSummary({ data, loading }) {
  if (loading) return (
    <div style={{ display:'flex', gap:12, flexWrap:'wrap', marginBottom:20 }}>
      {[1,2,3,4].map(i => (
        <div key={i} style={{ flex:'1 1 140px', background:'#fff', borderRadius:14, padding:18, border:'1px solid var(--border)' }}>
          <Skeleton h={28} w="60%" /><Skeleton h={12} w="80%" />
        </div>
      ))}
    </div>
  )
  if (!data) return null

  const cards = [
    { icon:'💰', label:'Oylik daromad',   value: (data.monthly_revenue||0).toLocaleString()+' so\'m', color:'#059669' },
    { icon:'✅', label:'To\'lagan',        value: data.paid_count ?? '—',                              color:'#2563eb' },
    { icon:'❌', label:'Qarzdor',          value: data.debtors    ?? '—',                              color:'#ef4444' },
    { icon:'📊', label:'To\'lov foizi',    value: (data.payment_pct||0)+'%',                           color:'#7c3aed' },
  ]

  return (
    <div style={{ display:'flex', gap:12, flexWrap:'wrap', marginBottom:20 }}>
      {cards.map(c => (
        <div key={c.label} style={{ flex:'1 1 140px', background:'#fff', borderRadius:14,
          padding:'16px 18px', border:`1px solid ${c.color}33` }}>
          <div style={{ fontSize:24 }}>{c.icon}</div>
          <div style={{ fontSize:22, fontWeight:900, color:c.color, margin:'6px 0 4px' }}>{c.value}</div>
          <div style={{ fontSize:12, color:'var(--text-light)' }}>{c.label}</div>
        </div>
      ))}
    </div>
  )
}

// ── Qarzdorlar jadvali ────────────────────────────────────
function DebtorsTable({ data, loading, onExport }) {
  const [search, setSearch] = useState('')

  const filtered = (data||[]).filter(d =>
    !search || d.child_name?.toLowerCase().includes(search.toLowerCase()) ||
    d.parent_name?.toLowerCase().includes(search.toLowerCase()) ||
    d.parent_phone?.includes(search)
  )

  const S = {
    th: { padding:'9px 12px', background:'#f8fafc', borderBottom:'2px solid var(--border)',
      textAlign:'left', fontWeight:700, fontSize:11, color:'var(--text-light)', whiteSpace:'nowrap' },
    td: { padding:'9px 12px', borderBottom:'1px solid var(--border)', fontSize:13, verticalAlign:'middle' },
  }

  return (
    <div style={{ background:'#fff', borderRadius:16, border:'1px solid var(--border)', overflow:'hidden' }}>
      <div style={{ padding:'14px 16px', borderBottom:'1px solid var(--border)',
        display:'flex', gap:10, justifyContent:'space-between', alignItems:'center', flexWrap:'wrap' }}>
        <div style={{ fontWeight:700, fontSize:15 }}>❌ Qarzdorlar ({filtered.length} ta)</div>
        <div style={{ display:'flex', gap:8 }}>
          <input style={{ padding:'7px 12px', borderRadius:10, border:'1px solid var(--border)',
            fontSize:13, outline:'none', width:180 }}
            placeholder="🔍 Qidirish..."
            value={search} onChange={e => setSearch(e.target.value)} />
          <button onClick={onExport}
            style={{ padding:'7px 14px', borderRadius:10, background:'#059669', color:'#fff',
              border:'none', cursor:'pointer', fontWeight:600, fontSize:12 }}>
            ⬇️ CSV
          </button>
        </div>
      </div>

      <div style={{ overflowX:'auto' }}>
        {loading ? (
          <div style={{ padding:24 }}><Skeleton /><Skeleton w="80%" /><Skeleton w="60%" /></div>
        ) : filtered.length===0 ? (
          <div style={{ padding:32, textAlign:'center', color:'var(--text-light)' }}>
            {search ? 'Topilmadi' : 'Barcha to\'lovlar amalga oshirilgan! 🎉'}
          </div>
        ) : (
          <table style={{ width:'100%', borderCollapse:'collapse', fontSize:13 }}>
            <thead>
              <tr>
                <th style={S.th}>Bola</th>
                <th style={S.th}>To'garak</th>
                <th style={S.th}>Narx</th>
                <th style={S.th}>Ota-ona</th>
                <th style={S.th}>Telefon</th>
                <th style={S.th}>ID</th>
              </tr>
            </thead>
            <tbody>
              {filtered.map((d, i) => (
                <tr key={i}>
                  <td style={S.td}><b>{d.child_name}</b></td>
                  <td style={S.td}>{d.club_name}</td>
                  <td style={{ ...S.td, color:'#ef4444', fontWeight:700 }}>
                    {Number(d.club_price||0).toLocaleString()} so'm
                  </td>
                  <td style={S.td}>{d.parent_name}</td>
                  <td style={S.td}>
                    <a href={`tel:${d.parent_phone}`} style={{ color:'#2563eb', textDecoration:'none' }}>
                      {d.parent_phone}
                    </a>
                  </td>
                  <td style={S.td}><code style={{ fontSize:10 }}>{d.payment_id}</code></td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  )
}

// ── Oylik to'lovlar grafigi ───────────────────────────────
function MonthlyChart({ data }) {
  if (!data?.monthly_breakdown?.length) return null
  const max = Math.max(...data.monthly_breakdown.map(m => m.revenue||0))

  return (
    <div style={{ background:'#fff', borderRadius:16, padding:20, border:'1px solid var(--border)', marginBottom:16 }}>
      <div style={{ fontWeight:700, marginBottom:14, fontSize:15 }}>📈 Oylik daromad</div>
      <div style={{ display:'flex', gap:6, alignItems:'flex-end', height:80 }}>
        {data.monthly_breakdown.slice(-6).map((m, i) => {
          const pct = max > 0 ? (m.revenue||0)/max*100 : 0
          return (
            <div key={i} style={{ flex:1, display:'flex', flexDirection:'column', alignItems:'center', gap:4 }}>
              <div style={{ fontSize:10, color:'var(--text-light)', fontWeight:600 }}>
                {(m.revenue||0)/1000 > 999 ? Math.round((m.revenue||0)/1000000)+'M' : Math.round((m.revenue||0)/1000)+'K'}
              </div>
              <div style={{ width:'100%', background:'#e5e7eb', borderRadius:4, height:60, display:'flex', flexDirection:'column', justifyContent:'flex-end' }}>
                <div style={{ width:'100%', background:'#6366f1', borderRadius:4,
                  height: pct+'%', minHeight: pct>0?4:0, transition:'height 0.5s ease' }} />
              </div>
              <div style={{ fontSize:9, color:'var(--text-light)' }}>{m.month?.slice(5)}</div>
            </div>
          )
        })}
      </div>
    </div>
  )
}

export default function IqtisodchiTab() {
  const { token } = useApp()
  const [summary,  setSummary]  = useState(null)
  const [debtors,  setDebtors]  = useState([])
  const [loading,  setLoading]  = useState(true)
  const [loadDbt,  setLoadDbt]  = useState(true)
  const [sub,      setSub]      = useState('summary')

  useEffect(() => {
    Promise.all([
      fetch(API('/analytics/summary'), { headers: H(token) }).then(r=>r.json()),
      fetch(API('/payments/debtors'),  { headers: H(token) }).then(r=>r.json()),
    ]).then(([s, d]) => {
      setSummary(s)
      setDebtors(Array.isArray(d) ? d : d.debtors || [])
    }).finally(() => { setLoading(false); setLoadDbt(false) })
  }, [token])

  const handleExport = () => {
    const month = new Date().toISOString().slice(0,7)
    exportCSV(debtors, `qarzdorlar_${month}.csv`)
  }

  return (
    <>
      <style>{shimmer}</style>
      <div style={{ padding:'20px 16px' }}>
        <h2 style={{ margin:'0 0 16px', fontWeight:800 }}>💰 Moliya paneli</h2>

        {/* Sub tabs */}
        <div style={{ display:'flex', gap:8, marginBottom:20 }}>
          {[['summary','📊 Xulosa'],['debtors','❌ Qarzdorlar']].map(([id,label]) => (
            <button key={id} onClick={()=>setSub(id)} style={{
              flex:1, padding:'9px', borderRadius:12, border:'none', cursor:'pointer',
              fontWeight:600, fontSize:13,
              background: sub===id ? '#6366f1' : '#f1f5f9',
              color: sub===id ? '#fff' : '#6b7280',
            }}>{label}</button>
          ))}
        </div>

        {sub==='summary' && (
          <>
            <FinanceSummary data={summary} loading={loading} />
            <MonthlyChart data={summary} />
          </>
        )}

        {sub==='debtors' && (
          <DebtorsTable data={debtors} loading={loadDbt} onExport={handleExport} />
        )}
      </div>
    </>
  )
}
