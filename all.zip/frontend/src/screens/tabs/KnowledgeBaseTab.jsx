/**
 * KnowledgeBaseTab — Bilimlar bazasi (admin/boshliq)
 */
import { useState, useEffect } from 'react'
import { useApp } from '../../context/AppContext'

const STATUS_C = { active:'#10B981', pending:'#F59E0B', rejected:'#EF4444' }
const STATUS_L = { active:'Aktiv', pending:'Kutmoqda', rejected:'Rad' }

function Card({ children, style }) {
  return <div style={{ background:'#fff', borderRadius:16, padding:16, border:'1.5px solid #E2EBF0', boxShadow:'0 2px 8px rgba(10,50,80,0.06)', ...style }}>{children}</div>
}

export default function KnowledgeBaseTab() {
  const { token } = useApp()
  const [entries, setEntries] = useState([])
  const [stats, setStats]     = useState({})
  const [loading, setLoading] = useState(true)
  const [filter, setFilter]   = useState({ status:'', search:'' })
  const [showAdd, setShowAdd] = useState(false)
  const [form, setForm]       = useState({ question_en:'', answer_en:'', lang:'uz_latin' })
  const [saving, setSaving]   = useState(false)
  const [msg, setMsg]         = useState('')

  const h = { Authorization:`Bearer ${token}`, 'Content-Type':'application/json', 'ngrok-skip-browser-warning':'true' }

  const load = async () => {
    setLoading(true)
    try {
      const p = new URLSearchParams()
      if (filter.status) p.set('status', filter.status)
      if (filter.search) p.set('search', filter.search)
      const [eRes, sRes] = await Promise.all([
        fetch(`/api/kb/entries?${p}`, { headers: h }),
        fetch('/api/kb/stats', { headers: h }),
      ])
      const [eD, sD] = await Promise.all([eRes.json(), sRes.json()])
      setEntries(eD.entries || [])
      setStats(sD)
    } catch { setEntries([]) } finally { setLoading(false) }
  }

  useEffect(() => { load() }, [filter.status])

  const changeStatus = async (id, status) => {
    await fetch(`/api/kb/entries/${id}`, { method:'PATCH', headers: h, body: JSON.stringify({ status }) })
    load()
  }

  const del = async (id) => {
    if (!confirm('O\'chirilsinmi?')) return
    await fetch(`/api/kb/entries/${id}`, { method:'DELETE', headers: h })
    load()
  }

  const submit = async () => {
    if (!form.question_en.trim() || !form.answer_en.trim()) { setMsg('Savol va javobni kiriting'); return }
    setSaving(true); setMsg('')
    try {
      const r = await fetch('/api/kb/entries', { method:'POST', headers: h, body: JSON.stringify(form) })
      if (r.ok) { setMsg('Qo\'shildi ✅'); setShowAdd(false); setForm({ question_en:'', answer_en:'', lang:'uz_latin' }); load() }
      else { const d = await r.json(); setMsg(d.detail || 'Xatolik') }
    } catch { setMsg('Tarmoq xatosi') } finally { setSaving(false) }
  }

  const inp = { width:'100%', padding:'10px 12px', borderRadius:10, border:'2px solid #E2EBF0', fontSize:13, fontFamily:'var(--font)', boxSizing:'border-box', outline:'none' }

  return (
    <div style={{ padding:'16px 12px', fontFamily:'var(--font)' }}>
      <div style={{ fontSize:20, fontWeight:900, color:'#0B5E50', marginBottom:4 }}>Bilimlar Bazasi</div>

      {/* Statistika */}
      <div style={{ display:'flex', gap:8, marginBottom:14, overflowX:'auto' }}>
        {[['Jami', stats.total, '#0B5E50'], ['Aktiv', stats.active, '#10B981'], ['Kutmoqda', stats.pending, '#F59E0B'], ['Rad', stats.rejected, '#EF4444']].map(([l, v, c]) => (
          <div key={l} style={{ flex:1, minWidth:64, background:'#fff', borderRadius:12, padding:'10px 8px', textAlign:'center', border:'1.5px solid #E2EBF0' }}>
            <div style={{ fontSize:18, fontWeight:900, color: c }}>{v ?? '—'}</div>
            <div style={{ fontSize:10, color:'#8A9BAB', fontWeight:700 }}>{l}</div>
          </div>
        ))}
      </div>

      {/* Filter + tugma */}
      <div style={{ display:'flex', gap:8, marginBottom:12 }}>
        <input placeholder="Qidirish..." value={filter.search} onChange={e => setFilter(f => ({...f, search: e.target.value}))}
          onKeyDown={e => e.key === 'Enter' && load()}
          style={{ ...inp, flex:1 }} />
        <select value={filter.status} onChange={e => setFilter(f => ({...f, status: e.target.value}))}
          style={{ ...inp, width:'auto', flex:'0 0 auto' }}>
          <option value=''>Barchasi</option>
          <option value='active'>Aktiv</option>
          <option value='pending'>Kutmoqda</option>
          <option value='rejected'>Rad</option>
        </select>
        <button onClick={() => setShowAdd(!showAdd)} style={{ padding:'10px 14px', borderRadius:10, border:'none', background:'#0B5E50', color:'#fff', fontWeight:700, fontSize:13, cursor:'pointer', whiteSpace:'nowrap' }}>
          +Yangi
        </button>
      </div>

      {showAdd && (
        <Card style={{ marginBottom:14 }}>
          <div style={{ fontSize:14, fontWeight:800, marginBottom:10 }}>Yangi yozuv (inglizcha)</div>
          <div style={{ marginBottom:8 }}>
            <label style={{ fontSize:11, fontWeight:700, color:'#8A9BAB', display:'block', marginBottom:4 }}>Savol (inglizcha)</label>
            <input value={form.question_en} onChange={e => setForm(f => ({...f, question_en: e.target.value}))} style={inp} placeholder="What is the monthly fee?" />
          </div>
          <div style={{ marginBottom:8 }}>
            <label style={{ fontSize:11, fontWeight:700, color:'#8A9BAB', display:'block', marginBottom:4 }}>Javob (inglizcha)</label>
            <textarea value={form.answer_en} onChange={e => setForm(f => ({...f, answer_en: e.target.value}))}
              style={{ ...inp, minHeight:70, resize:'vertical' }} placeholder="The monthly fee is..." />
          </div>
          {msg && <div style={{ color: msg.includes('✅') ? '#10B981' : '#EF4444', fontSize:12, marginBottom:8 }}>{msg}</div>}
          <button onClick={submit} disabled={saving} style={{ width:'100%', padding:10, borderRadius:10, border:'none', background:'#0B5E50', color:'#fff', fontWeight:800, fontSize:13, cursor:'pointer' }}>
            {saving ? 'Saqlanmoqda...' : 'Saqlash'}
          </button>
        </Card>
      )}

      {loading ? (
        <div style={{ textAlign:'center', padding:40, color:'#8A9BAB' }}>Yuklanmoqda...</div>
      ) : entries.length === 0 ? (
        <div style={{ textAlign:'center', padding:40, color:'#8A9BAB' }}>Yozuvlar topilmadi</div>
      ) : (
        entries.map(e => (
          <Card key={e.id} style={{ marginBottom:10 }}>
            <div style={{ display:'flex', justifyContent:'space-between', alignItems:'flex-start', gap:8 }}>
              <div style={{ flex:1, minWidth:0 }}>
                <div style={{ fontSize:13, fontWeight:800, marginBottom:4, wordBreak:'break-word' }}>{e.question_en}</div>
                <div style={{ fontSize:12, color:'#4A6070', lineHeight:1.5, wordBreak:'break-word' }}>{e.answer_en}</div>
                <div style={{ fontSize:11, color:'#B0BEC5', marginTop:6 }}>
                  {e.source === 'auto' ? '🤖 Auto' : '✍️ Manuel'} · {e.use_count} marta ishlatildi
                </div>
              </div>
              <span style={{ fontSize:11, fontWeight:700, padding:'3px 8px', borderRadius:8, background: STATUS_C[e.status] + '20', color: STATUS_C[e.status], whiteSpace:'nowrap' }}>
                {STATUS_L[e.status]}
              </span>
            </div>
            <div style={{ display:'flex', gap:6, marginTop:10, flexWrap:'wrap' }}>
              {e.status === 'pending' && (
                <>
                  <button onClick={() => changeStatus(e.id, 'active')} style={{ padding:'5px 12px', borderRadius:16, border:'none', background:'#ECFDF5', color:'#10B981', fontWeight:700, fontSize:11, cursor:'pointer' }}>✅ Tasdiqlash</button>
                  <button onClick={() => changeStatus(e.id, 'rejected')} style={{ padding:'5px 12px', borderRadius:16, border:'none', background:'#FEF2F2', color:'#EF4444', fontWeight:700, fontSize:11, cursor:'pointer' }}>✕ Rad</button>
                </>
              )}
              {e.status === 'rejected' && (
                <button onClick={() => changeStatus(e.id, 'pending')} style={{ padding:'5px 12px', borderRadius:16, border:'none', background:'#EFF6FF', color:'#3B82F6', fontWeight:700, fontSize:11, cursor:'pointer' }}>🔄 Qayta ko'rish</button>
              )}
              {e.status === 'active' && (
                <button onClick={() => changeStatus(e.id, 'rejected')} style={{ padding:'5px 12px', borderRadius:16, border:'none', background:'#FEF2F2', color:'#EF4444', fontWeight:700, fontSize:11, cursor:'pointer' }}>Faolsizlantirish</button>
              )}
              <button onClick={() => del(e.id)} style={{ padding:'5px 12px', borderRadius:16, border:'none', background:'#F0F4F8', color:'#8A9BAB', fontWeight:700, fontSize:11, cursor:'pointer' }}>🗑 O'chirish</button>
            </div>
          </Card>
        ))
      )}
    </div>
  )
}
