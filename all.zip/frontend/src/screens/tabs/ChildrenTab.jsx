/**
 * SmartDMTT v4 — ChildrenTab
 * Ota-ona: farzandlar, davomat, to'lov badge, bo'sh holat
 */
import { useState, useEffect } from 'react'
import { useApp } from '../../context/AppContext'
import { useTranslation } from '../../hooks/useTranslation'

const API = (p) => `/api${p}`
const H   = (tk) => ({ Authorization: `Bearer ${tk}`, 'Content-Type': 'application/json', 'ngrok-skip-browser-warning': 'true' })

function Skeleton({ w = '100%', h = 16, r = 8, mb = 8 }) {
  return <div style={{ width: w, height: h, borderRadius: r, marginBottom: mb,
    background: 'linear-gradient(90deg,#f0f0f0 25%,#e8e8e8 50%,#f0f0f0 75%)',
    backgroundSize: '200% 100%', animation: 'shimmer 1.4s infinite' }} />
}

const shimmer = `@keyframes shimmer{0%{background-position:200% 0}100%{background-position:-200% 0}}`

function AttBadge({ status }) {
  const map = {
    present: ['✅', '#dcfce7', '#166534'],
    absent:  ['❌', '#fee2e2', '#991b1b'],
    late:    ['⏰', '#fef9c3', '#854d0e'],
    excused: ['📝', '#ede9fe', '#5b21b6'],
  }
  const [icon, bg, color] = map[status] || ['—', '#f3f4f6', '#6b7280']
  return (
    <span style={{ background: bg, color, borderRadius: 20, padding: '2px 10px', fontSize: 11, fontWeight: 700 }}>
      {icon}
    </span>
  )
}

function PayBadge({ paid }) {
  return (
    <span style={{
      background: paid ? '#dcfce7' : '#fee2e2',
      color: paid ? '#166534' : '#991b1b',
      borderRadius: 20, padding: '2px 10px', fontSize: 11, fontWeight: 700,
    }}>
      {paid ? "✅ To'langan" : "❌ To'lanmagan"}
    </span>
  )
}

function EmptyState({ t }) {
  return (
    <div style={{ textAlign: 'center', padding: '60px 20px' }}>
      <div style={{ fontSize: 64, marginBottom: 12 }}>👶</div>
      <div style={{ fontSize: 18, fontWeight: 700, marginBottom: 8 }}>{t('no_children')}</div>
      <div style={{ fontSize: 14, color: 'var(--text-light)' }}>
        Farzandingizni qo'shish uchun administrator bilan bog'laning.
      </div>
    </div>
  )
}

function ChildCard({ child, token, t }) {
  const [open,      setOpen]      = useState(false)
  const [enrollments, setEnr]     = useState(null)
  const [attHistory,  setHist]    = useState(null)
  const [loading,   setLoading]   = useState(false)

  const load = async () => {
    if (enrollments) { setOpen(v => !v); return }
    setOpen(true)
    setLoading(true)
    try {
      const [enrR, attR] = await Promise.all([
        fetch(API(`/clubs/enrollments?child_id=${child.id}`), { headers: H(token) }),
        fetch(API(`/attendance/child/${child.id}?days=7`),   { headers: H(token) }),
      ])
      const enrD = enrR.ok ? await enrR.json() : []
      const attD = attR.ok ? await attR.json() : null
      setEnr(Array.isArray(enrD) ? enrD : enrD.enrollments || [])
      setHist(attD)
    } catch(e) { console.error(e) }
    setLoading(false)
  }

  const age = child.birth_year ? new Date().getFullYear() - child.birth_year : null

  return (
    <div style={{ background: '#fff', borderRadius: 16, marginBottom: 14,
      border: '1px solid var(--border)', overflow: 'hidden' }}>
      {/* Header */}
      <div style={{ padding: '16px 20px', display: 'flex', justifyContent: 'space-between',
        alignItems: 'center', cursor: 'pointer' }} onClick={load}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 14 }}>
          <div style={{ width: 48, height: 48, borderRadius: '50%', background: 'var(--primary-50)',
            display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 22 }}>
            👶
          </div>
          <div>
            <div style={{ fontWeight: 800, fontSize: 16 }}>{child.full_name}</div>
            {age && <div style={{ fontSize: 12, color: 'var(--text-light)' }}>{age} yosh ({child.birth_year})</div>}
          </div>
        </div>
        <span style={{ fontSize: 18, color: 'var(--text-light)', transition: 'transform 0.2s',
          transform: open ? 'rotate(90deg)' : 'none' }}>›</span>
      </div>

      {/* Detail */}
      {open && (
        <div style={{ borderTop: '1px solid var(--border)', padding: '16px 20px' }}>
          {loading ? (
            <><Skeleton /><Skeleton w="70%" /><Skeleton w="85%" /></>
          ) : (
            <>
              {/* Davomat summary */}
              {attHistory && (
                <div style={{ background: 'var(--primary-50)', borderRadius: 12, padding: '12px 16px', marginBottom: 14 }}>
                  <div style={{ fontWeight: 700, marginBottom: 8, fontSize: 13 }}>📊 7 kunlik davomat</div>
                  <div style={{ display: 'flex', gap: 12 }}>
                    <div><span style={{ fontWeight: 800, fontSize: 20, color: 'var(--primary)' }}>{attHistory.present}</span>
                      <span style={{ fontSize: 12, color: 'var(--text-light)', marginLeft: 4 }}>keldi</span></div>
                    <div><span style={{ fontWeight: 800, fontSize: 20, color: '#ef4444' }}>{attHistory.total - attHistory.present}</span>
                      <span style={{ fontSize: 12, color: 'var(--text-light)', marginLeft: 4 }}>kelmadi</span></div>
                    <div><span style={{ fontWeight: 800, fontSize: 20, color: '#059669' }}>{attHistory.pct}%</span>
                      <span style={{ fontSize: 12, color: 'var(--text-light)', marginLeft: 4 }}>davomat</span></div>
                  </div>
                  {/* Mini calendar */}
                  <div style={{ display: 'flex', gap: 6, marginTop: 10, flexWrap: 'wrap' }}>
                    {(attHistory.records || []).slice(0, 7).map((r, i) => (
                      <div key={i} style={{ textAlign: 'center' }}>
                        <div style={{ fontSize: 10, color: 'var(--text-light)', marginBottom: 2 }}>
                          {new Date(r.date).toLocaleDateString('uz-UZ', { weekday: 'short' }).slice(0, 2)}
                        </div>
                        <AttBadge status={r.status} />
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* To'garaklar */}
              <div style={{ fontWeight: 700, marginBottom: 10, fontSize: 13 }}>📚 To'garaklar</div>
              {!enrollments || enrollments.length === 0 ? (
                <div style={{ color: 'var(--text-light)', fontSize: 13 }}>{t('no_clubs')}</div>
              ) : (
                enrollments.map((enr, i) => (
                  <div key={i} style={{ display: 'flex', justifyContent: 'space-between',
                    alignItems: 'center', padding: '10px 0',
                    borderBottom: i < enrollments.length - 1 ? '1px solid var(--border)' : 'none' }}>
                    <div>
                      <div style={{ fontWeight: 600, fontSize: 14 }}>{enr.club_name || enr.name || '—'}</div>
                      <div style={{ fontSize: 11, color: 'var(--text-light)', marginTop: 2 }}>
                        ID: <code>{enr.payment_id}</code>
                      </div>
                    </div>
                    <PayBadge paid={enr.is_paid || enr.paid} />
                  </div>
                ))
              )}
            </>
          )}
        </div>
      )}
    </div>
  )
}

export default function ChildrenTab() {
  const { token, user } = useApp()
  const { t } = useTranslation()
  const [children, setChildren] = useState(null)
  const [loading,  setLoading]  = useState(true)
  const [error,    setError]    = useState(null)

  useEffect(() => {
    setLoading(true)
    fetch(API('/children/mine'), { headers: H(token) })
      .then(r => r.ok ? r.json() : Promise.reject(r.status))
      .then(d => { setChildren(Array.isArray(d) ? d : d.children || []); setLoading(false) })
      .catch(e => { setError(String(e)); setLoading(false) })
  }, [token])

  return (
    <>
      <style>{shimmer}</style>
      <div style={{ padding: '20px 16px' }}>
        <h2 style={{ margin: '0 0 16px', fontWeight: 800 }}>👶 {t('children')}</h2>

        {loading && [1,2].map(i => (
          <div key={i} style={{ background: '#fff', borderRadius: 16, padding: 20, marginBottom: 14, border: '1px solid var(--border)' }}>
            <div style={{ display: 'flex', gap: 14, marginBottom: 12 }}>
              <Skeleton w={48} h={48} r={24} mb={0} />
              <div style={{ flex: 1 }}><Skeleton w="60%" /><Skeleton w="40%" h={12} /></div>
            </div>
          </div>
        ))}

        {error && (
          <div style={{ textAlign: 'center', padding: 40 }}>
            <div style={{ fontSize: 48 }}>⚠️</div>
            <div style={{ color: '#ef4444', fontWeight: 600, marginBottom: 12 }}>{t('error')}: {error}</div>
            <button onClick={() => window.location.reload()}
              style={{ padding: '10px 24px', borderRadius: 12, background: 'var(--primary)', color: '#fff', border: 'none', cursor: 'pointer', fontWeight: 700 }}>
              🔄 {t('refresh')}
            </button>
          </div>
        )}

        {!loading && !error && children?.length === 0 && <EmptyState t={t} />}

        {!loading && !error && children?.map(child => (
          <ChildCard key={child.id} child={child} token={token} t={t} />
        ))}
      </div>
    </>
  )
}
