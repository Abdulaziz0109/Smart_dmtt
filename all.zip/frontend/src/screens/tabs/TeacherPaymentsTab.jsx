/**
 * TeacherPaymentsTab — Muallim oylik hisob
 */
import { useState, useEffect } from 'react'
import { useApp } from '../../context/AppContext'

function Card({ children, style }) {
  return <div style={{ background:'#fff', borderRadius:16, padding:16, border:'1.5px solid #E2EBF0', boxShadow:'0 2px 8px rgba(10,50,80,0.06)', ...style }}>{children}</div>
}

function StatRow({ label, value, bold }) {
  return (
    <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', padding:'8px 0', borderBottom:'1px solid #F0F4F8' }}>
      <span style={{ fontSize:13, color:'#4A6070' }}>{label}</span>
      <span style={{ fontSize:13, fontWeight: bold ? 800 : 600, color: bold ? '#0B5E50' : '#1A2E3B' }}>{value}</span>
    </div>
  )
}

export default function TeacherPaymentsTab() {
  const { token, user } = useApp()
  const [list, setList]     = useState([])
  const [loading, setLoading] = useState(true)
  const [selected, setSelected] = useState(null)

  const h = { Authorization:`Bearer ${token}`, 'ngrok-skip-browser-warning':'true' }

  useEffect(() => {
    fetch('/api/teacher-payments', { headers: h })
      .then(r => r.json())
      .then(d => setList(d.payments || []))
      .catch(() => setList([]))
      .finally(() => setLoading(false))
  }, [])

  const total = list.reduce((s, p) => s + (p.total || 0), 0)
  const paid  = list.filter(p => p.status === 'paid').reduce((s, p) => s + (p.total || 0), 0)

  return (
    <div style={{ padding:'16px 12px', fontFamily:'var(--font)' }}>
      <div style={{ fontSize:20, fontWeight:900, color:'#0B5E50', marginBottom:4 }}>Oylik hisob</div>
      <div style={{ fontSize:12, color:'#8A9BAB', marginBottom:16 }}>To'lov tarixi va hisob-kitob</div>

      {/* Umumiy ko'rsatkich */}
      <div style={{ display:'flex', gap:10, marginBottom:16 }}>
        <Card style={{ flex:1, textAlign:'center' }}>
          <div style={{ fontSize:11, color:'#8A9BAB', fontWeight:700 }}>Jami (yil)</div>
          <div style={{ fontSize:20, fontWeight:900, color:'#0B5E50', marginTop:4 }}>{total.toLocaleString()}</div>
          <div style={{ fontSize:11, color:'#8A9BAB' }}>so'm</div>
        </Card>
        <Card style={{ flex:1, textAlign:'center' }}>
          <div style={{ fontSize:11, color:'#8A9BAB', fontWeight:700 }}>To'langan</div>
          <div style={{ fontSize:20, fontWeight:900, color:'#10B981', marginTop:4 }}>{paid.toLocaleString()}</div>
          <div style={{ fontSize:11, color:'#8A9BAB' }}>so'm</div>
        </Card>
        <Card style={{ flex:1, textAlign:'center' }}>
          <div style={{ fontSize:11, color:'#8A9BAB', fontWeight:700 }}>Kutilmoqda</div>
          <div style={{ fontSize:20, fontWeight:900, color:'#F59E0B', marginTop:4 }}>{(total - paid).toLocaleString()}</div>
          <div style={{ fontSize:11, color:'#8A9BAB' }}>so'm</div>
        </Card>
      </div>

      {loading ? (
        <div style={{ textAlign:'center', padding:40, color:'#8A9BAB' }}>Yuklanmoqda...</div>
      ) : list.length === 0 ? (
        <Card style={{ textAlign:'center', padding:32 }}>
          <div style={{ fontSize:32, marginBottom:8 }}>📊</div>
          <div style={{ color:'#8A9BAB', fontSize:14 }}>Hisob ma'lumotlari yo'q</div>
        </Card>
      ) : (
        list.map(p => (
          <Card key={p.id} style={{ marginBottom:10, cursor:'pointer' }} onClick={() => setSelected(selected?.id === p.id ? null : p)}>
            <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center' }}>
              <div>
                <div style={{ fontSize:15, fontWeight:800 }}>{p.month}</div>
                <div style={{ fontSize:12, color:'#8A9BAB', marginTop:2 }}>{p.lessons_count} ta dars</div>
              </div>
              <div style={{ textAlign:'right' }}>
                <div style={{ fontSize:16, fontWeight:900, color:'#0B5E50' }}>{p.total?.toLocaleString()} so'm</div>
                <span style={{ fontSize:11, fontWeight:700, padding:'2px 8px', borderRadius:8, background: p.status === 'paid' ? '#ECFDF5' : '#FEF3C7', color: p.status === 'paid' ? '#10B981' : '#F59E0B' }}>
                  {p.status === 'paid' ? '✅ To\'landi' : '⏳ Kutilmoqda'}
                </span>
              </div>
            </div>

            {selected?.id === p.id && (
              <div style={{ marginTop:12, paddingTop:12, borderTop:'1px solid #F0F4F8' }}>
                <StatRow label="Asosiy to'lov (60%)" value={`${p.base_amount?.toLocaleString()} so'm`} />
                <StatRow label="Bonus (40%)" value={`${p.bonus_amount?.toLocaleString()} so'm`} />
                <StatRow label="Davomat darajasi" value={`${p.attendance_rate?.toFixed(1)}%`} />
                <StatRow label="Ota-ona reytingi" value={`${p.parent_rating?.toFixed(1)} / 5`} />
                <StatRow label="O'tilgan darslar" value={`${p.lessons_count} ta`} />
                <StatRow label="Jami" value={`${p.total?.toLocaleString()} so'm`} bold />
                {p.paid_at && <StatRow label="To'langan sana" value={new Date(p.paid_at).toLocaleDateString('uz')} />}
              </div>
            )}
          </Card>
        ))
      )}
    </div>
  )
}
