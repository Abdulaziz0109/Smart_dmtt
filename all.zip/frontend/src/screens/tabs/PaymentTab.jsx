/**
 * SmartDMTT v4 — PaymentTab
 * To'lov tarixi, qarzdorlar, Click/Payme deep link
 */
import { useState, useEffect } from 'react'
import { useApp } from '../../context/AppContext'
import { useTranslation } from '../../hooks/useTranslation'

const API = (p) => `/api${p}`
const H   = (tk) => ({ Authorization: `Bearer ${tk}`, 'Content-Type': 'application/json', 'ngrok-skip-browser-warning': 'true' })

const shimmer = `@keyframes shimmer{0%{background-position:200% 0}100%{background-position:-200% 0}}`

function Skeleton({ w='100%', h=16, r=8, mb=8 }) {
  return <div style={{ width:w, height:h, borderRadius:r, marginBottom:mb,
    background:'linear-gradient(90deg,#f0f0f0 25%,#e8e8e8 50%,#f0f0f0 75%)',
    backgroundSize:'200% 100%', animation:'shimmer 1.4s infinite' }} />
}

// ── Click / Payme deep link generatsiya ──────────────────
function getClickUrl(paymentId, amount) {
  const merchantId  = '12345'   // ← real merchant ID qo'ying
  const serviceId   = '67890'   // ← real service ID qo'ying
  const returnUrl   = encodeURIComponent('https://t.me/bulungur_bogcha_bot')
  return `https://my.click.uz/services/pay?service_id=${serviceId}&merchant_id=${merchantId}&amount=${amount}&transaction_param=${paymentId}&return_url=${returnUrl}`
}

function getPaymeUrl(paymentId, amount) {
  // Payme: base64(m=merchant_id;ac.order_id=xxx;a=amount_tiyin)
  const merchantId = 'your_payme_merchant_id'   // ← real merchant qo'ying
  const params     = `m=${merchantId};ac.payment_id=${paymentId};a=${amount * 100}`
  const encoded    = btoa(params)
  return `https://checkout.paycom.uz/${encoded}`
}

function getPaynetUrl(paymentId) {
  return `https://paynet.uz/processing/main?ORDER_ID=${paymentId}`
}

// ── To'lov kartochkasi ────────────────────────────────────
function PaymentCard({ enr, t }) {
  const [showLinks, setLinks] = useState(false)
  const amount = Number(enr.club_price || enr.amount || 0)
  const paid   = enr.is_paid || enr.paid

  return (
    <div style={{ background: '#fff', borderRadius: 16, padding: '16px 20px',
      marginBottom: 12, border: `1px solid ${paid ? '#86efac' : '#fca5a5'}` }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 8 }}>
        <div>
          <div style={{ fontWeight: 700, fontSize: 15 }}>{enr.club_name || enr.name}</div>
          <div style={{ fontSize: 11, color: 'var(--text-light)' }}>
            👶 {enr.child_name} · {enr.month}
          </div>
        </div>
        <span style={{
          background: paid ? '#dcfce7' : '#fee2e2',
          color: paid ? '#166534' : '#991b1b',
          borderRadius: 20, padding: '4px 12px', fontSize: 12, fontWeight: 700, flexShrink: 0,
        }}>
          {paid ? `✅ ${t('paid')}` : `❌ ${t('unpaid')}`}
        </span>
      </div>

      {/* Summa + ID */}
      <div style={{ display: 'flex', gap: 16, fontSize: 13, color: 'var(--text-mid)', marginBottom: paid ? 0 : 10 }}>
        <span>💰 {amount.toLocaleString()} so'm</span>
        <span>🆔 <code style={{ fontSize: 11 }}>{enr.payment_id}</code></span>
      </div>

      {/* To'lov tugmalari */}
      {!paid && (
        <>
          <button onClick={() => setLinks(v => !v)} style={{
            width: '100%', padding: '9px', borderRadius: 10,
            background: 'var(--primary-50)', color: 'var(--primary)',
            border: '1px solid var(--primary)', cursor: 'pointer', fontWeight: 700, fontSize: 13,
          }}>
            💳 {showLinks ? "Yopish" : "To'lash"}
          </button>

          {showLinks && (
            <div style={{ marginTop: 10, display: 'flex', flexDirection: 'column', gap: 8 }}>
              {[
                { label: '💙 Click orqali to\'lash',   color: '#0066cc', url: getClickUrl(enr.payment_id, amount) },
                { label: '💚 Payme orqali to\'lash',   color: '#00a86b', url: getPaymeUrl(enr.payment_id, amount) },
                { label: '🌐 Paynet orqali to\'lash',  color: '#f97316', url: getPaynetUrl(enr.payment_id) },
              ].map(({ label, color, url }) => (
                <a key={label} href={url} target="_blank" rel="noopener noreferrer"
                  style={{ display: 'block', padding: '10px 14px', borderRadius: 10,
                    background: color, color: '#fff', textDecoration: 'none',
                    fontWeight: 700, fontSize: 13, textAlign: 'center' }}>
                  {label}
                </a>
              ))}
              <div style={{ fontSize: 11, color: 'var(--text-light)', textAlign: 'center', marginTop: 4 }}>
                To'lov ID: <code>{enr.payment_id}</code> ni kiriting
              </div>
            </div>
          )}
        </>
      )}
    </div>
  )
}

// ── Tarix kartochkasi (to'langan) ────────────────────────
function HistoryCard({ payment }) {
  const paid_at = payment.paid_at
    ? new Date(payment.paid_at).toLocaleDateString('uz-UZ', { day:'2-digit', month:'short', year:'numeric' })
    : '—'

  return (
    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center',
      padding: '12px 0', borderBottom: '1px solid var(--border)' }}>
      <div>
        <div style={{ fontWeight: 600, fontSize: 14 }}>{payment.club_name || '—'}</div>
        <div style={{ fontSize: 12, color: 'var(--text-light)' }}>{payment.month} · {paid_at}</div>
      </div>
      <div style={{ textAlign: 'right' }}>
        <div style={{ fontWeight: 700, color: '#059669' }}>{Number(payment.amount || 0).toLocaleString()} so'm</div>
        <div style={{ fontSize: 11, color: '#16a34a' }}>✅ To'langan</div>
      </div>
    </div>
  )
}

export default function PaymentTab() {
  const { token, user } = useApp()
  const { t } = useTranslation()

  const [debts,   setDebts]   = useState([])
  const [history, setHistory] = useState([])
  const [summary, setSummary] = useState(null)
  const [loading, setLoading] = useState(true)
  const [tab,     setTab]     = useState('debts')   // 'debts' | 'history'

  const load = async () => {
    setLoading(true)
    try {
      const [debR, histR, sumR] = await Promise.all([
        fetch(API('/payments/my-debts'),   { headers: H(token) }),
        fetch(API('/payments/my-history'), { headers: H(token) }),
        fetch(API('/payments/my-summary'), { headers: H(token) }),
      ])
      const debD  = debR.ok  ? await debR.json()  : []
      const histD = histR.ok ? await histR.json() : []
      const sumD  = sumR.ok  ? await sumR.json()  : null

      setDebts(Array.isArray(debD)  ? debD  : debD.debts   || [])
      setHistory(Array.isArray(histD) ? histD : histD.history || [])
      setSummary(sumD)
    } catch(e) { console.error(e) }
    setLoading(false)
  }

  useEffect(() => { load() }, [token])

  const totalDebt = debts.reduce((s, d) => s + Number(d.club_price || d.amount || 0), 0)

  return (
    <>
      <style>{shimmer}</style>
      <div style={{ padding: '20px 16px' }}>
        <h2 style={{ margin: '0 0 16px', fontWeight: 800 }}>💰 {t('payment')}</h2>

        {/* Summary */}
        {loading ? (
          <div style={{ background: '#fff', borderRadius: 16, padding: 20, marginBottom: 16, border: '1px solid var(--border)' }}>
            <Skeleton h={24} w="40%" mb={12} /><Skeleton /><Skeleton w="70%" />
          </div>
        ) : (
          <div style={{ background: 'linear-gradient(135deg, var(--primary) 0%, #6366f1 100%)',
            borderRadius: 16, padding: '20px 24px', marginBottom: 16, color: '#fff' }}>
            <div style={{ fontSize: 13, opacity: 0.85 }}>Jami qarz</div>
            <div style={{ fontSize: 32, fontWeight: 900, margin: '4px 0 2px' }}>
              {totalDebt.toLocaleString()} <span style={{ fontSize: 16, opacity: 0.7 }}>so'm</span>
            </div>
            <div style={{ fontSize: 12, opacity: 0.75 }}>
              {debts.length} ta to'lanmagan · {history.length} ta to'langan
            </div>
          </div>
        )}

        {/* Tabs */}
        <div style={{ display: 'flex', gap: 8, marginBottom: 16 }}>
          {[
            { id: 'debts',   label: `❌ Qarzdorlik (${debts.length})` },
            { id: 'history', label: `✅ Tarix (${history.length})` },
          ].map(tb => (
            <button key={tb.id} onClick={() => setTab(tb.id)} style={{
              flex: 1, padding: '9px 12px', borderRadius: 12, border: 'none', cursor: 'pointer',
              fontWeight: 600, fontSize: 13,
              background: tab === tb.id ? 'var(--primary)' : 'var(--primary-50)',
              color:      tab === tb.id ? '#fff' : 'var(--primary)',
            }}>{tb.label}</button>
          ))}
        </div>

        {/* Qarzdorlik */}
        {tab === 'debts' && (
          <>
            {loading && [1,2].map(i => (
              <div key={i} style={{ background:'#fff', borderRadius:16, padding:16, marginBottom:12, border:'1px solid var(--border)' }}>
                <Skeleton w="60%" h={18} /><Skeleton w="40%" h={12} /><Skeleton h={38} r={10} />
              </div>
            ))}
            {!loading && debts.length === 0 && (
              <div style={{ textAlign: 'center', padding: '48px 20px' }}>
                <div style={{ fontSize: 56, marginBottom: 10 }}>🎉</div>
                <div style={{ fontWeight: 700, fontSize: 16 }}>Barcha to'lovlar amalga oshirilgan!</div>
                <div style={{ fontSize: 13, color: 'var(--text-light)', marginTop: 6 }}>
                  Hozirda qarzingiz yo'q.
                </div>
              </div>
            )}
            {!loading && debts.map((d, i) => <PaymentCard key={i} enr={d} t={t} />)}
          </>
        )}

        {/* Tarix */}
        {tab === 'history' && (
          <div style={{ background: '#fff', borderRadius: 16, padding: '4px 20px', border: '1px solid var(--border)' }}>
            {loading && [1,2,3].map(i => (
              <div key={i} style={{ padding: '12px 0', borderBottom: '1px solid var(--border)' }}>
                <Skeleton w="60%" h={16} /><Skeleton w="40%" h={12} />
              </div>
            ))}
            {!loading && history.length === 0 && (
              <div style={{ textAlign: 'center', padding: 32, color: 'var(--text-light)' }}>
                To'lov tarixi yo'q
              </div>
            )}
            {!loading && history.map((p, i) => <HistoryCard key={i} payment={p} />)}
          </div>
        )}

        {/* Yo'riqnoma */}
        <div style={{ background: '#fefce8', borderRadius: 14, padding: '14px 18px', marginTop: 20,
          border: '1px solid #fde68a', fontSize: 13 }}>
          <div style={{ fontWeight: 700, marginBottom: 6 }}>💡 To'lov yo'riqnomasi</div>
          <div style={{ color: 'var(--text-mid)', lineHeight: 1.6 }}>
            1. Qarzdorlik bo'limida to'lamoqchi bo'lgan to'garakni toping<br/>
            2. <b>"To'lash"</b> tugmasini bosing<br/>
            3. Qulay to'lov tizimini tanlang<br/>
            4. To'lov ID ni kiritib, miqdorni to'lang<br/>
            5. Tasdiqlangach, <b>bu sahifani yangilang</b>
          </div>
        </div>
      </div>
    </>
  )
}
