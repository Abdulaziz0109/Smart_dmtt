import { useState, lazy, Suspense } from 'react'

const MapGoogle = lazy(() => import('./MapGoogle'))
const MapYandex = lazy(() => import('./MapYandex'))

export default function MapTab() {
  const [active, setActive] = useState('google')

  return (
    <div style={{ height: '100dvh', display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>

      {/* Xarita */}
      <div style={{ flex: 1, minHeight: 0, position: 'relative' }}>
        <Suspense fallback={
          <div style={{ height: '100%', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
            <div style={{ width: 32, height: 32, border: '3px solid #E8F5F2', borderTopColor: '#0B5E50', borderRadius: '50%', animation: 'spin .7s linear infinite' }} />
            <style>{`@keyframes spin { to { transform: rotate(360deg) } }`}</style>
          </div>
        }>
          {active === 'google' ? <MapGoogle /> : <MapYandex />}
        </Suspense>
      </div>

      {/* Pastki tugmalar */}
      <div style={{
        display: 'flex', gap: 0,
        borderTop: '1px solid #e5e7eb',
        background: '#fff',
        flexShrink: 0,
        zIndex: 100,
      }}>
        <button
          onClick={() => setActive('google')}
          style={{
            flex: 1, padding: '12px 0',
            border: 'none', cursor: 'pointer',
            fontSize: 13, fontWeight: 700,
            borderBottom: active === 'google' ? '3px solid #0B5E50' : '3px solid transparent',
            color: active === 'google' ? '#0B5E50' : '#9ca3af',
            background: '#fff',
            transition: 'all .2s',
          }}
        >
          🌍 Google
        </button>
        <button
          onClick={() => setActive('yandex')}
          style={{
            flex: 1, padding: '12px 0',
            border: 'none', cursor: 'pointer',
            fontSize: 13, fontWeight: 700,
            borderBottom: active === 'yandex' ? '3px solid #FC3F1D' : '3px solid transparent',
            color: active === 'yandex' ? '#FC3F1D' : '#9ca3af',
            background: '#fff',
            transition: 'all .2s',
          }}
        >
          🗺 Yandex
        </button>
      </div>
    </div>
  )
}
