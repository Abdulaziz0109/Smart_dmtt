/**
 * SmartDMTT v4 — ClubsTab
 * To'garaklar ro'yxati + yozilish flow + filter
 */
import { useState, useEffect } from 'react'
import { useApp } from '../../context/AppContext'
import { useTranslation } from '../../hooks/useTranslation'

const API = (p) => `/api${p}`
const H   = (tk) => ({ Authorization: `Bearer ${tk}`, 'Content-Type': 'application/json', 'ngrok-skip-browser-warning': 'true' })

const shimmer = `@keyframes shimmer{0%{background-position:200% 0}100%{background-position:-200% 0}}`

function Skeleton({ w = '100%', h = 16, r = 8, mb = 8 }) {
  return <div style={{ width: w, height: h, borderRadius: r, marginBottom: mb,
    background: 'linear-gradient(90deg,#f0f0f0 25%,#e8e8e8 50%,#f0f0f0 75%)',
    backgroundSize: '200% 100%', animation: 'shimmer 1.4s infinite' }} />
}

// ── To'garak kartochkasi ─────────────────────────────────
function ClubCard({ club, onEnroll, enrolledIds, childrenCount }) {
  const enrolled = enrolledIds.has(club.id)
  const price    = Number(club.price || 0)

  const dayMap = { mon:'Du', tue:'Se', wed:'Ch', thu:'Pa', fri:'Ju', sat:'Sh', sun:'Ya' }
  const days   = (club.schedule_days || '').split(',').map(d => dayMap[d.trim()] || d.trim()).join(', ')

  return (
    <div style={{ background: '#fff', borderRadius: 16, padding: '18px 20px',
      marginBottom: 14, border: `1px solid ${enrolled ? '#86efac' : 'var(--border)'}`,
      boxShadow: enrolled ? '0 0 0 2px #86efac44' : 'none' }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 10 }}>
        <div style={{ flex: 1 }}>
          <div style={{ fontWeight: 800, fontSize: 15, marginBottom: 4 }}>{club.name}</div>
          {club.description && (
            <div style={{ fontSize: 12, color: 'var(--text-light)', marginBottom: 6 }}>{club.description}</div>
          )}
        </div>
        {enrolled && (
          <span style={{ background: '#dcfce7', color: '#166534', borderRadius: 20,
            padding: '3px 10px', fontSize: 11, fontWeight: 700, flexShrink: 0, marginLeft: 8 }}>
            ✅ Yozilgan
          </span>
        )}
      </div>

      {/* Ma'lumotlar */}
      <div style={{ display: 'flex', flexWrap: 'wrap', gap: 8, marginBottom: 12 }}>
        {[
          ['💰', price.toLocaleString() + " so'm/oy"],
          ['⏰', club.schedule_time || '—'],
          ['📅', days || '—'],
          ['👥', `${club.current_count || 0}/${club.capacity || '∞'} o'rin`],
        ].map(([icon, text]) => (
          <span key={text} style={{ background: '#f8fafc', borderRadius: 8, padding: '4px 10px', fontSize: 12, color: 'var(--text-mid)' }}>
            {icon} {text}
          </span>
        ))}
      </div>

      {/* Yozilish tugmasi */}
      {!enrolled && childrenCount > 0 && (
        <button onClick={() => onEnroll(club)} style={{
          width: '100%', padding: '10px', borderRadius: 12,
          background: 'var(--primary)', color: '#fff', border: 'none',
          cursor: 'pointer', fontWeight: 700, fontSize: 14,
        }}>
          📝 Yozilish
        </button>
      )}
      {!enrolled && childrenCount === 0 && (
        <div style={{ fontSize: 12, color: 'var(--text-light)', textAlign: 'center', padding: '8px 0' }}>
          Yozilish uchun farzand qo'shilishi kerak
        </div>
      )}
    </div>
  )
}

// ── Enroll modal ─────────────────────────────────────────
function EnrollModal({ club, children, onClose, onConfirm, saving }) {
  const [selectedChild, setChild] = useState(children[0]?.id || null)

  return (
    <div style={{ position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.5)',
      display: 'flex', alignItems: 'flex-end', justifyContent: 'center', zIndex: 1000 }}
      onClick={e => e.target === e.currentTarget && onClose()}>
      <div style={{ background: '#fff', borderRadius: '20px 20px 0 0', padding: 24,
        width: '100%', maxWidth: 480, maxHeight: '70vh', overflowY: 'auto' }}>
        <div style={{ fontWeight: 800, fontSize: 17, marginBottom: 4 }}>📝 Yozilish</div>
        <div style={{ color: 'var(--text-light)', fontSize: 13, marginBottom: 20 }}>{club.name}</div>

        <div style={{ fontWeight: 600, marginBottom: 10, fontSize: 14 }}>Farzand tanlang:</div>
        {children.map(c => (
          <div key={c.id} onClick={() => setChild(c.id)}
            style={{ display: 'flex', alignItems: 'center', gap: 12, padding: '12px 16px',
              borderRadius: 12, marginBottom: 8, cursor: 'pointer',
              border: `2px solid ${selectedChild === c.id ? 'var(--primary)' : 'var(--border)'}`,
              background: selectedChild === c.id ? 'var(--primary-50)' : '#fff' }}>
            <div style={{ width: 36, height: 36, borderRadius: '50%', background: 'var(--primary-50)',
              display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 18 }}>👶</div>
            <div>
              <div style={{ fontWeight: 700 }}>{c.full_name}</div>
              <div style={{ fontSize: 12, color: 'var(--text-light)' }}>{c.birth_year}-yil</div>
            </div>
          </div>
        ))}

        <div style={{ background: '#fefce8', borderRadius: 10, padding: '12px 14px', marginTop: 4, marginBottom: 16, fontSize: 13 }}>
          💡 <b>To'lov:</b> {Number(club.price || 0).toLocaleString()} so'm/oy<br/>
          Yozilgandan so'ng Click/Payme/Paynet orqali to'lang.
        </div>

        <div style={{ display: 'flex', gap: 10 }}>
          <button onClick={onClose} style={{ flex: 1, padding: 12, borderRadius: 12,
            background: '#f1f5f9', border: 'none', cursor: 'pointer', fontWeight: 600, fontSize: 14 }}>
            Bekor
          </button>
          <button onClick={() => onConfirm(selectedChild)}
            disabled={!selectedChild || saving}
            style={{ flex: 2, padding: 12, borderRadius: 12, background: 'var(--primary)',
              color: '#fff', border: 'none', cursor: 'pointer', fontWeight: 700, fontSize: 14,
              opacity: saving ? 0.6 : 1 }}>
            {saving ? '⏳ Yuklanmoqda...' : '✅ Tasdiqlash'}
          </button>
        </div>
      </div>
    </div>
  )
}

export default function ClubsTab() {
  const { token, user } = useApp()
  const { t } = useTranslation()

  const [clubs,      setClubs]    = useState([])
  const [children,   setChildren] = useState([])
  const [enrolledIds,setEnrIds]   = useState(new Set())
  const [loading,    setLoading]  = useState(true)
  const [search,     setSearch]   = useState('')
  const [modal,      setModal]    = useState(null)   // club obj
  const [saving,     setSaving]   = useState(false)
  const [msg,        setMsg]      = useState(null)

  const flash = (text, ok = true) => { setMsg({ text, ok }); setTimeout(() => setMsg(null), 3500) }

  const load = async () => {
    setLoading(true)
    try {
      const [clubR, childR, enrR] = await Promise.all([
        fetch(API('/clubs'),              { headers: H(token) }),
        fetch(API('/children/mine'),      { headers: H(token) }),
        fetch(API('/clubs/my-enrollments'),{ headers: H(token) }),
      ])
      const clubD = clubR.ok ? await clubR.json() : []
      const childD = childR.ok ? await childR.json() : []
      const enrD   = enrR.ok  ? await enrR.json()  : []

      setClubs(Array.isArray(clubD)  ? clubD  : clubD.clubs     || [])
      setChildren(Array.isArray(childD) ? childD : childD.children || [])

      const ids = new Set((Array.isArray(enrD) ? enrD : enrD.enrollments || []).map(e => e.club_id))
      setEnrIds(ids)
    } catch(e) { flash(t('error') + ': ' + e.message, false) }
    setLoading(false)
  }

  useEffect(() => { load() }, [token])

  const handleEnroll = async (childId) => {
    if (!modal || !childId) return
    setSaving(true)
    try {
      const r = await fetch(API('/clubs/enroll'), {
        method: 'POST', headers: H(token),
        body: JSON.stringify({ club_id: modal.id, child_id: childId }),
      })
      const d = await r.json()
      if (!r.ok) throw new Error(d.detail || 'Xatolik')
      flash(`✅ ${modal.name} ga yozildi! To'lov ID: ${d.payment_id}`)
      setModal(null)
      load()
    } catch(e) { flash('❌ ' + e.message, false) }
    setSaving(false)
  }

  const filtered = clubs.filter(c =>
    !search || c.name?.toLowerCase().includes(search.toLowerCase()) ||
    c.description?.toLowerCase().includes(search.toLowerCase())
  )

  const role    = user?.role || 'guest'
  const isParent = role === 'parent'

  return (
    <>
      <style>{shimmer}</style>
      <div style={{ padding: '20px 16px' }}>
        <h2 style={{ margin: '0 0 16px', fontWeight: 800 }}>🎯 {t('nav_clubs')}</h2>

        {msg && (
          <div style={{ padding: '10px 16px', borderRadius: 12, marginBottom: 14,
            background: msg.ok ? '#dcfce7' : '#fee2e2', color: msg.ok ? '#166534' : '#991b1b', fontWeight: 600 }}>
            {msg.text}
          </div>
        )}

        {/* Qidirish */}
        <input style={{ width: '100%', padding: '10px 14px', borderRadius: 12,
          border: '1px solid var(--border)', fontSize: 14, outline: 'none',
          marginBottom: 16, boxSizing: 'border-box' }}
          placeholder="🔍 To'garak qidirish..."
          value={search} onChange={e => setSearch(e.target.value)} />

        {/* Skeleton */}
        {loading && [1,2,3].map(i => (
          <div key={i} style={{ background: '#fff', borderRadius: 16, padding: 20, marginBottom: 14, border: '1px solid var(--border)' }}>
            <Skeleton w="70%" h={18} /><Skeleton w="50%" h={12} /><Skeleton h={36} r={12} />
          </div>
        ))}

        {/* Bo'sh holat */}
        {!loading && filtered.length === 0 && (
          <div style={{ textAlign: 'center', padding: '60px 20px' }}>
            <div style={{ fontSize: 64, marginBottom: 12 }}>🎯</div>
            <div style={{ fontSize: 16, fontWeight: 700 }}>
              {search ? 'Natija topilmadi' : "To'garaklar yo'q"}
            </div>
          </div>
        )}

        {/* Ro'yxat */}
        {!loading && filtered.map(club => (
          <ClubCard key={club.id} club={club} enrolledIds={enrolledIds}
            childrenCount={children.length}
            onEnroll={isParent ? setModal : null} />
        ))}
      </div>

      {/* Yozilish modali */}
      {modal && (
        <EnrollModal club={modal} children={children}
          saving={saving}
          onClose={() => setModal(null)}
          onConfirm={handleEnroll} />
      )}
    </>
  )
}
