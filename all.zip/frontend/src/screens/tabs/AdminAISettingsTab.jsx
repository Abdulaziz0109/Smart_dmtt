/**
 * AdminAISettingsTab — AI model sozlamalari (admin)
 */
import { useState, useEffect } from 'react'
import { useApp } from '../../context/AppContext'

const HELPER_MODELS = [
  { v:'gpt-4o-mini',   l:'GPT-4o-mini',   price:'$0.15/1M', desc:'Tezkor, arzon, tavsiya etiladi' },
  { v:'gemini-flash',  l:'Gemini Flash',   price:'$0.075/1M', desc:'Eng arzon variant' },
  { v:'claude-haiku',  l:'Claude Haiku',   price:'$0.80/1M', desc:'Sifatli, lekin qimmatroq' },
]
const USER_MODELS = [
  { v:'gemini-flash',  l:'Gemini Flash',  price:'$0.075/1M', desc:'Eng arzon, tavsiya etiladi' },
  { v:'gpt-4o-mini',  l:'GPT-4o-mini',   price:'$0.15/1M', desc:'Yaxshi sifat' },
]

function RadioCard({ item, selected, onSelect }) {
  const active = selected === item.v
  return (
    <div onClick={() => onSelect(item.v)} style={{ display:'flex', alignItems:'center', gap:12, padding:'12px 14px', borderRadius:12, border: `2px solid ${active ? '#0B5E50' : '#E2EBF0'}`, background: active ? '#F0FAF7' : '#fff', cursor:'pointer', marginBottom:8, transition:'all 0.15s' }}>
      <div style={{ width:18, height:18, borderRadius:'50%', border:`2px solid ${active ? '#0B5E50' : '#C4D0D8'}`, display:'flex', alignItems:'center', justifyContent:'center', flexShrink:0 }}>
        {active && <div style={{ width:9, height:9, borderRadius:'50%', background:'#0B5E50' }} />}
      </div>
      <div style={{ flex:1 }}>
        <div style={{ fontSize:14, fontWeight:800, color: active ? '#0B5E50' : '#1A2E3B' }}>{item.l}</div>
        <div style={{ fontSize:11, color:'#8A9BAB', marginTop:1 }}>{item.desc}</div>
      </div>
      <span style={{ fontSize:11, fontWeight:700, padding:'3px 8px', borderRadius:8, background:'#F0F4F8', color:'#4A6070' }}>{item.price}</span>
    </div>
  )
}

export default function AdminAISettingsTab() {
  const { token } = useApp()
  const [helperModel, setHelperModel] = useState('gpt-4o-mini')
  const [userModel, setUserModel]     = useState('gemini-flash')
  const [loading, setLoading]         = useState(true)
  const [saving, setSaving]           = useState(false)
  const [msg, setMsg]                 = useState('')

  const h = { Authorization:`Bearer ${token}`, 'Content-Type':'application/json', 'ngrok-skip-browser-warning':'true' }

  useEffect(() => {
    fetch('/api/admin/ai-settings', { headers: h })
      .then(r => r.json())
      .then(d => { setHelperModel(d.helper_model || 'gpt-4o-mini'); setUserModel(d.user_text_model || 'gemini-flash') })
      .catch(() => {})
      .finally(() => setLoading(false))
  }, [])

  const save = async () => {
    setSaving(true); setMsg('')
    try {
      const r = await fetch('/api/admin/ai-settings', {
        method:'POST', headers: h,
        body: JSON.stringify({ helper_model: helperModel, user_text_model: userModel })
      })
      if (r.ok) setMsg('Saqlandi ✅')
      else { const d = await r.json(); setMsg(d.detail || 'Xatolik') }
    } catch { setMsg('Tarmoq xatosi') } finally { setSaving(false) }
  }

  if (loading) return <div style={{ textAlign:'center', padding:60, color:'#8A9BAB', fontFamily:'var(--font)' }}>Yuklanmoqda...</div>

  return (
    <div style={{ padding:'16px 12px', fontFamily:'var(--font)' }}>
      <div style={{ fontSize:20, fontWeight:900, color:'#0B5E50', marginBottom:4 }}>AI Sozlamalari</div>
      <div style={{ fontSize:12, color:'#8A9BAB', marginBottom:20 }}>Foydalanuvchi va yordamchi AI modellari</div>

      <div style={{ background:'#FEF3C7', borderRadius:12, padding:'10px 14px', marginBottom:20, fontSize:12, color:'#92400E' }}>
        💡 <strong>Eslatma:</strong> Yordamchi AI ota-onalar savollariga javob beradi. Foydalanuvchi matni modeli infografika va xabarlarda ishlatiladi.
      </div>

      <div style={{ background:'#fff', borderRadius:16, padding:16, border:'1.5px solid #E2EBF0', marginBottom:16 }}>
        <div style={{ fontSize:14, fontWeight:800, marginBottom:12, color:'#1A2E3B' }}>🤖 Yordamchi AI modeli</div>
        <div style={{ fontSize:11, color:'#8A9BAB', marginBottom:10 }}>Ota-onalar savollari, bilimlar bazasi qidirish</div>
        {HELPER_MODELS.map(m => <RadioCard key={m.v} item={m} selected={helperModel} onSelect={setHelperModel} />)}
      </div>

      <div style={{ background:'#fff', borderRadius:16, padding:16, border:'1.5px solid #E2EBF0', marginBottom:20 }}>
        <div style={{ fontSize:14, fontWeight:800, marginBottom:12, color:'#1A2E3B' }}>💬 Foydalanuvchi matni modeli</div>
        <div style={{ fontSize:11, color:'#8A9BAB', marginBottom:10 }}>Infografika matni, haftalik xabarlar, tavsiyalar</div>
        {USER_MODELS.map(m => <RadioCard key={m.v} item={m} selected={userModel} onSelect={setUserModel} />)}
      </div>

      {msg && (
        <div style={{ padding:'10px 14px', borderRadius:10, background: msg.includes('✅') ? '#ECFDF5' : '#FEF2F2', color: msg.includes('✅') ? '#10B981' : '#EF4444', fontSize:13, fontWeight:700, marginBottom:12 }}>
          {msg}
        </div>
      )}

      <button onClick={save} disabled={saving} style={{ width:'100%', padding:14, borderRadius:12, border:'none', background:'#0B5E50', color:'#fff', fontWeight:800, fontSize:15, cursor:'pointer', opacity: saving ? 0.7 : 1 }}>
        {saving ? 'Saqlanmoqda...' : 'Saqlash'}
      </button>
    </div>
  )
}
