/**
 * ChildProfileTab — Bola profili (ota-ona)
 */
import { useState, useEffect } from 'react'
import { useApp } from '../../context/AppContext'

function Card({ children, style }) {
  return <div style={{ background:'#fff', borderRadius:16, padding:16, border:'1.5px solid #E2EBF0', boxShadow:'0 2px 8px rgba(10,50,80,0.06)', ...style }}>{children}</div>
}

function ScoreBar({ label, value }) {
  if (!value) return null
  const pct = (value / 5) * 100
  const color = value >= 4 ? '#10B981' : value >= 3 ? '#F59E0B' : '#EF4444'
  return (
    <div style={{ marginBottom:10 }}>
      <div style={{ display:'flex', justifyContent:'space-between', marginBottom:4 }}>
        <span style={{ fontSize:12, color:'#4A6070' }}>{label}</span>
        <span style={{ fontSize:12, fontWeight:800, color }}>{value}/5</span>
      </div>
      <div style={{ height:6, background:'#F0F4F8', borderRadius:3 }}>
        <div style={{ width:`${pct}%`, height:'100%', borderRadius:3, background: color, transition:'width 0.4s' }} />
      </div>
    </div>
  )
}

export default function ChildProfileTab() {
  const { token, user } = useApp()
  const [children, setChildren] = useState([])
  const [selected, setSelected] = useState(null)
  const [obs, setObs]           = useState([])
  const [loading, setLoading]   = useState(true)
  const [obsLoading, setObsLoading] = useState(false)

  const h = { Authorization:`Bearer ${token}`, 'ngrok-skip-browser-warning':'true' }

  useEffect(() => {
    fetch('/api/children', { headers: h })
      .then(r => r.json())
      .then(d => {
        const list = d.children || []
        setChildren(list)
        if (list.length === 1) selectChild(list[0])
      })
      .finally(() => setLoading(false))
  }, [])

  const selectChild = async (child) => {
    setSelected(child)
    setObsLoading(true)
    try {
      // enrollment ID larni olib, kuzatuvlarni yuklaymiz
      const attRes = await fetch(`/api/children/${child.id}/attendance?weeks=12`, { headers: h })
      const attData = await attRes.json()

      // Observation uchun enrollment ID kerak
      const enrRes = await fetch(`/api/children/${child.id}`, { headers: h })
      const enrData = await enrRes.json()
      const enrIds = (enrData.enrollments || []).map(e => e.enrollment_id)

      if (enrIds.length > 0) {
        const obsRes = await fetch(`/api/observations?enrollment_id=${enrIds[0]}`, { headers: h })
        const obsData = await obsRes.json()
        setObs(obsData.observations || [])
      } else {
        setObs([])
      }
    } catch { setObs([]) } finally { setObsLoading(false) }
  }

  // Kuzatuvlardan o'rtacha hisoblash
  const avgScores = (key) => {
    const vals = obs.map(o => o[key]).filter(v => v != null)
    if (!vals.length) return null
    return (vals.reduce((a, b) => a + b, 0) / vals.length).toFixed(1)
  }

  const flagCount = (key) => obs.filter(o => o[key]).length

  if (loading) return <div style={{ textAlign:'center', padding:60, color:'#8A9BAB', fontFamily:'var(--font)' }}>Yuklanmoqda...</div>

  return (
    <div style={{ padding:'16px 12px', fontFamily:'var(--font)' }}>
      <div style={{ fontSize:20, fontWeight:900, color:'#0B5E50', marginBottom:4 }}>Bola Profili</div>
      <div style={{ fontSize:12, color:'#8A9BAB', marginBottom:16 }}>Rivojlanish kuzatuvi va tavsiyalar</div>

      {/* Farzand tanlash */}
      {children.length > 1 && (
        <div style={{ display:'flex', gap:8, marginBottom:16, overflowX:'auto', paddingBottom:4 }}>
          {children.map(c => (
            <button key={c.id} onClick={() => selectChild(c)} style={{ padding:'8px 16px', borderRadius:20, border:'none', cursor:'pointer', fontWeight:700, fontSize:13, background: selected?.id === c.id ? '#0B5E50' : '#F0F4F8', color: selected?.id === c.id ? '#fff' : '#4A6070', whiteSpace:'nowrap', transition:'all 0.15s' }}>
              {c.full_name}
            </button>
          ))}
        </div>
      )}

      {!selected ? (
        <Card style={{ textAlign:'center', padding:32 }}>
          <div style={{ fontSize:32, marginBottom:8 }}>👦</div>
          <div style={{ color:'#8A9BAB', fontSize:14 }}>Farzandni tanlang</div>
        </Card>
      ) : obsLoading ? (
        <div style={{ textAlign:'center', padding:40, color:'#8A9BAB' }}>Ma'lumotlar yuklanmoqda...</div>
      ) : (
        <>
          {/* Bola kartasi */}
          <Card style={{ marginBottom:14 }}>
            <div style={{ display:'flex', alignItems:'center', gap:12 }}>
              <div style={{ width:52, height:52, borderRadius:'50%', background:'#E8F5F2', display:'flex', alignItems:'center', justifyContent:'center', fontSize:26 }}>👦</div>
              <div>
                <div style={{ fontSize:17, fontWeight:900 }}>{selected.full_name}</div>
                <div style={{ fontSize:12, color:'#8A9BAB' }}>{selected.birth_year ? `${new Date().getFullYear() - selected.birth_year} yosh` : ''}</div>
                <div style={{ fontSize:12, color:'#0B5E50', marginTop:2 }}>{(selected.active_clubs || []).length} ta to'garakda</div>
              </div>
            </div>
          </Card>

          {obs.length === 0 ? (
            <Card style={{ textAlign:'center', padding:32 }}>
              <div style={{ fontSize:32, marginBottom:8 }}>📊</div>
              <div style={{ color:'#8A9BAB', fontSize:14 }}>Kuzatuv ma'lumotlari yo'q</div>
              <div style={{ color:'#B0BEC5', fontSize:12, marginTop:4 }}>Muallim kuzatuvlar kiritganda bu yerda ko'rinadi</div>
            </Card>
          ) : (
            <>
              {/* O'rtacha ko'rsatkichlar */}
              <Card style={{ marginBottom:14 }}>
                <div style={{ fontSize:14, fontWeight:800, marginBottom:14 }}>📈 O'rtacha ko'rsatkichlar ({obs.length} ta kuzatuv)</div>
                <ScoreBar label="Faollik"      value={parseFloat(avgScores('energy'))}     />
                <ScoreBar label="Diqqat"       value={parseFloat(avgScores('focus'))}      />
                <ScoreBar label="Ijodiylik"    value={parseFloat(avgScores('creativity'))} />
                <ScoreBar label="Muloqot"      value={parseFloat(avgScores('social'))}     />
              </Card>

              {/* Ijobiy belgilar */}
              <Card style={{ marginBottom:14 }}>
                <div style={{ fontSize:14, fontWeight:800, marginBottom:12 }}>⭐ Kuchli tomonlar</div>
                {[
                  ['asked_question',  'Savol berdi',      '❓'],
                  ['made_discovery',  'Kashfiyot qildi',  '💡'],
                  ['helped_others',   'Boshqalarga yordam','🤝'],
                  ['completed_task',  'Vazifa bajardi',   '✅'],
                  ['struggled',       'Qiynaldi',         '😓'],
                ].map(([key, label, icon]) => (
                  <div key={key} style={{ display:'flex', justifyContent:'space-between', alignItems:'center', padding:'7px 0', borderBottom:'1px solid #F0F4F8' }}>
                    <span style={{ fontSize:13 }}>{icon} {label}</span>
                    <span style={{ fontSize:13, fontWeight:800, color: key === 'struggled' ? '#EF4444' : '#0B5E50' }}>{flagCount(key)} marta</span>
                  </div>
                ))}
              </Card>

              {/* So'nggi kuzatuvlar */}
              <div style={{ fontSize:14, fontWeight:800, marginBottom:10 }}>So'nggi kuzatuvlar</div>
              {obs.slice(0, 5).map(o => (
                <Card key={o.id} style={{ marginBottom:8 }}>
                  <div style={{ fontSize:12, color:'#8A9BAB', marginBottom:6 }}>{o.date}</div>
                  <div style={{ display:'flex', gap:8, flexWrap:'wrap' }}>
                    {[['⚡', o.energy], ['🎯', o.focus], ['🎨', o.creativity], ['💬', o.social]].filter(([, v]) => v).map(([icon, v], i) => (
                      <span key={i} style={{ fontSize:12, padding:'3px 8px', borderRadius:8, background:'#F0FAF7', color:'#0B5E50', fontWeight:700 }}>{icon} {v}/5</span>
                    ))}
                    {o.asked_question && <span style={{ fontSize:12, padding:'3px 8px', borderRadius:8, background:'#EFF6FF', color:'#3B82F6' }}>❓ Savol</span>}
                    {o.helped_others  && <span style={{ fontSize:12, padding:'3px 8px', borderRadius:8, background:'#F0FDF4', color:'#10B981' }}>🤝 Yordam</span>}
                    {o.completed_task && <span style={{ fontSize:12, padding:'3px 8px', borderRadius:8, background:'#F0FAF7', color:'#0B5E50' }}>✅ Bajardi</span>}
                  </div>
                </Card>
              ))}
            </>
          )}
        </>
      )}
    </div>
  )
}
