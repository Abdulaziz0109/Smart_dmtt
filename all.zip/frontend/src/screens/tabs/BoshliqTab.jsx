/**
 * SmartDMTT v4 — BoshliqTab
 * Anomaliyalar, broadcast, infographic, tuman statistikasi
 */
import { useState, useEffect } from 'react'
import { useApp } from '../../context/AppContext'
import { useTranslation } from '../../hooks/useTranslation'

const API = (p) => `/api${p}`
const H   = (tk) => ({ Authorization: `Bearer ${tk}`, 'Content-Type': 'application/json', 'ngrok-skip-browser-warning': 'true' })

const shimmer = `@keyframes shimmer{0%{background-position:200% 0}100%{background-position:-200% 0}}`

function Skeleton({ w='100%', h=16, r=8, mb=8 }) {
  return <div style={{ width:w, height:h, borderRadius:r, marginBottom:mb,
    background:'linear-gradient(90deg,#f0f0f0 25%,#e8e8e8 50%,#f0f0f0 75%)',
    backgroundSize:'200% 100%', animation:'shimmer 1.4s infinite' }} />
}

// ── Anomaliya kartochkasi ─────────────────────────────────
function AnomalyCard({ item }) {
  const severity = item.severity || 'medium'
  const cfg = {
    high:   { bg: '#fee2e2', color: '#991b1b', icon: '🔴', border: '#fca5a5' },
    medium: { bg: '#fef9c3', color: '#854d0e', icon: '🟡', border: '#fde68a' },
    low:    { bg: '#dbeafe', color: '#1e40af', icon: '🔵', border: '#93c5fd' },
  }[severity] || { bg: '#f3f4f6', color: '#374151', icon: '⚪', border: '#d1d5db' }

  return (
    <div style={{ background: cfg.bg, borderRadius: 12, padding: '12px 16px',
      marginBottom: 10, border: `1px solid ${cfg.border}` }}>
      <div style={{ display: 'flex', gap: 10, alignItems: 'flex-start' }}>
        <span style={{ fontSize: 18, flexShrink: 0 }}>{cfg.icon}</span>
        <div style={{ flex: 1 }}>
          <div style={{ fontWeight: 700, fontSize: 14, color: cfg.color, marginBottom: 4 }}>
            {item.title || item.message}
          </div>
          {item.description && (
            <div style={{ fontSize: 12, color: cfg.color, opacity: 0.8 }}>{item.description}</div>
          )}
          {item.kindergarten_name && (
            <div style={{ fontSize: 11, color: cfg.color, opacity: 0.7, marginTop: 4 }}>
              🏫 {item.kindergarten_name}
            </div>
          )}
        </div>
        <span style={{ fontSize: 11, color: cfg.color, opacity: 0.6, flexShrink: 0 }}>
          {item.created_at ? new Date(item.created_at).toLocaleDateString('uz-UZ') : ''}
        </span>
      </div>
    </div>
  )
}

// ── Broadcast panel ───────────────────────────────────────
function BroadcastPanel({ token, flash }) {
  const [text,    setText]    = useState('')
  const [target,  setTarget]  = useState('all')
  const [sending, setSending] = useState(false)
  const [result,  setResult]  = useState(null)

  const send = async () => {
    if (!text.trim()) return
    setSending(true)
    setResult(null)
    try {
      const r = await fetch(API('/admin/broadcast'), {
        method: 'POST', headers: H(token),
        body: JSON.stringify({ text, target }),
      })
      const d = await r.json()
      if (!r.ok) throw new Error(d.detail)
      setResult(d)
      setText('')
      flash(`✅ ${d.sent} ta foydalanuvchiga yuborildi`)
    } catch(e) { flash('❌ ' + e.message, false) }
    setSending(false)
  }

  return (
    <div style={{ background: '#fff', borderRadius: 16, padding: 20, border: '1px solid var(--border)' }}>
      <div style={{ fontWeight: 700, marginBottom: 14, fontSize: 15 }}>📢 Ommaviy xabar</div>

      <div style={{ display: 'flex', gap: 8, marginBottom: 12 }}>
        {[
          ['all',      '🌐 Hammaga'],
          ['parents',  '👨‍👩‍👧 Ota-onalar'],
          ['teachers', '👨‍🏫 Xodimlar'],
        ].map(([val, label]) => (
          <button key={val} onClick={() => setTarget(val)} style={{
            flex: 1, padding: '8px 4px', borderRadius: 10, border: 'none', cursor: 'pointer',
            fontWeight: 600, fontSize: 12,
            background: target === val ? '#6366f1' : '#f1f5f9',
            color: target === val ? '#fff' : '#6b7280',
          }}>{label}</button>
        ))}
      </div>

      <textarea
        value={text}
        onChange={e => setText(e.target.value)}
        placeholder="Xabar matnini yozing..."
        rows={4}
        style={{ width: '100%', padding: '12px 14px', borderRadius: 12,
          border: '1px solid var(--border)', fontSize: 14, outline: 'none',
          resize: 'vertical', boxSizing: 'border-box', marginBottom: 10,
          fontFamily: 'inherit' }}
      />

      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <span style={{ fontSize: 12, color: 'var(--text-light)' }}>{text.length} belgi</span>
        <button onClick={send} disabled={sending || !text.trim()} style={{
          padding: '10px 24px', borderRadius: 12, border: 'none', cursor: 'pointer',
          fontWeight: 700, fontSize: 14,
          background: sending || !text.trim() ? '#a5b4fc' : '#6366f1',
          color: '#fff',
        }}>
          {sending ? '⏳ Yuborilmoqda...' : '📤 Yuborish'}
        </button>
      </div>
    </div>
  )
}

// ── Tuman statistikasi ────────────────────────────────────
function TumanStats({ data, loading }) {
  if (loading) return (
    <div style={{ background:'#fff', borderRadius:16, padding:20, border:'1px solid var(--border)' }}>
      <Skeleton w="40%" h={18} mb={16} />
      {[1,2,3].map(i => <Skeleton key={i} />)}
    </div>
  )
  if (!data) return null

  const stats = [
    { icon:'🏫', label:'Bog\'chalar',       value: data.total_kindergartens ?? '—' },
    { icon:'👶', label:'Jami bolalar',       value: data.total_children      ?? '—' },
    { icon:'🎯', label:"To'garaklar",        value: data.total_clubs          ?? '—' },
    { icon:'✅', label:'Davomat (bugun)',    value: (data.attendance_today ?? 0) + '%' },
    { icon:'💰', label:'Oylik daromad',      value: (data.monthly_revenue ?? 0).toLocaleString() + " so'm" },
    { icon:'❌', label:'Qarzdorlar',         value: data.debtors             ?? '—' },
    { icon:'👥', label:'Foydalanuvchilar',   value: data.total_users          ?? '—' },
    { icon:'📝', label:'Yozilishlar',        value: data.active_enrollments   ?? '—' },
  ]

  return (
    <div style={{ background:'#fff', borderRadius:16, padding:20, border:'1px solid var(--border)' }}>
      <div style={{ fontWeight:700, marginBottom:14, fontSize:15 }}>📊 Tuman ko'rsatkichlari</div>
      <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:10 }}>
        {stats.map(s => (
          <div key={s.label} style={{ background:'#f8fafc', borderRadius:12, padding:'12px 14px' }}>
            <div style={{ fontSize:20 }}>{s.icon}</div>
            <div style={{ fontWeight:800, fontSize:18, margin:'4px 0 2px' }}>{s.value}</div>
            <div style={{ fontSize:11, color:'var(--text-light)' }}>{s.label}</div>
          </div>
        ))}
      </div>
    </div>
  )
}

// ── Bog'chalar reytingi ───────────────────────────────────
function KgRating({ data, loading }) {
  if (loading) return (
    <div style={{ background:'#fff', borderRadius:16, padding:20, border:'1px solid var(--border)' }}>
      <Skeleton w="50%" h={18} mb={14} />
      {[1,2,3].map(i => <Skeleton key={i} h={44} r={10} />)}
    </div>
  )
  if (!data?.kindergartens?.length) return null

  const sorted = [...data.kindergartens].sort((a,b) => (b.attendance_pct||0) - (a.attendance_pct||0))

  return (
    <div style={{ background:'#fff', borderRadius:16, padding:20, border:'1px solid var(--border)' }}>
      <div style={{ fontWeight:700, marginBottom:14, fontSize:15 }}>🏆 Bog'chalar reytingi</div>
      {sorted.map((kg, i) => {
        const pct = kg.attendance_pct || 0
        const medal = i===0?'🥇':i===1?'🥈':i===2?'🥉':'  '
        return (
          <div key={kg.id} style={{ padding:'10px 0', borderBottom: i<sorted.length-1?'1px solid var(--border)':'none' }}>
            <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:6 }}>
              <span style={{ fontWeight:700, fontSize:13 }}>{medal} {kg.name}</span>
              <span style={{ fontSize:13, fontWeight:700,
                color: pct>=80?'#059669':pct>=60?'#d97706':'#ef4444' }}>{pct}%</span>
            </div>
            <div style={{ display:'flex', gap:2 }}>
              {Array.from({length:10}).map((_,j) => (
                <div key={j} style={{ flex:1, height:5, borderRadius:2,
                  background: j < Math.round(pct/10)
                    ? (pct>=80?'#22c55e':pct>=60?'#f59e0b':'#ef4444') : '#e5e7eb' }} />
              ))}
            </div>
          </div>
        )
      })}
    </div>
  )
}

// ── Main BoshliqTab ───────────────────────────────────────
const SUB_TABS = [
  { id:'stats',     label:'📊 Statistika' },
  { id:'anomalies', label:'⚠️ Anomaliyalar' },
  { id:'broadcast', label:'📢 E\'lon' },
]

export default function BoshliqTab() {
  const { token, user } = useApp()
  const { t } = useTranslation()

  const [sub,        setSub]       = useState('stats')
  const [stats,      setStats]     = useState(null)
  const [anomalies,  setAnomalies] = useState([])
  const [loadStats,  setLoadStats] = useState(true)
  const [loadAnom,   setLoadAnom]  = useState(true)
  const [msg,        setMsg]       = useState(null)

  const flash = (text, ok=true) => { setMsg({text,ok}); setTimeout(()=>setMsg(null), 3500) }

  useEffect(() => {
    fetch(API('/analytics/summary'), { headers: H(token) })
      .then(r => r.json()).then(setStats).finally(() => setLoadStats(false))

    fetch(API('/analytics/anomalies?limit=20'), { headers: H(token) })
      .then(r => r.json())
      .then(d => setAnomalies(Array.isArray(d) ? d : d.anomalies || []))
      .finally(() => setLoadAnom(false))
  }, [token])

  const highCount = anomalies.filter(a => a.severity === 'high').length

  return (
    <>
      <style>{shimmer}</style>
      <div style={{ padding:'20px 16px' }}>
        <div style={{ marginBottom:20 }}>
          <h2 style={{ margin:0, fontWeight:800, fontSize:20 }}>
            {user?.role === 'boshliq' ? '👨‍💼 Boshliq paneli' : '🏛️ MMTB paneli'}
          </h2>
          <p style={{ margin:'4px 0 0', fontSize:13, color:'var(--text-light)' }}>
            {new Date().toLocaleDateString('uz-UZ', {weekday:'long', day:'numeric', month:'long'})}
          </p>
        </div>

        {msg && (
          <div style={{ padding:'10px 16px', borderRadius:12, marginBottom:14,
            background: msg.ok?'#dcfce7':'#fee2e2', color: msg.ok?'#166534':'#991b1b', fontWeight:600 }}>
            {msg.text}
          </div>
        )}

        {/* Sub tabs */}
        <div style={{ display:'flex', gap:8, marginBottom:20, overflowX:'auto', paddingBottom:4 }}>
          {SUB_TABS.map(tb => (
            <button key={tb.id} onClick={() => setSub(tb.id)} style={{
              padding:'9px 16px', borderRadius:20, border:'none', cursor:'pointer',
              fontWeight:600, fontSize:13, whiteSpace:'nowrap',
              background: sub===tb.id ? '#6366f1' : '#f1f5f9',
              color: sub===tb.id ? '#fff' : '#6b7280',
              position:'relative',
            }}>
              {tb.label}
              {tb.id==='anomalies' && highCount>0 && (
                <span style={{ position:'absolute', top:-6, right:-6,
                  background:'#ef4444', color:'#fff', borderRadius:'50%',
                  width:18, height:18, fontSize:10, fontWeight:900,
                  display:'flex', alignItems:'center', justifyContent:'center' }}>
                  {highCount}
                </span>
              )}
            </button>
          ))}
        </div>

        {/* Statistika */}
        {sub==='stats' && (
          <div style={{ display:'flex', flexDirection:'column', gap:16 }}>
            <TumanStats data={stats} loading={loadStats} />
            <KgRating data={stats} loading={loadStats} />
          </div>
        )}

        {/* Anomaliyalar */}
        {sub==='anomalies' && (
          <div>
            {loadAnom ? (
              [1,2,3].map(i => <div key={i} style={{ background:'#fff', borderRadius:12, padding:14, marginBottom:10, border:'1px solid var(--border)' }}><Skeleton /><Skeleton w="70%" /></div>)
            ) : anomalies.length===0 ? (
              <div style={{ textAlign:'center', padding:'48px 20px' }}>
                <div style={{ fontSize:56, marginBottom:10 }}>✅</div>
                <div style={{ fontWeight:700, fontSize:16 }}>Hozircha anomaliya yo'q</div>
                <div style={{ fontSize:13, color:'var(--text-light)', marginTop:6 }}>Tizim normal ishlayapti</div>
              </div>
            ) : (
              anomalies.map((a, i) => <AnomalyCard key={i} item={a} />)
            )}
          </div>
        )}

        {/* Broadcast */}
        {sub==='broadcast' && <BroadcastPanel token={token} flash={flash} />}
      </div>
    </>
  )
}
