/**
 * AdminFinanceTab — Moliya boshqaruvi (admin/boshliq)
 */
import { useState, useEffect } from 'react'
import { useApp } from '../../context/AppContext'

function Card({ children, style }) {
  return <div style={{ background:'#fff', borderRadius:16, padding:16, border:'1.5px solid #E2EBF0', boxShadow:'0 2px 8px rgba(10,50,80,0.06)', ...style }}>{children}</div>
}

export default function AdminFinanceTab() {
  const { token } = useApp()
  const [tpList, setTpList]   = useState([])   // teacher payments
  const [esList, setEsList]   = useState([])   // extra services
  const [loading, setLoading] = useState(true)
  const [tab, setTab]         = useState('teachers')

  const h = { Authorization:`Bearer ${token}`, 'ngrok-skip-browser-warning':'true' }

  useEffect(() => {
    Promise.all([
      fetch('/api/teacher-payments', { headers: h }).then(r => r.json()),
      fetch('/api/extra-services', { headers: h }).then(r => r.json()),
    ]).then(([tp, es]) => {
      setTpList(tp.payments || [])
      setEsList(es.services || [])
    }).catch(() => {}).finally(() => setLoading(false))
  }, [])

  const totalTeacher = tpList.reduce((s, p) => s + (p.total || 0), 0)
  const paidTeacher  = tpList.filter(p => p.status === 'paid').reduce((s, p) => s + (p.total || 0), 0)
  const totalExtra   = esList.filter(s => s.status === 'confirmed').reduce((s, x) => s + Number(x.amount || 0), 0)

  const markPaid = async (id) => {
    await fetch(`/api/teacher-payments/${id}/mark-paid`, { method:'PATCH', headers: h })
    const d = await fetch('/api/teacher-payments', { headers: h }).then(r => r.json())
    setTpList(d.payments || [])
  }

  const confirmExtra = async (id) => {
    await fetch(`/api/extra-services/${id}/confirm`, { method:'PATCH', headers: h })
    const d = await fetch('/api/extra-services', { headers: h }).then(r => r.json())
    setEsList(d.services || [])
  }

  const TabBtn = ({ id, label }) => (
    <button onClick={() => setTab(id)} style={{ flex:1, padding:'9px 4px', borderRadius:10, border:'none', cursor:'pointer', fontWeight:700, fontSize:13, background: tab === id ? '#0B5E50' : 'transparent', color: tab === id ? '#fff' : '#8A9BAB', transition:'all 0.15s' }}>
      {label}
    </button>
  )

  return (
    <div style={{ padding:'16px 12px', fontFamily:'var(--font)' }}>
      <div style={{ fontSize:20, fontWeight:900, color:'#0B5E50', marginBottom:4 }}>Moliya</div>
      <div style={{ fontSize:12, color:'#8A9BAB', marginBottom:14 }}>Muallim to'lovlari va qo'shimcha xizmatlar</div>

      {/* Umumiy kartalar */}
      <div style={{ display:'flex', gap:8, marginBottom:16 }}>
        <Card style={{ flex:1, textAlign:'center' }}>
          <div style={{ fontSize:11, color:'#8A9BAB', fontWeight:700 }}>Muallim (jami)</div>
          <div style={{ fontSize:17, fontWeight:900, color:'#0B5E50', marginTop:4 }}>{totalTeacher.toLocaleString()}</div>
          <div style={{ fontSize:10, color:'#10B981' }}>To'langan: {paidTeacher.toLocaleString()}</div>
        </Card>
        <Card style={{ flex:1, textAlign:'center' }}>
          <div style={{ fontSize:11, color:'#8A9BAB', fontWeight:700 }}>Qo'shimcha xizmat</div>
          <div style={{ fontSize:17, fontWeight:900, color:'#0B5E50', marginTop:4 }}>{totalExtra.toLocaleString()}</div>
          <div style={{ fontSize:10, color:'#8A9BAB' }}>Tasdiqlangan</div>
        </Card>
      </div>

      {/* Tab tugmalari */}
      <div style={{ display:'flex', background:'#F0F4F8', borderRadius:12, padding:4, marginBottom:14 }}>
        <TabBtn id='teachers' label='Muallimlar' />
        <TabBtn id='extra'    label="Qo'shimcha" />
      </div>

      {loading ? (
        <div style={{ textAlign:'center', padding:40, color:'#8A9BAB' }}>Yuklanmoqda...</div>
      ) : tab === 'teachers' ? (
        tpList.length === 0 ? (
          <Card style={{ textAlign:'center', padding:32 }}><div style={{ color:'#8A9BAB' }}>Ma'lumot yo'q</div></Card>
        ) : tpList.map(p => (
          <Card key={p.id} style={{ marginBottom:10 }}>
            <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center' }}>
              <div>
                <div style={{ fontSize:14, fontWeight:800 }}>Muallim #{p.teacher_id}</div>
                <div style={{ fontSize:12, color:'#8A9BAB' }}>{p.month} · {p.lessons_count} dars</div>
              </div>
              <div style={{ textAlign:'right' }}>
                <div style={{ fontSize:15, fontWeight:900, color:'#0B5E50' }}>{p.total?.toLocaleString()} so'm</div>
                <span style={{ fontSize:11, fontWeight:700, padding:'2px 8px', borderRadius:8, background: p.status==='paid' ? '#ECFDF5' : '#FEF3C7', color: p.status==='paid' ? '#10B981' : '#F59E0B' }}>
                  {p.status === 'paid' ? '✅ To\'landi' : '⏳ Kutilmoqda'}
                </span>
              </div>
            </div>
            {p.status === 'pending' && (
              <button onClick={() => markPaid(p.id)} style={{ marginTop:10, width:'100%', padding:'8px', borderRadius:10, border:'none', background:'#0B5E50', color:'#fff', fontWeight:700, fontSize:13, cursor:'pointer' }}>
                ✅ To'landi deb belgilash
              </button>
            )}
          </Card>
        ))
      ) : (
        esList.length === 0 ? (
          <Card style={{ textAlign:'center', padding:32 }}><div style={{ color:'#8A9BAB' }}>Ma'lumot yo'q</div></Card>
        ) : esList.map(s => (
          <Card key={s.id} style={{ marginBottom:10 }}>
            <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center' }}>
              <div>
                <div style={{ fontSize:14, fontWeight:800 }}>{s.service_type}</div>
                <div style={{ fontSize:12, color:'#8A9BAB' }}>{s.date} · Bola #{s.child_id}</div>
              </div>
              <div style={{ textAlign:'right' }}>
                <div style={{ fontSize:15, fontWeight:900, color:'#0B5E50' }}>{Number(s.amount).toLocaleString()} so'm</div>
                <span style={{ fontSize:11, padding:'2px 8px', borderRadius:8, fontWeight:700, background: s.status==='confirmed' ? '#ECFDF5' : s.status==='cancelled' ? '#FEF2F2' : '#FEF3C7', color: s.status==='confirmed' ? '#10B981' : s.status==='cancelled' ? '#EF4444' : '#F59E0B' }}>
                  {s.status === 'confirmed' ? 'Tasdiqlandi' : s.status === 'cancelled' ? 'Bekor' : 'Kutilmoqda'}
                </span>
              </div>
            </div>
            {s.status === 'pending' && (
              <button onClick={() => confirmExtra(s.id)} style={{ marginTop:10, width:'100%', padding:'8px', borderRadius:10, border:'none', background:'#0B5E50', color:'#fff', fontWeight:700, fontSize:13, cursor:'pointer' }}>
                ✅ Tasdiqlash
              </button>
            )}
          </Card>
        ))
      )}
    </div>
  )
}
