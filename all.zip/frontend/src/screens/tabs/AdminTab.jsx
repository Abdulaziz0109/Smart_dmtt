/**
 * AdminTab — Admin boshqaruv paneli
 * mode: stats | users | db | kindergartens | finance | anomalies | ai | staff | children | system
 */
import { useState, useEffect, useCallback } from 'react'
import { useApp } from '../../context/AppContext'

const API  = (path) => `/api${path}`
const H    = (token) => ({ Authorization: `Bearer ${token}`, 'Content-Type': 'application/json', 'ngrok-skip-browser-warning': 'true' })

// ── Reusable: kichik badge ─────────────────────────────────────
const Badge = ({ label, color = '#6b7280' }) => (
  <span style={{ background: color + '22', color, border: `1px solid ${color}44`,
    borderRadius: 20, padding: '2px 10px', fontSize: 11, fontWeight: 700 }}>
    {label}
  </span>
)

const ROLE_COLORS = {
  admin: '#ef4444', boshliq: '#7c3aed', mmtb_boshligi: '#7c3aed',
  director: '#2563eb', iqtisodchi: '#0891b2', teacher: '#059669',
  togarak_rahbari: '#16a34a', parent: '#d97706', guest: '#6b7280'
}

const ROLES = ['admin','boshliq','mmtb_boshligi','director','iqtisodchi','teacher','togarak_rahbari','parent','guest']

// ══════════════════════════════════════════════════════════
//  USERS TAB
// ══════════════════════════════════════════════════════════
function UsersTab({ token }) {
  const [users, setUsers]       = useState([])
  const [total, setTotal]       = useState(0)
  const [pages, setPages]       = useState(1)
  const [page, setPage]         = useState(1)
  const [search, setSearch]     = useState('')
  const [roleFilter, setRole]   = useState('')
  const [loading, setLoading]   = useState(false)
  const [editing, setEditing]   = useState(null)   // {id, field, value}
  const [saving, setSaving]     = useState(false)
  const [msg, setMsg]           = useState(null)

  const load = useCallback(async () => {
    setLoading(true)
    try {
      const params = new URLSearchParams({ page, limit: 30 })
      if (search)     params.set('search', search)
      if (roleFilter) params.set('role', roleFilter)
      const r = await fetch(API(`/admin/users?${params}`), { headers: H(token) })
      const d = await r.json()
      setUsers(d.users || [])
      setTotal(d.total || 0)
      setPages(d.pages || 1)
    } catch(e) { setMsg({ text: 'Xatolik: ' + e.message, ok: false }) }
    setLoading(false)
  }, [page, search, roleFilter, token])

  useEffect(() => { load() }, [load])

  const flash = (text, ok = true) => {
    setMsg({ text, ok })
    setTimeout(() => setMsg(null), 3000)
  }

  const patchUser = async (id, endpoint, body) => {
    setSaving(true)
    try {
      const r = await fetch(API(`/admin/users/${id}/${endpoint}`), {
        method: 'PATCH', headers: H(token), body: JSON.stringify(body)
      })
      const d = await r.json()
      if (!r.ok) throw new Error(d.detail || 'Xatolik')
      flash('✅ Saqlandi')
      load()
    } catch(e) { flash('❌ ' + e.message, false) }
    setSaving(false)
    setEditing(null)
  }

  const toggleBlock = async (id) => {
    await fetch(API(`/admin/users/${id}/block`), { method: 'PATCH', headers: H(token) })
    load()
  }

  const deleteUser = async (id, name) => {
    if (!confirm(`"${name}" ni o'chirasizmi?`)) return
    await fetch(API(`/admin/users/${id}`), { method: 'DELETE', headers: H(token) })
    flash('🗑️ O\'chirildi')
    load()
  }

  const S = {
    wrap:   { padding: 0 },
    bar:    { display:'flex', gap:10, marginBottom:16, flexWrap:'wrap' },
    input:  { flex:1, minWidth:180, padding:'9px 14px', borderRadius:10, border:'1px solid var(--border)', fontSize:14, outline:'none' },
    select: { padding:'9px 14px', borderRadius:10, border:'1px solid var(--border)', fontSize:13, background:'#fff' },
    table:  { width:'100%', borderCollapse:'collapse', fontSize:13 },
    th:     { padding:'10px 12px', background:'#f8fafc', borderBottom:'2px solid var(--border)', textAlign:'left', fontWeight:700, fontSize:12, color:'var(--text-light)', whiteSpace:'nowrap' },
    td:     { padding:'10px 12px', borderBottom:'1px solid var(--border)', verticalAlign:'middle' },
    btn:    { padding:'5px 12px', borderRadius:8, border:'none', cursor:'pointer', fontSize:12, fontWeight:600 },
    editInput: { width:'100%', padding:'4px 8px', borderRadius:6, border:'1px solid #93c5fd', fontSize:13, outline:'none' },
  }

  return (
    <div style={S.wrap}>
      {msg && (
        <div style={{ padding:'10px 16px', borderRadius:10, marginBottom:12,
          background: msg.ok ? '#dcfce7' : '#fee2e2', color: msg.ok ? '#166534' : '#991b1b', fontWeight:600 }}>
          {msg.text}
        </div>
      )}

      {/* Search / Filter */}
      <div style={S.bar}>
        <input style={S.input} placeholder="🔍 Ism, telefon yoki username bo'yicha..."
          value={search} onChange={e => { setSearch(e.target.value); setPage(1) }} />
        <select style={S.select} value={roleFilter} onChange={e => { setRole(e.target.value); setPage(1) }}>
          <option value="">Barcha rollar</option>
          {ROLES.map(r => <option key={r} value={r}>{r}</option>)}
        </select>
        <span style={{ alignSelf:'center', fontSize:13, color:'var(--text-light)' }}>
          Jami: <b>{total}</b>
        </span>
      </div>

      {/* Table */}
      <div style={{ overflowX:'auto', borderRadius:12, border:'1px solid var(--border)', background:'#fff' }}>
        <table style={S.table}>
          <thead>
            <tr>
              <th style={S.th}>#</th>
              <th style={S.th}>Ism</th>
              <th style={S.th}>Telefon</th>
              <th style={S.th}>Rol</th>
              <th style={S.th}>Til</th>
              <th style={S.th}>Holat</th>
              <th style={S.th}>Amallar</th>
            </tr>
          </thead>
          <tbody>
            {loading ? (
              <tr><td colSpan={7} style={{ ...S.td, textAlign:'center', color:'var(--text-light)', padding:32 }}>Yuklanmoqda...</td></tr>
            ) : users.length === 0 ? (
              <tr><td colSpan={7} style={{ ...S.td, textAlign:'center', color:'var(--text-light)', padding:32 }}>Foydalanuvchi topilmadi</td></tr>
            ) : users.map(u => (
              <tr key={u.id} style={{ opacity: u.is_blocked ? 0.5 : 1 }}>
                <td style={{ ...S.td, color:'var(--text-light)', fontSize:11 }}>{u.id}</td>

                {/* Ism */}
                <td style={S.td}>
                  {editing?.id === u.id && editing.field === 'name' ? (
                    <div style={{ display:'flex', gap:6 }}>
                      <input style={S.editInput} value={editing.value}
                        onChange={e => setEditing({ ...editing, value: e.target.value })}
                        onKeyDown={e => e.key==='Enter' && patchUser(u.id, 'phone', { phone: editing.value })} />
                      <button style={{ ...S.btn, background:'#dcfce7' }} onClick={() => patchUser(u.id, 'phone', { phone: editing.value })}>✓</button>
                      <button style={{ ...S.btn, background:'#fee2e2' }} onClick={() => setEditing(null)}>✗</button>
                    </div>
                  ) : (
                    <span style={{ fontWeight:600 }}>{u.full_name || '—'}</span>
                  )}
                </td>

                {/* Telefon */}
                <td style={S.td}>
                  {editing?.id === u.id && editing.field === 'phone' ? (
                    <div style={{ display:'flex', gap:6 }}>
                      <input style={S.editInput} value={editing.value}
                        onChange={e => setEditing({ ...editing, value: e.target.value })} />
                      <button style={{ ...S.btn, background:'#dcfce7', opacity: saving?0.6:1 }}
                        disabled={saving} onClick={() => patchUser(u.id, 'phone', { phone: editing.value })}>✓</button>
                      <button style={{ ...S.btn, background:'#fee2e2' }} onClick={() => setEditing(null)}>✗</button>
                    </div>
                  ) : (
                    <span style={{ cursor:'pointer', textDecoration:'underline dotted' }}
                      onClick={() => setEditing({ id: u.id, field: 'phone', value: u.phone })}>
                      {u.phone || '—'}
                    </span>
                  )}
                </td>

                {/* Rol */}
                <td style={S.td}>
                  {editing?.id === u.id && editing.field === 'role' ? (
                    <div style={{ display:'flex', gap:6 }}>
                      <select style={{ ...S.select, padding:'3px 8px' }} value={editing.value}
                        onChange={e => setEditing({ ...editing, value: e.target.value })}>
                        {ROLES.map(r => <option key={r} value={r}>{r}</option>)}
                      </select>
                      <button style={{ ...S.btn, background:'#dcfce7', opacity: saving?0.6:1 }}
                        disabled={saving} onClick={() => patchUser(u.id, 'role', { role: editing.value })}>✓</button>
                      <button style={{ ...S.btn, background:'#fee2e2' }} onClick={() => setEditing(null)}>✗</button>
                    </div>
                  ) : (
                    <span style={{ cursor:'pointer' }}
                      onClick={() => setEditing({ id: u.id, field: 'role', value: u.role })}>
                      <Badge label={u.role} color={ROLE_COLORS[u.role] || '#6b7280'} />
                    </span>
                  )}
                </td>

                <td style={S.td}>
                  <span style={{ fontSize:12, color:'var(--text-light)' }}>{u.language || 'uz'}</span>
                </td>

                {/* Holat */}
                <td style={S.td}>
                  <Badge label={u.is_blocked ? '🚫 Bloklangan' : '✅ Faol'}
                    color={u.is_blocked ? '#ef4444' : '#22c55e'} />
                </td>

                {/* Amallar */}
                <td style={S.td}>
                  <div style={{ display:'flex', gap:6, flexWrap:'wrap' }}>
                    <button style={{ ...S.btn, background:'#eff6ff', color:'#2563eb' }}
                      title="Parolni o'zgartirish"
                      onClick={() => {
                        const pw = prompt(`${u.full_name} uchun yangi parol:`)
                        if (pw) patchUser(u.id, 'password', { password: pw })
                      }}>🔑</button>
                    <button style={{ ...S.btn, background: u.is_blocked ? '#dcfce7' : '#fef3c7',
                      color: u.is_blocked ? '#166534' : '#92400e' }}
                      title={u.is_blocked ? 'Blokdan chiqarish' : 'Bloklash'}
                      onClick={() => toggleBlock(u.id)}>
                      {u.is_blocked ? '✅' : '🚫'}
                    </button>
                    <button style={{ ...S.btn, background:'#fee2e2', color:'#991b1b' }}
                      title="O'chirish"
                      onClick={() => deleteUser(u.id, u.full_name)}>🗑️</button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Pagination */}
      {pages > 1 && (
        <div style={{ display:'flex', gap:8, marginTop:16, justifyContent:'center' }}>
          <button style={{ ...S.btn, background:'#f1f5f9' }} disabled={page===1} onClick={() => setPage(p => p-1)}>← Oldingi</button>
          <span style={{ alignSelf:'center', fontSize:13 }}>{page} / {pages}</span>
          <button style={{ ...S.btn, background:'#f1f5f9' }} disabled={page===pages} onClick={() => setPage(p => p+1)}>Keyingi →</button>
        </div>
      )}
    </div>
  )
}


// ══════════════════════════════════════════════════════════
//  DB VIEWER TAB
// ══════════════════════════════════════════════════════════
function DBViewerTab({ token }) {
  const [tables, setTables]   = useState([])
  const [selTable, setSelTable] = useState(null)
  const [tableData, setData]  = useState(null)
  const [page, setPage]       = useState(1)
  const [search, setSearch]   = useState('')
  const [editing, setEditing] = useState(null)   // {rowId, col, value, origRow}
  const [loading, setLoading] = useState(false)
  const [saving, setSaving]   = useState(false)
  const [msg, setMsg]         = useState(null)

  const flash = (text, ok = true) => {
    setMsg({ text, ok })
    setTimeout(() => setMsg(null), 3000)
  }

  useEffect(() => {
    fetch(API('/admin/db/tables'), { headers: H(token) })
      .then(r => r.json()).then(setTables).catch(console.error)
  }, [token])

  const loadTable = useCallback(async (tbl, pg = 1, srch = '') => {
    if (!tbl) return
    setLoading(true)
    try {
      const params = new URLSearchParams({ page: pg, limit: 50 })
      if (srch) params.set('search', srch)
      const r = await fetch(API(`/admin/db/table/${tbl}?${params}`), { headers: H(token) })
      const d = await r.json()
      setData(d)
    } catch(e) { flash('Xatolik: ' + e.message, false) }
    setLoading(false)
  }, [token])

  const selectTable = (tbl) => {
    setSelTable(tbl)
    setPage(1)
    setSearch('')
    setEditing(null)
    loadTable(tbl, 1, '')
  }

  useEffect(() => {
    if (selTable) loadTable(selTable, page, search)
  }, [page])

  const saveEdit = async () => {
    if (!editing) return
    setSaving(true)
    try {
      const body = { [editing.col]: editing.value }
      const r = await fetch(API(`/admin/db/table/${selTable}/${editing.rowId}`), {
        method: 'PATCH', headers: H(token), body: JSON.stringify(body)
      })
      const d = await r.json()
      if (!r.ok) throw new Error(d.detail)
      flash('✅ Saqlandi')
      loadTable(selTable, page, search)
    } catch(e) { flash('❌ ' + e.message, false) }
    setSaving(false)
    setEditing(null)
  }

  const deleteRow = async (rowId) => {
    if (!confirm(`ID=${rowId} qatorni o'chirasizmi?`)) return
    try {
      await fetch(API(`/admin/db/table/${selTable}/${rowId}`), { method: 'DELETE', headers: H(token) })
      flash('🗑️ O\'chirildi')
      loadTable(selTable, page, search)
    } catch(e) { flash('❌ ' + e.message, false) }
  }

  const PROTECTED = new Set(['id', 'created_at', 'telegram_id'])

  const S = {
    layout: { display:'flex', gap:16, minHeight:500 },
    sidebar: { width:200, flexShrink:0 },
    tblItem: (active) => ({
      padding:'8px 12px', borderRadius:8, cursor:'pointer', fontSize:13,
      background: active ? 'var(--primary-50)' : 'transparent',
      color: active ? 'var(--primary)' : 'var(--text-mid)',
      fontWeight: active ? 700 : 400, marginBottom:2,
      display:'flex', justifyContent:'space-between', alignItems:'center',
    }),
    main: { flex:1, minWidth:0 },
    table: { width:'100%', borderCollapse:'collapse', fontSize:12 },
    th: { padding:'8px 10px', background:'#f8fafc', borderBottom:'2px solid var(--border)',
      textAlign:'left', fontWeight:700, fontSize:11, color:'var(--text-light)', whiteSpace:'nowrap' },
    td: { padding:'7px 10px', borderBottom:'1px solid var(--border)', maxWidth:200,
      overflow:'hidden', textOverflow:'ellipsis', whiteSpace:'nowrap', verticalAlign:'middle' },
    editInput: { width:'100%', padding:'3px 6px', borderRadius:6, border:'1px solid #93c5fd', fontSize:12, outline:'none' },
    btn: { padding:'3px 8px', borderRadius:6, border:'none', cursor:'pointer', fontSize:11, fontWeight:600 },
  }

  return (
    <div>
      {msg && (
        <div style={{ padding:'8px 14px', borderRadius:8, marginBottom:10,
          background: msg.ok ? '#dcfce7' : '#fee2e2', color: msg.ok ? '#166534' : '#991b1b', fontSize:13, fontWeight:600 }}>
          {msg.text}
        </div>
      )}

      <div style={S.layout}>
        {/* Jadvallar sidebar */}
        <div style={S.sidebar}>
          <div style={{ fontWeight:700, fontSize:12, color:'var(--text-light)', marginBottom:8, textTransform:'uppercase', letterSpacing:0.5 }}>
            Jadvallar ({tables.length})
          </div>
          <div style={{ maxHeight:520, overflowY:'auto' }}>
            {tables.map(t => (
              <div key={t.table} style={S.tblItem(selTable === t.table)} onClick={() => selectTable(t.table)}>
                <span>{t.table}</span>
                <span style={{ fontSize:11, opacity:0.6, background:'var(--border)', borderRadius:10, padding:'1px 6px' }}>{t.rows}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Jadval ma'lumotlari */}
        <div style={S.main}>
          {!selTable ? (
            <div style={{ textAlign:'center', padding:48, color:'var(--text-light)' }}>
              ← Chap tarafdan jadval tanlang
            </div>
          ) : (
            <>
              {/* Search bar */}
              <div style={{ display:'flex', gap:8, marginBottom:12 }}>
                <input
                  style={{ flex:1, padding:'7px 12px', borderRadius:8, border:'1px solid var(--border)', fontSize:13, outline:'none' }}
                  placeholder="🔍 Qidirish..."
                  value={search}
                  onChange={e => setSearch(e.target.value)}
                  onKeyDown={e => { if(e.key==='Enter') { setPage(1); loadTable(selTable, 1, search) } }}
                />
                <button style={{ padding:'7px 14px', borderRadius:8, background:'var(--primary)', color:'#fff', border:'none', cursor:'pointer', fontSize:13 }}
                  onClick={() => { setPage(1); loadTable(selTable, 1, search) }}>
                  Qidirish
                </button>
              </div>

              {/* Table */}
              <div style={{ overflowX:'auto', border:'1px solid var(--border)', borderRadius:10, background:'#fff' }}>
                {loading ? (
                  <div style={{ padding:32, textAlign:'center', color:'var(--text-light)' }}>Yuklanmoqda...</div>
                ) : tableData && tableData.rows?.length > 0 ? (
                  <table style={S.table}>
                    <thead>
                      <tr>
                        {Object.keys(tableData.rows[0]).map(col => (
                          <th key={col} style={S.th}>{col}</th>
                        ))}
                        <th style={S.th}>Amal</th>
                      </tr>
                    </thead>
                    <tbody>
                      {tableData.rows.map((row, ri) => (
                        <tr key={ri}>
                          {Object.entries(row).map(([col, val]) => (
                            <td key={col} style={S.td} title={String(val ?? '')}>
                              {editing?.rowId === row.id && editing.col === col && !PROTECTED.has(col) ? (
                                <input style={S.editInput} value={editing.value ?? ''}
                                  onChange={e => setEditing({ ...editing, value: e.target.value })}
                                  onKeyDown={e => { if(e.key==='Enter') saveEdit(); if(e.key==='Escape') setEditing(null) }}
                                  autoFocus />
                              ) : (
                                <span
                                  style={{ cursor: PROTECTED.has(col) ? 'default' : 'pointer', display:'block' }}
                                  title={PROTECTED.has(col) ? '' : 'Tahrirlash uchun bosing'}
                                  onDoubleClick={() => {
                                    if (!PROTECTED.has(col)) setEditing({ rowId: row.id, col, value: val ?? '', origRow: row })
                                  }}>
                                  {val === null ? <span style={{ opacity:0.3 }}>null</span> : String(val)}
                                </span>
                              )}
                            </td>
                          ))}
                          <td style={S.td}>
                            {editing?.rowId === row.id ? (
                              <div style={{ display:'flex', gap:4 }}>
                                <button style={{ ...S.btn, background:'#dcfce7', opacity:saving?0.6:1 }}
                                  disabled={saving} onClick={saveEdit}>✓</button>
                                <button style={{ ...S.btn, background:'#fee2e2' }} onClick={() => setEditing(null)}>✗</button>
                              </div>
                            ) : (
                              <button style={{ ...S.btn, background:'#fee2e2', color:'#991b1b' }}
                                onClick={() => deleteRow(row.id)}>🗑️</button>
                            )}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                ) : (
                  <div style={{ padding:32, textAlign:'center', color:'var(--text-light)' }}>Ma'lumot yo'q</div>
                )}
              </div>

              {/* Pagination */}
              {tableData && tableData.pages > 1 && (
                <div style={{ display:'flex', gap:8, marginTop:12, justifyContent:'center', alignItems:'center' }}>
                  <button style={{ ...S.btn, background:'#f1f5f9', padding:'5px 14px' }}
                    disabled={page===1} onClick={() => setPage(p => p-1)}>← Oldingi</button>
                  <span style={{ fontSize:12, color:'var(--text-light)' }}>
                    {page} / {tableData.pages} ({tableData.total} ta satr)
                  </span>
                  <button style={{ ...S.btn, background:'#f1f5f9', padding:'5px 14px' }}
                    disabled={page===tableData.pages} onClick={() => setPage(p => p+1)}>Keyingi →</button>
                </div>
              )}
            </>
          )}
        </div>
      </div>
      <p style={{ marginTop:12, fontSize:11, color:'var(--text-light)' }}>
        💡 Tahrirlash uchun katakni <b>ikki marta bosing</b>. id, created_at, telegram_id tahririlanmaydi.
      </p>
    </div>
  )
}


// ══════════════════════════════════════════════════════════
//  STATS TAB (sodda)
// ══════════════════════════════════════════════════════════
function StatsTab({ token }) {
  const [data, setData] = useState(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    fetch(API('/analytics/summary'), { headers: H(token) })
      .then(r => r.json()).then(setData).finally(() => setLoading(false))
  }, [token])

  if (loading) return <div style={{ padding:32, textAlign:'center', color:'var(--text-light)' }}>Yuklanmoqda...</div>
  if (!data)   return <div style={{ padding:32, textAlign:'center', color:'#ef4444' }}>Ma'lumot yuklanmadi</div>

  const cards = [
    { label: 'Jami bolalar',   value: data.total_children,     icon: '👶', color: '#2563eb' },
    { label: 'To\'garaklar',   value: data.total_clubs,         icon: '🎯', color: '#7c3aed' },
    { label: 'Davomat bugun',  value: data.attendance_today + '%', icon: '✅', color: '#059669' },
    { label: 'Qarzdorlar',     value: data.debtors,             icon: '⚠️', color: '#d97706' },
    { label: 'Oylik daromad',  value: (data.monthly_revenue || 0).toLocaleString() + " so'm", icon: '💰', color: '#0891b2' },
    { label: 'Aktiv yozilish', value: data.active_enrollments,  icon: '📝', color: '#6366f1' },
  ]

  return (
    <div style={{ display:'grid', gridTemplateColumns:'repeat(auto-fill, minmax(200px, 1fr))', gap:16 }}>
      {cards.map((c, i) => (
        <div key={i} style={{ background:'#fff', borderRadius:14, padding:'20px 24px',
          border:`1px solid ${c.color}33`, boxShadow:`0 2px 12px ${c.color}11` }}>
          <div style={{ fontSize:28 }}>{c.icon}</div>
          <div style={{ fontSize:26, fontWeight:900, color:c.color, margin:'8px 0 4px' }}>{c.value}</div>
          <div style={{ fontSize:13, color:'var(--text-light)' }}>{c.label}</div>
        </div>
      ))}
    </div>
  )
}


// ══════════════════════════════════════════════════════════
//  MAIN AdminTab
// ══════════════════════════════════════════════════════════
const TABS = [
  { id: 'stats',  label: '📊 Statistika' },
  { id: 'users',  label: '👥 Foydalanuvchilar' },
  { id: 'db',     label: '🗄️ DB Viewer' },
]

export default function AdminTab({ mode = 'stats' }) {
  const { token, user } = useApp()
  const [activeTab, setActiveTab] = useState(
    ['users','db'].includes(mode) ? mode : 'stats'
  )

  const role = user?.role || ''
  const isAdmin = ['admin','boshliq','mmtb_boshligi'].includes(role)

  if (!isAdmin) return (
    <div style={{ padding:32, textAlign:'center' }}>
      <div style={{ fontSize:48 }}>🚫</div>
      <p>Bu sahifaga kirish huquqi yo'q</p>
    </div>
  )

  return (
    <div style={{ padding: '20px 16px' }}>
      {/* Ichki tablar */}
      <div style={{ display:'flex', gap:8, marginBottom:20, flexWrap:'wrap' }}>
        {TABS.map(t => (
          <button key={t.id} onClick={() => setActiveTab(t.id)} style={{
            padding:'8px 18px', borderRadius:20, border:'none', cursor:'pointer',
            background: activeTab === t.id ? 'var(--primary)' : 'var(--primary-50)',
            color: activeTab === t.id ? '#fff' : 'var(--primary)',
            fontWeight: 600, fontSize: 13, transition:'all 0.2s',
          }}>{t.label}</button>
        ))}
      </div>

      {/* Content */}
      {activeTab === 'stats' && <StatsTab token={token} />}
      {activeTab === 'users' && <UsersTab token={token} />}
      {activeTab === 'db'    && <DBViewerTab token={token} />}
    </div>
  )
}
