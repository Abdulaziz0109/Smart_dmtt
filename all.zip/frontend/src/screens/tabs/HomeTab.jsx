/**
 * SmartDMTT v4 — HomeTab
 * Skeleton loader + error UI + i18n
 */
import { useState, useEffect } from 'react'
import { useApp } from '../../context/AppContext'
import { useTranslation } from '../../hooks/useTranslation'

const API = (p) => `/api${p}`
const H   = (tk) => ({ Authorization: `Bearer ${tk}`, 'Content-Type': 'application/json', 'ngrok-skip-browser-warning': 'true' })

// ── Skeleton ─────────────────────────────────────────────
function Skeleton({ w = '100%', h = 20, r = 8, mb = 0 }) {
  return (
    <div style={{
      width: w, height: h, borderRadius: r, marginBottom: mb,
      background: 'linear-gradient(90deg, #f0f0f0 25%, #e0e0e0 50%, #f0f0f0 75%)',
      backgroundSize: '200% 100%',
      animation: 'shimmer 1.4s infinite',
    }} />
  )
}

const skimmerStyle = `
@keyframes shimmer {
  0%   { background-position: 200% 0 }
  100% { background-position: -200% 0 }
}
`

// ── Error card ───────────────────────────────────────────
function ErrorCard({ msg, onRetry }) {
  return (
    <div style={{ textAlign: 'center', padding: 40 }}>
      <div style={{ fontSize: 48, marginBottom: 12 }}>⚠️</div>
      <div style={{ fontSize: 15, color: '#ef4444', fontWeight: 600, marginBottom: 8 }}>{msg}</div>
      <button onClick={onRetry} style={{
        padding: '10px 24px', borderRadius: 12, background: 'var(--primary)',
        color: '#fff', border: 'none', cursor: 'pointer', fontWeight: 700,
      }}>🔄 Qayta urinish</button>
    </div>
  )
}

// ── Stat kartochkasi ─────────────────────────────────────
function StatCard({ icon, value, label, color, loading }) {
  return (
    <div style={{
      background: '#fff', borderRadius: 14, padding: '18px 20px',
      border: `1px solid ${color}33`, flex: '1 1 140px',
    }}>
      <div style={{ fontSize: 26 }}>{icon}</div>
      {loading
        ? <><Skeleton h={28} w="70%" r={6} mb={6} /><Skeleton h={14} w="90%" r={6} /></>
        : <>
            <div style={{ fontSize: 24, fontWeight: 900, color, margin: '6px 0 4px' }}>{value}</div>
            <div style={{ fontSize: 12, color: 'var(--text-light)' }}>{label}</div>
          </>
      }
    </div>
  )
}

// ── Role-based qo'shimcha ma'lumot ───────────────────────
function RoleExtra({ role, token, loading, t }) {
  const [data, setData] = useState(null)
  const [err,  setErr]  = useState(null)

  useEffect(() => {
    if (!role || !token) return
    let endpoint = null
    if (['boshliq','mmtb_boshligi','admin'].includes(role)) endpoint = '/analytics/anomalies?limit=3'
    else if (role === 'teacher' || role === 'togarak_rahbari') endpoint = '/attendance/club/today'
    else if (role === 'parent') endpoint = '/children/mine?limit=3'

    if (!endpoint) return
    fetch(API(endpoint), { headers: H(token) })
      .then(r => r.ok ? r.json() : null)
      .then(setData)
      .catch(() => setErr(true))
  }, [role, token])

  if (!data && !err) return null

  if (err) return null // Qo'shimcha ma'lumot bo'lmasa xato ko'rsatmaylik

  if (['boshliq','mmtb_boshligi','admin'].includes(role) && Array.isArray(data)) {
    if (!data.length) return null
    return (
      <div style={{ background: '#fff', borderRadius: 14, padding: 20, border: '1px solid #fde68a' }}>
        <div style={{ fontWeight: 700, marginBottom: 12, color: '#92400e' }}>⚠️ Anomaliyalar</div>
        {data.map((a, i) => (
          <div key={i} style={{ padding: '8px 0', borderBottom: '1px solid var(--border)', fontSize: 13 }}>
            {a.message || a.description || JSON.stringify(a)}
          </div>
        ))}
      </div>
    )
  }

  return null
}

// ── Main HomeTab ─────────────────────────────────────────
export default function HomeTab() {
  const { token, user } = useApp()
  const { t } = useTranslation()
  const [stats,   setStats]   = useState(null)
  const [loading, setLoading] = useState(true)
  const [error,   setError]   = useState(null)

  const role = user?.role || 'guest'

  const load = () => {
    setLoading(true)
    setError(null)
    fetch(API('/analytics/summary'), { headers: H(token) })
      .then(r => { if (!r.ok) throw new Error(`${r.status}`); return r.json() })
      .then(d => { setStats(d); setLoading(false) })
      .catch(e => { setError(e.message); setLoading(false) })
  }

  useEffect(() => { if (token) load() }, [token])

  const name    = user?.full_name?.split(' ')[0] || user?.phone || 'Foydalanuvchi'
  const today   = new Date().toLocaleDateString('uz-UZ', { weekday: 'long', day: 'numeric', month: 'long' })

  // ── Statistika kartalari har bir rol uchun ─────────────
  const statCards = {
    admin:          ['total_children','total_clubs','attendance_today','debtors'],
    boshliq:        ['total_children','total_clubs','attendance_today','debtors'],
    mmtb_boshligi:  ['total_children','total_clubs','attendance_today','monthly_revenue'],
    director:       ['total_children','total_clubs','attendance_today','debtors'],
    iqtisodchi:     ['monthly_revenue','debtors','paid_count','active_enrollments'],
    teacher:        ['club_children','club_attendance','club_paid','club_debt'],
    togarak_rahbari:['club_children','club_attendance','club_paid','club_debt'],
    parent:         ['children_count','attendance_today','paid_clubs','debt_amount'],
    guest:          [],
  }

  const cardDefs = {
    total_children:    { icon: '👶', label: t('total_children'),  color: '#2563eb', key: 'total_children' },
    total_clubs:       { icon: '🎯', label: t('total_clubs'),     color: '#7c3aed', key: 'total_clubs' },
    attendance_today:  { icon: '✅', label: t('attendance_pct'),  color: '#059669', key: 'attendance_today', suffix: '%' },
    debtors:           { icon: '⚠️', label: t('debtors'),         color: '#d97706', key: 'debtors' },
    monthly_revenue:   { icon: '💰', label: t('monthly_revenue'), color: '#0891b2', key: 'monthly_revenue', format: 'money' },
    active_enrollments:{ icon: '📝', label: 'Yozilishlar',        color: '#6366f1', key: 'active_enrollments' },
    paid_count:        { icon: '✅', label: "To'lagan",           color: '#059669', key: 'paid_count' },
    club_children:     { icon: '👶', label: 'Guruh',              color: '#2563eb', key: 'club_children' },
    club_attendance:   { icon: '✅', label: 'Davomat',            color: '#059669', key: 'club_attendance', suffix: '%' },
    club_paid:         { icon: '💳', label: "To'lagan",           color: '#0891b2', key: 'club_paid' },
    club_debt:         { icon: '❌', label: 'Qarzdor',            color: '#d97706', key: 'club_debt' },
    children_count:    { icon: '👶', label: 'Farzandlar',         color: '#2563eb', key: 'children_count' },
    paid_clubs:        { icon: '✅', label: "To'langan",          color: '#059669', key: 'paid_clubs' },
    debt_amount:       { icon: '💸', label: 'Qarz',               color: '#ef4444', key: 'debt_amount', format: 'money' },
  }

  const activeCards = (statCards[role] || []).map(k => cardDefs[k]).filter(Boolean)

  const fmt = (def) => {
    const raw = stats?.[def.key] ?? '—'
    if (raw === '—' || raw === null || raw === undefined) return '—'
    if (def.format === 'money') return Number(raw).toLocaleString() + " so'm"
    if (def.suffix) return raw + def.suffix
    return raw
  }

  return (
    <>
      <style>{skimmerStyle}</style>
      <div style={{ padding: '20px 16px' }}>
        {/* Header */}
        <div style={{ marginBottom: 20 }}>
          {loading
            ? <><Skeleton h={22} w="60%" r={8} mb={8} /><Skeleton h={14} w="40%" r={6} /></>
            : <>
                <h2 style={{ margin: 0, fontSize: 20, fontWeight: 800 }}>
                  {t('welcome')}, {name}! 👋
                </h2>
                <p style={{ margin: '4px 0 0', fontSize: 13, color: 'var(--text-light)', textTransform: 'capitalize' }}>
                  {today}
                </p>
              </>
          }
        </div>

        {/* Error holat */}
        {error && <ErrorCard msg={`${t('error')}: ${error}`} onRetry={load} />}

        {/* Stat kartalar */}
        {!error && activeCards.length > 0 && (
          <div style={{ display: 'flex', flexWrap: 'wrap', gap: 12, marginBottom: 20 }}>
            {activeCards.map((def, i) => (
              <StatCard key={i} icon={def.icon} color={def.color}
                label={def.label} value={fmt(def)} loading={loading} />
            ))}
          </div>
        )}

        {/* Qo'shimcha ma'lumot */}
        {!error && !loading && (
          <RoleExtra role={role} token={token} loading={loading} t={t} />
        )}

        {/* Yangilash tugmasi */}
        {!loading && !error && (
          <button onClick={load} style={{
            marginTop: 16, padding: '10px 20px', borderRadius: 12,
            background: 'var(--primary-50)', color: 'var(--primary)',
            border: 'none', cursor: 'pointer', fontWeight: 600, fontSize: 13,
          }}>🔄 {t('refresh')}</button>
        )}
      </div>
    </>
  )
}
