import { useEffect, useRef, useState, useCallback } from 'react'
import { useApp } from '../../context/AppContext'

function haversine(lat1, lon1, lat2, lon2) {
  const R = 6371, toRad = d => d * Math.PI / 180
  const dLat = toRad(lat2 - lat1), dLon = toRad(lon2 - lon1)
  const a = Math.sin(dLat/2)**2 + Math.cos(toRad(lat1)) * Math.cos(toRad(lat2)) * Math.sin(dLon/2)**2
  return R * 2 * Math.asin(Math.sqrt(a))
}

const STYLES = `
  .ym-cm { width:38px;height:38px;background:linear-gradient(135deg,#b31217,#e52d27);border:3px solid #fff;border-radius:50% 50% 50% 4px;transform:rotate(-45deg);box-shadow:0 4px 14px rgba(179,18,23,.5);display:flex;align-items:center;justify-content:center;cursor:pointer }
  .ym-cm.sel { background:linear-gradient(135deg,#D97706,#F59E0B) }
  .ym-ci { transform:rotate(45deg);color:#fff;font-weight:800;font-size:10px;text-align:center;user-select:none }
  .leaflet-popup-content-wrapper { border-radius:16px!important;box-shadow:0 8px 32px rgba(179,18,23,.18)!important;padding:0!important;overflow:hidden }
  .leaflet-popup-content { margin:0!important;width:260px!important }
  .ym-ph { background:linear-gradient(135deg,#b31217,#e52d27);padding:12px 16px;display:flex;align-items:center;gap:10px }
  .ym-pn { width:36px;height:36px;background:rgba(255,255,255,.25);border:2px solid rgba(255,255,255,.4);border-radius:10px;display:flex;align-items:center;justify-content:center;font-weight:800;font-size:14px;color:#fff;flex-shrink:0 }
  .ym-pt { color:#fff;font-weight:700;font-size:15px;line-height:1.3 }
  .ym-pb { padding:12px 16px }
  .ym-bn { display:flex;align-items:center;justify-content:center;gap:6px;padding:9px 12px;border-radius:8px;text-decoration:none;font-weight:600;font-size:12px;border:1.5px solid #eee;background:#fff;cursor:pointer;flex:1 }
  .ym-ud { width:16px;height:16px;background:#3B82F6;border-radius:50%;border:3px solid #fff;box-shadow:0 0 0 4px rgba(59,130,246,.3) }
  @keyframes ym-spin { to { transform:rotate(360deg) } }
`

// Yandex EPSG:3395 resolution jadvali
const YANDEX_RES = [
  78271.517, 39135.758, 19567.879, 9783.940, 4891.970,
  2445.985,  1222.992,  611.496,   305.748,  152.874,
  76.437,    38.219,    19.109,    9.555,     4.777,
  2.389,     1.194,     0.597,     0.299,     0.149, 0.075,
]

const yNavUrl = (lat, lon) => `https://yandex.com/maps/?ll=${lon},${lat}&z=16&pt=${lon},${lat},pm2gnm`
const gNavUrl = (lat, lon) => `https://www.google.com/maps/dir/?api=1&destination=${lat},${lon}&travelmode=driving`

export default function MapYandex() {
  const { tr } = useApp()
  const mapRef  = useRef(null)
  const mapInst = useRef(null)
  const tileRef = useRef(null)
  const mRef    = useRef({})

  const [kgs, setKgs]           = useState([])
  const [filtered, setFiltered] = useState([])
  const [search, setSearch]     = useState('')
  const [sel, setSel]           = useState(null)
  const [locLoad, setLocLoad]   = useState(false)
  const [ready, setReady]       = useState(false)   // Leaflet+proj4 tayyor
  const [status, setStatus]     = useState('loading') // loading | error | ok

  // ── Kutubxonalar: Leaflet → proj4 → proj4leaflet ──────────────────────────
  useEffect(() => {
    fetch('/api/kindergartens')
      .then(r => r.ok ? r.json() : { kindergartens:[] })
      .then(d => { const l = d.kindergartens||[]; setKgs(l); setFiltered(l) })
      .catch(() => {})

    if (window.L && window.proj4 && window.L.Proj) { setReady(true); return }

    const ldLink = href => {
      if (!document.querySelector(`link[href="${href}"]`))
        document.head.appendChild(Object.assign(document.createElement('link'), {rel:'stylesheet',href}))
    }
    const ldScript = (src, cb, errCb) => {
      if (document.querySelector(`script[src="${src}"]`)) { setTimeout(cb, 200); return }
      const s = Object.assign(document.createElement('script'), { src, onload:cb, onerror:errCb||(() => setStatus('error')) })
      document.head.appendChild(s)
    }

    ldLink('https://unpkg.com/leaflet@1.9.4/dist/leaflet.css')
    ldScript('https://unpkg.com/leaflet@1.9.4/dist/leaflet.js', () =>
      ldScript('https://cdnjs.cloudflare.com/ajax/libs/proj4js/2.9.0/proj4.js', () =>
        ldScript('https://unpkg.com/proj4leaflet@1.0.2/src/proj4leaflet.js', () =>
          setReady(true)
        )
      )
    )
  }, [])

  // ── Yandex EPSG:3395 CRS ─────────────────────────────────────────────────
  const makeCRS = useCallback(() => {
    const L = window.L
    return new L.Proj.CRS(
      'EPSG:3395',
      '+proj=merc +lon_0=0 +k=1 +x_0=0 +y_0=0 +datum=WGS84 +units=m +no_defs',
      {
        resolutions: YANDEX_RES,
        origin: [-20037508.342789244, 20037508.342789244],
        bounds: L.bounds(
          [-20037508.342789244, -20037508.342789244],
          [ 20037508.342789244,  20037508.342789244]
        ),
      }
    )
  }, [])

  // ── Xarita yaratish ───────────────────────────────────────────────────────
  useEffect(() => {
    if (!ready || !mapRef.current || mapInst.current) return
    const L = window.L

    const center = kgs.length > 0
      ? [kgs.reduce((s,k)=>s+k.lat,0)/kgs.length, kgs.reduce((s,k)=>s+k.lon,0)/kgs.length]
      : [39.762, 67.274]

    try {
      const map = L.map(mapRef.current, {
        center, zoom:12,
        crs:             makeCRS(),
        zoomControl:     false,
        dragging:        true,
        tap:             true,
        tapTolerance:    15,
        touchZoom:       true,
        scrollWheelZoom: true,
      })
      L.control.zoom({ position:'topright' }).addTo(map)

      tileRef.current = L.tileLayer(
        'https://core-renderer-tiles.maps.yandex.net/tiles?l=map&x={x}&y={y}&z={z}&scale=1&lang=ru_RU',
        { attribution:'© Yandex', maxZoom:19, updateWhenIdle:false }
      ).addTo(map)

      mapInst.current = map
      setStatus('ok')

      if (kgs.length > 0) {
        try { map.fitBounds(L.featureGroup(kgs.map(k=>L.marker([k.lat,k.lon]))).getBounds().pad(0.1)) } catch(e){}
      }
      setTimeout(()=>map.invalidateSize(),150)
      setTimeout(()=>map.invalidateSize(),600)
      setTimeout(()=>map.invalidateSize(),1400)
    } catch(e) {
      console.error('Yandex map error:', e)
      setStatus('error')
    }

    return () => { mapInst.current?.remove(); mapInst.current=null; tileRef.current=null; mRef.current={} }
  }, [ready, kgs, makeCRS])

  // ── Markerlar ─────────────────────────────────────────────────────────────
  useEffect(() => {
    if (!mapInst.current || !window.L || status!=='ok') return
    const L = window.L, map = mapInst.current
    Object.entries(mRef.current).forEach(([k,m]) => { if(k!=='__user') map.removeLayer(m) })
    const nm = { __user: mRef.current.__user }
    filtered.forEach(k => {
      const num = k.number || k.name.replace(/\D/g,'') || '?'
      const icon = L.divIcon({
        className:'',
        html:`<div class="ym-cm${sel?.id===k.id?' sel':''}"><div class="ym-ci">${num}</div></div>`,
        iconSize:[38,38], iconAnchor:[19,38], popupAnchor:[0,-40],
      })
      const popup = `<div class="ym-ph"><div class="ym-pn">${num}</div><div class="ym-pt">${k.name}</div></div>
        <div class="ym-pb">
          ${k.address?`<div style="font-size:13px;color:#555;margin-bottom:10px;line-height:1.5">📍 ${k.address}</div>`:''}
          ${k.phone?`<a href="tel:${k.phone}" style="display:block;font-size:13px;color:#b31217;font-weight:700;margin-bottom:12px">📞 ${k.phone}</a>`:''}
          <div style="display:flex;gap:8px">
            <a href="${gNavUrl(k.lat,k.lon)}" target="_blank" class="ym-bn" style="color:#4285F4;border-color:#4285F4">📍 Google</a>
            <a href="${yNavUrl(k.lat,k.lon)}" target="_blank" class="ym-bn" style="color:#FC3F1D;border-color:#FC3F1D">📍 Yandex</a>
          </div>
        </div>`
      nm[k.id] = L.marker([k.lat,k.lon],{icon}).addTo(map).bindPopup(popup).on('click',()=>setSel(k))
    })
    mRef.current = nm
  }, [filtered, status, sel])

  // ── Qidiruv ───────────────────────────────────────────────────────────────
  useEffect(() => {
    const q = search.toLowerCase().trim()
    if (!q) { setFiltered(kgs); return }
    const r = kgs.filter(k => k.name.toLowerCase().includes(q)||String(k.number||'').includes(q)||(k.address||'').toLowerCase().includes(q))
    setFiltered(r)
    if (r.length===1 && mapInst.current) {
      mapInst.current.flyTo([r[0].lat,r[0].lon],16,{duration:0.8})
      setTimeout(()=>mRef.current[r[0].id]?.openPopup(),900)
    }
  }, [search, kgs])

  // ── Geolokatsiya ──────────────────────────────────────────────────────────
  const locate = () => {
    if (!navigator.geolocation) return
    setLocLoad(true)
    navigator.geolocation.getCurrentPosition(pos => {
      const {latitude:lat,longitude:lon} = pos.coords
      if (mapInst.current && window.L) {
        const L=window.L,map=mapInst.current
        if (mRef.current.__user) map.removeLayer(mRef.current.__user)
        mRef.current.__user = L.marker([lat,lon],{
          icon:L.divIcon({className:'',html:'<div class="ym-ud"></div>',iconSize:[16,16],iconAnchor:[8,8]}),zIndexOffset:1000
        }).addTo(map).bindPopup('📍 Sizning joylashuvingiz')
        if (kgs.length>0) {
          const n=[...kgs].sort((a,b)=>haversine(lat,lon,a.lat,a.lon)-haversine(lat,lon,b.lat,b.lon))[0]
          map.fitBounds(L.latLngBounds([[lat,lon],[n.lat,n.lon]]).pad(0.3))
        } else map.flyTo([lat,lon],14)
      }
      setLocLoad(false)
    }, ()=>setLocLoad(false), {enableHighAccuracy:true,timeout:10000})
  }

  // ── RENDER ────────────────────────────────────────────────────────────────
  return (
    <div style={{fontFamily:'var(--font)',height:'100%',display:'flex',flexDirection:'column',overflow:'hidden'}}>
      <style>{STYLES}</style>

      {/* Header — qizil Yandex uslubida */}
      <div style={{background:'linear-gradient(135deg,#b31217,#e52d27)',padding:'16px 20px',display:'flex',alignItems:'center',gap:12,color:'#fff',boxShadow:'0 2px 12px rgba(0,0,0,.15)',zIndex:10,flexShrink:0}}>
        <div style={{width:40,height:40,background:'rgba(255,255,255,.2)',borderRadius:12,display:'flex',alignItems:'center',justifyContent:'center',fontSize:20}}>🗺</div>
        <div>
          <div style={{fontSize:17,fontWeight:700}}>{tr('map_title')||"Bog'chalar xaritasi"}</div>
          <div style={{fontSize:12,opacity:.8}}>{filtered.length} ta bog'cha · Yandex</div>
        </div>
        <button onClick={locate} style={{marginLeft:'auto',background:'rgba(255,255,255,.2)',border:'none',width:38,height:38,borderRadius:'50%',color:'#fff',cursor:'pointer',display:'flex',alignItems:'center',justifyContent:'center',fontSize:18}}>
          {locLoad?'⏳':'📍'}
        </button>
      </div>

      {/* Qidiruv */}
      <div style={{padding:'10px 16px',background:'#fff',borderBottom:'1px solid #eee',zIndex:9,flexShrink:0}}>
        <input type="text" placeholder="Bog'cha nomi yoki raqami..." value={search} onChange={e=>setSearch(e.target.value)}
          style={{width:'100%',boxSizing:'border-box',padding:'10px 14px',borderRadius:12,border:'1px solid #ddd',fontSize:14,outline:'none',background:'#F9FAFB',fontFamily:'var(--font)'}} />
      </div>

      {/* Xarita */}
      <div style={{flex:1,position:'relative',minHeight:0}}>
        <div ref={mapRef} style={{width:'100%',height:'100%',background:'#f5e6e6'}} />

        {/* Yuklash */}
        {status === 'loading' && (
          <div style={{position:'absolute',inset:0,background:'#fff',zIndex:1000,display:'flex',flexDirection:'column',alignItems:'center',justifyContent:'center',gap:12}}>
            <div style={{width:32,height:32,border:'3px solid #fde8e8',borderTopColor:'#FC3F1D',borderRadius:'50%',animation:'ym-spin .7s linear infinite'}} />
            <div style={{fontSize:13,color:'#666'}}>Yandex xaritasi yuklanmoqda...</div>
            <div style={{fontSize:11,color:'#aaa'}}>proj4 kutubxonasi tayyorlanmoqda</div>
          </div>
        )}

        {/* Xato */}
        {status === 'error' && (
          <div style={{position:'absolute',inset:0,background:'#fff',zIndex:1000,display:'flex',flexDirection:'column',alignItems:'center',justifyContent:'center',gap:12,padding:32}}>
            <div style={{fontSize:40}}>⚠️</div>
            <div style={{fontSize:15,fontWeight:700,color:'#333',textAlign:'center'}}>Yandex xaritasi yuklanmadi</div>
            <div style={{fontSize:13,color:'#666',textAlign:'center'}}>Internet aloqasini tekshiring yoki Google xaritasidan foydalaning</div>
          </div>
        )}

        {/* Tanlangan bog'cha paneli */}
        {sel && (
          <div style={{position:'absolute',bottom:0,left:0,right:0,zIndex:800,background:'#fff',borderRadius:'20px 20px 0 0',boxShadow:'0 -4px 24px rgba(0,0,0,.12)',padding:'16px 20px 28px'}}>
            <div style={{width:40,height:4,background:'#E5E7EB',borderRadius:2,margin:'0 auto 14px'}} />
            <div style={{display:'flex',alignItems:'flex-start',gap:14}}>
              <div style={{width:48,height:48,borderRadius:14,flexShrink:0,background:'linear-gradient(135deg,#b31217,#e52d27)',display:'flex',alignItems:'center',justifyContent:'center',color:'#fff',fontWeight:800,fontSize:16}}>
                {sel.number||sel.name.replace(/\D/g,'')||'?'}
              </div>
              <div style={{flex:1}}>
                <div style={{fontWeight:800,fontSize:15,color:'#111'}}>{sel.name}</div>
                {sel.address&&<div style={{fontSize:13,color:'#666',marginTop:4}}>📍 {sel.address}</div>}
                {sel.phone&&<div style={{fontSize:13,color:'#b31217',marginTop:2,fontWeight:600}}>📞 {sel.phone}</div>}
              </div>
              <button onClick={()=>setSel(null)} style={{background:'#F3F4F6',border:'none',width:30,height:30,borderRadius:'50%',cursor:'pointer',fontSize:14,flexShrink:0}}>✕</button>
            </div>
            <div style={{display:'flex',gap:10,marginTop:14}}>
              <a href={gNavUrl(sel.lat,sel.lon)} target="_blank" rel="noopener noreferrer" className="ym-bn" style={{color:'#4285F4',borderColor:'#4285F4'}}>📍 Google Maps</a>
              <a href={yNavUrl(sel.lat,sel.lon)} target="_blank" rel="noopener noreferrer" className="ym-bn" style={{color:'#FC3F1D',borderColor:'#FC3F1D'}}>📍 Yandex Maps</a>
            </div>
          </div>
        )}
      </div>
    </div>
  )
}
