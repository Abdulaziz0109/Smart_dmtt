import { useEffect, useRef, useState } from 'react'
import { useApp } from '../../context/AppContext'

function haversine(lat1, lon1, lat2, lon2) {
  const R = 6371, toRad = d => d * Math.PI / 180
  const dLat = toRad(lat2 - lat1), dLon = toRad(lon2 - lon1)
  const a = Math.sin(dLat/2)**2 + Math.cos(toRad(lat1)) * Math.cos(toRad(lat2)) * Math.sin(dLon/2)**2
  return R * 2 * Math.asin(Math.sqrt(a))
}

const STYLES = `
  .gm-cm { width:38px;height:38px;background:linear-gradient(135deg,#0B5E50,#14847A);border:3px solid #fff;border-radius:50% 50% 50% 4px;transform:rotate(-45deg);box-shadow:0 4px 14px rgba(11,94,80,.5);display:flex;align-items:center;justify-content:center;cursor:pointer }
  .gm-cm.sel { background:linear-gradient(135deg,#D97706,#F59E0B) }
  .gm-ci { transform:rotate(45deg);color:#fff;font-weight:800;font-size:10px;text-align:center;user-select:none }
  .leaflet-popup-content-wrapper { border-radius:16px!important;box-shadow:0 8px 32px rgba(11,94,80,.22)!important;padding:0!important;overflow:hidden }
  .leaflet-popup-content { margin:0!important;width:260px!important }
  .gm-ph { background:linear-gradient(135deg,#0B5E50,#14847A);padding:12px 16px;display:flex;align-items:center;gap:10px }
  .gm-pn { width:36px;height:36px;background:rgba(255,255,255,.25);border:2px solid rgba(255,255,255,.4);border-radius:10px;display:flex;align-items:center;justify-content:center;font-weight:800;font-size:14px;color:#fff;flex-shrink:0 }
  .gm-pt { color:#fff;font-weight:700;font-size:15px;line-height:1.3 }
  .gm-pb { padding:12px 16px }
  .gm-bn { display:flex;align-items:center;justify-content:center;gap:6px;padding:9px 12px;border-radius:8px;text-decoration:none;font-weight:600;font-size:12px;border:1.5px solid #eee;background:#fff;cursor:pointer;flex:1 }
  .gm-ud { width:16px;height:16px;background:#3B82F6;border-radius:50%;border:3px solid #fff;box-shadow:0 0 0 4px rgba(59,130,246,.3) }
  @keyframes gm-spin { to { transform:rotate(360deg) } }
`

const TILE_LAYERS = {
  google:    { url:'https://mt{s}.google.com/vt/lyrs=m&x={x}&y={y}&z={z}', attr:'© Google', label:'🌍 Google', opts:{ subdomains:'0123', maxZoom:20 } },
  satellite: { url:'https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}', attr:'© Esri', label:'🛰 Satellite', opts:{ maxZoom:19 } },
  osm:       { url:'https://tile.openstreetmap.org/{z}/{x}/{y}.png', attr:'© OpenStreetMap', label:'🌐 OSM', opts:{ maxZoom:19 } },
}

const yUrl = (lat, lon) => `https://yandex.com/maps/?ll=${lon},${lat}&z=16&pt=${lon},${lat},pm2gnm`
const gUrl = (lat, lon) => `https://www.google.com/maps/dir/?api=1&destination=${lat},${lon}&travelmode=driving`

export default function MapGoogle() {
  const { tr } = useApp()
  const mapRef  = useRef(null)
  const mapInst = useRef(null)
  const tileRef = useRef(null)
  const mRef    = useRef({})

  const [kgs, setKgs]           = useState([])
  const [filtered, setFiltered] = useState([])
  const [search, setSearch]     = useState('')
  const [sel, setSel]           = useState(null)
  const [locLoad, setLocLoad]   = useState(false)
  const [ready, setReady]       = useState(false)
  const [layer, setLayer]       = useState('google')

  // ── Leaflet yuklash ───────────────────────────────────────────────────────
  useEffect(() => {
    fetch('/api/kindergartens')
      .then(r => r.ok ? r.json() : { kindergartens:[] })
      .then(d => { const l = d.kindergartens||[]; setKgs(l); setFiltered(l) })
      .catch(() => {})

    if (window.L) { setReady(true); return }
    if (!document.querySelector('link[href*="leaflet"]'))
      document.head.appendChild(Object.assign(document.createElement('link'), { rel:'stylesheet', href:'https://unpkg.com/leaflet@1.9.4/dist/leaflet.css' }))
    if (!document.querySelector('script[src*="leaflet"]')) {
      const s = Object.assign(document.createElement('script'), { src:'https://unpkg.com/leaflet@1.9.4/dist/leaflet.js', onload:()=>setReady(true) })
      document.head.appendChild(s)
    } else {
      const wait = setInterval(() => { if (window.L) { clearInterval(wait); setReady(true) } }, 100)
    }
  }, [])

  // ── Xarita yaratish ───────────────────────────────────────────────────────
  useEffect(() => {
    if (!ready || !mapRef.current || mapInst.current) return
    const L = window.L
    const center = kgs.length > 0
      ? [kgs.reduce((s,k)=>s+k.lat,0)/kgs.length, kgs.reduce((s,k)=>s+k.lon,0)/kgs.length]
      : [39.762, 67.274]

    const map = L.map(mapRef.current, { center, zoom:12, zoomControl:false, dragging:true, tap:true, tapTolerance:15, touchZoom:true, scrollWheelZoom:true })
    L.control.zoom({ position:'topright' }).addTo(map)
    const cfg = TILE_LAYERS.google
    tileRef.current = L.tileLayer(cfg.url, { ...cfg.opts, attribution:cfg.attr }).addTo(map)
    mapInst.current = map

    if (kgs.length > 0) {
      try { map.fitBounds(L.featureGroup(kgs.map(k=>L.marker([k.lat,k.lon]))).getBounds().pad(0.1)) } catch(e){}
    }
    setTimeout(()=>map.invalidateSize(),150)
    setTimeout(()=>map.invalidateSize(),600)
    setTimeout(()=>map.invalidateSize(),1400)

    return () => { mapInst.current?.remove(); mapInst.current=null; tileRef.current=null; mRef.current={} }
  }, [ready, kgs])

  // ── Tile almashtirish ─────────────────────────────────────────────────────
  useEffect(() => {
    if (!mapInst.current || !window.L) return
    const map = mapInst.current, L = window.L
    if (tileRef.current) map.removeLayer(tileRef.current)
    const cfg = TILE_LAYERS[layer]
    tileRef.current = L.tileLayer(cfg.url, { ...cfg.opts, attribution:cfg.attr }).addTo(map)
  }, [layer])

  // ── Markerlar ─────────────────────────────────────────────────────────────
  useEffect(() => {
    if (!mapInst.current || !window.L || !ready) return
    const L = window.L, map = mapInst.current
    Object.entries(mRef.current).forEach(([k,m]) => { if(k!=='__user') map.removeLayer(m) })
    const nm = { __user: mRef.current.__user }
    filtered.forEach(k => {
      const num = k.number || k.name.replace(/\D/g,'') || '?'
      const icon = L.divIcon({ className:'', html:`<div class="gm-cm${sel?.id===k.id?' sel':''}"><div class="gm-ci">${num}</div></div>`, iconSize:[38,38], iconAnchor:[19,38], popupAnchor:[0,-40] })
      const popup = `<div class="gm-ph"><div class="gm-pn">${num}</div><div class="gm-pt">${k.name}</div></div>
        <div class="gm-pb">
          ${k.address?`<div style="font-size:13px;color:#555;margin-bottom:10px;line-height:1.5">📍 ${k.address}</div>`:''}
          ${k.phone?`<a href="tel:${k.phone}" style="display:block;font-size:13px;color:#0B5E50;font-weight:700;margin-bottom:12px">📞 ${k.phone}</a>`:''}
          <div style="display:flex;gap:8px">
            <a href="${gUrl(k.lat,k.lon)}" target="_blank" class="gm-bn" style="color:#4285F4;border-color:#4285F4">📍 Google</a>
            <a href="${yUrl(k.lat,k.lon)}" target="_blank" class="gm-bn" style="color:#FC3F1D;border-color:#FC3F1D">📍 Yandex</a>
          </div>
        </div>`
      nm[k.id] = L.marker([k.lat,k.lon],{icon}).addTo(map).bindPopup(popup).on('click',()=>setSel(k))
    })
    mRef.current = nm
  }, [filtered, ready, sel])

  // ── Qidiruv ───────────────────────────────────────────────────────────────
  useEffect(() => {
    const q = search.toLowerCase().trim()
    if (!q) { setFiltered(kgs); return }
    const r = kgs.filter(k => k.name.toLowerCase().includes(q)||String(k.number||'').includes(q)||(k.address||'').toLowerCase().includes(q))
    setFiltered(r)
    if (r.length===1 && mapInst.current) {
      mapInst.current.flyTo([r[0].lat,r[0].lon],16,{duration:0.8})
      setTimeout(()=>mRef.current[r[0].id]?.openPopup(),900)
    }
  }, [search, kgs])

  // ── Geolokatsiya ──────────────────────────────────────────────────────────
  const locate = () => {
    if (!navigator.geolocation) return
    setLocLoad(true)
    navigator.geolocation.getCurrentPosition(pos => {
      const {latitude:lat,longitude:lon} = pos.coords
      if (mapInst.current && window.L) {
        const L=window.L, map=mapInst.current
        if (mRef.current.__user) map.removeLayer(mRef.current.__user)
        mRef.current.__user = L.marker([lat,lon],{
          icon:L.divIcon({className:'',html:'<div class="gm-ud"></div>',iconSize:[16,16],iconAnchor:[8,8]}),zIndexOffset:1000
        }).addTo(map).bindPopup('📍 Sizning joylashuvingiz')
        if (kgs.length>0) {
          const n=[...kgs].sort((a,b)=>haversine(lat,lon,a.lat,a.lon)-haversine(lat,lon,b.lat,b.lon))[0]
          map.fitBounds(L.latLngBounds([[lat,lon],[n.lat,n.lon]]).pad(0.3))
        } else map.flyTo([lat,lon],14)
      }
      setLocLoad(false)
    }, ()=>setLocLoad(false), {enableHighAccuracy:true,timeout:10000})
  }

  return (
    <div style={{fontFamily:'var(--font)',height:'100%',display:'flex',flexDirection:'column',overflow:'hidden'}}>
      <style>{STYLES}</style>

      {/* Header */}
      <div style={{background:'linear-gradient(135deg,#0B5E50,#14847A)',padding:'16px 20px',display:'flex',alignItems:'center',gap:12,color:'#fff',boxShadow:'0 2px 12px rgba(0,0,0,.15)',zIndex:10,flexShrink:0}}>
        <div style={{width:40,height:40,background:'rgba(255,255,255,.2)',borderRadius:12,display:'flex',alignItems:'center',justifyContent:'center',fontSize:20}}>🏫</div>
        <div>
          <div style={{fontSize:17,fontWeight:700}}>{tr('map_title')||"Bog'chalar xaritasi"}</div>
          <div style={{fontSize:12,opacity:.8}}>{filtered.length} ta bog'cha</div>
        </div>
        <button onClick={locate} style={{marginLeft:'auto',background:'rgba(255,255,255,.2)',border:'none',width:38,height:38,borderRadius:'50%',color:'#fff',cursor:'pointer',display:'flex',alignItems:'center',justifyContent:'center',fontSize:18}}>
          {locLoad?'⏳':'📍'}
        </button>
      </div>

      {/* Qidiruv */}
      <div style={{padding:'10px 16px',background:'#fff',borderBottom:'1px solid #eee',zIndex:9,flexShrink:0}}>
        <input type="text" placeholder="Bog'cha nomi yoki raqami..." value={search} onChange={e=>setSearch(e.target.value)}
          style={{width:'100%',boxSizing:'border-box',padding:'10px 14px',borderRadius:12,border:'1px solid #ddd',fontSize:14,outline:'none',background:'#F9FAFB',fontFamily:'var(--font)'}} />
      </div>

      {/* Xarita */}
      <div style={{flex:1,position:'relative',minHeight:0}}>
        <div ref={mapRef} style={{width:'100%',height:'100%',background:'#E8F0EE'}} />

        {!ready && (
          <div style={{position:'absolute',inset:0,background:'#fff',zIndex:1000,display:'flex',flexDirection:'column',alignItems:'center',justifyContent:'center',gap:12}}>
            <div style={{width:32,height:32,border:'3px solid #E8F5F2',borderTopColor:'#0B5E50',borderRadius:'50%',animation:'gm-spin .7s linear infinite'}} />
            <div style={{fontSize:13,color:'#666'}}>Xarita yuklanmoqda...</div>
          </div>
        )}

        {/* Layer tugmalari */}
        <div style={{position:'absolute',bottom:sel?175:24,right:12,zIndex:900,background:'#fff',borderRadius:14,padding:6,boxShadow:'0 4px 24px rgba(0,0,0,.15)',display:'flex',flexDirection:'column',gap:4,transition:'bottom .3s'}}>
          {Object.entries(TILE_LAYERS).map(([id,cfg]) => (
            <button key={id} onClick={()=>setLayer(id)} style={{
              padding:'8px 12px',border:'none',borderRadius:10,fontSize:12,fontWeight:600,cursor:'pointer',textAlign:'left',transition:'all .2s',
              background:layer===id?'#0B5E50':'#F0F7F5', color:layer===id?'#fff':'#0B5E50',
            }}>{cfg.label}</button>
          ))}
        </div>

        {/* Tanlangan bog'cha paneli */}
        {sel && (
          <div style={{position:'absolute',bottom:0,left:0,right:0,zIndex:800,background:'#fff',borderRadius:'20px 20px 0 0',boxShadow:'0 -4px 24px rgba(0,0,0,.12)',padding:'16px 20px 28px'}}>
            <div style={{width:40,height:4,background:'#E5E7EB',borderRadius:2,margin:'0 auto 14px'}} />
            <div style={{display:'flex',alignItems:'flex-start',gap:14}}>
              <div style={{width:48,height:48,borderRadius:14,flexShrink:0,background:'linear-gradient(135deg,#0B5E50,#14847A)',display:'flex',alignItems:'center',justifyContent:'center',color:'#fff',fontWeight:800,fontSize:16}}>
                {sel.number||sel.name.replace(/\D/g,'')||'?'}
              </div>
              <div style={{flex:1}}>
                <div style={{fontWeight:800,fontSize:15,color:'#111'}}>{sel.name}</div>
                {sel.address&&<div style={{fontSize:13,color:'#666',marginTop:4}}>📍 {sel.address}</div>}
                {sel.phone&&<div style={{fontSize:13,color:'#0B5E50',marginTop:2,fontWeight:600}}>📞 {sel.phone}</div>}
              </div>
              <button onClick={()=>setSel(null)} style={{background:'#F3F4F6',border:'none',width:30,height:30,borderRadius:'50%',cursor:'pointer',fontSize:14,flexShrink:0}}>✕</button>
            </div>
            <div style={{display:'flex',gap:10,marginTop:14}}>
              <a href={gUrl(sel.lat,sel.lon)} target="_blank" rel="noopener noreferrer" className="gm-bn" style={{color:'#4285F4',borderColor:'#4285F4'}}>📍 Google Maps</a>
              <a href={yUrl(sel.lat,sel.lon)} target="_blank" rel="noopener noreferrer" className="gm-bn" style={{color:'#FC3F1D',borderColor:'#FC3F1D'}}>📍 Yandex Maps</a>
            </div>
          </div>
        )}
      </div>
    </div>
  )
}
