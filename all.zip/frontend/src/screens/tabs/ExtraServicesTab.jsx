/**
 * ExtraServicesTab — Qo'shimcha xizmatlar (ota-ona)
 */
import { useState, useEffect } from 'react'
import { useApp } from '../../context/AppContext'

const SVC_TYPES = [
  { v:'late_pickup',   l:'🕐 Kechroq olish',      rate: 8000  },
  { v:'early_dropoff', l:'🌅 Ertaroq olib ketish', rate: 5000  },
  { v:'individual',    l:'📚 Individual dars',      rate: 35000 },
  { v:'lunch',         l:'🍱 Tushlik',              rate: 15000 },
  { v:'transport',     l:'🚌 Transport',             rate: 20000 },
]
const STATUS_C = { pending:'#F59E0B', confirmed:'#10B981', cancelled:'#EF4444' }
const STATUS_L = { pending:'Kutilmoqda', confirmed:'Tasdiqlandi', cancelled:'Bekor qilindi' }

function Card({ children, style }) {
  return <div style={{ background:'#fff', borderRadius:16, padding:16, border:'1.5px solid #E2EBF0', boxShadow:'0 2px 8px rgba(10,50,80,0.06)', ...style }}>{children}</div>
}

export default function ExtraServicesTab() {
  const { token, user } = useApp()
  const [list, setList]         = useState([])
  const [children, setChildren] = useState([])
  const [loading, setLoading]   = useState(true)
  const [showForm, setShowForm] = useState(false)
  const [form, setForm]         = useState({ child_id:'', service_type:'late_pickup', service_date: new Date().toISOString().slice(0,10), end_time:'', amount: 8000 })
  const [saving, setSaving]     = useState(false)
  const [msg, setMsg]           = useState('')

  const h = { Authorization:`Bearer ${token}`, 'Content-Type':'application/json', 'ngrok-skip-browser-warning':'true' }

  useEffect(() => {
    fetch('/api/children', { headers: h }).then(r => r.json()).then(d => setChildren(d.children || []))
    load()
  }, [])

  const load = async () => {
    setLoading(true)
    try {
      const r = await fetch('/api/extra-services', { headers: h })
      const d = await r.json()
      setList(d.services || [])
    } catch { setList([]) } finally { setLoading(false) }
  }

  const selectType = (v) => {
    const svc = SVC_TYPES.find(s => s.v === v)
    setForm(f => ({ ...f, service_type: v, amount: svc?.rate || 0 }))
  }

  const submit = async () => {
    if (!form.child_id) { setMsg('Farzandni tanlang'); return }
    setSaving(true); setMsg('')
    try {
      const r = await fetch('/api/extra-services', { method:'POST', headers: h, body: JSON.stringify(form) })
      if (r.ok) { setMsg('Qo\'shildi ✅'); setShowForm(false); load() }
      else { const d = await r.json(); setMsg(d.detail || 'Xatolik') }
    } catch { setMsg('Tarmoq xatosi') } finally { setSaving(false) }
  }

  const cancel = async (id) => {
    await fetch(`/api/extra-services/${id}/cancel`, { method:'PATCH', headers: h })
    load()
  }

  return (
    <div style={{ padding:'16px 12px', fontFamily:'var(--font)' }}>
      <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:16 }}>
        <div>
          <div style={{ fontSize:20, fontWeight:900, color:'#0B5E50' }}>Qo'shimcha xizmatlar</div>
          <div style={{ fontSize:12, color:'#8A9BAB' }}>Kechroq olish va boshqalar</div>
        </div>
        <button onClick={() => setShowForm(!showForm)} style={{ padding:'8px 16px', borderRadius:20, border:'none', background:'#0B5E50', color:'#fff', fontWeight:700, fontSize:13, cursor:'pointer' }}>
          {showForm ? '✕' : '+ Yangi'}
        </button>
      </div>

      {showForm && (
        <Card style={{ marginBottom:16 }}>
          <div style={{ fontSize:14, fontWeight:800, marginBottom:12 }}>Yangi xizmat</div>

          <div style={{ marginBottom:10 }}>
            <label style={{ fontSize:11, fontWeight:700, color:'#8A9BAB', display:'block', marginBottom:4 }}>Farzand</label>
            <select value={form.child_id} onChange={e => setForm(f => ({...f, child_id: e.target.value}))}
              style={{ width:'100%', padding:10, borderRadius:10, border:'2px solid #E2EBF0', fontSize:13, fontFamily:'var(--font)', outline:'none' }}>
              <option value=''>Tanlang...</option>
              {children.map(c => <option key={c.id} value={c.id}>{c.full_name}</option>)}
            </select>
          </div>

          <div style={{ marginBottom:10 }}>
            <label style={{ fontSize:11, fontWeight:700, color:'#8A9BAB', display:'block', marginBottom:4 }}>Xizmat turi</label>
            <div style={{ display:'flex', gap:6, flexWrap:'wrap' }}>
              {SVC_TYPES.map(s => (
                <button key={s.v} onClick={() => selectType(s.v)} style={{ padding:'6px 12px', borderRadius:16, border:'none', cursor:'pointer', fontSize:11, fontWeight:700, background: form.service_type === s.v ? '#0B5E50' : '#F0F4F8', color: form.service_type === s.v ? '#fff' : '#4A6070' }}>
                  {s.l}
                </button>
              ))}
            </div>
          </div>

          <div style={{ display:'flex', gap:10, marginBottom:10 }}>
            <div style={{ flex:1 }}>
              <label style={{ fontSize:11, fontWeight:700, color:'#8A9BAB', display:'block', marginBottom:4 }}>Sana</label>
              <input type='date' value={form.service_date} onChange={e => setForm(f => ({...f, service_date: e.target.value}))}
                style={{ width:'100%', padding:10, borderRadius:10, border:'2px solid #E2EBF0', fontSize:13, boxSizing:'border-box', outline:'none' }} />
            </div>
            <div style={{ flex:1 }}>
              <label style={{ fontSize:11, fontWeight:700, color:'#8A9BAB', display:'block', marginBottom:4 }}>Vaqt (ixtiyoriy)</label>
              <input type='time' value={form.end_time} onChange={e => setForm(f => ({...f, end_time: e.target.value}))}
                style={{ width:'100%', padding:10, borderRadius:10, border:'2px solid #E2EBF0', fontSize:13, boxSizing:'border-box', outline:'none' }} />
            </div>
          </div>

          <div style={{ padding:12, borderRadius:10, background:'#F0FAF7', marginBottom:12 }}>
            <span style={{ fontSize:13, fontWeight:700, color:'#0B5E50' }}>Narx: +{form.amount.toLocaleString()} so'm</span>
          </div>

          {msg && <div style={{ color: msg.includes('✅') ? '#10B981' : '#EF4444', fontSize:12, marginBottom:8 }}>{msg}</div>}

          <button onClick={submit} disabled={saving} style={{ width:'100%', padding:12, borderRadius:10, border:'none', background:'#0B5E50', color:'#fff', fontWeight:800, fontSize:14, cursor:'pointer', opacity: saving ? 0.7 : 1 }}>
            {saving ? 'Yuborilmoqda...' : 'So\'rov yuborish'}
          </button>
        </Card>
      )}

      {loading ? (
        <div style={{ textAlign:'center', padding:40, color:'#8A9BAB' }}>Yuklanmoqda...</div>
      ) : list.length === 0 ? (
        <div style={{ textAlign:'center', padding:40, color:'#8A9BAB' }}>Xizmatlar yo'q</div>
      ) : (
        list.map(s => (
          <Card key={s.id} style={{ marginBottom:10 }}>
            <div style={{ display:'flex', justifyContent:'space-between', alignItems:'flex-start' }}>
              <div>
                <div style={{ fontSize:14, fontWeight:800 }}>{SVC_TYPES.find(t => t.v === s.service_type)?.l || s.service_type}</div>
                <div style={{ fontSize:12, color:'#8A9BAB', marginTop:3 }}>{s.date} {s.end_time && `· ${s.end_time}`}</div>
              </div>
              <div style={{ textAlign:'right' }}>
                <span style={{ fontSize:11, fontWeight:700, padding:'3px 8px', borderRadius:8, background: STATUS_C[s.status] + '20', color: STATUS_C[s.status] }}>{STATUS_L[s.status]}</span>
                <div style={{ fontSize:13, fontWeight:800, color:'#0B5E50', marginTop:4 }}>{Number(s.amount).toLocaleString()} so'm</div>
              </div>
            </div>
            {s.status === 'pending' && (
              <button onClick={() => cancel(s.id)} style={{ marginTop:10, padding:'6px 14px', borderRadius:16, border:'none', background:'#FEF2F2', color:'#EF4444', fontWeight:700, fontSize:12, cursor:'pointer' }}>
                Bekor qilish
              </button>
            )}
          </Card>
        ))
      )}
    </div>
  )
}
