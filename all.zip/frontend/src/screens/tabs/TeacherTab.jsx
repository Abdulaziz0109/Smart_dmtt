/**
 * SmartDMTT v4 — TeacherTab (to'liq)
 * Davomat belgilash, haftalik hisobot, bulk mark, i18n
 */
import { useState, useEffect, useCallback } from 'react'
import { useApp } from '../../context/AppContext'
import { useTranslation } from '../../hooks/useTranslation'

const API = (p) => `/api${p}`
const H   = (tk) => ({ Authorization: `Bearer ${tk}`, 'Content-Type': 'application/json', 'ngrok-skip-browser-warning': 'true' })

const shimmer = `@keyframes shimmer{0%{background-position:200% 0}100%{background-position:-200% 0}}`

function Skeleton({ w='100%', h=16, r=8, mb=8 }) {
  return <div style={{ width:w, height:h, borderRadius:r, marginBottom:mb,
    background:'linear-gradient(90deg,#f0f0f0 25%,#e8e8e8 50%,#f0f0f0 75%)',
    backgroundSize:'200% 100%', animation:'shimmer 1.4s infinite' }} />
}

const STATUS_CONFIG = {
  present: { icon: '✅', label: 'Keldi',      bg: '#dcfce7', color: '#166534' },
  absent:  { icon: '❌', label: 'Kelmadi',    bg: '#fee2e2', color: '#991b1b' },
  late:    { icon: '⏰', label: 'Kech keldi', bg: '#fef9c3', color: '#854d0e' },
  excused: { icon: '📝', label: 'Sababli',    bg: '#ede9fe', color: '#5b21b6' },
}

function StatusBtn({ status, current, onClick }) {
  const cfg    = STATUS_CONFIG[status]
  const active = current === status
  return (
    <button onClick={() => onClick(status)} style={{
      padding: '6px 12px', borderRadius: 20, border: 'none', cursor: 'pointer',
      fontWeight: 600, fontSize: 12,
      background: active ? cfg.bg : '#f3f4f6',
      color:      active ? cfg.color : '#9ca3af',
      outline:    active ? `2px solid ${cfg.color}` : 'none',
      outlineOffset: 1,
      transition: 'all 0.15s',
    }}>
      {cfg.icon} {cfg.label}
    </button>
  )
}

function StudentRow({ record, onMark, saving }) {
  const [status, setStatus] = useState(record.status || null)

  const mark = async (s) => {
    setStatus(s)
    await onMark(record.enrollment_id, s)
  }

  return (
    <div style={{ padding: '12px 16px', borderBottom: '1px solid var(--border)' }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 8 }}>
        <div>
          <span style={{ fontWeight: 700, fontSize: 14 }}>{record.child_name}</span>
          {record.has_notice && (
            <span style={{ marginLeft: 8, background: '#fef3c7', color: '#92400e',
              borderRadius: 10, padding: '2px 8px', fontSize: 11, fontWeight: 600 }}>
              📅 Sababli
            </span>
          )}
        </div>
        <span style={{ fontSize: 11, color: 'var(--text-light)' }}>
          ID: {record.payment_id?.slice(-6)}
        </span>
      </div>
      <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap' }}>
        {Object.keys(STATUS_CONFIG).map(s => (
          <StatusBtn key={s} status={s} current={status} onClick={mark} />
        ))}
      </div>
    </div>
  )
}

export default function TeacherTab() {
  const { token, user } = useApp()
  const { t } = useTranslation()

  const [clubs,    setClubs]   = useState([])
  const [selClub,  setSelClub] = useState(null)
  const [records,  setRecords] = useState([])
  const [stats,    setStats]   = useState(null)
  const [weekly,   setWeekly]  = useState(null)
  const [loading,  setLoading] = useState(true)
  const [saving,   setSaving]  = useState(false)
  const [bulkMode, setBulk]    = useState(false)
  const [msg,      setMsg]     = useState(null)
  const [view,     setView]    = useState('today')  // 'today' | 'weekly'

  const flash = (text, ok=true) => { setMsg({text,ok}); setTimeout(()=>setMsg(null), 3000) }

  // To'garaklar
  useEffect(() => {
    fetch(API('/clubs'), { headers: H(token) })
      .then(r => r.json())
      .then(data => {
        const list = Array.isArray(data) ? data : data.clubs || []
        setClubs(list)
        if (list.length > 0) setSelClub(list[0].id)
        setLoading(false)
      })
      .catch(() => setLoading(false))
  }, [token])

  // Kunlik davomat
  const loadToday = useCallback(async (clubId) => {
    if (!clubId) return
    setLoading(true)
    try {
      const r = await fetch(API(`/attendance/club/${clubId}/today`), { headers: H(token) })
      const d = await r.json()
      setRecords(d.records || [])
      setStats({ total: d.total, present: d.present, absent: d.absent, pct: d.pct })
    } catch(e) { flash('Xatolik: ' + e.message, false) }
    setLoading(false)
  }, [token])

  // Haftalik hisobot
  const loadWeekly = useCallback(async (clubId) => {
    if (!clubId) return
    setLoading(true)
    try {
      const r = await fetch(API(`/attendance/club/${clubId}/weekly`), { headers: H(token) })
      const d = await r.json()
      setWeekly(d.days || [])
    } catch(e) { flash('Xatolik', false) }
    setLoading(false)
  }, [token])

  useEffect(() => {
    if (!selClub) return
    if (view === 'today')  loadToday(selClub)
    if (view === 'weekly') loadWeekly(selClub)
  }, [selClub, view])

  const markOne = async (enrollmentId, status) => {
    setSaving(true)
    try {
      await fetch(API('/attendance/mark'), {
        method: 'POST', headers: H(token),
        body: JSON.stringify({ enrollment_id: enrollmentId, status }),
      })
    } catch(e) { flash('Saqlashda xato', false) }
    setSaving(false)
  }

  const markAll = async (status) => {
    if (!records.length) return
    setSaving(true)
    try {
      const body = {
        records: records.map(r => ({ enrollment_id: r.enrollment_id, status })),
      }
      await fetch(API('/attendance/bulk'), {
        method: 'POST', headers: H(token), body: JSON.stringify(body),
      })
      flash(`✅ Hammasi "${STATUS_CONFIG[status].label}" deb belgilandi`)
      loadToday(selClub)
    } catch(e) { flash('Xatolik', false) }
    setSaving(false)
  }

  const dayNames = ['Du', 'Se', 'Ch', 'Pa', 'Ju', 'Sh', 'Ya']

  return (
    <>
      <style>{shimmer}</style>
      <div style={{ padding: '20px 16px' }}>
        <h2 style={{ margin: '0 0 16px', fontWeight: 800 }}>📚 {t('mark_attendance')}</h2>

        {msg && (
          <div style={{ padding: '10px 16px', borderRadius: 12, marginBottom: 12,
            background: msg.ok ? '#dcfce7' : '#fee2e2',
            color: msg.ok ? '#166534' : '#991b1b', fontWeight: 600 }}>
            {msg.text}
          </div>
        )}

        {/* To'garak tanlash */}
        {clubs.length > 1 && (
          <select value={selClub || ''} onChange={e => setSelClub(Number(e.target.value))}
            style={{ width: '100%', padding: '10px 14px', borderRadius: 12,
              border: '1px solid var(--border)', fontSize: 14, marginBottom: 14,
              outline: 'none', background: '#fff' }}>
            {clubs.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
          </select>
        )}

        {/* View tabs */}
        <div style={{ display: 'flex', gap: 8, marginBottom: 16 }}>
          {[['today','📅 Bugun'],['weekly','📊 Haftalik']].map(([id,label]) => (
            <button key={id} onClick={() => setView(id)} style={{
              flex: 1, padding: '9px', borderRadius: 12, border: 'none', cursor: 'pointer',
              fontWeight: 600, fontSize: 13,
              background: view === id ? 'var(--primary)' : 'var(--primary-50)',
              color:      view === id ? '#fff' : 'var(--primary)',
            }}>{label}</button>
          ))}
        </div>

        {/* Bugungi ko'rinish */}
        {view === 'today' && (
          <>
            {/* Stats */}
            {stats && (
              <div style={{ display: 'flex', gap: 10, marginBottom: 14 }}>
                {[
                  ['✅', stats.present, '#dcfce7', '#166534', 'Keldi'],
                  ['❌', stats.absent,  '#fee2e2', '#991b1b', 'Kelmadi'],
                  ['📊', stats.pct + '%', '#dbeafe', '#1d4ed8', 'Davomat'],
                ].map(([icon, val, bg, color, label]) => (
                  <div key={label} style={{ flex: 1, background: bg, borderRadius: 12,
                    padding: '10px 12px', textAlign: 'center' }}>
                    <div style={{ fontSize: 18 }}>{icon}</div>
                    <div style={{ fontWeight: 800, fontSize: 18, color }}>{val}</div>
                    <div style={{ fontSize: 11, color, opacity: 0.8 }}>{label}</div>
                  </div>
                ))}
              </div>
            )}

            {/* Bulk */}
            <div style={{ display: 'flex', gap: 8, marginBottom: 14 }}>
              <button onClick={() => markAll('present')} disabled={saving}
                style={{ flex: 1, padding: '8px', borderRadius: 10, border: 'none',
                  cursor: 'pointer', fontWeight: 600, fontSize: 12,
                  background: '#dcfce7', color: '#166534', opacity: saving ? 0.5 : 1 }}>
                ✅ Hammasi bor
              </button>
              <button onClick={() => markAll('absent')} disabled={saving}
                style={{ flex: 1, padding: '8px', borderRadius: 10, border: 'none',
                  cursor: 'pointer', fontWeight: 600, fontSize: 12,
                  background: '#fee2e2', color: '#991b1b', opacity: saving ? 0.5 : 1 }}>
                ❌ Hammasi yo'q
              </button>
            </div>

            {/* O'quvchilar */}
            <div style={{ background: '#fff', borderRadius: 16, border: '1px solid var(--border)', overflow: 'hidden' }}>
              {loading ? (
                [1,2,3,4].map(i => (
                  <div key={i} style={{ padding: '14px 16px', borderBottom: '1px solid var(--border)' }}>
                    <Skeleton w="50%" h={16} /><Skeleton w="80%" h={32} r={16} />
                  </div>
                ))
              ) : records.length === 0 ? (
                <div style={{ padding: 32, textAlign: 'center', color: 'var(--text-light)' }}>
                  O'quvchilar yo'q
                </div>
              ) : (
                records.map(r => (
                  <StudentRow key={r.enrollment_id} record={r}
                    onMark={markOne} saving={saving} />
                ))
              )}
            </div>
          </>
        )}

        {/* Haftalik ko'rinish */}
        {view === 'weekly' && (
          <div style={{ background: '#fff', borderRadius: 16, border: '1px solid var(--border)', overflow: 'hidden' }}>
            {loading ? (
              [1,2,3,4,5].map(i => (
                <div key={i} style={{ padding: '12px 16px', borderBottom: '1px solid var(--border)', display:'flex', gap:12 }}>
                  <Skeleton w={40} h={16} r={4} mb={0} />
                  <Skeleton h={16} mb={0} />
                </div>
              ))
            ) : !weekly || weekly.length === 0 ? (
              <div style={{ padding: 32, textAlign: 'center', color: 'var(--text-light)' }}>
                Ma'lumot yo'q
              </div>
            ) : (
              weekly.map((day, i) => {
                const d    = new Date(day.date)
                const name = dayNames[d.getDay() === 0 ? 6 : d.getDay() - 1]
                const pct  = day.pct
                const bar  = Math.round(pct / 10)
                return (
                  <div key={i} style={{ padding: '12px 16px', borderBottom: '1px solid var(--border)' }}>
                    <div style={{ display:'flex', justifyContent:'space-between', marginBottom:6 }}>
                      <span style={{ fontWeight:700, fontSize:13 }}>
                        {name} {d.toLocaleDateString('uz-UZ', {day:'2-digit',month:'short'})}
                      </span>
                      <span style={{ fontSize:13, fontWeight:600, color: pct>=80?'#059669':pct>=60?'#d97706':'#ef4444' }}>
                        {day.present}/{day.total} ({pct}%)
                      </span>
                    </div>
                    <div style={{ display:'flex', gap:2 }}>
                      {Array.from({length:10}).map((_,j) => (
                        <div key={j} style={{ flex:1, height:6, borderRadius:3,
                          background: j < bar ? (pct>=80?'#22c55e':pct>=60?'#f59e0b':'#ef4444') : '#e5e7eb' }} />
                      ))}
                    </div>
                  </div>
                )
              })
            )}
          </div>
        )}
      </div>
    </>
  )
}
