import { useState, useEffect } from 'react'
import { useApp } from '../context/AppContext'
import LegalModal from '../components/LegalModal'

const STEP = { PHONE: 'phone', PASSWORD: 'password', REGISTER: 'register', OTP: 'otp' }

function formatPhone(val) {
  const d = val.replace(/\D/g, '')
  if (d.startsWith('998')) return '+' + d
  if (d.startsWith('0'))   return '+998' + d.slice(1)
  if (d.length > 0 && !d.startsWith('9')) return '+998' + d
  return '+998' + d
}

// FastAPI validation xatosini string ga o'tkazish
function parseApiError(data) {
  if (!data) return 'Noma\'lum xatolik'
  if (Array.isArray(data.detail)) return data.detail[0]?.msg || 'Xatolik yuz berdi'
  if (typeof data.detail === 'string') return data.detail
  return 'Xatolik yuz berdi'
}

export default function LoginPage() {
  const { tr, login, LANGUAGES, lang, setLang } = useApp()

  const [step,           setStep]           = useState(STEP.PHONE)
  const [phone,          setPhone]          = useState('')
  const [fullName,       setFullName]       = useState('')
  const [password,       setPassword]       = useState('')
  const [showPassword,   setShowPassword]   = useState(false)
  const [otp,            setOtp]            = useState('')
  const [agreed,         setAgreed]         = useState(false)
  const [loading,        setLoading]        = useState(false)
  const [error,          setError]          = useState('')
  const [legalType,      setLegalType]      = useState(null)
  const [showLangPicker, setShowLangPicker] = useState(false)
  const [deviceId,       setDeviceId]       = useState('')

  useEffect(() => {
    let mounted = true
    const init = async () => {
      const cached = localStorage.getItem('device_fingerprint')
      if (cached) {
        if (mounted) setDeviceId(cached)
        return
      }
      try {
        const FingerprintJS = (await import('@fingerprintjs/fingerprintjs')).default
        const fp = await FingerprintJS.load()
        const result = await fp.get()
        if (mounted) {
          setDeviceId(result.visitorId)
          localStorage.setItem('device_fingerprint', result.visitorId)
        }
      } catch {}
    }
    init()
    return () => { mounted = false }
  }, [])

  const handleCheckPhone = async () => {
    const formatted = formatPhone(phone)
    if (formatted.length < 13) { setError('+998XXXXXXXXX formatida kiriting'); return }

    setError(''); setLoading(true)
    try {
      const res = await fetch('/api/auth/check-phone', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ phone: formatted })
      })
      const data = await res.json()
      if (res.ok) {
        const exists = Boolean(data.exists)
        setStep(exists ? STEP.PASSWORD : STEP.REGISTER)
      } else {
        setError(parseApiError(data))
      }
    } catch {
      setError(tr('network_error') || 'Tarmoq xatosi')
    } finally {
      setLoading(false)
    }
  }

  const handleLogin = async () => {
    const formatted = formatPhone(phone)
    if (formatted.length < 13) { setError('+998XXXXXXXXX formatida kiriting'); return }
    if (!password || password.length < 6) { setError("Parol kamida 6 belgidan iborat bo'lishi kerak"); return }

    setError(''); setLoading(true)
    try {
      const res = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 
          'Content-Type': 'application/json',
          'ngrok-skip-browser-warning': 'true'
        },
        body: JSON.stringify({ phone: formatted, password, device_id: deviceId })
      })
      const data = await res.json()

      if (res.ok && data.status === 'success') {
        login(
          {
            ...data.user,
            roles: data.roles,
            firstName: data.user.full_name?.split(' ')[0] || 'Foydalanuvchi'
          },
          data.token
        )
        return
      }

      if (res.ok && data.status === 'otp_required') {
        const otpRes = await fetch('/api/auth/send-otp', {
          method: 'POST',
          headers: { 
            'Content-Type': 'application/json',
            'ngrok-skip-browser-warning': 'true'
          },
          body: JSON.stringify({ phone: formatted, password, device_id: deviceId })
        })
        const otpData = await otpRes.json()
        if (otpRes.ok) {
          if (otpData.status === 'trusted_device') {
            login(
              {
                ...otpData.user,
                roles: otpData.roles,
                firstName: otpData.user.full_name?.split(' ')[0] || 'Foydalanuvchi'
              },
              otpData.token
            )
          } else {
            setStep(STEP.OTP)
          }
        } else {
          setError(parseApiError(otpData))
        }
        return
      }

      setError(parseApiError(data))
    } catch {
      setError(tr('network_error') || 'Tarmoq xatosi')
    } finally {
      setLoading(false)
    }
  }

  const handleRegister = async () => {
    const formatted = formatPhone(phone)
    if (formatted.length < 13) { setError('+998XXXXXXXXX formatida kiriting'); return }
    if (!fullName.trim()) { setError('Ism familiya kiriting'); return }
    if (!password || password.length < 6) { setError("Parol kamida 6 belgidan iborat bo'lishi kerak"); return }

    setError(''); setLoading(true)
    try {
      const res = await fetch('/api/auth/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ phone: formatted, password, full_name: fullName.trim(), language: lang })
      })
      const data = await res.json()
      if (res.ok) {
        login(
          {
            ...data.user,
            roles: data.roles,
            firstName: data.user.full_name?.split(' ')[0] || 'Foydalanuvchi'
          },
          data.token
        )
      } else {
        setError(parseApiError(data))
      }
    } catch {
      setError(tr('network_error') || 'Tarmoq xatosi')
    } finally {
      setLoading(false)
    }
  }

  // ─── 2-qadam: OTP tekshirish → JWT token ────────────────────────────────────
  const handleVerifyOTP = async () => {
    if (otp.length < 4) { setError('Tasdiqlash kodini kiriting'); return }

    setError(''); setLoading(true)
    try {
      const formatted = formatPhone(phone)
      const res = await fetch('/api/auth/verify-otp', {
        method: 'POST',
        headers: { 
          'Content-Type': 'application/json',
          'ngrok-skip-browser-warning': 'true'
        },
        body: JSON.stringify({
          phone: formatted,
          otp,
          device_id: deviceId,
          device_info: navigator.userAgent
        })
      })
      const data = await res.json()

      if (res.ok) {
        login(
          {
            ...data.user,
            roles: data.roles,
            firstName: data.user.full_name?.split(' ')[0] || 'Foydalanuvchi'
          },
          data.token
        )
      } else {
        setError(parseApiError(data))
      }
    } catch {
      setError(tr('network_error') || 'Tarmoq xatosi')
    } finally {
      setLoading(false)
    }
  }

  return (
    <div style={{
      minHeight: '100dvh', display: 'flex', flexDirection: 'column',
      background: 'var(--bg)', fontFamily: 'var(--font)',
      overflowX: 'hidden',
    }}>
      <style>{`
        .login-input {
          width: 100%; padding: 14px 16px;
          border: 2px solid var(--border); border-radius: 14px;
          font-size: 16px; font-family: var(--font);
          background: #FAFBFC; color: var(--text);
          transition: border-color 0.2s, box-shadow 0.2s;
          outline: none; box-sizing: border-box;
        }
        .login-input:focus {
          border-color: var(--primary);
          box-shadow: 0 0 0 3px rgba(11,94,80,0.12);
        }
        .otp-input {
          width: 100%; padding: 18px;
          border: 2px solid var(--border); border-radius: 14px;
          font-size: 32px; letter-spacing: 16px; font-weight: 900;
          text-align: center; font-family: monospace;
          background: #FAFBFC; color: var(--text);
          transition: border-color 0.2s; outline: none; box-sizing: border-box;
        }
        .otp-input:focus {
          border-color: var(--primary);
          box-shadow: 0 0 0 3px rgba(11,94,80,0.12);
        }
        .btn-main {
          width: 100%; padding: 15px; border: none; border-radius: 14px;
          background: linear-gradient(135deg, var(--primary), var(--primary-light));
          color: #fff; font-size: 16px; font-weight: 700; font-family: var(--font);
          cursor: pointer; transition: opacity 0.18s, transform 0.12s;
          box-shadow: 0 6px 20px rgba(11,94,80,0.25);
        }
        .btn-main:hover:not(:disabled) { opacity: 0.92; transform: translateY(-1px); }
        .btn-main:active:not(:disabled) { transform: translateY(0) scale(0.98); }
        .btn-main:disabled { opacity: 0.45; cursor: not-allowed; box-shadow: none; }
        .link-btn {
          background: none; border: none; color: var(--primary);
          cursor: pointer; font-size: 13.5px; font-family: var(--font);
          font-weight: 700; text-decoration: underline; padding: 0;
        }
        .lang-item {
          padding: 11px 16px; border-radius: 12px; cursor: pointer;
          display: flex; align-items: center; gap: 10px;
          font-size: 14px; font-weight: 600; transition: background 0.15s;
        }
        .lang-item:hover { background: var(--primary-50); }
        .lang-item.active { background: var(--primary-50); color: var(--primary); }
        @keyframes cardIn {
          from { opacity:0; transform: translateY(24px); }
          to   { opacity:1; transform: translateY(0); }
        }
        .login-card { animation: cardIn 0.4s ease forwards; }
      `}</style>

      {/* Header */}
      <div style={{
        background: 'linear-gradient(160deg, #083D34 0%, #0B5E50 60%, #0D8B6E 100%)',
        padding: '40px 24px 72px',
        position: 'relative', overflow: 'hidden',
        borderRadius: '0 0 36px 36px',
      }}>
        <div style={{ position:'absolute', right:-30, top:-30, width:160, height:160, borderRadius:'50%', background:'rgba(255,255,255,0.05)' }} />
        <div style={{ position:'absolute', left:-20, bottom:-40, width:120, height:120, borderRadius:'50%', background:'rgba(255,255,255,0.04)' }} />

        {/* Til tanlash */}
        <div style={{ display:'flex', justifyContent:'flex-end', marginBottom:24, position:'relative', zIndex:2 }}>
          <button onClick={() => setShowLangPicker(v => !v)} style={{
            background:'rgba(255,255,255,0.18)', border:'1px solid rgba(255,255,255,0.25)',
            borderRadius:10, padding:'7px 14px', color:'#fff',
            fontSize:13, fontWeight:700, cursor:'pointer', fontFamily:'var(--font)',
            display:'flex', alignItems:'center', gap:6,
          }}>
            {LANGUAGES.find(l => l.code === lang)?.flag} {LANGUAGES.find(l => l.code === lang)?.label}
            <span style={{ fontSize:10 }}>▼</span>
          </button>
          {showLangPicker && (
            <>
              <div style={{ position:'fixed', inset:0, zIndex:98 }} onClick={() => setShowLangPicker(false)} />
              <div style={{
                position:'absolute', top:40, right:0, background:'#fff',
                borderRadius:16, padding:8, boxShadow:'0 8px 32px rgba(0,0,0,0.15)',
                zIndex:99, minWidth:180,
              }}>
                {LANGUAGES.map(l => (
                  <div key={l.code} className={`lang-item${l.code === lang ? ' active' : ''}`}
                    onClick={() => { setLang(l.code); setShowLangPicker(false) }}>
                    <span style={{ fontSize:20 }}>{l.flag}</span>
                    <span>{l.label}</span>
                    {l.code === lang && <span style={{ marginLeft:'auto', color:'var(--primary)' }}>✓</span>}
                  </div>
                ))}
              </div>
            </>
          )}
        </div>

        {/* Logo */}
        <div style={{ display:'flex', alignItems:'center', gap:14, marginBottom:20, position:'relative', zIndex:2 }}>
          <div style={{
            width:56, height:56, background:'rgba(255,255,255,0.18)',
            borderRadius:18, display:'flex', alignItems:'center', justifyContent:'center',
            fontSize:30, border:'1.5px solid rgba(255,255,255,0.25)',
          }}>🏫</div>
          <div>
            <div style={{ color:'#fff', fontWeight:900, fontSize:22 }}>Smart MMTB</div>
            <div style={{ color:'rgba(255,255,255,0.65)', fontSize:13 }}>{tr('app_subtitle')}</div>
          </div>
        </div>

        <div style={{ color:'#fff', fontSize:26, fontWeight:900, lineHeight:1.25, position:'relative', zIndex:2 }}>
          {step === STEP.PHONE
            ? tr('welcome')
            : step === STEP.OTP
              ? '📱 Tasdiqlash kodi'
              : step === STEP.REGISTER
                ? '📝 Roʻyxatdan oʻtish'
                : '🔑 Parol'}
        </div>
        <div style={{ color:'rgba(255,255,255,0.7)', fontSize:14, marginTop:6, position:'relative', zIndex:2 }}>
          {step === STEP.PHONE
            ? tr('welcome_sub')
            : step === STEP.OTP
              ? `${formatPhone(phone)} raqamiga Telegram bot orqali kod yuborildi`
              : `${formatPhone(phone)} raqami tasdiqlandi`}
        </div>
      </div>

      {/* Forma */}
      <div style={{ padding:'0 18px', marginTop:-28, flex:1 }}>
        <div className="login-card" style={{
          background:'#fff', borderRadius:24,
          padding:24, marginBottom:16,
          boxShadow:'0 8px 40px rgba(10,50,80,0.12)',
        }}>

          {/* ── TELEFON + PAROL ────────────────────────────────────────────── */}
          {step === STEP.PHONE && (
            <div style={{ display:'flex', flexDirection:'column', gap:18 }}>

              {/* Telefon */}
              <div>
                <label style={{ fontSize:13, fontWeight:700, color:'var(--text-mid)', display:'block', marginBottom:8 }}>
                  {tr('phone_label')}
                </label>
                <input
                  className="login-input" type="tel"
                  placeholder={tr('phone_placeholder') || '+998 XX XXX XX XX'}
                  value={phone}
                  onChange={e => { setPhone(e.target.value); setError('') }}
                  onKeyDown={e => e.key === 'Enter' && handleCheckPhone()}
                  autoFocus
                />
              </div>

              {error && (
                <div style={{ background:'#FEF2F2', color:'#DC2626', borderRadius:10, padding:'10px 14px', fontSize:13 }}>
                  ⚠️ {error}
                </div>
              )}

              <button className="btn-main" onClick={handleCheckPhone} disabled={loading}>
                {loading ? '⏳ Yuklanmoqda...' : tr('get_sms') || 'Davom etish'}
              </button>
            </div>
          )}

          {step === STEP.PASSWORD && (
            <div style={{ display:'flex', flexDirection:'column', gap:18 }}>
              <div>
                <label style={{ fontSize:13, fontWeight:700, color:'var(--text-mid)', display:'block', marginBottom:8 }}>
                  🔑 Parol
                </label>
                <div style={{ position:'relative' }}>
                  <input
                    className="login-input"
                    type={showPassword ? 'text' : 'password'}
                    placeholder="Parolni kiriting"
                    value={password}
                    onChange={e => { setPassword(e.target.value); setError('') }}
                    onKeyDown={e => e.key === 'Enter' && agreed && handleLogin()}
                    autoComplete="current-password"
                    style={{ paddingRight:48 }}
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(p => !p)}
                    style={{
                      position:'absolute', right:14, top:'50%',
                      transform:'translateY(-50%)',
                      background:'none', border:'none',
                      cursor:'pointer', fontSize:18,
                      color:'var(--text-light)', padding:0,
                    }}
                  >{showPassword ? '🙈' : '👁️'}</button>
                </div>
              </div>

              {/* Xato */}
              {error && (
                <div style={{ background:'#FEF2F2', color:'#DC2626', borderRadius:10, padding:'10px 14px', fontSize:13 }}>
                  ⚠️ {error}
                </div>
              )}

              {/* Kelishuv */}
              <div style={{ display:'flex', alignItems:'flex-start', gap:10 }}>
                <input type="checkbox" id="agree" checked={agreed}
                  onChange={e => setAgreed(e.target.checked)}
                  style={{ width:18, height:18, cursor:'pointer', accentColor:'var(--primary)', marginTop:2, flexShrink:0 }} />
                <label htmlFor="agree" style={{ fontSize:13, color:'var(--text-mid)', lineHeight:1.55, cursor:'pointer' }}>
                  <button className="link-btn" onClick={() => setLegalType('offer')}>{tr('offer')}</button>,{' '}
                  <button className="link-btn" onClick={() => setLegalType('privacy')}>{tr('privacy')}</button>{' '}
                  {tr('agree_to')}{' '}
                  <button className="link-btn" onClick={() => setLegalType('terms')}>{tr('terms')}</button>.
                </label>
              </div>

              <button className="btn-main" onClick={handleLogin} disabled={loading || !agreed}>
                {loading ? '⏳ Yuklanmoqda...' : tr('get_sms') || 'Davom etish'}
              </button>

              {/* Ro'yxatdan o'tish linki */}
              <div style={{ textAlign:'center', fontSize:13, color:'var(--text-light)' }}>
                Akkaunt yo'qmi?{' '}
                <button
                  className="link-btn"
                  onClick={() => window.open(`https://t.me/${window._botUsername || 'SmartDMTT_bot'}`, '_blank')}
                >
                  Botga murojaat qiling
                </button>
              </div>

              <div style={{ textAlign:'center' }}>
                <button className="link-btn" onClick={() => { setStep(STEP.PHONE); setPassword(''); setError('') }}>
                  ← {tr('change_number') || 'Orqaga'}
                </button>
              </div>
            </div>
          )}

          {step === STEP.REGISTER && (
            <div style={{ display:'flex', flexDirection:'column', alignItems:'center', gap:16, padding:'12px 0 8px' }}>
              <div style={{ fontSize:52 }}>🤖</div>
              <div style={{ fontWeight:800, fontSize:18, color:'var(--text)', textAlign:'center' }}>
                Ro'yxatdan o'tilmagan
              </div>
              <div style={{
                fontSize:14, color:'var(--text-mid)', lineHeight:1.7,
                textAlign:'center', background:'#F0F7FF',
                borderRadius:14, padding:'14px 18px'
              }}>
                Bu telefon raqam tizimda topilmadi.<br/>
                <b>WebApp da ro'yxatdan o'tib bo'lmaydi.</b><br/><br/>
                Iltimos, avval <b>Telegram bot</b>ga kiring
                va ro'yxatdan o'ting — u yerda
                parolingiz avtomatik beriladi.
              </div>
              <a
                href="https://t.me/bulungur_bogcha_bot"
                target="_blank"
                rel="noreferrer"
                className="btn-main"
                style={{ textDecoration:'none', textAlign:'center', width:'100%', boxSizing:'border-box' }}
              >
                ✈️ Telegram botga o'tish
              </a>
              <button
                className="link-btn"
                onClick={() => { setStep(STEP.PHONE); setError('') }}
              >
                ← Orqaga
              </button>
            </div>
          )}

          {/* ── OTP KIRITISH ──────────────────────────────────────────────── */}
          {step === STEP.OTP && (
            <div style={{ display:'flex', flexDirection:'column', gap:18 }}>

              <div style={{ textAlign:'center', padding:'8px 0' }}>
                <div style={{ fontSize:40 }}>📲</div>
                <div style={{ fontSize:14, color:'var(--text-mid)', marginTop:8, lineHeight:1.5 }}>
                  Telegram botga yuborilgan <b>6 raqamli</b> kodni kiriting
                </div>
              </div>

              <div>
                <label style={{ fontSize:13, fontWeight:700, color:'var(--text-mid)', display:'block', marginBottom:8 }}>
                  {tr('otp_label') || 'Tasdiqlash kodi'}
                </label>
                <input
                  className="otp-input"
                  type="number"
                  placeholder="• • • • • •"
                  value={otp}
                  maxLength={6}
                  onChange={e => { setOtp(e.target.value.slice(0, 6)); setError('') }}
                  onKeyDown={e => e.key === 'Enter' && handleVerifyOTP()}
                  autoFocus
                />
              </div>

              {error && (
                <div style={{ background:'#FEF2F2', color:'#DC2626', borderRadius:10, padding:'10px 14px', fontSize:13 }}>
                  ⚠️ {error}
                </div>
              )}

              <button className="btn-main" onClick={handleVerifyOTP} disabled={loading}>
                {loading ? '⏳ Tekshirilmoqda...' : tr('confirm_login') || 'Tasdiqlash'}
              </button>

              <div style={{ textAlign:'center' }}>
                <button className="link-btn" onClick={() => { setStep(STEP.PHONE); setOtp(''); setError('') }}>
                  ← {tr('change_number') || 'Orqaga'}
                </button>
              </div>
            </div>
          )}
        </div>

        {/* Telegram Card */}
        <div
          onClick={async () => {
            if (window.Telegram?.WebApp?.initData) {
              // WebApp ichida — initData bilan avtomatik login
              setLoading(true)
              setError('')
              try {
                const res = await fetch('/api/auth/telegram-login', {
                  method: 'POST',
                  headers: { 'Content-Type': 'application/json', 'ngrok-skip-browser-warning': 'true' },
                  body: JSON.stringify({ initData: window.Telegram.WebApp.initData })
                })
                const data = await res.json()
                if (res.ok) {
                  login(
                    { ...data.user, roles: data.roles, firstName: data.user.full_name?.split(' ')[0] || 'Foydalanuvchi' },
                    data.token
                  )
                } else {
                  setError(data.detail || 'Telegram orqali kirish xatosi')
                }
              } catch {
                setError('Tarmoq xatosi')
              } finally {
                setLoading(false)
              }
            } else {
              // Oddiy brauzerda — botni yangi tabda och
              window.open('https://t.me/bulungur_bogcha_bot', '_blank')
            }
          }}
          style={{
            background:'#fff', borderRadius:20, padding:'14px 18px',
            display:'flex', alignItems:'center', gap:14,
            boxShadow:'0 2px 16px rgba(10,50,80,0.08)',
            cursor:'pointer', border:'1.5px solid var(--border)',
          }}
        >
          <div style={{
            width:46, height:46, borderRadius:14, flexShrink:0,
            background:'linear-gradient(135deg, #2aabee, #229ed9)',
            display:'flex', alignItems:'center', justifyContent:'center', fontSize:22,
          }}>✈️</div>
          <div style={{ flex:1 }}>
            <div style={{ fontWeight:800, fontSize:15, color:'var(--text)' }}>
              {tr('telegram_login') || 'Telegram orqali kirish'}
            </div>
            <div style={{ fontSize:12, color:'var(--text-light)' }}>
              {tr('telegram_sub') || 'Telegram botni oching'}
            </div>
          </div>
          <div style={{ color:'var(--primary)', fontSize:22 }}>›</div>
        </div>

        <div style={{ textAlign:'center', padding:'20px 0 24px', color:'var(--text-light)', fontSize:12 }}>
          Smart MMTB © 2025 · Tuman MMTB
        </div>
      </div>

      {legalType && <LegalModal type={legalType} onClose={() => setLegalType(null)} />}
    </div>
  )
}
