import { useApp } from '../context/AppContext'

export default function SplashScreen() {
  const { tr } = useApp()
  return (
    <div style={{
      minHeight: '100dvh',
      background: 'linear-gradient(160deg, #083D34 0%, #0B5E50 40%, #0D8B6E 100%)',
      display: 'flex', flexDirection: 'column',
      alignItems: 'center', justifyContent: 'center',
      fontFamily: 'var(--font)',
      position: 'relative', overflow: 'hidden',
    }}>
      <style>{`
        @keyframes splashBg1 {
          0%,100% { transform: translate(0,0) scale(1); }
          50% { transform: translate(30px,-20px) scale(1.1); }
        }
        @keyframes splashBg2 {
          0%,100% { transform: translate(0,0) scale(1.1); }
          50% { transform: translate(-20px,30px) scale(1); }
        }
        @keyframes logoIn {
          0% { transform: scale(0.4) rotate(-15deg); opacity: 0; }
          65% { transform: scale(1.08) rotate(2deg); opacity: 1; }
          100% { transform: scale(1) rotate(0deg); opacity: 1; }
        }
        @keyframes textReveal {
          0% { opacity: 0; transform: translateY(14px); }
          100% { opacity: 1; transform: translateY(0); }
        }
        @keyframes dot1 { 0%,80%,100%{transform:scale(.5);opacity:.3} 40%{transform:scale(1);opacity:1} }
        @keyframes dot2 { 0%,80%,100%{transform:scale(.5);opacity:.3} 40%{transform:scale(1);opacity:1} }
        @keyframes dot3 { 0%,80%,100%{transform:scale(.5);opacity:.3} 40%{transform:scale(1);opacity:1} }
        .splash-logo { animation: logoIn 0.85s cubic-bezier(0.34,1.56,0.64,1) forwards; }
        .splash-t1 { animation: textReveal .55s ease forwards .5s; opacity:0; }
        .splash-t2 { animation: textReveal .55s ease forwards .7s; opacity:0; }
        .splash-d1 { animation: dot1 1.4s ease .9s infinite; }
        .splash-d2 { animation: dot2 1.4s ease 1.1s infinite; }
        .splash-d3 { animation: dot3 1.4s ease 1.3s infinite; }
        .blob1 { animation: splashBg1 8s ease infinite; }
        .blob2 { animation: splashBg2 10s ease infinite; }
      `}</style>

      {/* Fon bezaklari */}
      <div className="blob1" style={{
        position: 'absolute', width: 300, height: 300, borderRadius: '50%',
        background: 'rgba(255,255,255,0.04)', top: -100, right: -80,
      }} />
      <div className="blob2" style={{
        position: 'absolute', width: 200, height: 200, borderRadius: '50%',
        background: 'rgba(255,255,255,0.06)', bottom: -60, left: -40,
      }} />

      {/* Logo */}
      <div className="splash-logo" style={{
        width: 100, height: 100, borderRadius: 28,
        background: 'rgba(255,255,255,0.14)',
        backdropFilter: 'blur(16px)',
        border: '2px solid rgba(255,255,255,0.22)',
        display: 'flex', alignItems: 'center', justifyContent: 'center',
        marginBottom: 24, fontSize: 50,
        boxShadow: '0 16px 48px rgba(0,0,0,0.2)',
      }}>🏫</div>

      <div className="splash-t1" style={{
        color: '#fff', fontSize: 28, fontWeight: 900,
        letterSpacing: -0.5, marginBottom: 6,
      }}>Smart MMTB</div>
      <div className="splash-t2" style={{
        color: 'rgba(255,255,255,0.65)', fontSize: 14,
        marginBottom: 48, textAlign: 'center', padding: '0 32px',
      }}>{tr('app_subtitle')}</div>

      <div style={{ display: 'flex', gap: 10 }}>
        {['splash-d1','splash-d2','splash-d3'].map(cls => (
          <div key={cls} className={cls} style={{
            width: 10, height: 10, borderRadius: '50%',
            background: 'rgba(255,255,255,0.75)',
          }} />
        ))}
      </div>
    </div>
  )
}
