/**
 * SmartDMTT v4 — LoginScreen
 * 5 til, animatsiya, xato ko'rsatish
 */
import { useState } from 'react'
import { useApp } from '../context/AppContext'
import { LANG_OPTIONS } from '../hooks/useTranslation'
import translations from '../i18n/translations'

const API = '/api/auth/login'

const T = (lang, key) => translations[lang]?.[key] ?? translations['uz']?.[key] ?? key

export default function LoginScreen() {
  const { setToken, setUser, setLang, lang } = useApp()

  const [phone,    setPhone]   = useState('')
  const [password, setPassword] = useState('')
  const [loading,  setLoading]  = useState(false)
  const [error,    setError]    = useState(null)
  const [showPw,   setShowPw]   = useState(false)
  const [activeLang, setActiveLang] = useState(lang || 'uz')

  const changeLang = (l) => {
    setActiveLang(l)
    setLang(l)
  }

  const t = (key) => T(activeLang, key)

  const formatPhone = (val) => {
    let digits = val.replace(/\D/g, '')
    if (digits.startsWith('998')) digits = digits.slice(3)
    digits = digits.slice(0, 9)
    let out = '+998'
    if (digits.length > 0) out += ' ' + digits.slice(0, 2)
    if (digits.length > 2) out += ' ' + digits.slice(2, 5)
    if (digits.length > 5) out += ' ' + digits.slice(5, 7)
    if (digits.length > 7) out += ' ' + digits.slice(7, 9)
    return out
  }

  const rawPhone = () => {
    const digits = phone.replace(/\D/g, '')
    return digits.startsWith('998') ? '+' + digits : '+998' + digits
  }

  const handleLogin = async () => {
    setError(null)
    const ph = rawPhone()
    if (ph.length < 13) { setError(t('enter_phone')); return }
    if (!password)       { setError(t('enter_password')); return }

    setLoading(true)
    try {
      const r = await fetch(API, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'ngrok-skip-browser-warning': 'true' },
        body: JSON.stringify({ phone: ph, password }),
      })
      const d = await r.json()
      if (!r.ok) throw new Error(d.detail || t('wrong_creds'))
      setToken(d.access_token)
      setUser(d.user)
      if (d.user?.language) changeLang(d.user.language)
    } catch(e) {
      setError(e.message)
    }
    setLoading(false)
  }

  const S = {
    wrap: {
      minHeight: '100dvh', display: 'flex', flexDirection: 'column',
      alignItems: 'center', justifyContent: 'center',
      background: 'linear-gradient(160deg, #eef2ff 0%, #f8fafc 60%, #fdf4ff 100%)',
      padding: '24px 20px',
    },
    card: {
      width: '100%', maxWidth: 400,
      background: '#fff', borderRadius: 24,
      padding: '36px 28px', boxShadow: '0 8px 40px rgba(99,102,241,0.12)',
    },
    logo: {
      textAlign: 'center', marginBottom: 28,
    },
    langRow: {
      display: 'flex', gap: 6, flexWrap: 'wrap', justifyContent: 'center', marginBottom: 28,
    },
    langBtn: (active) => ({
      padding: '5px 12px', borderRadius: 20, border: 'none', cursor: 'pointer',
      fontSize: 12, fontWeight: active ? 700 : 400,
      background: active ? '#6366f1' : '#f1f5f9',
      color: active ? '#fff' : '#6b7280',
      transition: 'all 0.15s',
    }),
    label: { fontSize: 12, fontWeight: 600, color: '#6b7280', marginBottom: 6, display: 'block' },
    inputWrap: {
      position: 'relative', marginBottom: 14,
    },
    input: {
      width: '100%', padding: '13px 16px', borderRadius: 14,
      border: '1.5px solid #e5e7eb', fontSize: 15, outline: 'none',
      background: '#f8fafc', boxSizing: 'border-box',
      transition: 'border-color 0.2s',
    },
    eyeBtn: {
      position: 'absolute', right: 14, top: '50%', transform: 'translateY(-50%)',
      background: 'none', border: 'none', cursor: 'pointer', fontSize: 18,
    },
    error: {
      background: '#fee2e2', color: '#991b1b', borderRadius: 12,
      padding: '10px 14px', fontSize: 13, fontWeight: 600, marginBottom: 14,
    },
    btn: (loading) => ({
      width: '100%', padding: '14px', borderRadius: 14,
      background: loading ? '#a5b4fc' : '#6366f1',
      color: '#fff', border: 'none', cursor: loading ? 'not-allowed' : 'pointer',
      fontWeight: 800, fontSize: 16, letterSpacing: 0.3,
      transition: 'all 0.2s', boxShadow: '0 4px 14px rgba(99,102,241,0.3)',
    }),
    footer: {
      textAlign: 'center', marginTop: 20, fontSize: 12, color: '#9ca3af',
    },
  }

  return (
    <div style={S.wrap}>
      <div style={S.card}>
        {/* Logo */}
        <div style={S.logo}>
          <div style={{ fontSize: 52, marginBottom: 8 }}>🏫</div>
          <div style={{ fontSize: 22, fontWeight: 900, color: '#6366f1', letterSpacing: -0.5 }}>
            SmartDMTT
          </div>
          <div style={{ fontSize: 12, color: '#9ca3af', marginTop: 4 }}>
            Bulung'ur tuman MTT tizimi
          </div>
        </div>

        {/* Til tanlash */}
        <div style={S.langRow}>
          {LANG_OPTIONS.map(opt => (
            <button key={opt.value} style={S.langBtn(activeLang === opt.value)}
              onClick={() => changeLang(opt.value)}>
              {opt.label}
            </button>
          ))}
        </div>

        {/* Telefon */}
        <div>
          <label style={S.label}>{t('phone')}</label>
          <div style={S.inputWrap}>
            <input
              style={{ ...S.input, borderColor: error ? '#fca5a5' : '#e5e7eb' }}
              type="tel"
              placeholder="+998 90 123 45 67"
              value={phone}
              onChange={e => setPhone(formatPhone(e.target.value))}
              onKeyDown={e => e.key === 'Enter' && document.getElementById('pw-input').focus()}
              autoComplete="tel"
            />
          </div>
        </div>

        {/* Parol */}
        <div>
          <label style={S.label}>{t('password')}</label>
          <div style={S.inputWrap}>
            <input
              id="pw-input"
              style={{ ...S.input, paddingRight: 44, borderColor: error ? '#fca5a5' : '#e5e7eb' }}
              type={showPw ? 'text' : 'password'}
              placeholder="••••••••"
              value={password}
              onChange={e => setPassword(e.target.value)}
              onKeyDown={e => e.key === 'Enter' && handleLogin()}
              autoComplete="current-password"
            />
            <button style={S.eyeBtn} onClick={() => setShowPw(v => !v)} tabIndex={-1}>
              {showPw ? '🙈' : '👁️'}
            </button>
          </div>
        </div>

        {/* Xato */}
        {error && <div style={S.error}>⚠️ {error}</div>}

        {/* Kirish tugmasi */}
        <button style={S.btn(loading)} onClick={handleLogin} disabled={loading}>
          {loading ? '⏳ ' + t('loading') : '🚀 ' + t('login')}
        </button>

        <div style={S.footer}>
          SmartDMTT v4 · © 2025 Bulung'ur tuman MTT
        </div>
      </div>
    </div>
  )
}
