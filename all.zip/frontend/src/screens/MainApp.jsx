/**
 * SmartDMTT v4 — MainApp (to'liq)
 * Barcha rollar, barcha tablar, i18n, RoleSwitcher
 */
import { useState } from 'react'
import { useApp } from '../context/AppContext'
import { useTranslation } from '../hooks/useTranslation'

import HomeTab       from './tabs/HomeTab'
import TeacherTab    from './tabs/TeacherTab'
import MainMapTab        from './tabs/MainMapTab'
import AdminTab      from './tabs/AdminTab'
import ChildrenTab   from './tabs/ChildrenTab'
import ClubsTab      from './tabs/ClubsTab'
import PaymentTab    from './tabs/PaymentTab'
import ProfileTab    from './tabs/ProfileTab'
import BoshliqTab    from './tabs/BoshliqTab'
import IqtisodchiTab from './tabs/IqtisodchiTab'
import RoleSwitcher  from '../components/RoleSwitcher'

const CSS = `
:root {
  --primary:     #6366f1;
  --primary-50:  #eef2ff;
  --border:      #e5e7eb;
  --text:        #111827;
  --text-mid:    #4b5563;
  --text-light:  #9ca3af;
  --bg:          #f8fafc;
}
* { box-sizing: border-box; margin: 0; padding: 0; }
body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
       background: var(--bg); color: var(--text); }
`

// ── Nav konfiguratsiyasi ──────────────────────────────────
const NAV_BY_ROLE = {
  parent: [
    { id: 'home',     icon: '🏠', labelKey: 'nav_home' },
    { id: 'children', icon: '👶', labelKey: 'nav_children' },
    { id: 'clubs',    icon: '🎯', labelKey: 'nav_clubs' },
    { id: 'payment',  icon: '💰', labelKey: 'payment' },
    { id: 'map',      icon: '🗺️', labelKey: 'nav_map' },
    { id: 'profile',  icon: '👤', labelKey: 'nav_profile' },
  ],
  teacher: [
    { id: 'home',     icon: '🏠', labelKey: 'nav_home' },
    { id: 'teacher',  icon: '📅', labelKey: 'nav_attendance' },
    { id: 'clubs',    icon: '🎯', labelKey: 'nav_clubs' },
    { id: 'profile',  icon: '👤', labelKey: 'nav_profile' },
  ],
  togarak_rahbari: [
    { id: 'home',     icon: '🏠', labelKey: 'nav_home' },
    { id: 'teacher',  icon: '📅', labelKey: 'nav_attendance' },
    { id: 'clubs',    icon: '🎯', labelKey: 'nav_clubs' },
    { id: 'profile',  icon: '👤', labelKey: 'nav_profile' },
  ],
  director: [
    { id: 'home',     icon: '🏠', labelKey: 'nav_home' },
    { id: 'clubs',    icon: '🎯', labelKey: 'nav_clubs' },
    { id: 'map',      icon: '🗺️', labelKey: 'nav_map' },
    { id: 'profile',  icon: '👤', labelKey: 'nav_profile' },
  ],
  iqtisodchi: [
    { id: 'home',     icon: '🏠', labelKey: 'nav_home' },
    { id: 'admin',    icon: '📊', labelKey: 'stats' },
    { id: 'profile',  icon: '👤', labelKey: 'nav_profile' },
  ],
  boshliq: [
    { id: 'home',     icon: '🏠', labelKey: 'nav_home' },
    { id: 'admin',    icon: '🛠️', labelKey: 'admin' },
    { id: 'map',      icon: '🗺️', labelKey: 'nav_map' },
    { id: 'profile',  icon: '👤', labelKey: 'nav_profile' },
  ],
  mmtb_boshligi: [
    { id: 'home',     icon: '🏠', labelKey: 'nav_home' },
    { id: 'admin',    icon: '🛠️', labelKey: 'admin' },
    { id: 'map',      icon: '🗺️', labelKey: 'nav_map' },
    { id: 'profile',  icon: '👤', labelKey: 'nav_profile' },
  ],
  admin: [
    { id: 'home',     icon: '🏠', labelKey: 'nav_home' },
    { id: 'admin',    icon: '🛠️', labelKey: 'admin' },
    { id: 'map',      icon: '🗺️', labelKey: 'nav_map' },
    { id: 'profile',  icon: '👤', labelKey: 'nav_profile' },
  ],
}

const DEFAULT_NAV = [
  { id: 'home',    icon: '🏠', labelKey: 'nav_home' },
  { id: 'clubs',   icon: '🎯', labelKey: 'nav_clubs' },
  { id: 'map',     icon: '🗺️', labelKey: 'nav_map' },
  { id: 'profile', icon: '👤', labelKey: 'nav_profile' },
]

function TabContent({ tabId }) {
  switch(tabId) {
    case 'home':     return <HomeTab />
    case 'teacher':  return <TeacherTab />
    case 'admin':    return <AdminTab />
    case 'children': return <ChildrenTab />
    case 'clubs':    return <ClubsTab />
    case 'payment':  return <PaymentTab />
    case 'map':      return <MainMapTab />
    case 'profile':  return <ProfileTab />
    default:         return <HomeTab />
  }
}

export default function MainApp() {
  const { user } = useApp()
  const { t }    = useTranslation()
  const role     = user?.role || 'guest'
  const navItems = NAV_BY_ROLE[role] || DEFAULT_NAV

  const [activeTab, setActiveTab] = useState(navItems[0]?.id || 'home')

  // Agar aktiv tab yangi rolda yo'q bo'lsa, birinchiga qaytish
  const validTab = navItems.find(n => n.id === activeTab) ? activeTab : navItems[0]?.id

  return (
    <>
      <style>{CSS}</style>
      <div style={{ minHeight: '100dvh', display: 'flex', flexDirection: 'column' }}>

        {/* Content */}
        <main style={{ flex: 1, overflowY: 'auto', paddingBottom: 70 }}>
          <TabContent tabId={validTab} />
        </main>

        {/* Bottom Nav */}
        <nav style={{
          position: 'fixed', bottom: 0, left: 0, right: 0,
          background: '#fff', borderTop: '1px solid var(--border)',
          display: 'flex', justifyContent: 'space-around',
          padding: '8px 0 max(8px, env(safe-area-inset-bottom))',
          boxShadow: '0 -4px 20px rgba(0,0,0,0.06)',
          zIndex: 100,
        }}>
          {navItems.map(item => {
            const active = validTab === item.id
            return (
              <button key={item.id} onClick={() => setActiveTab(item.id)} style={{
                display: 'flex', flexDirection: 'column', alignItems: 'center',
                gap: 2, padding: '4px 12px', border: 'none', background: 'none',
                cursor: 'pointer', minWidth: 52,
              }}>
                <span style={{
                  fontSize: 22,
                  filter: active ? 'none' : 'grayscale(80%) opacity(0.5)',
                  transition: 'all 0.2s',
                  transform: active ? 'scale(1.1)' : 'scale(1)',
                }}>{item.icon}</span>
                <span style={{
                  fontSize: 10, fontWeight: active ? 700 : 400,
                  color: active ? 'var(--primary)' : 'var(--text-light)',
                  transition: 'color 0.2s',
                }}>{t(item.labelKey) || item.labelKey}</span>
                {active && (
                  <div style={{ width: 4, height: 4, borderRadius: '50%', background: 'var(--primary)' }} />
                )}
              </button>
            )
          })}
        </nav>

        {/* Admin Rol almashtirish (faqat admin/boshliq/mmtb) */}
        {['admin','boshliq','mmtb_boshligi'].includes(role) && <RoleSwitcher />}
      </div>
    </>
  )
}
