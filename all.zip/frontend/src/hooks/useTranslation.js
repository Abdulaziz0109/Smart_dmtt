/**
 * SmartDMTT v4 — useTranslation hook
 * AppContext dan lang olib, translations.js dan matn qaytaradi
 *
 * Ishlatish:
 *   const { t, lang, setLang } = useTranslation()
 *   <p>{t('loading')}</p>
 */
import { useCallback } from 'react'
import { useApp } from '../context/AppContext'
import translations from '../i18n/translations'

const SUPPORTED = ['uz', 'kril', 'ru', 'en', 'turk']
const DEFAULT   = 'uz'

export function useTranslation() {
  const { lang, setLang } = useApp()
  const activeLang = SUPPORTED.includes(lang) ? lang : DEFAULT

  const t = useCallback((key, fallback = '') => {
    const dict = translations[activeLang] || translations[DEFAULT]
    return dict?.[key] ?? translations[DEFAULT]?.[key] ?? fallback ?? key
  }, [activeLang])

  return { t, lang: activeLang, setLang }
}

export const LANG_OPTIONS = [
  { value: 'uz',   label: "🇺🇿 O'zbek (lotin)" },
  { value: 'kril', label: "🇺🇿 Ўзбек (кирил)"  },
  { value: 'ru',   label: "🇷🇺 Русский"         },
  { value: 'en',   label: "🇬🇧 English"          },
  { value: 'turk', label: "🇹🇷 Türkçe"           },
]
